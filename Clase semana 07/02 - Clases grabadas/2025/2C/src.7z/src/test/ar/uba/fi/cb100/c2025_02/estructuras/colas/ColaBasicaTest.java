package test.ar.uba.fi.cb100.c2025_02.estructuras.colas;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.cola.ColaBasica;

class ColaBasicaTest {

    private ColaBasica<Integer> cola;

    @BeforeEach
    void setUp() {
        cola = new ColaBasica<>();
    }

    @Test
    void testColaNuevaEstaVacia() {
        assertTrue(cola.estaVacia());
        assertEquals(0, cola.contarElementos());
        assertNull(cola.obtener());
        assertNull(cola.desacolar());
    }

    @Test
    void testAcolarUnElemento() {
        cola.acolar(10);
        assertFalse(cola.estaVacia());
        assertEquals(1, cola.contarElementos());
        assertEquals(10, cola.obtener());
    }

    @Test
    void testAcolarVariosElementosMantieneOrden() {
        cola.acolar(1);
        cola.acolar(2);
        cola.acolar(3);

        assertEquals(3, cola.contarElementos());
        assertEquals(1, cola.obtener()); // frente
        assertEquals(1, cola.desacolar());
        assertEquals(2, cola.desacolar());
        assertEquals(3, cola.desacolar());
        assertTrue(cola.estaVacia());
    }

    @Test
    void testDesacolarEnColaVaciaDevuelveNull() {
        assertNull(cola.desacolar());
    }

    @Test
    void testObtenerNoElimina() {
        cola.acolar(5);
        cola.acolar(6);
        assertEquals(5, cola.obtener());
        assertEquals(2, cola.contarElementos());
    }

    @Test
    void testAcolarLista() {
        cola.acolarAll(Arrays.asList(1, 2, 3));
        assertEquals(3, cola.contarElementos());
        assertEquals(1, cola.desacolar());
        assertEquals(2, cola.desacolar());
        assertEquals(3, cola.desacolar());
        assertTrue(cola.estaVacia());
    }

    @Test
    void testAcolarListaVaciaNoCambiaCola() {
        cola.acolarAll(Collections.emptyList());
        assertTrue(cola.estaVacia());
    }

    @Test
    void testAcolarYAcolarAllJuntos() {
        cola.acolar(10);
        cola.acolarAll(Arrays.asList(20, 30));
        assertEquals(3, cola.contarElementos());
        assertEquals(10, cola.desacolar());
        assertEquals(20, cola.desacolar());
        assertEquals(30, cola.desacolar());
    }

    @Test
    void testDesacolarHastaVaciaReseteaUltimo() {
        cola.acolar(1);
        cola.acolar(2);
        cola.desacolar();
        cola.desacolar(); // ahora debería quedar vacía
        assertTrue(cola.estaVacia());
        assertNull(cola.obtener());
        assertNull(cola.desacolar());
    }
} 