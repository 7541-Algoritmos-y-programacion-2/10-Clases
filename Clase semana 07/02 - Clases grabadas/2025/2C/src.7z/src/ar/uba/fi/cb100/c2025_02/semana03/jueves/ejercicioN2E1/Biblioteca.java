package ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1;

public class Biblioteca {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Libro[] libros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Biblioteca(int cantidadMaximaDeLibros) {
		this.libros = new Libro[cantidadMaximaDeLibros];
		for(int i = 0; i < this.libros.length; i++) {
			this.libros[i] = null;
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public void agregar(Libro libro) {
		//validar: null, duplicado
		this.libros[getCantidadDeLibros()] = libro;
	}
	
	public void quitar(Libro libro) {
		
	}
	
	public void prestar(Libro libro) {
		
	}
	
	public void devolver(Libro libro) {
		
	}
	
	public Libro buscar(String texto) {
		for(int i = 0; i < this.getCantidadDeLibros(); i++) {
			if (this.libros[i].contiene(texto)) {
				return this.libros[i];
			}
		}
		throw new RuntimeException("No se encuentra el libro");
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	public int getCantidadDeLibros() {
		for(int i = 0; i < this.libros.length; i++) {
			if (this.libros[i] == null) {
				return i;
			}
		}
		return this.libros.length;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
