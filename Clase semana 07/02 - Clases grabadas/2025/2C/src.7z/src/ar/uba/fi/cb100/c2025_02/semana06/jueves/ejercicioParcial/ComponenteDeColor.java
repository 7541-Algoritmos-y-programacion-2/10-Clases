package ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial;

public enum ComponenteDeColor {
	Rojo,
	Verde,
	Azul
}
