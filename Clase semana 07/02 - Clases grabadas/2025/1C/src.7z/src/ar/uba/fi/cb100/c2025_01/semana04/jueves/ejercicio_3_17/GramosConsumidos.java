package ar.uba.fi.cb100.c2025_01.semana04.jueves.ejercicio_3_17;

public class GramosConsumidos {

	private int gramos;

	public GramosConsumidos() {

		this.gramos = 0;

	}

	public int getGramos() {

		return this.gramos;

	}

	public void setGramos(int nroGramos) {

		this.gramos = nroGramos;

	}

}