package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import ar.uba.fi.cb100.c2025_01.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.Eslabon;

public class PrincipalClase13 {

	public static void main(String[] args) {
		Vehiculo vehiculo = new Auto();		
		vehiculo.arrancar();
		vehiculo.detener();
		
		Auto auto = new Auto();
		auto.abrirPuerta();
		
		//Ahora con moto
		vehiculo = new Moto();		
		vehiculo.arrancar();
		vehiculo.detener();
		((Moto) vehiculo).acelerar();
		if (vehiculo instanceof Moto) {
			Moto moto = (Moto) vehiculo;
			moto.acelerar();
		}
				
		Moto moto = new Moto();
		moto.arrancar();
		moto.detener();
		moto.acelerar();
		//moto.abrirPuerta();
		
		
		List<String> lista = new ListaSimplementeEnlazada<String>();
		lista.add("Hola");
		lista.add("Mundo");
		
		for(int i = 0; i < lista.size(); i++) {
			System.out.println( lista.get(i));
		}
		
		for(String texto: lista) {
			System.out.println(texto);
			//lista.add(texto) no esta pensado para este caso
		}

		Iterator<String> iterador = lista.iterator();
		while (iterador.hasNext()) {
			String texto = iterador.next();
			System.out.println(texto);
			//iterador.remove();
		}
		
		ListIterator<String> listIterator = lista.listIterator();
		while (listIterator.hasNext()) {
			String texto = listIterator.next();
			System.out.println(texto);
			listIterator.add("Texto 2");
		}
		while (listIterator.hasPrevious()) {
			String texto = listIterator.next();
			System.out.println(texto);
		}
		
		
		lista.stream()
				.forEach( texto -> System.out.println(texto));
		
		if (lista instanceof ListaSimplementeEnlazada<String>) {
			ListaSimplementeEnlazada<String> listaSimplementeEnlazada = (ListaSimplementeEnlazada<String>) lista;
			listaSimplementeEnlazada.iniciarCursor();
			while (listaSimplementeEnlazada.avanzarCursor()) {
				String texto = listaSimplementeEnlazada.obtenerCursor();
				System.out.println(texto);
			}
		}
	}
	
	
	public static void contiene() {
		ListaSimplementeEnlazada<String> lista = new ListaSimplementeEnlazada<String>();
		lista.add("Hola");
		lista.add("Mundo");
		lista.getClass();
		if (lista.contains("Hola")) {
			System.out.println("Si contiene");
		}
		if (lista.contiene("Hola")) {
			System.out.println("Si contiene");
		}
		
		List<Eslabon> lista2 = new ListaSimplementeEnlazada<Eslabon>();
		Eslabon eslabon = new Eslabon(10, 15);
		lista2.add( eslabon );
		
//		if (lista2.contiene(new Eslabon(10, 15))) {
//			System.out.println("Si contiene");
//		}
		if (lista2.contains(eslabon)) {
			System.out.println("Si contiene");
		}
		
	}
	
	public static void contieneParcial() {
		ListaSimplementeEnlazada<String> lista = new ListaSimplementeEnlazada<String>();
		lista.add("Hola");
		lista.add("Mundo");
		
		if (lista.contains("Hola")) {
			int i = lista.indexOf("Hola");
			
		}
		
		if (lista.contains("Hol")) {
			int i = lista.indexOf("Hol");
		}
			
		//Opcion 1: hacer el metodo (LA LISTA CONOCE EL TIPO DE DATO Y LA BUSQUEDA PARCIAL)
		lista.contiene("hol", new Contenible<String>() {
			@Override
			public boolean contiene(String dato, Object valor) {
				String texto = (String) dato;
				return texto.toLowerCase().contains(valor.toString().toLowerCase());
			}
		});
		
		lista.contiene("hol", new ContieneTexto());
		
		//Opcion 2: usando stream (LA LISTA NO CONOCE EL TIPO DE DATO)
		//Opcion 3: recorrido (LA LISTA NO CONOCE EL TIPO DE DATO)
		
		String palabraABuscar = "hol";
		for(String texto: lista) {
			if (texto.toLowerCase().contains(palabraABuscar.toLowerCase())) {
				System.out.println("Se encontro la palabra");
			}
		}
		
		if (lista.stream()
					.anyMatch(texto -> texto.toLowerCase().contains(palabraABuscar.toLowerCase()))) {
			System.out.println("Se encontro la palabra");
		}
		
	}
}
