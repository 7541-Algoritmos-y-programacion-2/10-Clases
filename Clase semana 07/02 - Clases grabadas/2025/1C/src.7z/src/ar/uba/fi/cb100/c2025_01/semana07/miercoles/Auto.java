package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

public class Auto implements Vehiculo {

	@Override
	public void arrancar() {
		System.out.println("El auto arranca");
	}

	@Override
	public void detener() {
		System.out.println("El auto se detiene");		
	}

	@Override
	public void acelerar() {
		System.out.println("El auto acelera");
	}
	
	public void abrirPuerta() {
		System.out.println("El auto abre la puerta");
	}
	
}
