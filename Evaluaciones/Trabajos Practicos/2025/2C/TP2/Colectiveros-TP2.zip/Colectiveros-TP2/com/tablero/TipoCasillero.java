package com.tablero;

/**
 * Define los tipos de terreno posibles para un Casillero.
 */
public enum TipoCasillero {
    VACIO,
    ROCA,
    AGUA,
    RAMPA
}
