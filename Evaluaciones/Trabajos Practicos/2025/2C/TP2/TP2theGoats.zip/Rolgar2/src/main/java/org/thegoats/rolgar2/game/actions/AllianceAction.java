package org.thegoats.rolgar2.game.actions;
import java.util.Arrays;
import java.util.List;

public enum AllianceAction {
    CrearAlianza,
    AgregarAliado,
    Abandonar,
    DarCarta,
    Volver;

    public static List<AllianceAction> getNotAlliedAllianceActions(){
        return Arrays.asList(CrearAlianza, Volver);
    }
    public static List<AllianceAction> getAlliedAllianceActions(){
        return Arrays.asList(AgregarAliado, Abandonar, DarCarta, Volver);
    }
}
