package org.thegoats.rolgar2.game;

import org.thegoats.rolgar2.game.config.*;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.logging.Logger;
import org.thegoats.rolgar2.util.io.interaction.ConsoleSelection;
import org.thegoats.rolgar2.util.structures.sets.TheGoatsSet;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class GameBuilder {
    private Logger logger;
    private Random random;
    private Set<Player> players;
    private DifficultyConfig difficultyConfig;
    private MapConfig mapConfig;

    public GameBuilder() {}

    /**
     * Crea una nueva instancia de GameBuilder
     * @return Devuelve la instancia creada
     */
    public static GameBuilder createBuilder() {
        return new GameBuilder();
    }

    /**
     * Crea una nueva instancia de Game
     * @return Devuelve una instancia configurada de Game
     */
    public Game build() {
        Assert.notNull(players, "players");
        Assert.notNull(logger, "logger");
        Assert.notNull(difficultyConfig, "difficultyConfig");
        Assert.notNull(mapConfig, "mapConfig");

        if (random == null) {
            random = new Random();
        }

        return new Game(logger, random, players, new GameConfig(difficultyConfig, mapConfig));
    }

    /**
     * Establece el logger que usara Game para registrar eventos
     * @param logger no puede ser nulo
     * @return Devuelve esta misma instancia de GameBuilder
     */
    public GameBuilder setLogger(Logger logger) {
        Assert.notNull(logger, "logger");
        this.logger = logger;
        return this;
    }

    public GameBuilder setRandom(Random random) {
        Assert.notNull(random, "random");
        this.random = random;
        return this;
    }

    public GameBuilder setDifficultyConfig(DifficultyConfig difficultyConfig) {
        Assert.notNull(difficultyConfig, "difficultyConfig");
        this.difficultyConfig = difficultyConfig;
        return this;
    }



    /**
     * Permite al usuario seleccionar una dificultad desde un directorio que contiene las configuraciones válidas de dificultad
     * @param difficultiesDirectoryPath ruta al directorio que contiene los archivos de dificultad
     * @return Devuelve esta misma instancia de GameBuilder
     * @throws RuntimeException si ocurre un error al cargar las dificultades o si el usuario no selecciona ninguna
     */
    public GameBuilder selectDifficulty(String difficultiesDirectoryPath) {
        Set<DifficultyConfig> difficulties = null;
        try {
            difficulties = DifficultyLoader.loadDifficulties(Path.of(difficultiesDirectoryPath));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        logger.logInfo("Difficulties: " + difficulties);

        difficultyConfig = new ConsoleSelection<DifficultyConfig>()
                .maxTries(10)
                .selectionHeader("Seleccione la dificultad: ")
                .selectionRetryMessage("Dificultad invalida, vuelva a intentarlo.")
                .selectionFailMessage("Demasiados intentos para seleccionar la dificultad.")
                .addAllOptions(difficulties.stream().toList())
                .select().orElseThrow(() -> new RuntimeException("No se pudo seleccionar la dificultad."));

        logger.logInfo("Selected difficulty: " + difficultyConfig);

        return this;
    }

    public GameBuilder setMapConfig(MapConfig mapConfig) {
        Assert.notNull(mapConfig, "mapConfig");
        this.mapConfig = mapConfig;
        return this;
    }

    /**
     * Permite al usuario seleccionar un mapa desde un directorio que contiene las configuraciones válidas de mapas
     * @param mapsDirectoryPath ruta al directorio que contiene los archivos de mapa
     * @return Devuelve esta misma instancia de GameBuilder
     * @throws RuntimeException si ocurre un error al cargar los mapas o si el usuario no elige ninguno
     */
    public GameBuilder selectMap(String mapsDirectoryPath) {
        Set<MapConfig> maps = null;
        try {
            maps = MapLoader.loadMaps(mapsDirectoryPath);
        } catch (IOException | URISyntaxException e) {
            throw new RuntimeException(e);
        }

        logger.logInfo("Maps: " + maps);

        mapConfig = new ConsoleSelection<MapConfig>()
                .maxTries(10)
                .selectionHeader("Seleccione el mapa: ")
                .selectionRetryMessage("Mapa invalido, vuelva a intentarlo.")
                .selectionFailMessage("Demasiados intentos para seleccionar el mapa.")
                .addAllOptions(maps.stream().toList().reversed())
                .select().orElseThrow(() -> new RuntimeException("No se pudo seleccionar el mapa."));

        logger.logInfo("Selected map: " + mapConfig);

        return this;
    }



    public GameBuilder setPlayers(Set<Player> players) {
        Assert.notNull(players, "players");
        Assert.isTrue(!players.isEmpty(), "players no debe estar vacio.");
        this.players = players;
        return this;
    }

    /**
     * Inicializa la cantidad de jugadores que ingrese el usuario
     * @return Devuelve esta misma instancia de GameBuilder
     */
    public GameBuilder initPlayers() {
        Assert.notNull(mapConfig, "mapConfig");
        Scanner scanner = new Scanner(System.in);

        Integer playerCount;
        do{
            try{
                System.out.println("Cantidad de jugadores:");
                playerCount = Integer.parseInt(scanner.nextLine());
                Assert.inRange(playerCount, 2, mapConfig.getSpawnableCellsCount()/5,
                        "cantidad de jugadores");
            }catch (Exception e){
                System.out.println("Ingreso inválido. (Solo enteros)");
                playerCount = null;
            }
        }while(playerCount == null || playerCount < 2 );

        players = new TheGoatsSet<>();
        for (int i = 0; i < playerCount; i++) {

            System.out.print("Nombre del jugador " + (i + 1) + ": ");
            var playerName = scanner.nextLine();
            boolean hasFinished = false;
            while (!hasFinished) {
                try{
                    Assert.validName(playerName);
                    hasFinished = true;
                }catch (Exception e){
                    System.out.println(e.getMessage());
                    System.out.print("Nombre del jugador " + (i + 1) + ": ");
                    playerName = scanner.nextLine();
                }
            }

            logger.logDebug(playerName);
            players.add(new Player(playerName));
        }

        return this;
    }
}