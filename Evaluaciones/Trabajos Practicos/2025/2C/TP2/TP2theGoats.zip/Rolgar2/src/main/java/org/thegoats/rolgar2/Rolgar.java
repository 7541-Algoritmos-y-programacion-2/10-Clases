package org.thegoats.rolgar2;

import org.thegoats.rolgar2.game.GameBuilder;
import org.thegoats.rolgar2.util.io.interaction.ConsoleLogger;
import org.thegoats.rolgar2.util.io.logging.LogLevel;
import org.thegoats.rolgar2.util.io.interaction.ConsoleSelection;

import java.util.Random;

import static org.thegoats.rolgar2.util.io.bitmaps.AnsiColor.*;


public class Rolgar {
    public static void main(String[] args) {
        var logger = new ConsoleLogger(LogLevel.DEBUG);

        logger.logInfo("Iniciando Rolgar 2.");
        logger.logInfo(YELLOW+"Rolgar 2 es un juego multijugador donde los jugadores\n" +
                "controlan cada uno a un personaje que se desplaza por un mapa\n" +
                "matricial de distintos niveles, enfrentando a enemigos y a otros\n" +
                "jugadores, formando alianzas, y recogiendo y utilizando cartas con\n" +
                "distintos efectos/utilidades para facilitar su objetivo de derrotar\n" +
                "a todos los enemigos antes de quedarse sin vida."+RESET);

        var playAgainSelection = new ConsoleSelection<Boolean>()
                .addOption("Si", true)
                .addOption("No", false)
                .maxTries(3)
                .selectionPrompt("¿Desea jugar de nuevo?")
                .selectionRetryMessage("Opcion invalida. Intentelo nuevamente.");

        boolean playAgain = true;
        while (playAgain) {
            GameBuilder.createBuilder()
                    // configura el juego
                    .setLogger(logger)
                    .setRandom(new Random())
                    .selectDifficulty("difficulties")
                    .selectMap("maps")
                    .initPlayers()
                    // construye el juego
                    .build()
                    // ejecuta el juego
                    .run();

            playAgain = playAgainSelection.select().orElse(false);
        }

        System.out.println("El juego finalizo!");
    }
}
