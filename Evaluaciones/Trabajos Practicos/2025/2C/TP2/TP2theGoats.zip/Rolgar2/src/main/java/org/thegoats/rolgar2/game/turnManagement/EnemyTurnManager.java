package org.thegoats.rolgar2.game.turnManagement;
import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.util.Assert;

public class EnemyTurnManager extends GameCharacterTurnManager {

    /**
     *  Crea un administrador de turnos para un personaje enemigo.
     * @param gameCharacter personaje del juego cuyo turno se va a administrar. Debe representar a un enemigo.
     * Se valida que el personaje NO sea un personaje de jugador.
     */
    public EnemyTurnManager(GameCharacter gameCharacter) {
        super(gameCharacter);
        Assert.isTrue(!gameCharacter.isPlayerCharacter(), "gameCharacter no debe ser un personaje de un jugador.");
    }

    /**
     * Ejecuta el turno completo del enemigo.
     */
    @Override
    public void doTurn() {
        // busca un personaje de jugador en una celda vecina, si lo encuentra lo ataca
        if(gameCharacter.getCharacterData().isAlive()){
            gameCharacter.getGame().logger.logInfo(gameCharacter.getActor().getName() + " realiza su turno");
            gameCharacter.getWorldCell().getNeighborsOnSameLayer().stream()
                    .filter(cell -> cell.getCharacter().isPresent() && cell.getCharacter().get().isPlayerCharacter())
                    .findAny()
                    .ifPresent(worldCell -> {
                        gameCharacter.attack(worldCell.getCharacter().get());
                    });
        }
    }
}