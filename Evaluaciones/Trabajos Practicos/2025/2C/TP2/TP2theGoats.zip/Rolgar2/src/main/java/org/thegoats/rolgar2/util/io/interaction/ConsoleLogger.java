package org.thegoats.rolgar2.util.io.interaction;

import org.thegoats.rolgar2.util.io.logging.LogLevel;
import org.thegoats.rolgar2.util.io.logging.Logger;

/**
 * Logger que imprime en la consola
 */
public final class ConsoleLogger extends Logger {

    public ConsoleLogger(LogLevel logLevel) {
        super(logLevel);
    }

    @Override
    public void logInfo(String message) {
        System.out.println(message);
    }

    @Override
    public void logError(String message) {
        System.err.println("Error: " + message);
    }

    @Override
    public void logWarning(String message) {
        System.out.println("Advertencia: " + message);
    }

    @Override
    public void logDebug(String message) {
        System.out.println("Debug: " + message);
    }
}
