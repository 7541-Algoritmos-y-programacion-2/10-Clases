package org.thegoats.rolgar2.util;

import java.net.URL;

import static org.thegoats.rolgar2.util.io.bitmaps.AnsiColor.*;

public class Assert {
    /**
     * @param o No null
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si 'o' es null
     */
    public static void notNull(Object o, String name) {
        if (o == null) {
            throw new RuntimeException(RED + name + " no puede ser null" + RESET);
        }
    }

    /**
     * @param value No negativo
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si 'n' es negativo
     */
    public static void nonNegative(int value, String name) {
        if (value < 0) {
            throw new RuntimeException(RED + name + " no puede ser negativo. Se ingreso "+ name + RESET);
        }
    }

    /**
     * @param value Positivo
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si 'n' no es positivo
     */
    public static void positive(int value, String name) {
        if (value <= 0) {
            throw new RuntimeException(RED + name + " debe ser positivo. Se ingreso "+ value + RESET);
        }
    }

    /**
     * @param value Positivo
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si 'n' no es positivo
     */
    public static void positive(double value, String name) {
        if (value <= 0) {
            throw new RuntimeException(RED + name + " debe ser positivo. Se ingreso "+ value + RESET);
        }
    }

    /**
     * @param value no cero
     * @param name nombre de la variable para mostrar en la excepcion
     */
    public static void nonZero(int value, String name){
        if(value == 0){
            throw new RuntimeException(name + " no puede ser cero.");
        }
    }

    /**
     * @param value Debe ser un valor en el rango de 'a' a 'b'
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si n no es un valor entre 'a' a 'b'
     */
    public static void inRange(int value, int min, int max, String name) {
        int floor = Math.min(min, max);
        int roof = Math.max(min, max);
        if (value < floor || value > roof) {
            throw new RuntimeException(RED + name + " debe estar entre " + min + " y " + max + " se ingreso "+ value + RESET);
        }
    }

    /**
     * El nombre se valida con la regex ^[a-zA-Z0-9._-]{3,20}$
     * @param name Nombre valido
     * @throws RuntimeException Si 'nombre' es invalido
     */
    public static void validName(String name) {
        if (name == null || !name.matches("^[a-zA-Z0-9._-]{3,20}$")) {
            throw new RuntimeException(RED + "El nombre sólo debe contener de 3 a 20 caracteres alfanuméricos, '.' , '-' y '_'. Se ingreso "+ name + RESET);
        }
    }

    /**
     * @param string No null, No vacío
     * @param name Nombre del Objeto a chequear
     * @throws RuntimeException Si 'string' es null o vacío
     */
    public static void notNullOrEmpty(String string, String name) {
        if (string == null || string.isEmpty()) {
            throw new RuntimeException(RED + name + " no debe ser null ni vacío." +RESET);
        }
    }

    /**
     * @param condition debe ser verdadera
     * @param message mensaje a mostrar en la excepcion
     * @throws RuntimeException si la condicion era false
     */
    public static void isTrue(boolean condition, String message){
        if(!condition){
            throw new RuntimeException(RED + message + RESET);
        }
    }

    /**
     * @param condition debe ser false
     * @param message mensaje a mostrar en la excepcion
     */
    public static void isFalse(boolean condition, String message){
        isTrue(!condition, message);
    }

    /**
     * @param path ruta relativa del archivo
     * @param name nombre del archivo
     */
    public static void fileExists(String path, String name) {
        ClassLoader cl = Assert.class.getClassLoader();

        // Busca el recurso dentro del classpath
        URL url = cl.getResource(path);

        if (url == null) {
            throw new RuntimeException(RED + "No existe el archivo "+ name + RESET);
        }
    }
}