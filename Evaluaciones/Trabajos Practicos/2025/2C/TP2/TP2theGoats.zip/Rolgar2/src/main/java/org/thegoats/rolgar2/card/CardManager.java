package org.thegoats.rolgar2.card;
import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.game.turnManagement.PlayerTurnSelections;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.interaction.Keyboard;
import org.thegoats.rolgar2.util.io.selection.Selection;
import org.thegoats.rolgar2.world.Position;
import org.thegoats.rolgar2.world.WorldCell;

import java.util.Optional;

public class CardManager {

    /**
     * Dada una carta, la usa, pidiendole al usuario los inputs necesarios.
     * @param card no null, carta a usar
     * @param gameCharacter no null, personaje que usa la carta
     * @return true si se pudo completar la operacion
     */
    public static boolean useCard(Card card, GameCharacter gameCharacter){
        Assert.notNull(gameCharacter, "gameCharacter no puede ser null");
        Assert.notNull(card, "card no puede ser null");
        Selection<Boolean> election = PlayerTurnSelections.booleanSelection(
                "¿Desea usar la carta "+card+"?", "Opcion invalida");
        if(election.select().isEmpty()){
            return false;
        }
        return switch (card){
            case CardWithCharacterTarget cardWithCharacterTarget -> useCardWithCharacterTarget(cardWithCharacterTarget, gameCharacter);
            case StealingCard stealingCard -> useStealingCard(stealingCard, gameCharacter);
            case TeleportCard teleportCard -> useTeleportCard(teleportCard, gameCharacter);
            default -> throw new RuntimeException("No está implementado aún");
        };
    }

    /**
     * Dada una carta con personaje objetivo, la usa pidiendole al jugador los inputs necesarios
     * @param card no null, carta a usar
     * @param gameCharacter no null, personaje que usa la carta
     * @return true si se pudo completar la operacion
     */
    private static boolean useCardWithCharacterTarget(CardWithCharacterTarget card, GameCharacter gameCharacter){
        Assert.notNull(gameCharacter, "gameCharacter no puede ser null");
        Assert.notNull(card, "card no puede ser null");
        Selection<GameCharacter> cardTargetSelection = PlayerTurnSelections.buildCardTargetSelection(gameCharacter.getGame());

        cardTargetSelection.select().ifPresent(target -> {
            switch(card.getCategory()){
                case POSITIVE -> Assert.isTrue(target.equals(gameCharacter) ||
                                (gameCharacter.isAllied() && gameCharacter.getAlliance().isAlly((Player)target.getActor())),
                        "No le puedes aplicar una carta buena a un enemigo");
                case NEGATIVE -> Assert.isTrue(!target.equals(gameCharacter) &&
                                (!gameCharacter.isAllied() || !gameCharacter.getAlliance().isAlly((Player)target.getActor())),
                        "No le puedes aplicar una carta negativa a un aliado");
            }
            card.setTarget(target.getCharacterData());
            gameCharacter.getGame().logger.logInfo(String.format("%s usa la carta %s sobre %s",
                    gameCharacter.getActor().getName(),
                    card.getName(),
                    target.getActor().getName()));
        });
        card.use();
        gameCharacter.getCharacterData().getDeck().remove(card);
        return true;
    }

    /**
     * Dada una carta de robo, la usa pidiendole al jugador los inputs necesarios
     * @param stealingCard no null, carta de robo a usar
     * @param gameCharacter no null, personaje que usa la carta
     * @return true si se uso correctamente
     */
    private static boolean useStealingCard(StealingCard stealingCard, GameCharacter gameCharacter){
        Assert.notNull(gameCharacter, "gameCharacter no puede ser null");
        Assert.notNull(stealingCard, "stealingCard");
        Assert.isTrue(!gameCharacter.getCharacterData().getDeck().isFull(), "El mazo está lleno");
        Selection<CardDeck> stolenDeckSelection = PlayerTurnSelections.buildStolenDeckSelection(gameCharacter);

        stealingCard.setThiefDeck(gameCharacter.getCharacterData().getDeck());
        stolenDeckSelection.select().ifPresent(stolenDeck -> {
            Selection<Card> cardSelection = PlayerTurnSelections.cardSelection(stolenDeck, "¿Que carta quiere robar?");
            stealingCard.setStolenDeck(stolenDeck);
            cardSelection.select().ifPresent(card1 -> {
                stealingCard.setStolenCard(card1);
                gameCharacter.getGame().logger.logInfo(String.format("El jugador %s roba la carta %s",
                        gameCharacter.getActor().getName(),
                        card1
                ));
            });
        });
        stealingCard.use();
        gameCharacter.getCharacterData().getDeck().remove(stealingCard);
        return true;
    }

    /**
     * Dada una carta de teleport, la usa pidiendole al jugador los inputs necesarios.
     * @param teleportCard no null, carta a usar.
     * @param gameCharacter no null, personaje que esta usando la carta
     * @return true si se pudo utilizar la carta
     */
    private static boolean useTeleportCard(TeleportCard teleportCard, GameCharacter gameCharacter){
        Assert.notNull(teleportCard, "teleportCard");
        Assert.notNull(gameCharacter, "gameCharacter");
        Selection<GameCharacter> gameCharacterSelection = PlayerTurnSelections.buildGameCharacterSelection(gameCharacter.getGame());
        gameCharacterSelection.select().ifPresent(character -> {
            teleportCard.setCharacter(character);
            teleportCard.setOrigin(character.getWorldCell());
            teleportCard.setDestination(gameCharacter.getWorld().getCell(pickPosition(3, gameCharacter)));
            gameCharacter.getGame().logger.logInfo("se movio a "+character.getActor().getName());
        });
        teleportCard.use();
        gameCharacter.getCharacterData().getDeck().remove(teleportCard);
        return true;
    }

    /**
     * Le pide al usuario ingresar coordenadas X, Y, Z y devuelve una position clampeada al tamaño del mundo
     * @param maxRetries no negativo, maximos intentos para elegir la position
     * @param gameCharacter no null
     * @return position ingresada por el usuario y recortada segun el tamaño del mundo
     */
    private static Position pickPosition(int maxRetries, GameCharacter gameCharacter){
        Assert.nonNegative(maxRetries, "maxRetries");
        Assert.notNull(gameCharacter, "gameCharacter");
        Assert.nonZero(maxRetries, "maxRetries");

        System.out.println("Ingrese la coordenada del eje X");
        int row = Keyboard.readInteger();

        System.out.println("Ingrese la coordenada del eje Y");
        int column = Keyboard.readInteger();

        System.out.println("Ingrese la coordenada del eje Z");
        int layer = Keyboard.readInteger();

        Selection<Boolean> confirmAction = PlayerTurnSelections.booleanSelection(
                "¿Son estas coordenadas correctas? (tenga en cuenta que se recortarán a los limites del mapa): (X,Y,Z) = ("+row+","+column+","+layer+")"
                , "Opcion Inválida");

        Optional<Boolean> election = confirmAction.select();

        if (election.isPresent() && election.get()) {
            return gameCharacter.getWorld().getClampedPosition(row - 1, column - 1, layer - 1);
        }
        return pickPosition(--maxRetries, gameCharacter);
    }

    /**
     * Le pregunta al jugador si quiere recoger la carta que esta ubicada en la celda destino
     */
    public static boolean pickCard(GameCharacter gameCharacter) {
        Assert.notNull(gameCharacter, "gameCharacter");
        CardDeck deck = gameCharacter.getCharacterData().getDeck();
        WorldCell cell = gameCharacter.getWorldCell();
        Assert.isTrue(cell.hasCard(), "La celda no contiene una carta");
        Assert.isTrue(!deck.isFull(), "El mazo está lleno");

        Selection<Boolean> election = PlayerTurnSelections.booleanSelection(
                "¿Desea tomar la carta "+cell.getCard().get()+"?", "Opcion invalida");
        if(!election.select().get()){
            return false;
        }
        deck.add(cell.getCard().get());
        gameCharacter.getWorldCell().setCard(null);
        return true;
    }

}