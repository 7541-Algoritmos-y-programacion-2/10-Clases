package org.thegoats.rolgar2.game;

import org.thegoats.rolgar2.actors.Actor;
import org.thegoats.rolgar2.actors.Enemy;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.character.CharacterData;
import org.thegoats.rolgar2.alliance.Alliance;
import org.thegoats.rolgar2.game.turnManagement.GameCharacterTurnManager;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.world.Position;
import org.thegoats.rolgar2.world.World;
import org.thegoats.rolgar2.world.WorldCell;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Objects;
import static org.thegoats.rolgar2.util.io.bitmaps.AnsiColor.*;


public final class GameCharacter {
    private final Game game;
    private final World world;
    private final Actor actor;
    private final CharacterData characterData;
    private Alliance alliance;
    private final GameCharacterTurnManager turnManager;
    private WorldCell worldCell;

    /**
     * Crea un GameCharacter con toda la información necesaria.
     * @param game instancia del juego, no puede ser nulo
     * @param world mundo en el que se mueve el personaje, no puede ser nulo
     * @param actor entidad ya sea player o enemy
     * @param characterData datos del personaje, no puede ser nulo
     * @param initialWorldCell celda inicial del mundo donde estará el personaje
     * @param gameCharacterTurnManagerClass clase concreta que administrará el turno de este personaje
     */
    public GameCharacter(
            Game game,
            World world,
            Actor actor,
            CharacterData characterData,
            WorldCell initialWorldCell,
            Class<? extends GameCharacterTurnManager> gameCharacterTurnManagerClass
    ) {
        Assert.notNull(game, "game");
        Assert.notNull(characterData, "characterData");
        Assert.notNull(world, "world");
        Assert.notNull(actor, "entity");
        setWorldCell(initialWorldCell);
        this.world = world;
        this.game = game;
        this.actor = actor;
        this.characterData = characterData;
        this.alliance = null;
        this.worldCell = initialWorldCell;
        this.worldCell.setCharacter(this);

        try {
            Constructor<?> ctor = gameCharacterTurnManagerClass.getDeclaredConstructor(GameCharacter.class);
            this.turnManager =  (GameCharacterTurnManager) ctor.newInstance(this);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Cambia la celda en el mapa en la que se encuentra el personaje
     * @param worldCell no puede ser nulo
     */
    public void setWorldCell(WorldCell worldCell) {
        Assert.notNull(worldCell, "worldCell");
        this.worldCell = worldCell;
    }

    /**
     * @return el characterData
     */
    public CharacterData getCharacterData(){
        return characterData;
    }

    public String getName() {
        return actor.getName();
    }

    /**
     * @return true si pertenece a una alianza
     */
    public boolean isAllied(){
        return alliance != null;
    }

    /**
     * @return alianza a la que pertenece el jugador
     */
    public Alliance getAlliance(){
        return alliance;
    }

    /**
     * @return el Actor
     */
    public Actor getActor(){
        return actor;
    }

    /**
     * Dada una alianza, si el jugador no está en niguna alianza lo agrega y devuelve true, caso contrario no lo
     * agrega y devuelve false
     * @param alliance no null, alianza destino
     * @return true si pudo unirse
     */
    public boolean joinAlliance(Alliance alliance){
        Assert.notNull(alliance, "alliance");
        Assert.isTrue(!isAllied(), "El jugador ya esta en una alianza");
        this.alliance = alliance;

        switch (actor){
            case Player player -> alliance.addAlly(player);
            case Enemy enemy -> throw new RuntimeException("No se puede agregar a "+enemy.getName()+" a la alianza");
            default -> throw new IllegalStateException("Unexpected value: " + actor);
        }
        return true;
    }

    /**
     * Abandona su alianza
     */
    public void leaveAlliance(){
        Assert.isTrue(isAllied(), "El jugador debe estar aliado para abandonar la alianza");
        alliance = null;
    }


    /**
     * @return juego en curso
     */
    public Game getGame(){
        return game;
    }

    /**
     * @return mundo
     */
    public World getWorld() {
        return world;
    }


    /**
     * @return Devuelve la celda en el mapa en la que se encuentra el personaje
     */
    public WorldCell getWorldCell() {
        return worldCell;
    }

    /**
     * Determina si el personaje es un jugador
     * @return Devuelve True si el es un jugador, False en caso contrario
     */
    public boolean isPlayerCharacter() {
        return actor instanceof Player;
    }

    /**
     * Realiza un ataque al personaje enviado por parametro, lo registra en el logger,
     * y se le aplica daño en funcion de la fuerza del atacante
     * @param character no puede ser nulo
     */
    public void attack(GameCharacter character) {
        Assert.notNull(character, "character");
        game.logger.logInfo(RED + actor.getName() + " ataca a " + character.actor.getName() + RESET);
        character.characterData.takeDamage(this.characterData.getStrength());
    }

    /**
     * Coloca al personaje en la celda correspondiente a position
     * @param position no null, nueva posicion del personaje
     */
    public void moveCharacter(Position position){
        Assert.notNull(position, "newPosition");

        var newCell = world.getCell(position);
        newCell.setCharacter(this);
        world.getCell(this.worldCell.getPosition()).setCharacter(null);
        setWorldCell(newCell);

    }

    @Override
    public String toString() {
        return characterData.toString();
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof GameCharacter && Objects.equals(characterData, ((GameCharacter) o).characterData);
    }

    @Override
    public int hashCode() {
        return Objects.hash(characterData);
    }

    /**
     * @return administrador de turnos del jugador
     */
    public GameCharacterTurnManager getTurnManager() {
        return turnManager;
    }
}