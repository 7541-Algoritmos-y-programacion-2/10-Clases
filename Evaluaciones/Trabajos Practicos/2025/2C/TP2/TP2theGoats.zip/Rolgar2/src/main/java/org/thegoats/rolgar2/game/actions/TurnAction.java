package org.thegoats.rolgar2.game.actions;
import java.util.Arrays;
import java.util.List;

public enum TurnAction {
    RealizarMovimiento,
    UsarCarta,
    AgarrarCarta,
    Atacar,
    GestionarAlianzas,
    UsarEscaleraSogaOResorte,
    SaltarTurno;

    public static List<TurnAction> getActions() {
        return Arrays.asList(values());
    }

    public static List<TurnAction> getFreezedActions() {
        return Arrays.asList(UsarCarta, AgarrarCarta, GestionarAlianzas, SaltarTurno);
    }
}

