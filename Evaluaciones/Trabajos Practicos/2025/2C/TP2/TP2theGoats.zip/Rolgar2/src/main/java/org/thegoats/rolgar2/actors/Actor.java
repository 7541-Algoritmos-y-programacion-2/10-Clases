package org.thegoats.rolgar2.actors;
import org.thegoats.rolgar2.util.Assert;

/**
 * Clase abstracta actor, todos los tipos de jugadores y enemigos la heredarán
 */
public abstract class Actor {
    private String name;

    protected void setName(String name){
        Assert.validName(name);
        this.name = name;
    }

    public String getName(){
        return name;
    }
}
