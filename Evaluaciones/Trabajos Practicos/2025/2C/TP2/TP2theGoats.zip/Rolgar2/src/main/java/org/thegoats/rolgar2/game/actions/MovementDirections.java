package org.thegoats.rolgar2.game.actions;

public enum MovementDirections {
    Norte,
    Sur,
    Este,
    Oeste,
    Noreste,
    Noroeste,
    Sudeste,
    Sudoeste,
    Volver
}