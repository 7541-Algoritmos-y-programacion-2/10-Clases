package org.thegoats.rolgar2.actors;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    @Test
    void testConstructorStoresName() {
        Player p = new Player("Lucas_123");
        assertEquals("Lucas_123", p.getName());
    }

    @Test
    void testInvalidNameThrows() {
        // depende de tu Assert.validName()
        // nombres inválidos típicos: null, "", muy cortos, muy largos, caracteres prohibidos
        assertThrows(Exception.class, () -> new Player(null));
        assertThrows(Exception.class, () -> new Player(""));
        assertThrows(Exception.class, () -> new Player("ab"));        // menos de 3
        assertThrows(Exception.class, () -> new Player("a".repeat(25))); // más de 20
        assertThrows(Exception.class, () -> new Player("??!?"));     // no alfanumerico o .-_
    }

    @Test
    void testGamesPlayedAndWon() {
        Player p = new Player("TestUser");

        assertEquals(0, p.getGamesPlayed());
        assertEquals(0, p.getGamesWon());

        p.incrementGamesPlayed();
        p.incrementGamesPlayed();
        p.incrementGamesWon();

        assertEquals(2, p.getGamesPlayed());
        assertEquals(1, p.getGamesWon());
    }

    @Test
    void testWinRate() {
        Player p = new Player("PlayerA");

        p.incrementGamesPlayed();
        p.incrementGamesPlayed();
        p.incrementGamesWon(); // 1/2 → 50%

        assertEquals(50.0, p.getWinRate(), 0.0001);
    }

    @Test
    void testWinRateZeroDivision() {
        Player p = new Player("Zero");

        // (0 * 100) / 0 → 0/0 → Infinity o NaN dependiendo la implementación
        // Probamos comportamiento esperado:
        assertTrue(Double.isNaN(p.getWinRate()) || Double.isInfinite(p.getWinRate()));
    }

    @Test
    void testEqualsSameReference() {
        Player p = new Player("Lucas");
        assertEquals(p, p);
    }

    @Test
    void testEqualsSameName() {
        Player p1 = new Player("Juan");
        Player p2 = new Player("Juan");

        assertEquals(p1, p2);
        assertEquals(p1.hashCode(), p2.hashCode());
    }

    @Test
    void testNotEqualsDifferentName() {
        Player p1 = new Player("Juan");
        Player p2 = new Player("Pedro");

        assertNotEquals(p1, p2);
    }

    @Test
    void testToStringContainsValues() {
        Player p = new Player("Ana");
        p.incrementGamesPlayed();
        p.incrementGamesWon();

        String s = p.toString();

        assertTrue(s.contains("Ana"));
        assertTrue(s.contains("gamesPlayed=1"));
        assertTrue(s.contains("gamesWon=1"));
    }
}
