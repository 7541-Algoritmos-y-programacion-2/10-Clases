package org.thegoats.rolgar2.game;

import org.thegoats.rolgar2.card.*;
import org.thegoats.rolgar2.character.CharacterFactory;
import org.thegoats.rolgar2.actors.Enemy;
import org.thegoats.rolgar2.game.config.GameConfig;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.alliance.Alliance;
import org.thegoats.rolgar2.game.turnManagement.EnemyTurnManager;
import org.thegoats.rolgar2.game.turnManagement.PlayerTurnManager;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.logging.Logger;
import org.thegoats.rolgar2.util.io.bitmaps.Bitmap;
import org.thegoats.rolgar2.util.structures.lists.TheGoatsLinkedList;
import org.thegoats.rolgar2.util.structures.maps.SetMap;
import org.thegoats.rolgar2.util.structures.sets.TheGoatsSet;
import org.thegoats.rolgar2.world.World;
import org.thegoats.rolgar2.world.WorldViewer;

import java.awt.*;
import java.io.IOException;
import java.util.*;
import java.util.List;



public final class Game {
    private int turnCount = 0;
    public final Logger logger;
    public final Random random;
    public final GameConfig config;
    public final WorldViewer worldViewer;

    private final World world;
    private final Set<Player> players;
    private final Set<GameCharacter> gameCharacters;
    private final Set<Alliance> alliances;
    private final Set<Card.Factory<? extends Card>> cardFactories;
    private final CharacterFactory playerCharacterFactory;
    private final CharacterFactory enemyCharacterFactory;

    private final Map<Player, GameCharacter> playerCharacterMap;

    /**
     * Construye una nueva partida del juego.
     * @param logger logger a utilizar para registrar mensajes
     * @param random generador de números aleatorios
     * @param players conjunto de jugadores que participarán
     * @param config configuración del juego (dificultad + mapa)
     */
    public Game(Logger logger, Random random, Set<Player> players, GameConfig config) {
        Assert.notNull(logger, "Logger");
        Assert.notNull(config, "random");
        Assert.notNull(players, "players");
        Assert.notNull(config, "config");

        this.logger = logger;
        this.random = random;
        this.config = config;
        this.players = new TheGoatsSet<>();
        this.players.addAll(players);

        //
        // World
        //

        this.world = config.mapConfig().generateWorld();

        //
        // Bitmaps
        //

        try{
            Map<String, Bitmap> cardBitmapMap = new SetMap<>();

            //sprite enemigos
            Bitmap enemyBitmap = Bitmap.loadFromFile("sprites/characters/enemy.png");
            // sprites de personajes
            Bitmap playerCharacterBitmap = Bitmap.loadFromFile("sprites/characters/player.png");
            Bitmap enemyCharacterBitmap  = Bitmap.loadFromFile("sprites/characters/playerEnemy.png");
            //sprite aliado de alianza
            Bitmap allieBitmap = Bitmap.loadFromFile("sprites/characters/ally.png");

            // Cartas: cargar imágenes desde resources
            Bitmap doubleMoveCardBitmap   = Bitmap.loadFromFile("sprites/cards/doubleMove.png");
            Bitmap fireBallCardBitmap     = Bitmap.loadFromFile("sprites/cards/fireBall.png");
            Bitmap healingCardBitmap      = Bitmap.loadFromFile("sprites/cards/healing.png");
            Bitmap iceCardBitmap          = Bitmap.loadFromFile("sprites/cards/iceBall.png");
            Bitmap invisibilityCardBitmap = Bitmap.loadFromFile("sprites/cards/invisibility.png");
            Bitmap shieldCardBitmap       = Bitmap.loadFromFile("sprites/cards/shield.png");
            Bitmap stealingCardBitmap     = Bitmap.loadFromFile("sprites/cards/stealing.png");
            Bitmap teleportCardBitmap     = Bitmap.loadFromFile("sprites/cards/teleport.png");
            Bitmap strengthCardBitmap     = Bitmap.loadFromFile("sprites/cards/strength.png");


            cardBitmapMap.put(DoubleMoveCard.class.getName(), doubleMoveCardBitmap);
            cardBitmapMap.put(FireballCard.class.getName(), fireBallCardBitmap);
            cardBitmapMap.put(HealingCard.class.getName(), healingCardBitmap);
            cardBitmapMap.put(IceballCard.class.getName(), iceCardBitmap);
            cardBitmapMap.put(InvisibilityCard.class.getName(), invisibilityCardBitmap);
            cardBitmapMap.put(ShieldCard.class.getName(), shieldCardBitmap);
            cardBitmapMap.put(StealingCard.class.getName(), stealingCardBitmap);
            cardBitmapMap.put(TeleportCard.class.getName(), teleportCardBitmap);
            cardBitmapMap.put(StrengthCard.class.getName(), strengthCardBitmap);



            this.worldViewer = new WorldViewer(
                    config.mapConfig().getFloorBitmapMap(),
                    config.mapConfig().getWallBitmapMap(),
                    cardBitmapMap,
                    playerCharacterBitmap,
                    enemyCharacterBitmap,
                    enemyBitmap,
                    allieBitmap,
                    Color.BLACK,
                    new Color(0, 0, 0, 0),
                    new Color(0, 0, 0, 180),
                    100, 100
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        //
        // GameCharacters
        //

        this.playerCharacterFactory = config.difficultyConfig().playerConfig().getCharacterFactory(random);
        this.enemyCharacterFactory = config.difficultyConfig().playerConfig().getCharacterFactory(random);
        this.gameCharacters = new TheGoatsSet<>();
        this.alliances = new TheGoatsSet<>();
        {
            int i = 0;
            for (Player player : players) {
                this.gameCharacters.add(new GameCharacter(
                        this,
                        world,
                        player,
                        playerCharacterFactory.create(),
                        world.getRandomEmptyCharacterWalkableCell(random),
                        PlayerTurnManager.class
                ));

                if (i++ % 2 == 1) { // crea un enemigo por cada dos jugadores
                    this.gameCharacters.add(new GameCharacter(
                            this,
                            world,
                            new Enemy("Duende_verde"),
                            enemyCharacterFactory.create(),
                            world.getRandomEmptyCharacterWalkableCell(random),
                            EnemyTurnManager.class
                    ));
                }
            }
        }
        playerCharacterMap = new SetMap<>();
        for (var gameCharacter : gameCharacters) {
            if (gameCharacter.isPlayerCharacter()) {
                playerCharacterMap.put((Player)gameCharacter.getActor(), gameCharacter);
            }
        }

        //
        // Cards
        //

        this.cardFactories = config.difficultyConfig().cardConfig().getFactories(random);

        int cardCount = world.getTotalEmptyCells()/10; // se genera una carta cada 10 celdas
        for (int i = 0; i < cardCount; i++) {
            world.getRandomEmptyCharacterWalkableCell(random).setCard(
                    ((Card.Factory<? extends Card>) cardFactories.toArray()[random.nextInt(cardFactories.size())])
                            .create()
            );
        }

        logger.logInfo("Game constructor:");
        logger.logInfo("logger: " + logger);
        logger.logInfo("config: " + config);
        logger.logInfo("gameCharacters: " + gameCharacters);
    }

    /**
     * Inicia la ejecucion del juego, esto implica:
     * Cargar las configuraciones y mapas
     * Realizar las impresiones de inicio de juego
     * Iniciar el bucle de juego
     * Realizar las impresiones de fin del juego
     */
    public void run()
    {
        logger.logInfo("Game run:");

        logger.logInfo("Good Luck");
        while (hasNextTurn()) {
            nextTurn();
        }
        // Si terminó y hay un solo ganador
        var ganadores = getAliveGameCharacterPlayers();
        if(ganadores.size() == 1){
            logger.logInfo("GANADOR: "+ ganadores.getFirst().getName());
        } else {// si hay varios ganadores (los que siguen vivos eran una alianza)
            StringBuilder output = new StringBuilder("GANADORES: ");
            for(var ally: alliances.iterator().next().getAllies()){
                output.append(ally.getName());
                output.append(" ");
            }
            logger.logInfo(output.toString());
        }
    }

    /**
     * Evalua si debe haber un proximo turno o si el juego debe terminar
     * @return true si hay un proximo turno, false si no lo hay
     */
    private boolean hasNextTurn()
    {
        // Si hay solo una alianza y contiene a todos los jugadores vivos,
        if(alliances.size() == 1){
            var alliance = alliances.iterator().next();
            return !alliance.getAllies().containsAll(getAlivePlayers());
        }
        // Debe haber mas de un character vivo para continuar
        return getAlivePlayersCount() > 1;
    }

    /**
     * Todos los personajes hacen su turno
     */
    private void nextTurn()
    {
        logger.logInfo("Turn " + ++turnCount);
        for (GameCharacter gameCharacter : gameCharacters) {
            gameCharacter.getCharacterData().updateEffects();
            gameCharacter.getTurnManager().doTurn();
        }
    }

    /**
     * @return lista inmutable de GameCharacters
     */
    public List<GameCharacter> getGameCharacters(){
        return List.copyOf(gameCharacters);
    }

    /**
     * @return devuelve una lista con los jugadores vivos
     */
    public int getAlivePlayersCount(){
        int alivePlayers = 0;
        for(GameCharacter gameCharacter: gameCharacters){
            if(gameCharacter.isPlayerCharacter() && gameCharacter.getCharacterData().isAlive()){
                alivePlayers++;
            }
        }
        return alivePlayers;
    }

    /**
     * Dada una alianza nueva, la agrega.
     * @param alliance no null, alianza a agregar.
     * @return true si se pudo agregar.
     */
    public boolean addAlliance(Alliance alliance){
        Assert.notNull(alliance, "alliance");
        return alliances.add(alliance);
    }

    public Set<Alliance> getAlliances() {
        Set<Alliance> alliances = new TheGoatsSet<>();
        alliances.addAll(this.alliances);
        return alliances;
    }

    /**
     * Dada una alianza ya existente, la remueve.
     * @param alliance no null, alianza a remover.
     * @return true si se pudo remover.
     */
    public boolean removeAlliance(Alliance alliance){
        Assert.notNull(alliance, "alliance");
        return alliances.remove(alliance);
    }

    /**
     * @return cantidad de jugadores sin alianza
     */
    public int getNonAlliedPlayerCount() {
        int count = 0;
        for(GameCharacter character: gameCharacters){
            if(character.isPlayerCharacter() && !character.isAllied() && character.getCharacterData().isAlive()){
                count++;
            }
        }

        return count;
    }

    public GameCharacter playerToGameCharacter(Player player) {
        return playerCharacterMap.get(player);
    }

    /**
     * @return devuelve una lista con los gameCharacters que pertenecen a jugadores.
     */
    private List<GameCharacter> getAliveGameCharacterPlayers() {
        List<GameCharacter> playerCharacters = new TheGoatsLinkedList<>();
        for(GameCharacter gameCharacter: gameCharacters){
            if(gameCharacter.isPlayerCharacter() && gameCharacter.getCharacterData().isAlive()){
                playerCharacters.add(gameCharacter);
            }
        }
        return playerCharacters;
    }

    /**
     * @return una lista con los players que siguen vivos
     */
    private List<Player> getAlivePlayers(){
        List<Player> players = new TheGoatsLinkedList<>();
        for(Player player: players){
            GameCharacter gameCharacter = playerToGameCharacter(player);
            if(gameCharacter.getCharacterData().isAlive()){
                players.add(player);
            }
        }
        return players;
    }

}