package org.thegoats.rolgar2.world;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

class BlockTest {

    @Test
    @DisplayName("Constructor inicializa correctamente")
    void testConstructor() {
        Block walkable = new Block(true);
        Block notWalkable = new Block(false);

        assertTrue(walkable.isWalkable());
        assertFalse(notWalkable.isWalkable());
    }

    @Test
    @DisplayName("isWalkable devuelve correctamente el estado")
    void testIsWalkable() {
        Block block = new Block(true);
        assertTrue(block.isWalkable());

        Block b2 = new Block(false);
        assertFalse(b2.isWalkable());
    }

    @Test
    @DisplayName("setWalkable funciona cuando el bloque NO era caminable")
    void testSetWalkableValid() {
        Block block = new Block(false);
        block.setWalkable();
        assertTrue(block.isWalkable());
    }

    @Test
    @DisplayName("setWalkable lanza excepción si ya era caminable")
    void testSetWalkableInvalid() {
        Block block = new Block(true);

        RuntimeException e = assertThrows(RuntimeException.class, block::setWalkable);
    }

    @Test
    @DisplayName("setNotWalkable funciona cuando el bloque ERA caminable")
    void testSetNotWalkableValid() {
        Block block = new Block(true);
        block.setNotWalkable();
        assertFalse(block.isWalkable());
    }

    @Test
    @DisplayName("setNotWalkable lanza excepción si NO era caminable")
    void testSetNotWalkableInvalid() {
        Block block = new Block(false);

        RuntimeException e = assertThrows(RuntimeException.class, block::setNotWalkable);
    }

    @Test
    @DisplayName("equals: misma referencia")
    void testEqualsSameReference() {
        Block block = new Block(true);
        assertEquals(block, block);
    }

    @Test
    @DisplayName("equals: distintos objetos pero mismo isWalkable")
    void testEqualsSameWalkable() {
        Block b1 = new Block(true);
        Block b2 = new Block(true);

        assertEquals(b1, b2);
    }

    @Test
    @DisplayName("equals: distintos estados walkable")
    void testEqualsDifferentWalkable() {
        Block b1 = new Block(true);
        Block b2 = new Block(false);

        assertNotEquals(b1, b2);
    }

    @Test
    @DisplayName("equals: null y distintas clases")
    void testEqualsInvalidCases() {
        Block block = new Block(true);

        assertNotEquals(block, null);
        assertNotEquals(block, "hola");
    }

    @Test
    @DisplayName("hashCode respeta contrato con equals")
    void testHashCode() {
        Block b1 = new Block(true);
        Block b2 = new Block(true);
        Block b3 = new Block(false);

        assertEquals(b1.hashCode(), b2.hashCode());
        assertNotEquals(b1.hashCode(), b3.hashCode());
    }

    @Test
    @DisplayName("toString devuelve formato correcto")
    void testToString() {
        Block block = new Block(true);
        assertEquals("Block[isWalkable=true]", block.toString());

        Block b2 = new Block(false);
        assertEquals("Block[isWalkable=false]", b2.toString());
    }
}
