package org.thegoats.rolgar2.world;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WallTest {

    @Test
    @DisplayName("Constructor inicializa correctamente")
    void testConstructor() {
        Wall w = new Wall("stone_wall", true);

        assertEquals("stone_wall", w.name());
        assertTrue(w.isClimbable());
    }

    @Test
    @DisplayName("equals: mismo nombre, distinto isClimbable → deben ser iguales")
    void testEqualsSameName() {
        Wall w1 = new Wall("brick", true);
        Wall w2 = new Wall("brick", false);

        assertEquals(w1, w2);
    }

    @Test
    @DisplayName("equals: distinto nombre → deben ser distintos")
    void testEqualsDifferentName() {
        Wall w1 = new Wall("wood", true);
        Wall w2 = new Wall("iron", true);

        assertNotEquals(w1, w2);
    }

    @Test
    @DisplayName("equals: misma referencia")
    void testEqualsSameReference() {
        Wall w = new Wall("marble", false);
        assertEquals(w, w);
    }

    @Test
    @DisplayName("equals: null y otros tipos")
    void testEqualsInvalidCases() {
        Wall w = new Wall("obsidian", true);

        assertNotEquals(w, null);
        assertNotEquals(w, "obsidian");
    }

    @Test
    @DisplayName("hashCode debe depender solo del name, igual que equals")
    void testHashCodeConsistentWithEquals() {
        Wall w1 = new Wall("gold", true);
        Wall w2 = new Wall("gold", false);

        assertEquals(w1.hashCode(), w2.hashCode());
    }

    @Test
    @DisplayName("toString tiene el formato de un record")
    void testToString() {
        Wall w = new Wall("granite", false);

        assertEquals("Wall[name=granite, isClimbable=false]", w.toString());
    }
}
