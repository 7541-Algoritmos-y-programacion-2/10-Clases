package org.thegoats.rolgar2.world;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FloorTest {

    @Test
    @DisplayName("Constructor inicializa correctamente")
    void testConstructor() {
        Floor f = new Floor("stone", true);

        assertEquals("stone", f.name());
        assertTrue(f.isWalkable());
    }

    @Test
    @DisplayName("equals: mismo nombre, distinto isWalkable → deben ser iguales")
    void testEqualsSameName() {
        Floor f1 = new Floor("grass", true);
        Floor f2 = new Floor("grass", false);

        assertEquals(f1, f2);
    }

    @Test
    @DisplayName("equals: distinto nombre → deben ser distintos")
    void testEqualsDifferentName() {
        Floor f1 = new Floor("sand", true);
        Floor f2 = new Floor("mud", true);

        assertNotEquals(f1, f2);
    }

    @Test
    @DisplayName("equals: misma referencia")
    void testEqualsSameReference() {
        Floor f = new Floor("wood", false);
        assertEquals(f, f);
    }

    @Test
    @DisplayName("equals: null y otros tipos")
    void testEqualsInvalidCases() {
        Floor f = new Floor("lava", false);

        assertNotEquals(f, null);
        assertNotEquals(f, "lava");
    }

    @Test
    @DisplayName("hashCode debe depender solo del name, igual que equals")
    void testHashCodeConsistentWithEquals() {
        Floor f1 = new Floor("ice", true);
        Floor f2 = new Floor("ice", false);

        assertEquals(f1.hashCode(), f2.hashCode());
    }

    @Test
    @DisplayName("toString tiene el formato de un record")
    void testToString() {
        Floor f = new Floor("rock", true);

        assertEquals("Floor[name=rock, isWalkable=true]", f.toString());
    }
}
