package org.thegoats.rolgar2.util.io.bitmaps;

import org.thegoats.rolgar2.util.Assert;


import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;


public class Bitmap {
    private int width;
    private int height;
    private BufferedImage image;
    private double distanceToCamera = 200;

    /**
     * Genera un bitmap de ancho y alto dados
     * @param width ancho en pixeles mayor a 0
     * @param height alto en pixeles mayor a 0
     */
    public Bitmap(int width, int height) {
        Assert.positive(width, "ancho");
        Assert.positive(height, "alto");
        this.width = width;
        this.height = height;
        this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
    }

    public void fill(Color color) {
        for(int x = 0; x < width; x++) {
            for(int y = 0; y < height; y++) {
                image.setRGB(x, y, color.getRGB());
            }
        }
    }

    /**
     * Dibuja un pixel de un color determinado
     * @param x: pixel entre 1 y ancho
     * @param y: pixel entre 1 y alto
     * @param color: no nulo
     */
    public void drawPixel(int x, int y, Color color) {
        Assert.inRange(x, 0, getWidth(), "ancho");
        Assert.inRange(y, 0, getHeight(), "alto");
        Assert.notNull(color, "color");
        if (x >= 0 && x < width && y >= 0 && y < height) {
            image.setRGB(x, y, color.getRGB());
        }
    }

    /**
     * Dibuja una linea del color dado
     * @param x1: pixel entre 1 y ancho (origen)
     * @param y1: pixel entre 1 y alto (origen)
     * @param x2: pixel entre 1 y ancho (destino)
     * @param y2: pixel entre 1 y alto (destino)
     * @param color: no nulo
     */
    public void drawLine(int x1, int y1, int x2, int y2, Color color) {
        Assert.inRange(x1, 0, getWidth(), "x1");
        Assert.inRange(x2, 0, getWidth(), "x2");
        Assert.inRange(y1, 0, getHeight(), "y1");
        Assert.inRange(y2, 0, getHeight(), "y2");
        Assert.notNull(color, "color");
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            drawPixel(x1, y1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
    }

    /**
     * Dibuja un rectangulo del color dado
     * @param x: pixel entre 1 y ancho (origen)
     * @param y: pixel entre 1 y alto (origen)
     * @param width: pixel entre 1 y ancho (destino)
     * @param height: pixel entre 1 y alto (destino)
     * @param color: no nulo
     */
    public void drawRectangle(int x, int y, int width, int height, Color color) {
        Assert.inRange(x, 0, getWidth(), "x1");
        Assert.inRange(y, 0, getHeight(), "y1");
        Assert.inRange(width, 0, getWidth(), "ancho");
        Assert.inRange(height, 0, getHeight(), "alto");
        Assert.notNull(color, "color");
        drawLine(x, y, x + width, y, color);
        drawLine(x, y, x, y + height, color);
        drawLine(x + width, y, x + width, y + height, color);
        drawLine(x, y + height, x + width, y + height, color);
    }

    /**
     * Dibuja un circulo del color dado
     * @param centerX: pixel entre 1 y ancho (origen)
     * @param centerY: pixel entre 1 y alto (origen)
     * @param radius: mayor a cero
     * @param color: no nulo
     */
    public void drawCircle(int centerX, int centerY, int radius, Color color) {
        Assert.inRange(centerX, 0, getWidth(), "x1");
        Assert.inRange(centerY, 0, getHeight(), "y1");
        Assert.inRange(radius, 0, Math.min(getWidth(), getHeight()), "ancho");
        Assert.notNull(color, "color");
        int x = radius;
        int y = 0;
        int err = 0;

        while (x >= y) {
            drawPixel(centerX + x, centerY + y, color);
            drawPixel(centerX + y, centerY + x, color);
            drawPixel(centerX - y, centerY + x, color);
            drawPixel(centerX - x, centerY + y, color);
            drawPixel(centerX - x, centerY - y, color);
            drawPixel(centerX - y, centerY - x, color);
            drawPixel(centerX + y, centerY - x, color);
            drawPixel(centerX + x, centerY - y, color);

            y++;
            if (err <= 0) {
                err += 2 * y + 1;
            }
            if (err > 0) {
                x--;
                err -= 2 * x + 1;
            }
        }
    }

    /**
     * Dibuja un texto en la posicion dada
     * @param text: texto a dibujar
     * @param x: pixel entre 1 y ancho (origen)
     * @param y: pixel entre 1 y alto (origen)
     * @param font: fuente a utilizar, no nula
     * @param color: colo no nulo
     */
    public void drawText(String text, int x, int y, Font font, Color color, Color background) {
        Assert.inRange(x, 0, getWidth(), "x");
        Assert.inRange(y, 0, getHeight(), "y");
        Assert.notNull(font, "fuente");
        Assert.notNull(color, "color");
        Graphics2D g = image.createGraphics();

        g.setColor(background);
        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        int textAscent = fm.getAscent();
        int paddingSuperior = 5;
        int paddingInferior = 10;
        g.fillRect(x-paddingInferior, y - textAscent - paddingInferior, textWidth + (paddingSuperior*4), textHeight + (paddingSuperior*2));

        g.setFont(font);
        g.setColor(color);
        g.drawString(text, x, y);
        g.dispose();
    }

    /**
     * Genera una copia redimensionada de la imagen
     * @param width nuevo ancho mayor a cero
     * @param height nuevo alto mayor a cero
     */
    public Bitmap scaled(int width, int height) {
        BufferedImage output = new BufferedImage(width, height, image.getType());
        Graphics2D g = output.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(image, 0, 0, width, height, null);
        g.dispose();

        Bitmap result = new Bitmap(width, height);
        result.image = output;
        return result;
    }

    /**
     * Pega otro bitmap en this en la posicion (x,y)
     * @param other no null, otro bitmap
     * @param x entre 0 y ancho, posicion en el eje horizontal donde pegar el bitmap
     * @param y entre 0 y alto, posicion en el eje vertical donde pegar el bitmap
     */
    public void pasteBitmap(Bitmap other, int x, int y) {
        Assert.notNull(other, "other");

        Graphics2D g = image.createGraphics();
        g.drawImage(other.image, x, y, null);
        g.dispose();
    }

    /**
     * Guarda el bitmap en un archivo
     * @param path no null, ruta relativa donde guardar el bitmap
     * @return ruta absoluta donde fue guardado el bitmap
     * @throws IOException Si hay un error en la escritura del archivo
     */
    public String saveToFile(String path) throws IOException {
        Assert.notNull(path, "path");
        File output = new File(path);
        ImageIO.write(image, "bmp", output);
        return output.getAbsolutePath();
    }

    /**
     * Carga un bitmap desde la ruta {@code path} dentro de resources y lo devuelve.
     * @param path no null, ruta del archivo dentro del classpath
     * @return bitmap leído del recurso
     * @throws IOException si no pudo leer el recurso
     */
    public static Bitmap loadFromFile(String path) throws IOException {
        Assert.notNull(path, "path");

        // Obtener recurso dentro del classpath
        ClassLoader cl = Bitmap.class.getClassLoader();
        InputStream in = cl.getResourceAsStream(path);

        Assert.notNull(in, "in");

        BufferedImage img = ImageIO.read(in);
        Assert.notNull(img, "img");

        Bitmap bmp = new Bitmap(img.getWidth(), img.getHeight());
        bmp.image = img;
        return bmp;
    }

    private int projectX(double x, double z) {
        return (int) (this.width / 2 + x * distanceToCamera / (z + distanceToCamera));
    }

    private int projectY(double y, double z) {
        return (int) (this.height / 2 - y * distanceToCamera / (z + distanceToCamera));
    }

    /**
     * Dibuja un segmento de color {@code color} y extremos { (x1, y1, z1), (x2, y2, z2) }
     * @param x1 coordenada x del extremo A
     * @param y1 coordenada y del extremo A
     * @param z1 coordenada z del extremo A
     * @param x2 coordenada x del extremo B
     * @param y2 coordenada y del extremo B
     * @param z2 coordenada z del extremo B
     * @param color no null, color de la linea
     */
    public void drawLine3D(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        Assert.notNull(color, "color");
        int x1p = projectX(x1, z1);
        int y1p = projectY(y1, z1);
        int x2p = projectX(x2, z2);
        int y2p = projectY(y2, z2);
        this.drawLine(x1p, y1p, x2p, y2p, color);
    }

    /**
     * Dibuja un cubo con una de sus aristas ubicada en { {@code cx}, {@code cy}, {@code cz} }
     * @param size mayor a cero
     * @param cx coordenada x de la ubicacion de la arista origen
     * @param cy coordenada y de la ubicacion de la arista origen
     * @param cz coordenada z de la ubicacion de la arista origen
     * @param color no null
     */
    public void drawCube(double size, double cx, double cy, double cz, Color color) {
        Assert.notNull(color, "color");
        Assert.positive(size, "size");
        double[][] vertices = new double[8][3];
        int i = 0;
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dy = -1; dy <= 1; dy += 2) {
                for (int dz = -1; dz <= 1; dz += 2) {
                    vertices[i][0] = cx + dx * size / 2;
                    vertices[i][1] = cy + dy * size / 2;
                    vertices[i][2] = cz + dz * size / 2;
                    i++;
                }
            }
        }

        int[][] edges = {
                {0, 1}, {1, 3}, {3, 2}, {2, 0},
                {4, 5}, {5, 7}, {7, 6}, {6, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };

        for (int[] edge : edges) {
            double[] p1 = vertices[edge[0]];
            double[] p2 = vertices[edge[1]];
            drawLine3D(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], color);
        }
    }

    /**
     * Dibuja un texto sobre la imagen interna del Bitmap
     *
     * @param text  texto a dibujar (no null)
     * @param x     coordenada X (en píxeles) dentro del bitmap
     * @param y     coordenada Y (en píxeles) dentro del bitmap (línea base del texto)
     * @param color color del texto (si es null no cambia el color actual)
     * @param font  fuente del texto (si es null no cambia la fuente actual)
     */
    public void drawString(String text, int x, int y, Color color, Font font) {
        Assert.notNullOrEmpty(text,"text");
        Graphics2D g = (Graphics2D) this.getImage().getGraphics();
        try {
            if (font != null) {
                g.setFont(font);
            }
            //seteo de color
            if (color != null) {
                g.setColor(color);
            }

            // Suavizado de texto
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            //texto con la posicion
            g.drawString(text, x, y);
        } finally {
            g.dispose();
        }
    }

    /**
     * @return La imagen en memoria
     */
    public BufferedImage getImage() {
        return image;
    }

    /**
     * @return pixeles de ancho
     */
    public int getWidth() {
        return width;
    }

    /**
     * @return pixeles de alto
     */
    public int getHeight() {
        return height;
    }
}