package org.thegoats.rolgar2.util.structures.sets;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TheGoatsBasicSet<E> {

    private List<E> elements;

    public TheGoatsBasicSet() {
        this.elements = new ArrayList<>();
    }


    public boolean add(E element) {
        if (!elements.contains(element)) {
            elements.add(element);
            return true;
        }
        return false;
    }

    public boolean remove(E element) {
        return elements.remove(element);
    }

    public boolean contains(E element) {
        return elements.contains(element);
    }

    public int size() {
        return elements.size();
    }

    public boolean isEmpty() {
        return elements.isEmpty();
    }

    public void empty() {
        elements.clear();
    }

    public TheGoatsBasicSet<E> union(TheGoatsBasicSet<E> other) {
    	TheGoatsBasicSet<E> result = new TheGoatsBasicSet<>();
        for (E e : this.elements) {
            result.add(e);
        }
        for (E e : other.elements()) {
            result.add(e);
        }
        return result;
    }

    public TheGoatsBasicSet<E> intersection(TheGoatsBasicSet<E> other) {
    	TheGoatsBasicSet<E> result = new TheGoatsBasicSet<>();
        for (E e : this.elements) {
            if (other.contains(e)) {
                result.add(e);
            }
        }
        return result;
    }

    public TheGoatsBasicSet<E> difference(TheGoatsBasicSet<E> other) {
    	TheGoatsBasicSet<E> result = new TheGoatsBasicSet<>();
        for (E e : this.elements) {
            if (!other.contains(e)) {
                result.add(e);
            }
        }
        return result;
    }

    public Collection<E> elements() {
        return new ArrayList<>(elements);
    }
}