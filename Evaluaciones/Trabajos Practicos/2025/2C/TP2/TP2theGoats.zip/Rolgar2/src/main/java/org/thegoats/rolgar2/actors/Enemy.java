package org.thegoats.rolgar2.actors;

public class Enemy extends Actor {
    /**
     * Construye el jugador si su nombre es válido
     * @param name no null, entre 3 y 20 caracteres alfanumericos, y '.-_'
     */
    public Enemy(String name){
        setName(name);
    }
}