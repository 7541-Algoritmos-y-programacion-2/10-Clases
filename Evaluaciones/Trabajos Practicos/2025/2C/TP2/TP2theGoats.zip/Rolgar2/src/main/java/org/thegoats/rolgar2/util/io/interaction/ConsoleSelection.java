package org.thegoats.rolgar2.util.io.interaction;

import org.thegoats.rolgar2.util.io.selection.Selection;
import org.thegoats.rolgar2.util.structures.maps.SetMap;

import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

import static org.thegoats.rolgar2.util.io.bitmaps.AnsiColor.*;


/**
 * Implementación de Selection que permite realizar una selección a través de la consola.
 * Cada opción se imprime asociada a un número, y el usuario debe ingresar el numero correspondiente para elegir.
 */
public class ConsoleSelection<T> extends Selection<T> {
    /**
     * Selecciona por la consola.
     * Muestra encabezado, opciones numeradas y mensajes configurados.
     * Luego solicita entrada al usuario hasta que se seleccione una opción válida
     * o se agoten los intentos permitidos.
     * @return un Optional con el ítem seleccionado, o vacío si no hubo selección exitosa
     */
    @Override
    public Optional<T> select() {
            var markerOptionMap = createMarkerOptionMap();

            printIfNotNull(MAGENTA, getSelectionHeader());
            printMarkerOptionMap(markerOptionMap);

            var selection = trySelect(markerOptionMap);
            for (int tryCount = 1; tryCount < getMaxTries(); tryCount++) {
                if (selection.isPresent()) {
                    printIfNotNull(GREEN, getSelectionSuccessMessage());
                    return selection;
                }

                printIfNotNull(YELLOW, getSelectionRetryMessage());
                selection = trySelect(markerOptionMap);
            }

            printIfNotNull(RED, getSelectionFailMessage());
            return selection;
        }

    /**
     * Intenta obtener una selección del usuario leyendo una entrada desde consola
     * y comparándola con el mapa de opciones.
     * @param markerOptionMap mapa que asocia los valores ingresados a opciones
     * @return un Optional con el valor seleccionado, o vacío si la entrada no coincide
     */
        private Optional<T> trySelect(Map<String, SelectionOption<T>> markerOptionMap) {
            Scanner scanner = new Scanner(System.in);
            printIfNotNull(MAGENTA, getSelectionPrompt());
            String input =  scanner.nextLine();
            var selectionOption = markerOptionMap.getOrDefault(input, null);
            return selectionOption == null ? Optional.empty() : Optional.ofNullable(selectionOption.getItemValue());
        }

    /**
     * Crea un mapa que asigna a cada opción un marcador numérico incremental iniciando en 1.
     * @return mapa entre marcadores en texto y sus respectivas opciones
     */
        private Map<String, SelectionOption<T>> createMarkerOptionMap() {
            Map<String, SelectionOption<T>> markerOptionMap = new SetMap<>();

            int i = 0;
            for (SelectionOption<T> option : options) {
                var marker = String.valueOf(++i);
                markerOptionMap.put(marker, option);
            }

            return markerOptionMap;
        }

    /**
     * Imprime por consola el listado de marcadores junto con las opciones correspondientes.
     * @param markerOptionMap mapa entre marcadores y opciones
     */
        private void printMarkerOptionMap(Map<String, SelectionOption<T>> markerOptionMap) {
            for (Map.Entry<String, SelectionOption<T>> entry : markerOptionMap.entrySet()) {
                System.out.printf("[%s] %s\n", entry.getKey(), entry.getValue());
            }
        }

    /**
     * Imprime una cadena únicamente si no es null.
     * @param string texto a imprimir, o null para no imprimir nada
     */
        private static void printIfNotNull(String color,  String string) {
            if (string != null) {
                System.out.println(color + string + RESET);
            }
        }
}
