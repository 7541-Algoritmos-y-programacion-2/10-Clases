package org.thegoats.rolgar2.world;

import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.collections.Board3d;
import org.thegoats.rolgar2.util.structures.lists.TheGoatsLinkedList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Clase que envuelve Board3d para adicionarle logica, validaciones y metodos propios del juego
 */
public class World implements Iterable<WorldCell> {
    private final Board3d<WorldCell> board;

    /**
     * Crea un mundo de Rows.ColumnsxLayers
     * @param rows filas del tablero, mayor a cero
     * @param columns columnas del tablero, mayor a cero
     * @param layers capas del tablero, mayor a cero
     */
    public World(int rows, int columns, int layers) {
        board = new Board3d<>(rows, columns, layers, WorldCell::new);
        initWorldCells();
    }

    //
    // Getters simples
    //

    /**
     * @return Cantidad de filas
     */
    public int getRowCount() {
        return board.getRowCount();
    }

    /**
     * @return Cantidad de columnas
     */
    public int getColumnCount() {
        return board.getColumnCount();
    }

    /**
     * @return Cantidad de capas
     */
    public int getLayerCount() {
        return board.getLayerCount();
    }

    /**
     * @param row fila, mayor o igual a cero y menor a getRowCount
     * @param column columna, mayor o igual a cero y menor a getColumnsCount
     * @param layer capa, mayor o igual a cero y menor a getLayerCount
     * @return La celda en la posicion {row, column, layer}
     */
    public WorldCell getCell(int row, int column, int layer) {
        return board.get(row, column, layer);
    }

    /**
     * @param position no nulo, posicion válida dentro del tablero
     * @return La celda en la posicion position
     */
    public WorldCell getCell(Position position) {
        return board.get(position);
    }

    /**
     * Obtiene una celda aleatoria vacia en la que un personaje pueda caminar
     * @param random generador aleatorio de valores
     * @return una celda vacia en la que se pueda caminar
     */
    public WorldCell getRandomEmptyCharacterWalkableCell(Random random) {
        Assert.notNull(random, "Random");
        List<WorldCell> emptyWalkableCells = new ArrayList<>();

        board.forEach(cell -> {
            if (cell.characterCanMove() && !cell.hasWall()) {
                emptyWalkableCells.add(cell);
            }
        });

        return emptyWalkableCells.get(random.nextInt(0, emptyWalkableCells.size()));
    }

    /**
     * @return cantidad de celda vacias y caminables del mapa
     */
    public int getTotalEmptyCells() {
        int count = 0;
        for (WorldCell cell : board) {
            if (cell.isEmptyAndWalkable()) {
                count++;
            }
        }
        return count;
    }


    /**
     * Iterador que itera pasando por cada fila de cada columna de cada capa del tablero
     */
    @Override
    public Iterator<WorldCell> iterator() {
        return board.iterator();
    }

    //
    // Helpers
    //

    /**
     * Inicializa los vecinos de las celdas (26 vecinos)
     */
    private void initWorldCells() {

        for (WorldCell worldCell : board) {
            List<WorldCell> neighbors = new TheGoatsLinkedList<>();
            for (int dz = -1; dz <= 1; dz++) {
                int layer = worldCell.getPosition().getLayer() + dz;

                // salta la celda si esta fuera de los limites
                if (layer < 0 || layer >= getLayerCount())
                    continue;

                for (int dy = -1; dy <= 1; dy++) {
                    int column = worldCell.getPosition().getColumn() + dy;

                    // salta la celda si esta fuera de los limites
                    if (column < 0 || column >= getColumnCount())
                        continue;

                    for (int dx = -1; dx <= 1; dx++) {
                        int row = worldCell.getPosition().getRow() + dx;

                        // salta la celda si esta fuera de los limites
                        if (row < 0 || row >= getRowCount())
                            continue;

                        // saltar la celda actual
                        if (dx == 0 && dy == 0 && dz == 0)
                            continue;

                        neighbors.add(board.get(row, column, layer));
                    }
                }
            }

            worldCell.initNeighbors(neighbors);
        }
    }

    /**
     * Dados row, column y layer, construye un Position que está comprendido entre los limites del mapa
     * @param row    entero
     * @param column entero
     * @param layer  entero
     * @return Position recortada entre 0 y los limites del mapa
     */
    public Position getClampedPosition(int row, int column, int layer) {

        return new Position(
                Math.clamp(row, 0, this.getRowCount()-1),
                Math.clamp(column, 0, this.getColumnCount()-1),
                Math.clamp(layer, 0, this.getLayerCount()-1)
        );
    }
}