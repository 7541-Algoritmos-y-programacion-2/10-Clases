package org.thegoats.rolgar2.card;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class CardDeckTest {

    // ========================
    // DummyCard PARA TEST
    // ========================
    static class DummyCard implements Card {
        private final String name;

        DummyCard(String name) { this.name = name; }

        @Override
        public void use() { }

        @Override
        public String getName() { return name; }

        @Override
        public CardCategory getCategory() { return null; }

        @Override
        public boolean equals(Object o) {
            return o instanceof DummyCard dc && this.name.equals(dc.name);
        }

        @Override
        public int hashCode() {
            return name.hashCode();
        }
    }

    @Test
    void testConstructorAndMaxSize() {
        CardDeck deck = new CardDeck(3);

        assertEquals(3, deck.getMaxSize());
        assertEquals(0, deck.getSize());
        assertTrue(deck.isEmpty());
        assertFalse(deck.isFull());
    }

    @Test
    void testAddCards() {
        CardDeck deck = new CardDeck(2);

        DummyCard c1 = new DummyCard("A");
        DummyCard c2 = new DummyCard("B");

        deck.add(c1);
        deck.add(c2);

        assertEquals(2, deck.getSize());
        assertTrue(deck.isFull());

        // Ya no debería poder agregar
        assertThrows(IllegalStateException.class, () -> deck.add(new DummyCard("C")));
    }

    @Test
    void testRemoveCard() {
        CardDeck deck = new CardDeck(5);

        DummyCard c1 = new DummyCard("X");
        DummyCard c2 = new DummyCard("Y");

        deck.add(c1);
        deck.add(c2);

        deck.remove(c1);

        List<Card> cards = deck.getCards();
        assertEquals(1, cards.size());
        assertEquals("Y", cards.get(0).getName());
    }

    @Test
    void testGetCardsReturnsImmutableList() {
        CardDeck deck = new CardDeck(2);
        DummyCard c1 = new DummyCard("A");
        deck.add(c1);

        List<Card> list = deck.getCards();
        assertThrows(UnsupportedOperationException.class, () -> list.add(c1));
    }

    @Test
    void testGetCardNames() {
        CardDeck deck = new CardDeck(3);

        deck.add(new DummyCard("One"));
        deck.add(new DummyCard("Two"));

        String[] names = deck.getCardNames();

        assertArrayEquals(new String[]{"One", "Two"}, names);
    }

    @Test
    void testToStringFormat() {
        CardDeck deck = new CardDeck(2);
        deck.add(new DummyCard("Fireball"));

        String s = deck.toString();

        assertTrue(s.contains("1/2"));
        assertTrue(s.contains("Fireball"));
    }

    @Test
    void testSetMaxSize() {
        CardDeck deck = new CardDeck(2);
        deck.setMaxSize(5);

        assertEquals(5, deck.getMaxSize());
    }

    @Test
    void testIsEmptyAndIsFull() {
        CardDeck deck = new CardDeck(1);

        assertTrue(deck.isEmpty());
        assertFalse(deck.isFull());

        deck.add(new DummyCard("A"));
        assertFalse(deck.isEmpty());
        assertTrue(deck.isFull());
    }

    @Test
    void testAddNullCardThrows() {
        CardDeck deck = new CardDeck(2);

        assertThrows(RuntimeException.class, () -> deck.add(null));
    }

    @Test
    void testRemoveNullCardThrows() {
        CardDeck deck = new CardDeck(2);

        assertThrows(RuntimeException.class, () -> deck.remove(null));
    }
}
