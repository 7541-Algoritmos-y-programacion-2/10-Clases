package org.thegoats.rolgar2.world;

import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.bitmaps.Bitmap;
import org.thegoats.rolgar2.util.io.bitmaps.BitmapViewer;

import java.awt.*;
import java.util.Collections;
import java.util.Map;

public class WorldViewer {
    private Map<String, Bitmap> floorBitmapMap;
    private Map<String, Bitmap> wallBitmapMap;
    private Map<String, Bitmap> cardBitmapMap;
    private Bitmap characterBitmap;
    private Bitmap enemyCharacterBitmap;
    private Bitmap enemyBitmap;
    private Bitmap allieBitmap;
    private int cellWidth;
    private int cellHeight;
    private Color backgroundColor;
    private Color gradientFrom;
    private Color gradientTo;
    private final Font nameFont  = new Font("Monospaced", Font.BOLD, 12);
    private Bitmap activeLayerBitmap = null;

    public WorldViewer(Map<String, Bitmap> floorBitmapMap,
                       Map<String, Bitmap> wallBitmapMap,
                       Map<String, Bitmap> cardBitmapMap,
                       Bitmap characterBitmap,
                       Bitmap enemyCharacterBitmap,
                       Bitmap enemyBitmap,
                       Bitmap allieBitmap,
                       Color backgroundColor,
                       Color gradientFrom,
                       Color gradientTo,
                       int cellWidth,
                       int cellHeight) {
        setCellHeight(cellHeight);
        setCellWidth(cellWidth);
        setBackgroundColor(backgroundColor);
        setGradientFrom(gradientFrom);
        setGradientTo(gradientTo);
        setFloorBitmapMap(floorBitmapMap);
        setWallBitmapMap(wallBitmapMap);
        setCardBitmapMap(cardBitmapMap);
        setCharacterBitmap(characterBitmap);
        setEnemyCharacterBitmap(enemyCharacterBitmap);
        setEnemyBitmap(enemyBitmap);
        setAllieBitmap(allieBitmap);
    }

    /**
     * @return Devuelve el ancho en pixeles de una celda
     */
    public int getCellWidth() {
        return cellWidth;
    }

    /**
     * @return Devuelve el alto en pixeles de una celda
     */
    public int getCellHeight() {
        return cellHeight;
    }

    /**
     * @return Devuelve el color de fondo de una celda
     */
    public Color getBackgroundColor() {
        return backgroundColor;
    }

    /**
     * @return Devuelve el color inicial de un degradado
     */
    public Color getGradientFrom() {
        return gradientFrom;
    }

    /**
     * @return Devuelve el color final de un degradado
     */
    public Color getGradientTo() {
        return gradientTo;
    }


    /**
     * @return true si tiene un bitmap actual
     */
    public boolean hasActiveLayerBitmap() {
        return activeLayerBitmap != null;
    }

    /**
     * Establece el ancho en pixeles de una celda
     * @param cellWidth debe ser positivo
     */
    public void setCellWidth(int cellWidth) {
        Assert.positive(cellWidth, "cellWidth");
        this.cellWidth = cellWidth;
    }

    /**
     * Establece el alto en pixeles de una celda
     * @param cellHeight debe ser positivo
     */
    public void setCellHeight(int cellHeight) {
        Assert.positive(cellHeight, "cellHeight");
        this.cellHeight = cellHeight;
    }

    /**
     * Establece el color de fondo de una celda
     * @param backgroundColor no puede ser nulo
     */
    public void setBackgroundColor(Color backgroundColor) {
        Assert.notNull(backgroundColor, "backgroundColor");
        this.backgroundColor = backgroundColor;
    }

    /**
     * Establece el color inicial de un degradado
     * @param gradientFrom no puede ser nulo
     */
    public void setGradientFrom(Color gradientFrom) {
        Assert.notNull(gradientFrom, "gradientFrom");
        this.gradientFrom = gradientFrom;
    }

    /**
     * Establece el color final de un degradado
     * @param gradientTo no puede ser nulo
     */
    public void setGradientTo(Color gradientTo) {
        Assert.notNull(gradientTo, "gradientTo");
        this.gradientTo = gradientTo;
    }

    /**
     * Establece el mapa de bitmaps de piso
     * @param floorBitmapMap no puede ser nulo
     */
    public void setFloorBitmapMap(Map<String, Bitmap> floorBitmapMap) {
        Assert.notNull(floorBitmapMap, "floorBitmapMap");
        this.floorBitmapMap = floorBitmapMap;
    }

    /**
     * Establece el mapa de bitmaps de pared
     * @param wallBitmapMap no puede ser nulo
     */
    public void setWallBitmapMap(Map<String, Bitmap> wallBitmapMap) {
        Assert.notNull(wallBitmapMap, "wallBitmapMap");
        this.wallBitmapMap = wallBitmapMap;
    }

    /**
     * Establece el mapa de bitmaps de cartas
     * @param cardBitmapMap no puede ser nulo
     */
    public void setCardBitmapMap(Map<String, Bitmap> cardBitmapMap) {
        Assert.notNull(cardBitmapMap, "cardBitmapMap");
        this.cardBitmapMap = cardBitmapMap;
    }

    /**
     * Establece el bitmap utilizado para representar al personaje
     * @param characterBitmap no puede ser nulo
     */
    public void setCharacterBitmap(Bitmap characterBitmap) {
        Assert.notNull(characterBitmap, "characterBitmap");
        this.characterBitmap = characterBitmap;
    }

    /**
     * Establece el bitmap utilizado para representar al personaje enemigo
     * @param enemyCharacterBitmap no puede ser nulo
     */
    public void setEnemyCharacterBitmap(Bitmap enemyCharacterBitmap) {
        Assert.notNull(enemyCharacterBitmap, "enemyCharacterBitmap");
        this.enemyCharacterBitmap = enemyCharacterBitmap;
    }

    public void setEnemyBitmap(Bitmap enemy){
        Assert.notNull(enemy, "enemyBitmap");
        this.enemyBitmap = enemy;
    }

    public void setAllieBitmap(Bitmap allieBitmap){
        Assert.notNull(allieBitmap, "allieBitmap");
        this.allieBitmap = allieBitmap;
    }


    /**
     * Muestra las capas del mundo
     * @param world no puede ser nulo
     */
    public void instanceLayer(World world) {
        Assert.notNull(world, "world");
        this.activeLayerBitmap = new Bitmap(
                cellWidth * world.getColumnCount(),
                cellHeight * world.getRowCount()
        );;

    }

    /**
     * Muestra el bitmap de la capa
     */
    public void showLayer(){
        Assert.isTrue(hasActiveLayerBitmap(), "Debe haberse instanciado el bitmap");
        BitmapViewer.showBitmaps(Collections.singleton(activeLayerBitmap));
    }

    /**
     * Actualiza el bitmap
     * @param world no null
     * @param gameCharacter no null
     * @param layer entre 0 y layerCount-1
     */
    public void updateLayer(World world, GameCharacter gameCharacter, int layer) {
        Assert.notNull(activeLayerBitmap, "activeLayerBitmap");
        Assert.notNull(world, "world");
        Assert.notNull(gameCharacter, "gameCharacter");
        Assert.inRange(layer, 0, world.getLayerCount() - 1, "layer");
        // Limpia el bitmap reutilizado
        activeLayerBitmap.fill(backgroundColor);

        int characterRow = gameCharacter.getWorldCell().getPosition().getRow();
        int characterColumn = gameCharacter.getWorldCell().getPosition().getColumn();
        int characterVision = gameCharacter.getCharacterData().getVision();

        for (int row = Math.max(0, characterRow - characterVision);
             row <= Math.min(characterRow + characterVision, world.getRowCount() - 1);
             row++) {

            for (int col = Math.max(0, characterColumn - characterVision);
                 col <= Math.min(characterColumn + characterVision, world.getColumnCount() - 1);
                 col++) {

                var cell = world.getCell(row, col, layer);

                int x = col * cellWidth;
                int y = row * cellHeight;

                // floor
                cell.getFloor().ifPresent(floor -> {
                    var bmp = floorBitmapMap.get(floor.name());
                    if (bmp != null)
                        activeLayerBitmap.pasteBitmap(bmp.scaled(cellWidth, cellHeight), x, y);
                });

                // wall
                cell.getWall().ifPresent(wall -> {
                    var bmp = wallBitmapMap.get(wall.name());
                    if (bmp != null)
                        activeLayerBitmap.pasteBitmap(bmp.scaled(cellWidth, cellHeight), x, y);
                });

                // card
                cell.getCard().ifPresent(card -> {
                    var bmp = cardBitmapMap.get(card.getClass().getName());
                    if (bmp != null)
                        activeLayerBitmap.pasteBitmap(bmp.scaled(cellWidth, cellHeight), x, y);
                });

                // character
                cell.getCharacter().ifPresent(character -> {

                    if (!character.getCharacterData().isVisible()
                            && !character.equals(gameCharacter)) {
                        return;
                    }

                    Bitmap bmp;

                    if (!character.isPlayerCharacter()) {
                        bmp = enemyBitmap;
                    } else if (character.equals(gameCharacter)) {
                        bmp = characterBitmap;
                    } else if (gameCharacter.isAllied() &&
                            gameCharacter.getAlliance().getAllies()
                                    .contains((Player)character.getActor())) {
                        bmp = allieBitmap;
                    } else {
                        bmp = enemyCharacterBitmap;
                    }

                    activeLayerBitmap.pasteBitmap(bmp.scaled(cellWidth, cellHeight), x, y);

                    // nombre
                    if (character.isPlayerCharacter()) {
                        String name = character.getName();
                        activeLayerBitmap.drawString(
                                name, x + 30, y + cellHeight - 2,
                                Color.WHITE, nameFont
                        );
                    }
                });
            }
        }
    }

}