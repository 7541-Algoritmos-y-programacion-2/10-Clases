package org.thegoats.rolgar2.character;

import org.thegoats.rolgar2.card.CardDeck;
import org.thegoats.rolgar2.util.Assert;

import org.thegoats.rolgar2.util.structures.lists.TheGoatsLinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class CharacterData {
    //
    // Constantes estaticas
    //

    public static final float MIN_INCOMING_DAMAGE_FACTOR = 0.0f;
    public static final float MAX_INCOMING_DAMAGE_FACTOR = 2.0f;

    //
    // Atributos privados
    //

    private int health;
    private int maxHealth;
    private int strength;
    private int vision;
    private boolean visible = true;
    private boolean isFreezed = false;
    private double incomingDamageFactor;
    private int regeneration;
    private int turnsToRegenerate;
    private int moves;
    private int kills = 0;
    private final CardDeck deck;
    private List<StatusEffect> effects = new TheGoatsLinkedList<>();

    //
    // Constructor
    //

    /**
     * @param maxHealth Debe ser mayor a 0, vida maxima del personaje
     * @param strength Debe ser mayor o 0, daño del personaje
     * @param deckSize Debe ser mayor a 0, tamaño maximo que puede tomar el inventario (mazo de cartas)
     * @param moves Debe ser mayor a cero
     * @param incomingDamageFactor mayor a cero, multiplicador de daño recibido
     * @param vision mayor a cero, rango de vision del personaje
     * @param regeneration mayor a cero, regeneracion por turno
     */
    public CharacterData(int maxHealth,
                         int strength,
                         int deckSize,
                         int moves,
                         double incomingDamageFactor,
                         int vision,
                         int regeneration,
                         int turnsToRegenerate) {
        setRegeneration(regeneration);
        setTurnsToRegenerate(turnsToRegenerate);
        setMaxHealth(maxHealth);
        setHealth(maxHealth); // la vida inicial es la vida maxima
        setStrength(strength);
        setMoves(moves);
        setIncomingDamageFactor(incomingDamageFactor);
        setVision(vision);
        this.deck = new CardDeck(deckSize);
    }

    //
    // Comportamiento
    //

    /**
     * Actualiza la lista de efectos activos
     */
    public void updateEffects() {
        // deja en la lista solo los efectos que no expiraron
        effects = effects.stream().filter((effect) -> {
            effect.tick();

            if (!effect.isExpired())
                return true;

            effect.onRemove();
            return false;
        }).collect(Collectors.toCollection(TheGoatsLinkedList::new));
    }

    //
    // Setters compuestos
    //

    /**
     * Reduce la vida y la trunca en 0
     * @param damage Debe ser mayor a 0
     */
    public void takeDamage(int damage){
        Assert.nonNegative(damage, "damage");
        setHealth(Math.max(getHealth() - (int)(damage * incomingDamageFactor), 0));
    }

    /**
     * Aumenta la vida y la trunca a maxHealth
     * @param health puntos de vida a recuperar
     */
    public void recoverHealth(int health){
        Assert.nonNegative(health, "health");
        setHealth(Math.min(getHealth() + health, maxHealth));
    }

    /**
     * Recupera regeneration puntos de vida
     */
    public void regenerate(){
        recoverHealth(regeneration);
    }


    //
    // Getters
    //

    /**
     * @return la vision del personaje
     */
    public int getVision(){
        return this.vision;
    }

    /**
     * @return La vida actual del personaje
     */
    public int getHealth(){
        return this.health;
    }

    /**
     * @return las kills de character
     */
    public int getKills() {
        return kills;
    }

    /**
     * @return La vida máxima del personaje
     */
    public int getMaxHealth(){
        return this.maxHealth;
    }

    /**
     * @return El daño que inflige el personaje por cada golpe
     */
    public int getStrength(){
        return this.strength;
    }

    /**
     * @return regeneracion
     */
    public int getRegeneration(){
        return regeneration;
    }

    /**
     * @return turnos que tarda en regenerar vida por sí mismo
     */
    public int getTurnsToRegenerate() {
        return turnsToRegenerate;
    }

    /**
     * @return true si el personaje es visible, false si es invisible
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * @return true si esta congelado
     */
    public boolean isFreezed() {
        return isFreezed;
    }

    /**
     * @return true si no esta congelado
     */
    public boolean isNotFreezed(){
        return !isFreezed;
    }
    /**
     * @return Factor por el cual se multiplica el daño entrante, estará entre MIN_INCOMING_DAMAGE_FACTOR y MAX_INCOMING_DAMAGE_FACTOR
     */
    public double getIncomingDamageFactor() {
        return incomingDamageFactor;
    }

    /**
     * @return Una copia de la lista de efectos activos en el personaje
     */
    public List<StatusEffect> getEffects() {
        return List.copyOf(effects);
    }

    /**
     * @return mazo o inventario del personaje
     */
    public CardDeck getDeck() {
        return deck;
    }

    /**
     * @return movimientos por turno del personaje
     */
    public int getMoves() {
        return moves;
    }

    //
    // Setters
    //

    /**
     *@param vision mayor a cero, modulo de vision
     */
    public void setVision(int vision){
        Assert.positive(vision, "vision");
        this.vision = vision;
    }

    /**
     * @param health Debe ser mayor o igual a 0 y menor o igual a maxHealth
     */
    public void setHealth(int health) {
        Assert.inRange(health,0, maxHealth, "health");
        this.health = health;
    }

    /**
     * @param maxHealth Debe ser mayor a 0
     */
    public void setMaxHealth(int maxHealth) {
        Assert.positive(maxHealth, "maxHealth");
        this.maxHealth = maxHealth;
    }
    /**
     * @param kills debe ser mayor o igual a 0
     */
    public void setKills(int kills) {
        Assert.nonNegative(kills, "kills");
        this.kills = kills;
    }

    /**
     * @param strength Debe ser mayor o igual a 0
     */
    public void setStrength(int strength) {
        Assert.positive(strength, "strength");
        this.strength = strength;
    }

    /**
     * Si el personaje era invisible, lo vuelve visible
     */
    public void setVisible() {
        this.visible = true;
    }

    /**
     * Si el personaje era visible, lo vuelve invisible
     */
    public void setInvisible() {
        this.visible = false;
    }

    /**
     * Si el personaje estaba descongelado
     */
    public void freeze() {
        this.isFreezed = true;
    }

    /**
     * Si el personaje estaba congelado, lo descongela
     */
    public void unfreeze() {
        this.isFreezed = false;
    }

    /**
     * @param incomingDamageFactor cualquier double, se recorta entre MIN_INCOMING_DAMAGE_FACTOR y MAX_INCOMING_DAMAGE_FACTOR
     */
    public void setIncomingDamageFactor(double incomingDamageFactor) {
        Assert.positive(incomingDamageFactor, "incomingDamageFactor");
        this.incomingDamageFactor = Math.clamp(incomingDamageFactor, MIN_INCOMING_DAMAGE_FACTOR, MAX_INCOMING_DAMAGE_FACTOR);
    }

    /**
     * Dado unos movimientos por turno dados, si son validos los setea.
     * @param moves movimientos por turno del personaje
     */
    public void setMoves(int moves) {
        Assert.positive(moves, "moves");
        this.moves = moves;
    }

    /**
     * Dada una regeneracion, si es valida la setea
     * @param regeneration positivo
     */
    public void setRegeneration(int regeneration){
        Assert.positive(regeneration, "regeneration");
        this.regeneration = regeneration;
    }

    /**
     * Dados unos turnos para regenerarse, si son validos los setea
     * @param turnsToRegenerate positivo
     */
    public void setTurnsToRegenerate(int turnsToRegenerate) {
        Assert.positive(turnsToRegenerate, "turnsToRegenerate");
        this.turnsToRegenerate = turnsToRegenerate;
    }


    /**
     * Aplica un efecto al personaje y lo agrega a la lista de efectos activos
     * @param effect efecto a aplicar, no nulo, si el mismo objeto se paso dos veces, se ignora
     */
    public void applyEffect(StatusEffect effect) {
        Assert.notNull(effect, "effect");

        // si la referencia al efecto ya existe en la lista, no lo vuelve a agregar
        if (effects.stream().anyMatch((incomingEffect) -> effect == incomingEffect)) {
            return; // en vez de lanzar excepcion, lo ignora
        }

        effects.add(effect);
        effect.onApply();
    }

    //
    // Estado
    //

    /**
     * @return True si el personaje esta vivo, False si murio
     */
    public boolean isAlive(){
        return getHealth() > 0;
    }

    /**
     * @return True si el personaje murio, False si esta vivo
     */
    public boolean isDead(){
        return !isAlive();
    }

    //
    // Implemetacion de metodos abstractos
    //

    /**
     * @return version en formato String del personaje
     */
    @Override
    public String toString() {
        return String.format("CharacterData[health=%d, maxHealth=%d, strength=%d, visible=%s, isFreezed=%s, incomingDamageFactor=%.2f, moves=%d, deck=%s]",
                health, maxHealth, strength, visible, isFreezed, incomingDamageFactor, moves, deck.toString()
        );
    }

    /**
     * @param obj el otro personaje con el que comparar
     * @return true si son iguales, unicamente si son la misma referencia.
     */
    @Override
    public boolean equals(Object obj) {
        // si dos personajes comparten nombre y stats, siguen siendo personajes distintos, por lo tanto, solo su referencia los diferencia
        return this == obj;
    }
}