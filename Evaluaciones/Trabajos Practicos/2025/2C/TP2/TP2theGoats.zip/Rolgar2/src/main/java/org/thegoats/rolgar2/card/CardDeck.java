package org.thegoats.rolgar2.card;
import org.thegoats.rolgar2.util.Assert;

import java.util.Arrays;
import org.thegoats.rolgar2.util.structures.lists.TheGoatsLinkedList;
import java.util.List;

/**
 * Mazo de cartas que tendran los jugadores o inventario
 */

public class CardDeck {
    private final List<Card> cards;
    private int maxSize;

    /**
     * Crea el mazo de cartas con un tope de 'size' cartas
     * @param size mayor a cero
     */
    public CardDeck(int size) {
        this.cards = new TheGoatsLinkedList<>();
        setMaxSize(size);
    }


    /**
     *
     * @param card no null
     */
    public void add(Card card) {
        Assert.notNull(card, "carta");
        if (cards.size() >= maxSize) {
            throw new IllegalStateException("El mazo ya esta lleno");
        }

        cards.add(card);
    }

    /**
     * Setea el tope de cartas del mazo
     * @param maxSize mayor a cero
     */
    public void setMaxSize(int maxSize){
        Assert.positive(maxSize, "tamaño del inventario");
        this.maxSize = maxSize;
    }

    /**
     * Remueve una carta dada del mazo, esto se resuelve segun el equals de card
     * @param card no null, carta a remover del mazo
     */
    public void remove(Card card) {
        Assert.notNull(card, "carta a buscar");
        cards.remove(card);
    }

    /**
     * Devuelve una lista de las cartas, no modificable, para solo lectura
     * @return lista inmutable de las cartas
     */
    public List<Card> getCards() {
        return List.copyOf(cards);
    }


    /**
     * Devuelve la cantidad de cartas que posee el mazo
     * @return cantidad actual de cartas
     */
    public int getSize() {
        return cards.size();
    }

    /**
     *
     * @return maximo tamaño que puede tomar el mazo
     */
    public int getMaxSize() {
        return maxSize;
    }

    /**
     * @return true si el mazo ya esta lleno, false caso contrario
     */
    public boolean isFull() {
        return maxSize == cards.size();
    }

    /**
     * @return true si el mazo esta vacio, false caso contrario
     */
    public boolean isEmpty(){
        return cards.isEmpty();
    }

    public String[] getCardNames(){
        String[] cardNames = new String[cards.size()];
        int i=0;
        for(Card card: cards){
            cardNames[i] = card.getName();
            i++;
        }
        return cardNames;
    }
    @Override
    public String toString(){
        return String.format("CardDeck[%s/%s, %s]", getSize(), getMaxSize(), Arrays.toString(getCardNames()));
    }
}