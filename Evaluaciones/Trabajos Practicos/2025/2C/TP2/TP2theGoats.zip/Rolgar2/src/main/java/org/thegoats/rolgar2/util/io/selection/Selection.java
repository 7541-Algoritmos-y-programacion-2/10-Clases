package org.thegoats.rolgar2.util.io.selection;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.structures.sets.TheGoatsSet;

import java.util.*;

/**
 * Representa una selección genérica de elementos, permitiendo configurar opciones,
 * mensajes para mostrar por pantalla y un límite de intentos para elegir una opción.
 */
public abstract class Selection<T> {

    /**
     * Representa una opción dentro de una selección.
     */
    public static class SelectionOption<T> {
        private final T item;

        /**
         * Crea una nueva opción con el valor especificado.
         * @param item el valor asociado a la opción
         * @throws RuntimeException si el item es null
         */
        private SelectionOption(T item) {
            Assert.notNull(item, "item");
            this.item = item;
        }

        /**
         * @return el valor del ítem
         */
        public T getItemValue() {
            return item;
        }

        /**
         * @return representación texto del ítem
         */
        @Override
        public String toString() {
            return item.toString();
        }

        /**
         * @return valor hash del ítem
         */
        @Override
        public int hashCode() {
            return item.hashCode();
        }
    }

    /**
     * Variante de SelectionOption que permite especificar un texto fijo
     * para representar la opción.
     */
    public static class PresetStringSelectionOption<T> extends SelectionOption<T> {
        private final String itemString;

        /**
         * Crea una nueva opción con texto predefinido.
         * @param item el valor del ítem
         * @param itemString representación textual fija
         * @throws RuntimeException si itemString es null
         */
        private PresetStringSelectionOption(T item, String itemString) {
            super(item);
            Assert.notNull(itemString, "itemString");
            this.itemString = itemString;
        }

        /**
         * @return el texto predefinido de esta opción.
         */
        @Override
        public String toString() {
            return itemString;
        }
    }

    protected final Set<SelectionOption<T>> options = new TheGoatsSet<>();

    private int maxTries = 1;
    private String selectionHeader = null;
    private String selectionPrompt = null;
    private String selectionSuccessMessage = null;
    private String selectionFailMessage = null;
    private String selectionRetryMessage = null;

    /**
     * Obtiene la cantidad máxima de intentos permitidos para realizar la selección.
     * @return número máximo de intentos
     */
    public int getMaxTries() {
        return maxTries;
    }

    /**
     * Obtiene el encabezado mostrado antes de listar las opciones.
     * @return encabezado de selección, o null si no se definió
     */
    public String getSelectionHeader() {
        return selectionHeader;
    }

    /**
     * Obtiene el mensaje que solicita al usuario elegir una opción.
     * @return mensaje de solicitud, o null si no se definió
     */
    public String getSelectionPrompt() {
        return selectionPrompt;
    }

    /**
     * Obtiene el mensaje mostrado al seleccionar una opción correctamente.
     * @return mensaje de éxito, o null si no se definió
     */
    public String getSelectionSuccessMessage() {
        return selectionSuccessMessage;
    }

    /**
     * Obtiene el mensaje mostrado cuando la selección falla.
     * @return mensaje de fallo, o null si no se definió
     */
    public String getSelectionFailMessage() {
        return selectionFailMessage;
    }

    /**
     * Obtiene el mensaje mostrado cuando se permite reintentar la selección.
     * @return mensaje de reintento, o null si no se definió
     */
    public String getSelectionRetryMessage() {
        return selectionRetryMessage;
    }

    /**
     * Configura el máximo de intentos permitidos.
     * @param maxTries cantidad máxima de intentos, debe ser positiva
     * @return esta selección para encadenamiento
     * @throws IllegalArgumentException si maxTries no es positivo
     */
    public Selection<T> maxTries(int maxTries) {
        Assert.positive(maxTries, "maxTries");
        this.maxTries = maxTries;
        return this;
    }

    /**
     * Configura el encabezado de la selección.
     * @param selectHeader texto del encabezado
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> selectionHeader(String selectHeader) {
        this.selectionHeader = selectHeader;
        return this;
    }

    /**
     * Configura el mensaje de solicitud de entrada.
     * @param selectPrompt mensaje de solicitud
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> selectionPrompt(String selectPrompt) {
        this.selectionPrompt = selectPrompt;
        return this;
    }

    /**
     * Configura el mensaje mostrado al seleccionar exitosamente.
     *
     * @param successOnSelectMessage mensaje de éxito
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> selectionSuccessMessage(String successOnSelectMessage) {
        this.selectionSuccessMessage = successOnSelectMessage;
        return this;
    }

    /**
     * Configura el mensaje mostrado al fallar la selección.
     *
     * @param failOnSelectMessage mensaje de error
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> selectionFailMessage(String failOnSelectMessage) {
        this.selectionFailMessage = failOnSelectMessage;
        return this;
    }

    /**
     * Configura el mensaje mostrado al reintentar la selección.
     *
     * @param retryMessage mensaje de reintento
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> selectionRetryMessage(String retryMessage) {
        this.selectionRetryMessage = retryMessage;
        return this;
    }

    /**
     * Agrega una nueva opción basada en el valor del ítem.
     *
     * @param item elemento a agregar
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> addOption(T item) {
        options.add(new SelectionOption<>(item));
        return this;
    }

    /**
     * Agrega una nueva opción con un texto predefinido.
     * @param itemString texto que representa la opción
     * @param item       valor asociado
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> addOption(String itemString, T item) {
        options.add(new PresetStringSelectionOption<>(item, itemString));
        return this;
    }

    /**
     * Agrega todas las opciones contenidas en una lista de ítems.
     * @param items lista de elementos
     * @return esta selección para poder encadenar metodos
     */
    public Selection<T> addAllOptions(List<T> items) {
        for (T item : items) {
            addOption(item);
        }
        return this;
    }

    /**
     * Agrega todas las opciones especificadas con textos customizados.
     * @param items lista de ítems
     * @param itemStrings lista de textos, debe tener el mismo tamaño que items
     * @return esta selección para poder encadenar metodos
     * @throws IllegalArgumentException si ambas listas no tienen el mismo tamaño
     */
    public Selection<T> addAllOptions(List<T> items, List<String> itemStrings) {
        if (items.size() != itemStrings.size()) {
            throw new IllegalArgumentException();
        }

        for (int i = 0; i < items.size(); i++) {
            addOption(itemStrings.get(i), items.get(i));
        }

        return this;
    }

    /**
     * Selecciona según la implementación concreta.
     * @return un Optional que contiene el ítem seleccionado, o vacío si no se logró seleccionar ninguno
     */
    public abstract Optional<T> select();
}
