package org.thegoats.rolgar2.world;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WorldNeighborsTest {

    @Test
    void centerCellHas26Neighbors() {
        // Mundo 3x3x3 => la celda (1,1,1) está completamente “rodeada”
        World world = new World(3, 3, 3);

        WorldCell center = world.getCell(1, 1, 1);
        List<WorldCell> neighbors = center.getNeighbors();

        // 1) Debe tener exactamente 26 vecinos
        assertEquals(26, neighbors.size(), "La celda central debe tener 26 vecinos");

        // 2) Ningún vecino puede ser la misma celda
        neighbors.forEach(n -> assertNotSame(center, n, "Un vecino no puede ser la celda misma"));

        // 3) Todos los vecinos deben ser adyacentes (diferencia máx 1 en cada coord, y no iguales)
        neighbors.forEach(n -> {
            Position p0 = center.getPosition();
            Position p1 = n.getPosition();

            int dr = Math.abs(p0.getRow()    - p1.getRow());
            int dc = Math.abs(p0.getColumn() - p1.getColumn());
            int dl = Math.abs(p0.getLayer()  - p1.getLayer());

            assertTrue(dr <= 1 && dc <= 1 && dl <= 1,
                    "El vecino no es adyacente a la celda central: " + p1);

            assertFalse(dr == 0 && dc == 0 && dl == 0,
                    "La celda central no puede ser vecina de sí misma");
        });
    }

    @Test
    void cornerCell000Has7Neighbors() {
        // mismo mundo 3x3x3
        World world = new World(3, 3, 3);

        // esquina (0,0,0)
        WorldCell corner = world.getCell(0, 0, 0);
        List<WorldCell> neighbors = corner.getNeighbors();

        // En una esquina de un cubo 3x3x3 hay 7 vecinos posibles
        assertEquals(7, neighbors.size(), "La esquina (0,0,0) debe tener 7 vecinos");
    }
}
