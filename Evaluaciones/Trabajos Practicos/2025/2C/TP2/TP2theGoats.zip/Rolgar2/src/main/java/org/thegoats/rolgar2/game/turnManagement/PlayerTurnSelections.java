package org.thegoats.rolgar2.game.turnManagement;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.card.*;
import org.thegoats.rolgar2.character.CharacterData;
import org.thegoats.rolgar2.game.Game;
import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.game.actions.AllianceAction;
import org.thegoats.rolgar2.game.actions.MovementDirections;
import org.thegoats.rolgar2.game.actions.TurnAction;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.interaction.ConsoleSelection;
import org.thegoats.rolgar2.util.io.selection.Selection;
import org.thegoats.rolgar2.util.structures.lists.TheGoatsLinkedList;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

public class PlayerTurnSelections {

    /**
     * Actualiza la seleccion de cartas disponibles para el jugador
     * @param deck mazo desde el cual se obtendran las cartas, no puede ser nulo
     * @param prompt mensaje que se le muestra al usuario al solicitar la eleccion de carta, no puede ser nulo
     */
    public static Selection<Card> cardSelection(CardDeck deck, String prompt) {
        Assert.notNull(deck, "deck no puede ser null");
        Assert.notNull(prompt, "prompt no puede ser null");

        return new ConsoleSelection<Card>()
                .addAllOptions(deck.getCards())
                .maxTries(3)
                .selectionPrompt(prompt)
                .selectionRetryMessage("Opcion invalida.");
    }

    /**
     * Crea una seleccion booleana de dos opciones: si y no
     * @param prompt mensaje que se le mostrara al usuario para solicitar la eleccion, no debe ser nulo
     * @param retryMessage mensaje que se mostrara cuando la eleccion sea invalida, no debe ser nulo
     * @return Devuelve la seleccion creada
     */
    public static Selection<Boolean> booleanSelection(String prompt, String retryMessage) {
        return new ConsoleSelection<Boolean>()
                .addOption("Si", true)
                .addOption("No", false)
                .maxTries(3)
                .selectionPrompt(prompt)
                .selectionRetryMessage(retryMessage);
    }

    /**
     * Actualiza la lista de los personajes a los que se les puede aplicar una carta
     */
    public static Selection<GameCharacter> buildCardTargetSelection(Game game) {
        List<GameCharacter> alive = new TheGoatsLinkedList<>();
        List<String> aliveNames = new TheGoatsLinkedList<>();

        for(GameCharacter character : game.getGameCharacters()){
            CharacterData characterData = character.getCharacterData();
            if(characterData.isAlive()){
                alive.add(character);
                aliveNames.add(character.getActor().getName());
            }
        }

        return new ConsoleSelection<GameCharacter>()
                .addAllOptions(alive, aliveNames)
                .maxTries(3)
                .selectionPrompt("¿A quién se la quiere aplicar?")
                .selectionRetryMessage("Opción inválida.");
    }


    /**
     * Actualiza la lista de los personajes a los que se les puede robar una carta
     * @param self no null
     */
    public static Selection<CardDeck> buildStolenDeckSelection(GameCharacter self) {
        Assert.notNull(self, "self no puede ser null");
        List<CardDeck> validDecks = new TheGoatsLinkedList<>();
        List<String> validCharactersStrings = new TheGoatsLinkedList<>();

        for(GameCharacter character : self.getGame().getGameCharacters()){
            CharacterData characterData = character.getCharacterData();
            if(!character.equals(self) &&
                    !characterData.getDeck().isEmpty() &&
                    characterData.isAlive())
            {
                validDecks.add(character.getCharacterData().getDeck());
                validCharactersStrings.add("Mazo de "+ character.getActor().getName()+ ": "+character.getCharacterData().getDeck().toString());
            }
        }

        Assert.positive(validDecks.size(), "No hay ninguna carta disponible para robar");

        return new ConsoleSelection<CardDeck>()
                .maxTries(3)
                .addAllOptions(validDecks, validCharactersStrings)
                .selectionPrompt("¿A quién le desea robar una carta?")
                .selectionRetryMessage("Opción inválida.");
    }

    /**
     * selector de gameCharacter cuyas opciones son los gameCharacters vivos
     */
    public static Selection<GameCharacter> buildGameCharacterSelection(Game game) {
        Assert.notNull(game, "game no puede ser null");
        List<GameCharacter> validCharacters = new TheGoatsLinkedList<>();
        List<String> validCharacterNames = new TheGoatsLinkedList<>();

        for(GameCharacter character: game.getGameCharacters()){
            if(character.getCharacterData().isAlive()){
                validCharacters.add(character);
                validCharacterNames.add(character.getActor().getName());
            }
        }

        Assert.positive(validCharacters.size(), "No hay personajes válidos");

        return new ConsoleSelection<GameCharacter>()
                .addAllOptions(validCharacters, validCharacterNames)
                .maxTries(3)
                .selectionPrompt("¿Qué jugador desea teletransportar?")
                .selectionRetryMessage("Opción inválida.");
    }

    /**
     * @return Selector de acciones de alianza, estando aliado
     */
    public static Selection<AllianceAction> alliedAllianceSelection() {
        return new ConsoleSelection<AllianceAction>()
                .addAllOptions(AllianceAction.getAlliedAllianceActions())
                .maxTries(3)
                .selectionPrompt("¿Qué desea hacer?")
                .selectionRetryMessage("Opción inválida");
    }

    /**
     * @return selector de acciones de alianza, sin estar aliado
     */
    public static Selection<AllianceAction> nonAlliedAllianceSelection(){
        return new ConsoleSelection<AllianceAction>()
                .addAllOptions(AllianceAction.getNotAlliedAllianceActions())
                .maxTries(3)
                .selectionPrompt("¿Qué desea hacer?")
                .selectionRetryMessage("Opción inválida");
    }

    /**
     * @param self no null
     * @return selector de gameCharacter para añadir a la alianza, que unicamente incluye a los que no tienen alianza
     */
    public static Selection<GameCharacter> newAllieSelection(GameCharacter self){
        Assert.notNull(self, "self no puede ser null");
        Selection<GameCharacter> newAllieSelection = new ConsoleSelection<GameCharacter>()
                .maxTries(3)
                .selectionPrompt("¿Quién desea agregar a la alianza?")
                .selectionRetryMessage("Opción inválida");

        for(GameCharacter gameCharacter: self.getGame().getGameCharacters()){
            if(gameCharacter != self &&
                    gameCharacter.isPlayerCharacter() &&
                    !gameCharacter.isAllied() &&
                    gameCharacter.getCharacterData().isAlive()){
                newAllieSelection.addOption(gameCharacter.getActor().getName(), gameCharacter);
            }
        }

        return newAllieSelection;
    }

    /**
     * @param gameCharacter no null, personaje al que se le pide seleccionar
     * @param prompt no null, pregunta que se le hace al usuario para pedir el input
     * @return selector por consola que contiene a los aliados vivos
     */
    public static Selection<GameCharacter> AlliesSelection(GameCharacter gameCharacter, String prompt) {
        Assert.notNull(prompt, "prompt no puede ser null");
        Assert.notNull(gameCharacter, "gameCharacter no puede ser null");
        Assert.isTrue(gameCharacter.isAllied(), "debes estar aliado");
        Game game = gameCharacter.getGame();

        Selection<GameCharacter> alliesSelection = new ConsoleSelection<>();
        alliesSelection.selectionPrompt(prompt)
                .selectionRetryMessage("Opción inválida")
                .maxTries(3);

        for(Player player: gameCharacter.getAlliance().getAllies()){
            GameCharacter ally = game.playerToGameCharacter(player);
            if(!ally.equals(gameCharacter)){
                alliesSelection.addOption(player.getName(), ally);
            }
        }

        return alliesSelection;
    }

    /**
     * @return seleccion de direccion a la que moverse
     */
    public static Selection<MovementDirections> directionSelection(){
        return new ConsoleSelection<MovementDirections>()
                .addAllOptions(Arrays.stream(MovementDirections.values()).toList())
                .maxTries(3)
                .selectionPrompt("¿Hacia que direccion se desea mover?")
                .selectionRetryMessage("Opcion invalida.");
    }

    /**
     * @return selector de accion que comprende sólo las que son validas mientras estás congelado
     */
    public static Selection<TurnAction> freezedTurnSelection(){
        return new ConsoleSelection<TurnAction>()
                .addAllOptions(TurnAction.getFreezedActions())
                .maxTries(3)
                .selectionPrompt("¿Cual sera su proxima accion?")
                .selectionRetryMessage("Opcion invalida.");
    }

    /**
     * @return selector de acciones
     */
    public static Selection<TurnAction> turnSelection(){
        return new ConsoleSelection<TurnAction>()
                .addAllOptions(TurnAction.getActions())
                .maxTries(3)
                .selectionPrompt("¿Cual sera su proxima accion?")
                .selectionRetryMessage("Opcion invalida.");
    }

    public static Optional<Selection<GameCharacter>> attackCharacterSelection(
            List<GameCharacter> enemiesAround,
            GameCharacter gameCharacter,
            Function<Player, GameCharacter> playerToGameCharacter) {
        Assert.notNull(gameCharacter, "gameCharacter no puede ser null");
        Assert.notNull(enemiesAround, "enemiesAround no puede ser null");

        List<GameCharacter> enemies = new TheGoatsLinkedList<>();
        List<String> enemyNames = new TheGoatsLinkedList<>();
        enemies.addAll(enemiesAround);
        if (gameCharacter.isAllied()) {
            enemies.removeAll(
                    gameCharacter.getAlliance().getAllies().stream()
                            .map(playerToGameCharacter)
                            .toList()
            );
        }
        if (enemies.isEmpty()) {
            return Optional.empty();
        }

        for(GameCharacter validEnemy: enemies){
            enemyNames.add(validEnemy.getActor().getName());
        }

        return Optional.of(
                new ConsoleSelection<GameCharacter>()
                        .addAllOptions(enemies, enemyNames)
                        .maxTries(3)
                        .selectionPrompt("¿A qué enemigo quiere atacar?")
                        .selectionRetryMessage("Opcion invalida.")
        );
    }
}