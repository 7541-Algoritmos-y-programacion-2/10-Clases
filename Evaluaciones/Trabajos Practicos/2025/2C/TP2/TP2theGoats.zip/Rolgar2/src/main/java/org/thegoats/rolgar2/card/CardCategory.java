package org.thegoats.rolgar2.card;

public enum CardCategory {
    POSITIVE,
    NEGATIVE,
    NEUTRAL
}
