package org.thegoats.rolgar2.alliance;

import org.thegoats.rolgar2.util.Assert;

/**
 * Alianza que expira luego de que transcurran 'duration' turnos
 */
public class AutoExpirableAlliance extends Alliance {
    private int remainingTurns;

    /**
     * Crea una alianza autoexpirable
     * @param duration mayor a cero, duracion que tendra la alianza
     */
    public AutoExpirableAlliance(int duration) {
        Assert.positive(duration, "duration");
        this.remainingTurns = duration;
    }

    /**
     * Actualiza los turnos restantes: si es el último turno, se disuelve la alianza, sino, decrementa los turnos
     * restantes
     */
    public void updateRemainingTurns() {
        if (remainingTurns == 1) {
            disolve();
        } else  {
            remainingTurns--;
        }
    }
}