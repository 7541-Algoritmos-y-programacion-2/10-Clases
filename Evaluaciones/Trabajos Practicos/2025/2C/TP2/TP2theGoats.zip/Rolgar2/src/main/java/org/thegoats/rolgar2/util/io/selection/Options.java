package org.thegoats.rolgar2.util.io.selection;

import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.interaction.Keyboard;

import java.util.Arrays;
import java.util.Optional;

/**
 * Facilita la toma de la entrada de un usuario cuando se le quiere dar elegir entre un conjunto de opciones.
 * Puede crearse una instancia de Options y llamar instancia.choose o puede llamarse Options.choose directamente.
 * @deprecated Primera aproximacion para lo que ahora es {@link Selection}
 * @see Selection
 */
@Deprecated
public final class Options {
    private String promptMessage;
    private String[] options;
    private String retryMessage;
    private int maxRetries;
    public boolean caseInsensitive;

    /**
     * @param promptMessage No null, no vacío, mensaje a mostrar al pedir la entrada del usuario
     * @param options No null, no vacío, ninguno de los strings que contiene debe ser null o vacío, conjunto de opciones
     * @param retryMessage No null, no vacío, mensaje a ser mostrado en cada reintento
     * @param maxRetries Mayor o igual a cero, cantidad de reintentos antes de devolver null
     * @param caseInsensitive Si la eleccion de opciones sera case sensitive o no
     */
    public Options(String promptMessage, String[] options, String retryMessage, int maxRetries, boolean caseInsensitive) {
        setPromptMessage(promptMessage);
        setOptions(options);
        setRetryMessage(retryMessage);
        this.maxRetries = maxRetries;
        this.caseInsensitive = caseInsensitive;
    }

    /**
     * Versión no estatica de Options.choose
     * @return la opción elegida o null en caso de haberse agotado los intentos
     */
    public Optional<String> choose() {
        for (int tryCount = 0; tryCount <= maxRetries; tryCount++) {
            System.out.print(promptMessage + " " + Arrays.toString(options) + ": ");
            String choice = Keyboard.readString();

            if (isValidChoice(choice, options, caseInsensitive)) {
                return Optional.ofNullable(choice);
            }
        }

        return Optional.empty();
    }

    /**
     * @return prompt message, es decir, el mensaje a mostrar al pedir la entrada al usuario
     */
    public String getPromptMessage() {
        return promptMessage;
    }

    /**
     * @return clon inmutable de las opciones
     */
    public String[] getOptions() {
        return options.clone();
    }

    /**
     * @return mensaje de reintento
     */
    public String getRetryMessage() {
        return retryMessage;
    }

    /**
     * @return numero maximo de reintentos
     */
    public int getMaxRetries() {
        return maxRetries;
    }

    /**
     * @param promptMessage No null, no vacío
     */
    public void setPromptMessage(String promptMessage) {
        Assert.notNullOrEmpty(promptMessage, "promptMessage");
        this.promptMessage = promptMessage;
    }

    /**
     * @param options No null, no vacío, ninguno de los strings que contiene debe ser null o vacío
     */
    public void setOptions(String[] options) {
        Assert.notNull(options, "options");
        Assert.positive(options.length, "'options' debe ser no vacío");
        for (String option : options) {
            Assert.notNullOrEmpty(option, "ninguna opción en 'options' debe ser null o vacía");
        }
        this.options = options.clone();
    }

    /**
     * @param retryMessage No null, no vacío
     */
    public void setRetryMessage(String retryMessage) {
        Assert.notNullOrEmpty(promptMessage, "'retryMessage' debe ser no null y no vacío");
        this.retryMessage = retryMessage;
    }

    /**
     * @param maxRetries Mayor o igual a cero
     */
    public void setMaxRetries(int maxRetries) {
        Assert.positive(maxRetries, "'maxRetries' debe ser mayor o igual a cero");
        this.maxRetries = maxRetries;
    }

    /**
     * @param caseInsensitive true si se quiere que la lectura sea case insensitive, false en caso contrario
     */
    public void setCaseInsensitive(boolean caseInsensitive) {
        this.caseInsensitive = caseInsensitive;
    }

    //
    // Los siguientes metodos son puramente auxiliares
    //

    /**
     * Valida que choice se encuentre en options, ya sea case sensitive o case insensitive
     */
    private static boolean isValidChoice(String choice, String[] options, boolean caseInsensitive) {
        // comprueba que choice se encuentre en options
        // usando equalsIgnoreCase o equals si caseInsensitive es true o false respectivamente
        return Arrays.stream(options).anyMatch(caseInsensitive ? choice::equalsIgnoreCase : choice::equals);
    }
}