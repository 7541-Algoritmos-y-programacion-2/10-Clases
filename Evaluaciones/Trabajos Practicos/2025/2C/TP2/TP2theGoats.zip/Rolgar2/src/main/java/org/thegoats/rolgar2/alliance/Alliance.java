package org.thegoats.rolgar2.alliance;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.structures.sets.TheGoatsSet;

import java.util.Set;

/**
 * Alianza de jugadores, implementada con un conjunto
 */
public class Alliance {
    private final Set<Player> allies = new TheGoatsSet<>();
    private boolean inForce = true;

    /**
     * @return conjunto de Players integrantes de la alianza
     */
    public Set<Player> getAllies() {
        return Set.copyOf(this.allies);
    }

    /**
     * Dado un player, si es válido lo agrega a la alianza
     * @param character no null, fuera de la alianza jugador a agregar
     */
    public void addAlly(Player character) {
        Assert.notNull(character, "player");
        Assert.isTrue(!isAlly(character), "El jugador ya esta en la alianza");
        allies.add(character);
    }

    /**
     * Dado un jugador, lo quita de la alianza
     * @param player no null, perteneciente a la alianza
     */
    public void removeAlly(Player player) {
        Assert.notNull(player, "player");
        Assert.isTrue(isAlly(player), "El jugador debe estar aliado para removerlo");
        allies.remove(player);
    }

    /**
     * Dado un jugador, permite conocer si pertenece a la alianza
     * @param player no null, jugador del que se quiere conocer si pertenece a la alianza
     * @return true si esta aliado
     */
    public boolean isAlly(Player player) {
        Assert.notNull(player, "player");
        return allies.contains(player);
    }

    /**
     * @return true si la alianza sigue en pie
     */
    public boolean inForce() {
        return inForce;
    }

    /**
     * @return cantidad de miembros en la alianza
     */
    public int getAlliesCount() {
        return this.allies.size();
    }

    /**
     * Disuelve la alianza
     */
    public void disolve() {
        Assert.isTrue(inForce, "La alianza ya está disuelta");

        allies.clear();

        this.inForce = false;
    }
}