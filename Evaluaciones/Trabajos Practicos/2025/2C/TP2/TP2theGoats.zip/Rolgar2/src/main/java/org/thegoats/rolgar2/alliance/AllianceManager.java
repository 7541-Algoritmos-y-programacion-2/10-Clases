package org.thegoats.rolgar2.alliance;

import org.thegoats.rolgar2.card.Card;
import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.game.turnManagement.PlayerTurnSelections;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.selection.Selection;

import static org.thegoats.rolgar2.game.turnManagement.PlayerTurnSelections.newAllieSelection;

public class AllianceManager {

    /**
     * Le pregunta al jugador con quién quiere hacer la alianza
     * @param gameCharacter no null, no aliado. personaje que quiere crear la alianza
     */
    public static void createAlliance(GameCharacter gameCharacter){
        Assert.notNull(gameCharacter, "gameCharacter");
        Assert.isTrue(!gameCharacter.isAllied(), "gameCharacter ya esta en una alianza");
        Assert.isTrue(gameCharacter.getGame().getNonAlliedPlayerCount() >= 2, "No hay jugadores sin alianza");
        Selection<GameCharacter> newAllieSelection = newAllieSelection(gameCharacter);
        newAllieSelection.select().ifPresent(allie -> {
            var alliance = new Alliance();
            gameCharacter.joinAlliance(alliance);
            allie.joinAlliance(alliance);
            gameCharacter.getGame().addAlliance(alliance);
        });
    }

    /**
     * Le pide al jugador que elija entre los personajes disponibles para aliar a uno.
     * Debe haber personajes sin alianza para agregarlos.
     * @param gameCharacter no null, que pertenezca a una alianza. Jugador que pidio agregar a otro.
     */
    public static void addAllie(GameCharacter gameCharacter){
        Assert.isTrue(gameCharacter.getGame().getNonAlliedPlayerCount() > 0, "No hay jugadores sin alianza");
        Assert.isTrue(gameCharacter.isAllied(), "gameCharacter debe pertenecer a una alianza");
        Assert.notNull(gameCharacter, "gameCharacter");
        Selection<GameCharacter> newAllieSelection = newAllieSelection(gameCharacter);
        newAllieSelection.select().ifPresent(newAllie -> {
            newAllie.joinAlliance(gameCharacter.getAlliance());
        });
    }

    /**
     * Remueve al personaje de la alianza, y si solo le queda un jugador a la alianza, la disuelve
     * @param gameCharacter no null, personaje a remover de la alianza
     */
    public static void removeAllie(GameCharacter gameCharacter){
        Assert.notNull(gameCharacter, "gameCharacter");
        var alliance = gameCharacter.getAlliance();
        gameCharacter.leaveAlliance();
        if(alliance.getAlliesCount() <= 1){
            alliance.disolve();
            gameCharacter.getGame().removeAlliance(alliance);
        }
    }

    /**
     *
     * @param gameCharacter no null, personaje que quiere darle una carta a otro
     */
    public static void giveCard(GameCharacter gameCharacter) {
        Assert.notNull(gameCharacter, "gameCharacter");
        Assert.positive(gameCharacter.getCharacterData().getDeck().getSize(), "cantidad de cartas");
        Selection<Card> cardSelection = PlayerTurnSelections.cardSelection(gameCharacter.getCharacterData().getDeck(),
                "¿Que carta quiere darle a su aliado?");
        Selection<GameCharacter> gameCharacterSelection = PlayerTurnSelections.AlliesSelection(gameCharacter,
                "¿A qué aliado desea darle la carta?");

        cardSelection.select().ifPresent(card -> {
            gameCharacterSelection.select().ifPresent(ally -> {
                Assert.isTrue(!ally.getCharacterData().getDeck().isFull(), ally.getActor().getName() + " tiene el mazo lleno");
                ally.getCharacterData().getDeck().add(card);
                gameCharacter.getCharacterData().getDeck().remove(card);
                gameCharacter.getGame().logger.logInfo(String.format("%s le dio la carta %s a %s",
                        gameCharacter.getActor().getName(),
                        card.getName(),
                        ally.getActor().getName()));
            });
        });
    }
}