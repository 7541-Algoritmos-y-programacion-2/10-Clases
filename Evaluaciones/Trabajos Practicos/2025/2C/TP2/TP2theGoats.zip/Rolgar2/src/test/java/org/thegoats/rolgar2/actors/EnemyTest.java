package org.thegoats.rolgar2.actors;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EnemyTest {

    @Test
    void testConstructorStoresName() {
        Enemy e = new Enemy("Goblin_01");
        assertEquals("Goblin_01", e.getName());
    }

    @Test
    void testInvalidNameThrows() {
        // Lo que Assert.validName(name) lance
        assertThrows(Exception.class, () -> new Enemy(null));
        assertThrows(Exception.class, () -> new Enemy(""));
        assertThrows(Exception.class, () -> new Enemy("ab"));          // menos de 3 chars
        assertThrows(Exception.class, () -> new Enemy("a".repeat(30))); // más de 20
        assertThrows(Exception.class, () -> new Enemy("@@@@"));         // caracteres inválidos
    }

    @Test
    void testDifferentNamesNotEqual() {
        Enemy e1 = new Enemy("Orc");
        Enemy e2 = new Enemy("Troll");

        assertNotEquals(e1.getName(), e2.getName());
    }

    @Test
    void testSameNameDifferentInstanceNotEqualByDefault() {
        Enemy e1 = new Enemy("Shadow");
        Enemy e2 = new Enemy("Shadow");

        // Actor no sobrescribe equals → identidad
        assertNotEquals(e1, e2);
        assertNotEquals(e1.hashCode(), e2.hashCode());
    }

    @Test
    void testToStringExists() {
        Enemy e = new Enemy("Vampire");
        String string = e.toString(); // hereda Object.toString()

        assertNotNull(string);
        assertTrue(string.contains("Vampire") || string.length() > 0);
    }
}
