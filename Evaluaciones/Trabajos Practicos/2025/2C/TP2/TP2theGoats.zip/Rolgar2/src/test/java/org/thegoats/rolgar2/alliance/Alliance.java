package org.thegoats.rolgar2.alliance;
import org.junit.jupiter.api.Test;
import org.thegoats.rolgar2.actors.Player;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AllianceTest {

    @Test
    void testAddAlly() {
        Alliance alliance = new Alliance();
        Player p = new Player("Juan");

        alliance.addAlly(p);

        assertTrue(alliance.isAlly(p));
        assertEquals(1, alliance.getAlliesCount());
    }

    @Test
    void testAddAllyNullThrows() {
        Alliance alliance = new Alliance();
        assertThrows(Exception.class, () -> alliance.addAlly(null));
    }

    @Test
    void testAddSameAllyTwiceThrows() {
        Alliance alliance = new Alliance();
        Player p = new Player("Lucas");

        alliance.addAlly(p);

        assertThrows(Exception.class, () -> alliance.addAlly(p));
    }

    @Test
    void testRemoveAlly() {
        Alliance alliance = new Alliance();
        Player p = new Player("Ana");

        alliance.addAlly(p);
        alliance.removeAlly(p);

        assertFalse(alliance.isAlly(p));
        assertEquals(0, alliance.getAlliesCount());
    }

    @Test
    void testRemoveNonAllyThrows() {
        Alliance alliance = new Alliance();
        Player p = new Player("Rita");

        assertThrows(Exception.class, () -> alliance.removeAlly(p));
    }

    @Test
    void testIsAllyNullThrows() {
        Alliance alliance = new Alliance();
        assertThrows(Exception.class, () -> alliance.isAlly(null));
    }

    @Test
    void testGetAlliesReturnsImmutableCopy() {
        Alliance alliance = new Alliance();
        Player p = new Player("Pablo");

        alliance.addAlly(p);

        Set<Player> allies = alliance.getAllies();

        assertTrue(allies.contains(p));
        assertThrows(UnsupportedOperationException.class, () -> allies.add(new Player("Otro")));
    }

    @Test
    void testInForceAtStart() {
        Alliance alliance = new Alliance();
        assertTrue(alliance.inForce());
    }

    @Test
    void testDisolve() {
        Alliance alliance = new Alliance();
        Player a = new Player("Aaa");
        Player b = new Player("Bbb");

        alliance.addAlly(a);
        alliance.addAlly(b);

        alliance.disolve();

        assertFalse(alliance.inForce());
        assertEquals(0, alliance.getAlliesCount());
        assertFalse(alliance.isAlly(a));
        assertFalse(alliance.isAlly(b));
    }

    @Test
    void testDisolveTwiceThrows() {
        Alliance alliance = new Alliance();
        alliance.disolve();

        assertThrows(Exception.class, alliance::disolve);
    }
}
