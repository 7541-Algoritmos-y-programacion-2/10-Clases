package org.thegoats.rolgar2.game.turnManagement;
import org.thegoats.rolgar2.actors.Player;
import org.thegoats.rolgar2.alliance.AllianceManager;
import org.thegoats.rolgar2.card.*;
import org.thegoats.rolgar2.game.GameCharacter;
import org.thegoats.rolgar2.game.actions.AllianceAction;
import org.thegoats.rolgar2.game.actions.MovementDirections;
import org.thegoats.rolgar2.game.actions.TurnAction;
import org.thegoats.rolgar2.util.Assert;
import org.thegoats.rolgar2.util.io.selection.Selection;
import org.thegoats.rolgar2.world.Position;
import org.thegoats.rolgar2.world.World;
import org.thegoats.rolgar2.world.WorldCell;
import org.thegoats.rolgar2.world.WorldViewer;

import java.util.Arrays;
import java.util.Optional;

import static org.thegoats.rolgar2.game.turnManagement.PlayerTurnSelections.attackCharacterSelection;
import static org.thegoats.rolgar2.util.io.bitmaps.AnsiColor.*;

public class PlayerTurnManager extends GameCharacterTurnManager {

    private final Selection<TurnAction> turnSelection = PlayerTurnSelections.turnSelection();
    private final Selection<TurnAction> freezedTurnSelection = PlayerTurnSelections.freezedTurnSelection();
    private final Selection<MovementDirections> directionSelection = PlayerTurnSelections.directionSelection();
    private Selection<Card> cardSelection = null;
    private int turnCount = 0;

    /**
     * Construye el GameCharacterTurnManager
     * @param gameCharacter no null
     */
    public PlayerTurnManager(GameCharacter gameCharacter) {
        super(gameCharacter);
        Assert.isTrue(gameCharacter.isPlayerCharacter(), "gameCharacter debe ser un personaje de un jugador.");
    }

    /**
     * realiza el turno, deriva a doFreezedTurn() si es necesario
     */
    @Override
    public void doTurn() {
        if(gameCharacter.getCharacterData().isDead()){
            logger.logInfo(RED + gameCharacter.getActor().getName() + " esta muerto" + RESET);
            return;
        }
        int remainingMoves = gameCharacter.getCharacterData().getMoves();


        int layer = gameCharacter.getWorldCell().getPosition().getLayer();
        WorldViewer worldViewer = gameCharacter.getGame().worldViewer;
        if(!worldViewer.hasActiveLayerBitmap()){
            worldViewer.instanceLayer(gameCharacter.getWorld());
            worldViewer.updateLayer(gameCharacter.getWorld(), gameCharacter, layer);
            worldViewer.showLayer();
        }

        while (remainingMoves > 0 && gameCharacter.getGame().getAlivePlayersCount() > 1) {
            layer = gameCharacter.getWorldCell().getPosition().getLayer();
            worldViewer.updateLayer(gameCharacter.getWorld(),gameCharacter,layer);
            logger.logInfo(GREEN + "El jugador " + gameCharacter.getActor().getName() +
                    " realiza su turno." + RESET);
            showStats(remainingMoves);

            logger.logInfo("");
            if(gameCharacter.getCharacterData().isFreezed()){
                logger.logInfo(CYAN+"ESTÁS CONGELADO!!"+RESET);
            }

            TurnAction action = (gameCharacter.getCharacterData().isFreezed()
                    ? freezedTurnSelection.select()
                    : turnSelection.select())
                    .orElseThrow();

            boolean completed = false;
            try {
                // acá se ejecuta mover / usar carta / agarrar carta / etc.
                completed = doTurnAction(action);
            } catch (RuntimeException e) {
                // acá caen los Assert que fallan (sin cartas, sin carta en la celda, mazo lleno, etc.)
                logger.logWarning(e.getMessage());
            }

            if (completed) {
                remainingMoves--;
            } else {
                logger.logWarning(YELLOW+"La accion no se ha completado."+RESET);
            }
        }
        if(++turnCount >= gameCharacter.getCharacterData().getTurnsToRegenerate()){
            gameCharacter.getCharacterData().regenerate();
            turnCount = 0;
        }
    }

    /**
     *
     * @param action valor de enum
     * @return true si se utiliza el metodo del enum o se aplica saltar turno, false caso contrario
     */
    private boolean doTurnAction(TurnAction action) {
        return switch (action) {
            case RealizarMovimiento -> move();
            case Atacar -> attack();
            case AgarrarCarta -> CardManager.pickCard(gameCharacter);
            case UsarCarta -> useCard();
            case GestionarAlianzas -> manageAlliances();
            case UsarEscaleraSogaOResorte -> useSpringORopeOStair();
            case SaltarTurno -> true;
        };
    }

    /**
     * Consulta al usuario en que direccion moverse y realiza el movimiento
     * @return true si se pudo concretar el movimiento
     */
    private boolean move() {
        var direction = directionSelection
                .select();

        if (direction.isEmpty()) {
            logger.logInfo("No se pudo realizar el movimiento.");
            return false;
        }

        Position position = gameCharacter.getWorldCell().getPosition();
        World world = gameCharacter.getWorld();
        var newCell = gameCharacter.getWorld().getCell(
                switch (direction.get()) {
                    case Norte -> world.getClampedPosition(position.getRow()-1, position.getColumn(), position.getLayer());
                    case Oeste -> world.getClampedPosition(position.getRow(), position.getColumn()-1, position.getLayer());
                    case Sur -> world.getClampedPosition(position.getRow()+1, position.getColumn(), position.getLayer());
                    case Este -> world.getClampedPosition(position.getRow(), position.getColumn()+1, position.getLayer());
                    case Noreste -> world.getClampedPosition(position.getRow()-1, position.getColumn()+1, position.getLayer());
                    case Noroeste -> world.getClampedPosition(position.getRow()-1, position.getColumn()-1, position.getLayer());
                    case Sudeste -> world.getClampedPosition(position.getRow()+1, position.getColumn()+1, position.getLayer());
                    case Sudoeste -> world.getClampedPosition(position.getRow()+1, position.getColumn()-1, position.getLayer());
                    case Volver -> gameCharacter.getWorldCell().getPosition();
                }
        );

        if(newCell.characterCanMove()) {
            gameCharacter.moveCharacter(newCell.getPosition());
            return true;
        }
        return false;
    }

    /**
     * Realiza un ataque a un enemigo adyacete al personaje
     * @return Devuelve true si se realizo el ataque con exito y false si no ocurrio
     */
    private boolean attack() {
        var neighborCells = gameCharacter.getWorldCell().getNeighborsOnSameLayer();
        var enemiesAround = neighborCells.stream()
                .map(WorldCell::getCharacter)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();

        if (enemiesAround.isEmpty()) {
            logger.logInfo("No hay enemigos alrededor para atacar.");
            return false;
        }

        GameCharacter target;

        // si hay un solo enemigo
        if (enemiesAround.size() == 1) {
            target = enemiesAround.getFirst();
            if(gameCharacter.isAllied() && gameCharacter.getAlliance().isAlly((Player)target.getActor())) { // si es aliado no lo ataca
                logger.logInfo(target.getActor().getName() + " es un aliado");
                return false;
            }
        } else {
            // si hay varios enemigos, mostramos menú para elegir
            var selectionOpt = attackCharacterSelection(enemiesAround, gameCharacter, gameCharacter.getGame()::playerToGameCharacter);
            if (selectionOpt.isEmpty()) {
                logger.logInfo("No hay enemigos alrededor para atacar.");
                return false;
            }

            var chosen = selectionOpt.get().select();
            if (chosen.isEmpty()) {
                logger.logInfo("No se seleccionó enemigo para atacar.");
                return false;
            }
            target = chosen.get();
        }

        Selection<Boolean> election = PlayerTurnSelections.booleanSelection(
                "¿Desea atacar a "+target.getActor().getName()+"?", "Opcion invalida");
        if(election.select().isEmpty()){
            return false;
        }
        logger.logInfo(RED+"Atacando a " +target.getActor().getName()+ "."+RESET);
        gameCharacter.attack(target);

        if (target.getCharacterData().isDead()) {
            gameCharacter.getCharacterData().setKills(gameCharacter.getCharacterData().getKills()+1);
            if(target.isAllied() && target.getAlliance().getAlliesCount() == 1){
                target.getAlliance().disolve();
            }
            target.getWorldCell().setCharacter(null);
            logger.logInfo(RED+"El enemigo " + target.getActor().getName() + " ha sido derrotado."+RESET);
        }
        return true;
    }


    /**
     * Usa la escalera para subir o bajar de capa.
     * @return true si se pudo usar la escalera y mover al personaje; false en caso contrario.
     */
    private boolean useStair() {
        WorldCell currentCell = gameCharacter.getWorldCell();

        // Debe estar parado sobre una escalera
        if (!currentCell.hasStair()) {
            logger.logInfo("No estás parado sobre una escalera.");
            return false;
        }

        // Buscamos la parte de escalera arriba y abajo
        Optional<WorldCell> upperPart = currentCell.getUpperStairPart();
        Optional<WorldCell> lowerPart = currentCell.getLowerStairPart();

        WorldCell stairDestinationCell;
        boolean goingUp;

        if (upperPart.isPresent()) {
            stairDestinationCell = upperPart.get();
            goingUp = true;
        } else if (lowerPart.isPresent()) {
            stairDestinationCell = lowerPart.get();
            goingUp = false;
        } else {
            logger.logInfo("Esta escalera no conecta con otra capa.");
            return false;
        }

        // Buscamos vecinos libres alrededor de la parte de la escalera en la capa destino
        var freeNeighbors = stairDestinationCell.getFreeNeighborsOnSameLayer();

        if (freeNeighbors.isEmpty()) {
            logger.logWarning(goingUp
                    ? "No hay espacio libre para subir por la escalera."
                    : "No hay espacio libre para bajar por la escalera.");
            return false;
        }

        // Tomamos cualquier celda vecina libre (la primera de la lista)
        WorldCell targetCell = freeNeighbors.getFirst();

        // Movemos al personaje a la celda destino
        gameCharacter.moveCharacter(targetCell.getPosition());

        logger.logInfo(goingUp
                ? "Subiste por la escalera."
                : "Bajaste por la escalera.");

        return true;
    }


    /**
     * Le pregunta al usuario qué carta usar y la usa.
     * @return true si se pudo usar la carta
     */
    private boolean useCard() {
        Assert.isTrue(!gameCharacter.getCharacterData().getDeck().isEmpty(), "El jugador tiene que tener cartas");
        cardSelection = PlayerTurnSelections.cardSelection(gameCharacter.getCharacterData().getDeck(), "¿Que carta quiere usar?");

        return cardSelection.select()
                .map(card -> CardManager.useCard(card, gameCharacter))
                .orElse(false);

    }

    /**
     * Usa el resorte o la soga, dependiendo de en cual esta parado
     * @return true si uso resorte o soga y movio al personaje. False caso contrario
     */
    private boolean useSpringOrRope() {

        //obtengo donde esta el player (celda/posicion)
        WorldCell cell = gameCharacter.getWorldCell();
        Position pos = cell.getPosition();

        //calculo la capa actual y la destino
        int currentLayer = pos.getLayer();
        int targetLayer;

        //veo si la celda tiene soga o resorte
        if (cell.hasSpring()) {
            targetLayer = currentLayer + 1;
        } else if (cell.hasRope()) {
            targetLayer = currentLayer - 1;
        } else {
            logger.logInfo("No hay soga/resorte en esta celda.");
            return false;
        }

        // veo que no salga del mundo. Por como esta el json esto no pasa
        if (targetLayer < 0 || targetLayer >= gameCharacter.getWorld().getLayerCount()) {
            logger.logWarning("No se puede cambiar de capa desde aquí.");
            return false;
        }

        // busco la celda destino
        Position targetPos = new Position(pos.getRow(), pos.getColumn(), targetLayer);
        WorldCell targetCell = gameCharacter.getWorld().getCell(targetPos);

        // veo si se puede mover el player
        if (!targetCell.characterCanMove()) {
            logger.logInfo("La celda destino está ocupada o no es transitable.");
            return false;
        }
        // muevo al personaje
        gameCharacter.moveCharacter(targetPos);
        logger.logInfo("Te has movido a la capa " + (targetLayer+1));
        return true;
    }


    private boolean useSpringORopeOStair() {
        WorldCell cell = gameCharacter.getWorldCell();

        if (cell.hasStair()) {
            return useStair();
        }

        if (cell.hasSpring() || cell.hasRope()) {
            return useSpringOrRope();
        }

        logger.logInfo("No hay escalera, resorte ni soga en esta celda.");
        return false;
    }

    /**
     * Comprende el comportamiento de las selecciones de alianzas, pregunta y resuelve la accion ya sea crear alianza,
     * salir de la alianza, etc.
     * @return true si se pudo completar la operacion.
     */
    private boolean manageAlliances() {
        Selection<AllianceAction> allianceActionSelection;

        if(gameCharacter.isAllied()){
            allianceActionSelection = PlayerTurnSelections.alliedAllianceSelection();
            return allianceActionSelection.select()
                    .map(allianceAction -> {
                        switch (allianceAction){
                            case Abandonar -> AllianceManager.removeAllie(gameCharacter);
                            case AgregarAliado -> AllianceManager.addAllie(gameCharacter);
                            case DarCarta -> AllianceManager.giveCard(gameCharacter);
                            case Volver -> {return false;}
                        }
                        return true;
                    }).orElse(false);
        } else {
            allianceActionSelection = PlayerTurnSelections.nonAlliedAllianceSelection();
            return allianceActionSelection.select()
                    .map(allianceAction -> {
                        switch (allianceAction) {
                            case CrearAlianza -> AllianceManager.createAlliance(gameCharacter);
                            case Volver -> {return false;}
                        }
                        return true;
                    }).orElse(false);
        }
    }

    /**
     * Muestra las estadisticas del personaje
     * @param remainingMoves movimientos restantes
     */
    private void showStats(int remainingMoves){
        Assert.nonNegative(remainingMoves, RED + "remainingMoves debe ser mayor o igual a cero" + RESET);
        logger.logInfo("Movimientos Restantes: "+ remainingMoves);
        logger.logInfo("Cartas en Posesión: " + Arrays.toString(gameCharacter.getCharacterData().getDeck().getCardNames()));
        logger.logInfo(RED + "Kills: " + gameCharacter.getCharacterData().getKills() + RESET);
        logger.logInfo(GREEN+"PV:" +gameCharacter.getCharacterData().getHealth() + RESET);
    }
}