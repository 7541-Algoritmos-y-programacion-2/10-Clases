package org.thegoats.rolgar2.card;

import org.thegoats.rolgar2.util.Assert;

import java.util.Random;

/**
 * Muchas de las cartas que tienen un CharacterData como target, le aplican un efecto de estado
 * StatusEffect a dicho personaje, por lo tanto abstraemos en esta clase el atributo duration,
 * que sera la duracion del efecto de estado en turnos, y los metodos setDuration, getDuration,
 * y validateDuration. Todas las cartas que apliquen un efecto
 * de estado heredaran de esta clase.
 */
public abstract class CardWithStatusEffect extends CardWithCharacterTarget {
    private final int duration;

    /**
     * Construye la carta cuyo efecto de estado tendrá 'duration' turnos
     * @param duration mayor a cero, duracion de la carta en turnos
     */
    public CardWithStatusEffect(int duration) {
        Assert.positive(duration, "duration");
        this.duration = duration;
    }

    /**
     * Devuelve la duracion que tendra la carta al aplicarse sobre el personaje en cuestion
     * @return duracion de la carta en turnos
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Recibe al construirse un piso y un techo para la duracion. De esta manera tendra un rango de valores para los que
     * generar una duracion aleatoria de la carta.
     * @param <T> Clase de la carta a construir
     */
    public static abstract class Factory<T extends CardWithStatusEffect> implements Card.Factory<T> {
        protected final Random random;
        protected final int durationFloor;
        protected final int durationRoof;

        /**
         * Recibe el piso y techo y los setea, recibe el generador aleatorio y lo setea. Valida los tres parametros.
         * @param random objeto de tipo Random, generador aleatorio en este caso utilizado para generar duraciones de
         *               los efectos de estado
         * @param durationFloor mayor a cero, menor a 'durationRoof'
         * @param durationRoof mayor a cero, mayor a 'durationFloor'
         */
        public Factory(Random random, int durationFloor, int durationRoof) {
            Assert.notNull(random, "random");
            Assert.positive(durationFloor, "durationFloor");
            Assert.positive(durationRoof, "durationRoof");
            Assert.isTrue(durationFloor <= durationRoof, "durationFloor debe ser menor o igual a durationRoof.");

            this.random = random;
            this.durationFloor = durationFloor;
            this.durationRoof = durationRoof;
        }

        /**
         * Genera una duracion aleatoria con el rango numerico indicado por 'duracionFloor' (piso) y 'durationRoof' (techo).
         * @return un entero aleatorio, con el piso y techo indicados, que será la duración del efecto de estado
         */
        public int getRandomDuration() {
            return random.nextInt(durationFloor, durationRoof);
        }
    }
}