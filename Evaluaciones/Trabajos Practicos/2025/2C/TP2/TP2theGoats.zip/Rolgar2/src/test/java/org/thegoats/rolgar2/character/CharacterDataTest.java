package org.thegoats.rolgar2.character;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.thegoats.rolgar2.character.effects.*;
import static org.junit.jupiter.api.Assertions.*;
import org.thegoats.rolgar2.character.effects.*;


public class CharacterDataTest {

    private CharacterData character;

    @BeforeEach
    public void setup() {
        character = new CharacterData(
                100,   // maxHealth
                10,    // strength
                10,    // deckSize
                5,     // moves
                1.0,   // incomingDamageFactor
                4,     // vision
                2,     // regeneration
                1      // turnsToRegenerate
        );
    }

    // -------------------------------------------------------------------------
    // DoubleMoveEffect
    // -------------------------------------------------------------------------

    @Test
    public void testDoubleMoveEffect() {
        int originalMoves = character.getMoves();

        character.applyEffect(new DoubleMoveEffect(character, 2));
        assertEquals(originalMoves * 2, character.getMoves());

        character.updateEffects(); // turn 1
        assertEquals(originalMoves * 2, character.getMoves());

        character.updateEffects(); // turn 2 → expires
        assertEquals(originalMoves, character.getMoves());
    }

    // -------------------------------------------------------------------------
    // DoubleStrengthEffect
    // -------------------------------------------------------------------------

    @Test
    public void testDoubleStrengthEffect() {
        int originalStr = character.getStrength();

        character.applyEffect(new DoubleStrengthEffect(character, 1));
        assertEquals(originalStr * 2, character.getStrength());

        character.updateEffects(); // expires
        assertEquals(originalStr, character.getStrength());
    }

    // -------------------------------------------------------------------------
    // FreezeEffect
    // -------------------------------------------------------------------------

    @Test
    public void testFreezeEffect() {
        assertFalse(character.isFreezed());

        character.applyEffect(new FreezeEffect(character, 1));
        assertTrue(character.isFreezed());

        character.updateEffects(); // expires
        assertFalse(character.isFreezed());
    }

    // -------------------------------------------------------------------------
    // HalfDamageEffect
    // -------------------------------------------------------------------------

    @Test
    public void testHalfDamageEffect() {
        assertEquals(1.0, character.getIncomingDamageFactor());

        character.applyEffect(new HalfDamageEffect(character, 2));
        assertEquals(0.5, character.getIncomingDamageFactor());

        character.takeDamage(20);
        assertEquals(100 - 10, character.getHealth()); // damage halved

        character.updateEffects(); // turn 1
        character.updateEffects(); // turn 2 → expires

        assertEquals(1.0, character.getIncomingDamageFactor());
    }

    // -------------------------------------------------------------------------
    // InvisibilityEffect
    // -------------------------------------------------------------------------

    @Test
    public void testInvisibilityEffect() {
        assertTrue(character.isVisible());

        character.applyEffect(new InvisibilityEffect(character, 2));
        assertFalse(character.isVisible());

        character.updateEffects(); // turn 1
        assertFalse(character.isVisible());

        character.updateEffects(); // turn 2 → expires
        assertTrue(character.isVisible());
    }

    // -------------------------------------------------------------------------
    // Combined effects
    // -------------------------------------------------------------------------

    @Test
    public void testMultipleEffectsSimultaneously() {
        int originalMoves = character.getMoves();
        int originalStr = character.getStrength();

        character.applyEffect(new DoubleMoveEffect(character, 2));
        character.applyEffect(new DoubleStrengthEffect(character, 1));

        assertEquals(originalMoves * 2, character.getMoves());
        assertEquals(originalStr * 2, character.getStrength());

        character.updateEffects(); // turn 1: strength expires, move stays

        assertEquals(originalMoves * 2, character.getMoves());
        assertEquals(originalStr, character.getStrength());

        character.updateEffects(); // turn 2: movement effect expires

        assertEquals(originalMoves, character.getMoves());
    }

    // -------------------------------------------------------------------------
    // updateEffects() removes expired effects from the list
    // -------------------------------------------------------------------------

    @Test
    public void testUpdateEffectsRemovesExpired() {
        assertEquals(0, character.getEffects().size());

        character.applyEffect(new FreezeEffect(character, 1));
        assertEquals(1, character.getEffects().size());

        character.updateEffects(); // expires
        assertEquals(0, character.getEffects().size());
    }

    // -------------------------------------------------------------------------
    // applyEffect does NOT duplicate effects if same instance is passed
    // -------------------------------------------------------------------------

    @Test
    public void testApplyEffectDoesNotDuplicateSameReference() {
        FreezeEffect f = new FreezeEffect(character, 2);

        character.applyEffect(f);
        character.applyEffect(f); // should be ignored

        assertEquals(1, character.getEffects().size());
    }

    // -------------------------------------------------------------------------
    // takeDamage respects clamp + incomingDamageFactor
    // -------------------------------------------------------------------------

    @Test
    public void testTakeDamageClamps() {
        character.setIncomingDamageFactor(2.0); // max allowed

        character.takeDamage(60);
        assertEquals(100 - 120 < 0 ? 0 : 100 - 120, character.getHealth());
        assertEquals(0, character.getHealth()); // should clamp at 0
    }

    // -------------------------------------------------------------------------
    // regenerate respects maxHealth
    // -------------------------------------------------------------------------

    @Test
    public void testRegenerate() {
        character.takeDamage(50);
        assertEquals(50, character.getHealth());

        character.regenerate(); // +2
        assertEquals(52, character.getHealth());
    }

    // -------------------------------------------------------------------------
    // visibility toggle
    // -------------------------------------------------------------------------

    @Test
    public void testVisibilityToggle() {
        character.setInvisible();
        assertFalse(character.isVisible());

        character.setVisible();
        assertTrue(character.isVisible());
    }

    // -------------------------------------------------------------------------
    // freeze/unfreeze direct methods
    // -------------------------------------------------------------------------

    @Test
    public void testFreezeToggle() {
        character.freeze();
        assertTrue(character.isFreezed());

        character.unfreeze();
        assertFalse(character.isFreezed());
    }
}
