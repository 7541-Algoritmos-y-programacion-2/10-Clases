package org.thegoats.rolgar2.util.structures.nodes;


public class TheGoatsLinkedNode<T> extends TheGoatsNode<T> {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private TheGoatsLinkedNode<T> next = null;
	
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * pre: -
	 * pos: el NodoSimplementeEnlazado resulta inicializado con el dato dado
     *       y sin un NodoSimplementeEnlazado siguiente.
	 */
	public TheGoatsLinkedNode(T data) {
		super(data);
		this.next = null;
	}
	
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * pre: -
	 * pos: el NodoSimplementeEnlazado resulta inicializado con el dato dado
     *       y sin un NodoSimplementeEnlazado siguiente.
	 */
	public boolean hasNext() {
		return this.next != null;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------

	/**
	 * pre:
	 * pos: cambia el dato del NodoSimplementeEnlazado
	 */
	public TheGoatsLinkedNode<T> getNext() {
		return this.next;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
	
	/**
	 * pre:
	 * pos: cambia el NodoSimplementeEnlazado siguiente
	 */
	public void setNext(TheGoatsLinkedNode<T> next) {
		this.next = next;
	}
}
