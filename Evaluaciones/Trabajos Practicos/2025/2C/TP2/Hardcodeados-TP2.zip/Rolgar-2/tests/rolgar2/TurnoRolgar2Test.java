package tests.rolgar2;

import org.junit.jupiter.api.Test;
import src.rolgar2.TurnoRolgar2;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para la clase TurnoRolgar2.
 */
public class TurnoRolgar2Test {

    @Test
    public void testTurnoRolgar2Existe() {
        assertNotNull(TurnoRolgar2.class);
    }
}
