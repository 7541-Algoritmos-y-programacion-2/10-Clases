package tests.rolgar2;

import org.junit.jupiter.api.Test;
import src.rolgar2.Rolgar2;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests para la clase Rolgar2.
 */
public class Rolgar2Test {

    @Test
    public void testRolgar2Existe() {
        assertNotNull(Rolgar2.class);
    }
}
