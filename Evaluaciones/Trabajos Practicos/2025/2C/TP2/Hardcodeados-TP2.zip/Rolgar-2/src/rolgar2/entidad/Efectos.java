package src.rolgar2.entidad;

/**
 * Enum que define los efectos especiales que pueden aplicarse a los personajes.
 * 
 * <p>Efectos disponibles:</p>
 * <ul>
 *   <li>ESCUDO: Reduce el daño recibido en un porcentaje</li>
 *   <li>INVISIBILIDAD: Hace invisible al personaje en el mapa</li>
 * </ul>
 */
public enum Efectos {
    ESCUDO,
    INVISIBILIDAD
}
