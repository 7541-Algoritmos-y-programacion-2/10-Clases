package util;

import java.util.Scanner; // Este import es el unico que necesitamos

public class  Teclado {

    private static Scanner scanner = new Scanner(System.in);

    /**
     * Constructor privado para prevenir que se instancie esta clase.
     */
    private Teclado() {
    }

    /**
     * Imprime un mensaje en la consola, seguido de un salto de linea.
     * @param mensaje El string a imprimir.
     */
    public static void imprimir(String mensaje) {
        System.out.println(mensaje);
    }

    /**
     * Lee una linea completa de texto ingresada por el usuario.
     * @return El String ingresado por el usuario.
     */
    public static String leerString() {
        return scanner.nextLine();
    }

    /**
     * Lee un numero entero ingresado por el usuario.
     * Si el usuario ingresa un valor no numerico, le volvera a pedir el numero hatsa que ingrese uno valido.
     * @return El numero entero valido ingresado.
     */
    public static int leerEntero() {
        while (true) {
            String entrada = scanner.nextLine();

            try {
                // Intenta convertir la entrada en un numero
                int valor = Integer.parseInt(entrada);
                return valor;
            } catch (NumberFormatException e) {
                Teclado.imprimir("Error: Por favor, ingrese un numero entero valido.");
            }
        }
    }

    /**
     * Cierra el scanner principal.
     * Se debe llamar una sola vez al final del programa.
     */
    public static void cerrar() {
        scanner.close();
    }
}
