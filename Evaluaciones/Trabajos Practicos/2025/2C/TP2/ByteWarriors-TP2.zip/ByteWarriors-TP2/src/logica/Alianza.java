package logica;

import java.util.ArrayList;
import java.util.List;
import modelo.Personaje;
import util.Teclado;

public class Alianza {

    private List<Personaje> miembros;

    /**
     * Inicializa el constructor.
     * Post: Crea una alianza vacia sin miembros
     */
    public Alianza() {
        miembros = new ArrayList<>();
    }

    /**
     * Agrega un personaje a la alianza si auno no pertenece.
     * Pre: p no es null.
     * Post: Si p no estaba en la alianza, queda agregado.
     *      Si ya estaba, la lista de miembros no cambia.
     * @param p
     */
    public void agregarMiembro(Personaje p) {
        if (!miembros.contains(p)) {
            miembros.add(p);
            Teclado.imprimir(p.getNombre() + " se ha unido a la alianza.");
        }
    }

    /**
     * Remueve un personaje de la alianza si este pertenece a ella.
     * Pre: p no es null.
     * Post: Si p estana en la alianza, deja de pertenecer a ella.
     *      Si no estaba, no modifica la lista.
     * @param p
     */
    public void removerMiembro(Personaje p) {
        if (miembros.remove(p)) {
            Teclado.imprimir(p.getNombre() + " ha abandonado la alianza.");
        }
    }

    /**
     * Envia una peticion de ayuda desde un miembro hacia el resto de la alianza.
     * Pre: Solicitante no es null. Solicitante pertenece a la alianza.
     * Post: Se muestra un mensaje en consola para cada aliado distinto de solicitante.
     * @param solicitante
     */
    public void pedirAyuda(Personaje solicitante) {
        Teclado.imprimir(solicitante.getNombre() + " está pidiendo ayuda a su alianza.");

        for (Personaje aliado : miembros) {
            if (!aliado.equals(solicitante)) {
                Teclado.imprimir(" → " + aliado.getNombre() + " recibe la petición.");
            }
        }
    }

    /**
     * Permite compartir la primera carta del inventario de un personaje hacia otro, siempre que ambos sean miembros de la alianza.
     * Pre: donante y receptor no son null.
     *      donante y receptor pertenecen a la alianza.
     * Post: Si el donante tenia al menos una carta, la primera carta se transfiere
     *         al inventario del receptro y se elimina del donante.
     *         Si el donante no tiene cartas, no cambia nada.
     * @param donante
     * @param receptor
     */
    public void compartirCartas(Personaje donante, Personaje receptor) {
        if (!miembros.contains(donante) || !miembros.contains(receptor)) {
            Teclado.imprimir("Ambos personajes deben pertenecer a la alianza.");
            return;
        }

        if (donante.getInventario().isEmpty()) {
            Teclado.imprimir(donante.getNombre() + " no tiene cartas para compartir.");
            return;
        }

        var carta = donante.getInventario().get(0);
        donante.getInventario().remove(0);
        receptor.agregarCarta(carta);

        Teclado.imprimir(donante.getNombre() + " compartió una carta con " + receptor.getNombre());
    }

    /**
     * Muestra por consola todos los miembros actuales de la alianza.
     * Pre:
     * Post: Se imprime la lista completa de aliados.
     */
    public void verAliados() {
        System.out.println("Miembros de la alianza:");
        for (Personaje p : miembros) {
            Teclado.imprimir(" - " + p.getNombre());
        }
    }

    /**
     * Devuelve la lista de miembros actuales.
     * Pre:
     * Post: Retorna la lista de personajes aliados.
     * @return
     */
    public List<Personaje> getMiembros() {
        return miembros;
    }
}