package modelo;

import util.Teclado;

public class AumentoDefensa extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int aumento;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre: Aumento > 0.
     * Post: La carta queda inicializada.
     * @param aumento
     */
    public AumentoDefensa(int aumento) {
        super(TipoCarta.AUMENTO_DEFENZA, "Aumenta la defensa del usuario.");
        this.aumento = aumento;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE

    /**
     * Pre: usuario no es nulo.
     * Post: aumenta la defensa del usuario.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.setDefensa(usuario.getDefensa() + aumento);
        Teclado.imprimir(usuario.getNombre() + " gana +" + aumento + " defensa.");
    }

//METODOS GENERALES
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
