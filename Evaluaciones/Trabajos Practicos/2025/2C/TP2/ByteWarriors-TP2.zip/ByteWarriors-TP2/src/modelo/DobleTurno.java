package modelo;

import util.Teclado;

public class DobleTurno extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS
//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre:
     * Post: otorga doble turno.
     */
    public DobleTurno() {
        super(TipoCarta.DOBLE_TURNO, "Permite realizar dos acciones seguidas en el proximo turno.");
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: usuario no es nulo.
     * Post: activa el estado de doble turno en el usuario.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.activarDobleTurno();
        Teclado.imprimir(usuario.getNombre() + " obtiene DOBLE TURNO.");
    }

//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
