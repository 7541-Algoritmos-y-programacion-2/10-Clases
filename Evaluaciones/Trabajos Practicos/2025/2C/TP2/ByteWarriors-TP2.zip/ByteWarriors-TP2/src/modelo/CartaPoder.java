package modelo;

public class CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private TipoCarta nombre;
    private String descripcion;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Crea una carta de poder con un nombre y una descripcion.
     * pre: Nombre y descripcion no deben ser nulos.
     * post: La carta queda inicializada con los valores recibidos.
     * @param nombre
     * @param descripcion
     */
    public CartaPoder(TipoCarta nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES
//METODOS DE COMPORTAMIENTO

    /**
     * Aplica el efecto de la carta.
     * Cada tipo de carta redefinira este metodo si necesita un efecto especifico.
     * pre: usuario y objetivos no son nulos.
     * post: Se ejecuta el efecto correspondiente de la carta.
     * @param usuario
     * @param objetivo
     */
    public void aplicar(Personaje usuario, Personaje objetivo) {
        // cada carta define su propio efecto
    }

//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES

    /**
     * Devuelve el nombre de la carta.
     * @return
     */
    public TipoCarta getNombre() {
        return nombre;
    }

    /**
     * Devuelve la descripcion de la carta.
     * @return
     */
    public String getDescripcion() {
        return descripcion;
    }

//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
