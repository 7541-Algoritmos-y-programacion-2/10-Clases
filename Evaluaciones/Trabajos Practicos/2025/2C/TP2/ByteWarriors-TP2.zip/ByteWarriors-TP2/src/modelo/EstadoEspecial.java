package modelo;

public enum EstadoEspecial {
    NORMAL,
    CONGELADO,
    DOBLE_ATAQUE,
    REFLEJO_MAGNETICO,
    DOBLE_TURNO
}
