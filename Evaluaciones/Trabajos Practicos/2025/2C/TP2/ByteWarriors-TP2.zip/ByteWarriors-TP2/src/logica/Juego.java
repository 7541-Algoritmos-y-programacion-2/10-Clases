package logica;

import modelo.*;

import util.Teclado;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Clase principal del juego Rolgar II.
 * Maneja la configuración dinámica y el bucle principal del juego.
 */
public class Juego {
    // Enum para el estado del juego, requerido por el bucle principal
    private enum EstadoJuego {
        ACTIVO,
        VICTORIA_ALIANZA,
        VICTORIA_SOLITARIA,
        DERROTA;
    }

    private static Random rand = new Random();
    private static List<Alianza> alianzasDelJuego = new ArrayList<>();
    private static Alianza alianzaHeroes;
    private static Alianza alianzaEnemigos;


    public static void main(String[] args) {

        //BIENVENIDA E INSTRUCCIONES
        imprimirBienvenidaEInstrucciones();

        //CONFIGURACIÓN DEL MUNDO
        Teclado.imprimir("--- 1. CONFIGURACIÓN DEL MUNDO ---");
        Tablero3D<Personaje> tablero = configurarTablero();

        //CREACION DE ALIANZAS
        alianzaHeroes = new Alianza();
        alianzaEnemigos = new Alianza();
        alianzasDelJuego.add(alianzaHeroes);
        alianzasDelJuego.add(alianzaEnemigos);

        //CREACIÓN DE JUGADORES
        Teclado.imprimir("\n CREACIÓN DE JUGADORES (N)");
        List<Personaje> jugadores = configurarJugadores(tablero, alianzaHeroes);

        // CREACIÓN DE ENEMIGOS
        Teclado.imprimir("\n CREACIÓN DE ENEMIGOS (M)");
        List<Enemigo> enemigos = configurarEnemigos(tablero, alianzaEnemigos);

        //COLOCANDO OBSTACULOS EN EL TABLERO
        Teclado.imprimir("\n COLOCANDO OBSTACULOS EN EL TABLERO");
        colocarObstaculos(tablero);
        colocarCartas(tablero);

        // --- 7. INICIO DEL BUCLE DE JUEGO ---
        Teclado.imprimir("\n------------------------------");
        Teclado.imprimir("¡INICIA EL JUEGO!");
        Teclado.imprimir("------------------------------");

        ejecutarBucleDeJuego(jugadores, enemigos, tablero);

        // --- 8. FIN DEL JUEGO ---
        Teclado.imprimir("\n------------------------------");
        Teclado.imprimir("---       FIN DEL JUEGO       ---");
        Teclado.imprimir("------------------------------");
        Teclado.cerrar();
    }

    //METODOS
    /**
     * Imprime el menú de bienvenida y las instrucciones del juego
     */
    private static void imprimirBienvenidaEInstrucciones() {
        Teclado.imprimir("-------------------------------");
        Teclado.imprimir("--------- ¡ROLGAR II! ---------");
        Teclado.imprimir("-------------------------------");
        Teclado.imprimir("OBJETIVO: ¡Elimina a todos los enemigos y sé el último jugador en pie!");
        Teclado.imprimir("\nINSTRUCCIONES DE MOVIMIENTO ):");
        Teclado.imprimir(" W = Adelante   | S = Atrás ");
        Teclado.imprimir(" A = Izquierda  | D = Derecha ");
        Teclado.imprimir(" Q = Diag. Atrás-Izq  | E = Diag. Atrás-Der");
        Teclado.imprimir(" Z = Diag. Adel-Izq   | C = Diag. Adel-Der");
        Teclado.imprimir(" U = Arriba (Z+1) | J = Abajo (Z-1)"); // NUEVA INSTRUCCIÓN
        Teclado.imprimir("\nOTRAS TECLAS:");
        Teclado.imprimir(" M = Ver Menú (Cartas, Alianzas)");
        Teclado.imprimir(" I = Ver estas Instrucciones de nuevo");
        Teclado.imprimir("---------------------------------");
    }

    /**
     * Pregunta al usuario por las dimensiones X, Y, Z y crea el tablero.
     */
    private static Tablero3D<Personaje> configurarTablero() {
        Teclado.imprimir("Define el tamaño del tablero:");
        Teclado.imprimir("ANCHO (X):");
        int ancho = Teclado.leerEntero();
        Teclado.imprimir("ALTO (Y):");
        int alto = Teclado.leerEntero();
        Teclado.imprimir("PROFUNDIDAD (Z):");
        int profundo = Teclado.leerEntero();

        Tablero3D<Personaje> tablero = new Tablero3D<>(ancho, alto, profundo);
        Teclado.imprimir("¡Tablero de " + ancho + "x" + alto + "x" + profundo + " creado!");
        return tablero;
    }

    /**
     * Pregunta cuántos jugadores (N) crear y los coloca en el centro.
     */
    private static List<Personaje> configurarJugadores(Tablero3D<Personaje> tablero, Alianza alianza) {
        List<Personaje> jugadores = new ArrayList<>();
        Teclado.imprimir("¿Cuántos jugadores (N) participarán?");
        int n = Teclado.leerEntero();

        int centroX = (tablero.getAncho() / 2) + 1;
        int centroY = (tablero.getAlto() / 2) + 1;

        for (int i = 0; i < n; i++) {
            Teclado.imprimir("Nombre del Jugador " + (i + 1) + ":");
            String nombre = Teclado.leerString();

            // Cada jugador empieza en un nivel distinto (Z = 1,2,3,...)
            int zInicial = (i % tablero.getProfundo()) + 1;

            Personaje p = new Personaje(nombre, 100, centroX, centroY, zInicial, 50, 30, 5, 5);
            p.unirseA(alianza);
            jugadores.add(p);

            tablero.getCasillero(centroX, centroY, zInicial).setContenido(p);
        }

        return jugadores;
    }


    /**
     * Pregunta cuántos enemigos (M) crear y los coloca aleatoriamente.
     */
    private static List<Enemigo> configurarEnemigos(Tablero3D<Personaje> tablero, Alianza alianza) {
        List<Enemigo> enemigos = new ArrayList<>();
        Teclado.imprimir("¿Cuántos enemigos (M) deseas colocar aleatoriamente?");
        int m = Teclado.leerEntero();

        for (int i = 0; i < m; i++) {
            int x, y, z;
            do {
                x = rand.nextInt(tablero.getAncho()) + 1;
                y = rand.nextInt(tablero.getAlto()) + 1;
                z = rand.nextInt(tablero.getProfundo()) + 1;
            } while (!tablero.getCasillero(x, y, z).estaVacio());

            Enemigo e = new Enemigo("Enemigo " + (i + 1), 50, x, y, z, 30, 10, 3, 2);
            e.unirseA(alianza);
            enemigos.add(e);

            tablero.getCasillero(x, y, z).setContenido(e);
        }
        Teclado.imprimir(m + " enemigos colocados.");
        return enemigos;
    }

    /**
     * Coloca obstáculos aleatoriamente en el tablero.
     */
    private static void colocarObstaculos(Tablero3D<Personaje> tablero) {
        Teclado.imprimir("¿Qué porcentaje del tablero debe ser no transitable? ");
        int porcentaje = Teclado.leerEntero();
        int totalCasilleros = tablero.getAncho() * tablero.getAlto() * tablero.getProfundo();
        int cantidadRocas = (totalCasilleros * porcentaje) / 100;

        for (int i = 0; i < cantidadRocas; i++) {
            int x, y, z;
            do {
                x = rand.nextInt(tablero.getAncho()) + 1;
                y = rand.nextInt(tablero.getAlto()) + 1;
                z = rand.nextInt(tablero.getProfundo()) + 1;
            } while (!tablero.getCasillero(x, y, z).estaVacio());

            // Asume que TipoCasillero es un Enum y Casillero.setTipo() existe
            tablero.getCasillero(x, y, z).setTipoCasillero(TipoCasillero.ROCA);
        }
        Teclado.imprimir(cantidadRocas + " rocas colocadas.");
    }

    /**
     * Coloca cartas de poder aleatoriamente en el tablero.
     */
    private static void colocarCartas(Tablero3D<Personaje> tablero) {
        Teclado.imprimir("¿Cuántas cartas de poder deseas colocar aleatoriamente?");
        int cantidadCartas = Teclado.leerEntero();

        // Obtener todos los tipos de carta posibles
        TipoCarta[] tipos = TipoCarta.values();

        for (int i = 0; i < cantidadCartas; i++) {
            int x, y, z;
            do {
                x = rand.nextInt(tablero.getAncho()) + 1;
                y = rand.nextInt(tablero.getAlto()) + 1;
                z = rand.nextInt(tablero.getProfundo()) + 1;
            } while (!tablero.getCasillero(x, y, z).estaVacio() ||
                    !tablero.getCasillero(x, y, z).esTransitable());

            // 1. Elegir un tipo de carta aleatorio
            TipoCarta tipoElegido = tipos[rand.nextInt(tipos.length)];

            // 2. Crear la instancia de la subclase de CartaPoder
            CartaPoder nuevaCarta = null;

            // Usamos un switch para instanciar la clase correcta (Curacion, AumentoFuerza, etc.)
            switch (tipoElegido) {
                case CURACION:
                    nuevaCarta = new Curacion(rand.nextInt(30) + 10); // Cura entre 10 y 40
                    break;
                case AUMENTO_FUERZA:
                    nuevaCarta = new AumentoFuerza(rand.nextInt(10) + 5); // Aumenta Fuerza entre 5 y 15
                    break;
                case AUMENTO_DEFENZA:
                    nuevaCarta = new AumentoDefensa(rand.nextInt(10) + 5); // Aumenta Defensa entre 5 y 15
                    break;
                case TRAMPA:
                    nuevaCarta = new Trampa(rand.nextInt(30) + 10); // Daño de Trampa entre 10 y 40
                    break;
                case DOBLE_ATAQUE:
                    nuevaCarta = new DobleAtaque();
                    break;
                case DOBLE_TURNO:
                    nuevaCarta = new DobleTurno();
                    break;
                case CONGELAMIENTO:
                    nuevaCarta = new Congelamiento();
                    break;
                case REFLEJO_MAGNETICO:
                    nuevaCarta = new ReflejoMagnetico();
                    break;
                case EMPUJE:
                    // Se usa un valor simple para el empuje (e.g., 2 casilleros).
                    nuevaCarta = new Empuje(2);
                    break;
                case TELETRANSPORTE:
                    // Dado que Teletransporte requiere coordenadas específicas,
                    // creamos una posición aleatoria válida dentro del tablero.
                    int tx, ty, tz;
                    do {
                        tx = rand.nextInt(tablero.getAncho()) + 1;
                        ty = rand.nextInt(tablero.getAlto()) + 1;
                        tz = rand.nextInt(tablero.getProfundo()) + 1;
                    } while (!tablero.getCasillero(tx, ty, tz).esTransitable() ||
                            !tablero.getCasillero(tx, ty, tz).estaVacio());

                    nuevaCarta = new Teletransporte(tx, ty, tz);
                    break;
                default:
                    // Para cualquier otro tipo, usamos la clase base si no se encuentra subclase
                    nuevaCarta = new CartaPoder(tipoElegido, "Carta base de poder no definida.");
                    break;
            }

            tablero.getCasillero(x, y, z).setCarta(nuevaCarta);
        }
        Teclado.imprimir(cantidadCartas + " cartas colocadas.");
    }


    /**
     * Maneja los turnos de los jugadores y el estado de la partida.
     */
    private static void ejecutarBucleDeJuego(List<Personaje> jugadores, List<Enemigo> enemigos, Tablero3D<Personaje> tablero) {

        int turno = 1;
        EstadoJuego estado = EstadoJuego.ACTIVO;

        while (estado == EstadoJuego.ACTIVO) {
            Teclado.imprimir("\n--- TURNO " + turno + " ---");


            // Usamos una copia para iterar para evitar problemas de concurrencia
            for (Personaje jugadorActual : new ArrayList<>(jugadores)) {
                if (!jugadorActual.estaVivo()) {
                    continue; // Salta al siguiente jugador si este está muerto
                }
                procesarTurnoJugador(jugadorActual, tablero, jugadores, enemigos);

                // Comprobar estado después de cada acción de jugador
                estado = comprobarEstadoJuego(jugadores, enemigos);
                if (estado != EstadoJuego.ACTIVO) break;
            }

            if (estado != EstadoJuego.ACTIVO) break; // Salir del bucle principal si el juego terminó


            // Eliminar enemigos y jugadores que hayan caído durante el turno de enemigos o contraataques
            enemigos.removeIf(e -> !e.estaVivo());
            jugadores.removeIf(j -> !j.estaVivo());

            // Comprobación final de victoria/derrota
            estado = comprobarEstadoJuego(jugadores, enemigos);

            turno++;
        }

        // Resultado final
        switch (estado) {
            case VICTORIA_ALIANZA:
                Teclado.imprimir("¡VICTORIA! La alianza de Héroes ha eliminado a todos los enemigos.");
                break;
            case VICTORIA_SOLITARIA:
                Teclado.imprimir("¡VICTORIA! Solo queda un jugador en pie.");
                break;
            case DERROTA:
                Teclado.imprimir("¡DERROTA! Todos los jugadores han sido eliminados.");
                break;
            default:
                break;
        }
    }


    private static void procesarTurnoJugador(Personaje jugador, Tablero3D<Personaje> tablero, List<Personaje> jugadores, List<Enemigo> enemigos) {

        Teclado.imprimir("Es el turno de: " + jugador.getNombre() + " (Vida: " + jugador.getVida() + ")");

        // REGENERACIÓN DE SALUD
        Teclado.imprimir("--- Tablero (Nivel Z=" + jugador.getZ() + ") ---");
        tablero.imprimirNivel(jugador.getZ());

        boolean turnoActivo = true;
        while (turnoActivo) {

            Teclado.imprimir("\nAcción para " + jugador.getNombre() + "? (W/A/S/D... = Mover, M = Menú, I = Instrucc.)");
            String accion = Teclado.leerString().toUpperCase();

            switch (accion) {
                // Movimientos en el plano XY y Z
                case "W": // Adelante (Y+1)
                case "S": // Atrás (Y-1)
                case "A": // Izquierda (X-1)
                case "D": // Derecha (X+1)
                case "E": // Diag. Atrás-Der (Y-1, X+1)
                case "Q": // Diag. Atrás-Izq (Y-1, X-1)
                case "C": // Diag. Adel-Der (Y+1, X+1)
                case "Z": // Diag. Adel-Izq (Y+1, X-1)
                case "U": // Arriba (Z+1)
                case "J": // Abajo (Z-1)
                    int dx = 0, dy = 0, dz = 0;
                    switch (accion) {
                        case "W": dy = 1;{ break;}
                        case "S": dy = -1; { break;}
                        case "A": dx = -1; { break;}
                        case "D": dx = 1; { break;}
                        case "E": dx = 1; dy = -1; { break;}
                        case "Q": dx = -1; dy = -1; { break;}
                        case "C": dx = 1; dy = 1; { break;}
                        case "Z": dx = -1; dy = 1; { break;}
                        case "U": dz = 1; { break;} // MOVIMIENTO Z+ (Arriba)
                        case "J": dz = -1; { break;}// MOVIMIENTO Z- (Abajo)
                    }
                    turnoActivo = !intentarMover(jugador, dx, dy, dz, tablero);
                    break;

                // Menú Secundario
                case "M":
                    mostrarMenuSecundario(jugador, jugadores, enemigos);
                    break; // Mostrar menú no gasta el turno

                // Instrucciones
                case "I":
                    imprimirBienvenidaEInstrucciones();
                    break; // Ver instrucciones no gasta el turno

                case "PASAR":
                    turnoActivo = false;
                    Teclado.imprimir(jugador.getNombre() + " decide no moverse.");
                    break;

                default:
                    Teclado.imprimir("Acción no reconocida. Intenta de nuevo.");
                    break;
            }
        }
    }

    /**
     * Procesa el turno de todos los enemigos vivos (IA básica: ataca si es adyacente).
     */
    private static void procesarTurnoEnemigos(List<Personaje> jugadores, List<Enemigo> enemigos, Tablero3D<Personaje> tablero) {
        Teclado.imprimir("\n--- TURNO DE LOS ENEMIGOS ---");

        // Iteramos sobre una copia para evitar problemas si un enemigo es derrotado.
        for (Enemigo enemigoActual : new ArrayList<>(enemigos)) {
            if (!enemigoActual.estaVivo()) {
                continue;
            }

            //  Encontrar al objetivo más cercano (un jugador vivo)
            Personaje objetivo = encontrarJugadorMasCercano(enemigoActual, jugadores);

            if (objetivo != null) {

                int xE = enemigoActual.getX();
                int yE = enemigoActual.getY();
                int zE = enemigoActual.getZ();

                int xO = objetivo.getX();
                int yO = objetivo.getY();
                int zO = objetivo.getZ();

                //  Comprobar si está adyacente para atacar (IA básica)
                if (tablero.esVecino3D(xE, yE, zE, xO, yO, zO)) {
                    Teclado.imprimir(enemigoActual.getNombre() + " (Enemigo) ATACA a " + objetivo.getNombre() + "!");
                    new Combate(enemigoActual, objetivo).pelear();

                } else {
                    // Lógica de movimiento: Un sistema de IA más robusto iría aquí (e.g., A* para moverse).
                    Teclado.imprimir(enemigoActual.getNombre() + " busca moverse hacia " + objetivo.getNombre() + " (No hay movimiento implementado para enemigos).");
                }
            } else {
                // Esto solo debería ocurrir si ya no quedan jugadores vivos.
                Teclado.imprimir(enemigoActual.getNombre() + " no tiene objetivos y espera.");
            }
        }
    }

    /**
     * Lógica central de movimiento, combate y recolección.
     * Mantiene la lógica robusta que estaba aquí (y que hacía redundante a SistemaMovimiento.java).
     *
     * @return true si la acción (moverse, atacar) fue exitosa y termina el turno, false si falló y el turno continúa.
     */
    private static boolean intentarMover(Personaje jugador, int dx, int dy, int dz, Tablero3D<Personaje> tablero) {
        int x = jugador.getX();
        int y = jugador.getY();
        int z = jugador.getZ();

        int nx = x + dx;
        int ny = y + dy;
        int nz = z + dz;

        //Validar si la posición existe en el tablero
        if (!tablero.existePosicion(nx, ny, nz)) {
            Teclado.imprimir("¡No puedes moverte fuera de los límites del tablero!");
            return false; // Falla, no termina el turno
        }

        Casillero casilleroActual = tablero.getCasillero(x, y, z);
        Casillero casilleroDestino = tablero.getCasillero(nx, ny, nz);

        //Validar si el casillero es transitable
        if (!casilleroDestino.esTransitable()) {
            Teclado.imprimir("¡No puedes moverte! Hay una ROCA en el camino.");
            return false; // Falla, no termina el turno
        }

        Object contenido = casilleroDestino.getContenido();

        // CASILLERO VACÍO → MOVER
        if (contenido == null) {

            Teclado.imprimir(jugador.getNombre() + " se mueve a (" + nx + "," + ny + "," + nz + ").");

            casilleroDestino.setContenido(jugador);
            casilleroActual.limpiarContenido();
            jugador.setPosicion(nx, ny, nz);

            // RECOGER CARTA
            if (casilleroDestino.tieneCarta()) {
                CartaPoder carta = casilleroDestino.recogerCarta();
                jugador.agregarCarta(carta);
                Teclado.imprimir(jugador.getNombre() + " ha recogido una carta: " + carta.getNombre());
            }

            return true;
        }


        //  ENEMIGO O PERSONAJE > COMBATE

        if (contenido instanceof Personaje objetivo) {

            Teclado.imprimir(jugador.getNombre() + " intenta atacar a " + objetivo.getNombre() + "!");

            new Combate(jugador, objetivo).pelear();

            if (!objetivo.estaVivo()) {

                Teclado.imprimir(jugador.getNombre() + " ha derrotado a " + objetivo.getNombre() + ".");

                // LOOT
                List<CartaPoder> botin = objetivo.getInventario();
                if (botin != null && !botin.isEmpty()) {
                    for (CartaPoder carta : botin) {
                        jugador.agregarCarta(carta);
                    }
                    botin.clear();
                }

                // MOVER AL JUGADOR A ESA CASILLA
                casilleroDestino.setContenido(jugador);
                casilleroActual.limpiarContenido();
                jugador.setPosicion(nx, ny, nz);
            }

            return true;
        }
        if (contenido instanceof Enemigo enemigo) {

            Teclado.imprimir(jugador.getNombre() + " se topa con " + enemigo.getNombre() + "!");

            new Combate(jugador, enemigo).pelear();

            if (!enemigo.estaVivo()) {
                Teclado.imprimir(jugador.getNombre() + " ha derrotado a " + enemigo.getNombre() + ".");

                // mover al jugador a esa casilla
                casilleroDestino.setContenido(jugador);
                casilleroActual.limpiarContenido();
                jugador.setPosicion(nx, ny, nz);
            }

            return true;
        }


        //CUALQUIER OTRA COSA

        Teclado.imprimir("No puedes moverte ahí.");
        return false;

    }

    /**
     * Muestra el menú de acciones secundarias (Cartas, Alianzas).
     */
    private static void mostrarMenuSecundario(Personaje jugador, List<Personaje> jugadores, List<Enemigo> enemigos) {
        Teclado.imprimir("\n--- MENÚ DE ACCIONES: " + jugador.getNombre() + " ---");
        Teclado.imprimir("1. Usar Carta de Poder");
        Teclado.imprimir("2. Gestionar Alianzas");
        Teclado.imprimir("3. Ver mis Stats e Inventario");
        Teclado.imprimir("4. Volver al turno");

        int opcion = Teclado.leerEntero();
        switch (opcion) {
            case 1:
                gestionarCartas(jugador, jugadores, enemigos);
                break;
            case 2:
                gestionarAlianzas(jugador, jugadores);
                break;
            case 3:
                Teclado.imprimir("Stats: " + jugador.toString());
                Teclado.imprimir("Inventario: " + (jugador.getInventario() != null ? jugador.getInventario().toString() : "Vacío"));
                break;
            case 4:
                Teclado.imprimir("Volviendo al turno...");
                break;
            default:
                Teclado.imprimir("Opción no válida.");
                break;
        }
    }

    /**
     * Lógica para usar una carta del inventario.
     */
    private static void gestionarCartas(Personaje jugador, List<Personaje> jugadores, List<Enemigo> enemigos) {
        Teclado.imprimir("--- Inventario de Cartas ---");
        List<CartaPoder> inventario = jugador.getInventario();
        if (inventario == null || inventario.isEmpty()) {
            Teclado.imprimir("No tienes cartas.");
            return;
        }

        for (int i = 0; i < inventario.size(); i++) {
            Teclado.imprimir(i + ". " + inventario.get(i).getNombre() + ": " + inventario.get(i).getDescripcion());
        }

        Teclado.imprimir("Elige una carta para usar (o -1 para cancelar):");
        int indice = Teclado.leerEntero(); // <-- Variable 'indice'
        if (indice < 0 || indice >= inventario.size()) {
            Teclado.imprimir("Uso de carta cancelado.");
            return;
        }

        List<Personaje> objetivosPosibles = new ArrayList<>();

        //Añadirse a sí mismo (para curarse por ejemplo)
        objetivosPosibles.add(jugador);
        Teclado.imprimir("--- ¿Sobre quién? ---");
        Teclado.imprimir("0. [TÚ MISMO] " + jugador.getNombre());

        //Añadir otros jugadores (aliados o no)
        int contador = 1;
        for (Personaje p : jugadores) {
            if (p != jugador && p.estaVivo()) { // Que no sea él mismo y esté vivo
                objetivosPosibles.add(p);
                Teclado.imprimir(contador + ". [JUGADOR] " + p.getNombre() + " (Vida: " + p.getVida() + ")");
                contador++;
            }
        }

        //Añadir enemigos
        for (Enemigo e : enemigos) {
            if (e.estaVivo()) {
                objetivosPosibles.add(e);
                Teclado.imprimir(contador + ". [ENEMIGO] " + e.getNombre() + " (Vida: " + e.getVida() + ")");
                contador++;
            }
        }
        // Pedir el objetivo
        Teclado.imprimir("Elige un objetivo (o -1 para cancelar):");
        int indiceObjetivo = Teclado.leerEntero();

        if (indiceObjetivo < 0 || indiceObjetivo >= objetivosPosibles.size()) {
            Teclado.imprimir("Uso de carta cancelado.");
            return;
        }

        //  Ejecutar la carta
        Personaje objetivoSeleccionado = objetivosPosibles.get(indiceObjetivo);

        jugador.usarCarta(indice, objetivoSeleccionado);
    }


    /**
     * Lógica para gestionar alianzas.
     */
    private static void gestionarAlianzas(Personaje jugador, List<Personaje> jugadores) {
        Teclado.imprimir("--- Gestión de Alianzas ---");
        Teclado.imprimir("Alianza actual: " + (jugador.getAlianza() != null ? "Miembro" : "Ninguna"));
        Teclado.imprimir("1. Ver miembros de mi alianza");
        Teclado.imprimir("2. Compartir carta (con aliado cercano)");
        Teclado.imprimir("3. Pedir ayuda");
        Teclado.imprimir("4. Abandonar alianza");

        int opcion = Teclado.leerEntero();
        switch (opcion) {
            case 1:
                if (jugador.tieneAlianza()) jugador.getAlianza().verAliados();
                else Teclado.imprimir("No estás en una alianza.");
                break;
            case 2:
                // Esta lógica es muy simple, solo busca al primer aliado que encuentra
                Personaje aliado = null;
                for (Personaje p : jugadores) {
                    // Se agrega chequeo de que esté vivo para evitar compartir con personajes inactivos.
                    if (p != jugador && p.getAlianza() == jugador.getAlianza() && p.estaVivo()) {
                        aliado = p;
                        break;
                    }
                }
                if (aliado != null) {
                    Teclado.imprimir("Compartiendo con " + aliado.getNombre());
                    jugador.compartirCarta(aliado); // (Asume que este método existe y funciona)
                }
                else Teclado.imprimir("No se encontró un aliado vivo.");
                break;
            case 3:
                jugador.pedirAyuda(); // (Asume que este método existe)
                break;
            case 4:
                jugador.salirdeAlianza(); // (Asume que este método existe)
                break;
        }
    }

    /**
     * Encontrar el objetivo más cercano.
     */
    private static Personaje encontrarJugadorMasCercano(Enemigo enemigo, List<Personaje> jugadores) {
        Personaje masCercano = null;
        double minDist = Double.MAX_VALUE;

        for (Personaje p : jugadores) {
            if (!p.estaVivo()) continue;

            int dx = p.getX() - enemigo.getX();
            int dy = p.getY() - enemigo.getY();
            int dz = p.getZ() - enemigo.getZ();
            // Distancia Euclidiana
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

            if (dist < minDist) {
                minDist = dist;
                masCercano = p;
            }
        }
        return masCercano;
    }

    /**
     * Comprueba las condiciones de victoria/derrota.
     */
    private static EstadoJuego comprobarEstadoJuego(List<Personaje> jugadores, List<Enemigo> enemigos) {
        int jugadoresVivos = 0;
        for (Personaje p : jugadores) {
            if (p.estaVivo()) {
                jugadoresVivos++;
            }
        }

        int enemigosVivos = 0;
        for (Enemigo e : enemigos) {
            if (e.estaVivo()) {
                enemigosVivos++;
            }
        }

        if (jugadoresVivos == 0) {
            return EstadoJuego.DERROTA;
        }

        if (enemigosVivos == 0) {
            if (jugadoresVivos > 1) {
                // (Aquí faltaría la lógica de si son de la misma alianza)
                // Por ahora, si no hay enemigos, los jugadores ganan.
                return EstadoJuego.VICTORIA_ALIANZA;
            } else {
                return EstadoJuego.VICTORIA_SOLITARIA;
            }
        }

        return EstadoJuego.ACTIVO;
    }

}