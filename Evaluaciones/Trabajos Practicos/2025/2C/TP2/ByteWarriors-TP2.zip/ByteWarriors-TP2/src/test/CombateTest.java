package test;

import org.junit.jupiter.api.Test;
import logica.Combate;
import modelo.Personaje;
import static org.junit.jupiter.api.Assertions.*;

class CombateTest {

    @Test
    void testCombateNormal() {
        // P1: Fuerza 20
        Personaje p1 = new Personaje("P1", 100, 0,0,0, 20, 0, 0, 0);
        // P2: Fuerza 10, Defensa 0 (para facilitar cálculo)
        Personaje p2 = new Personaje("P2", 100, 0,0,0, 10, 0, 0, 0);

        // Ejecutar combate
        new Combate(p1, p2).pelear();

        // P1 ataca a P2: P2 recibe 20 daño -> P2 Vida 80
        // P2 contraataca a P1: P1 recibe 10 daño -> P1 Vida 90

        assertEquals(90, p1.getVida(), "P1 debería haber recibido el contraataque");
        assertEquals(80, p2.getVida(), "P2 debería haber recibido el ataque inicial");
    }

    @Test
    void testCombateContraUnoMismo() {
        Personaje p1 = new Personaje("P1", 100, 0,0,0, 10, 0, 0, 0);
        new Combate(p1, p1).pelear();

        // La vida no debería cambiar
        assertEquals(100, p1.getVida());
    }

    @Test
    void testCombateConMuerto() {
        Personaje vivo = new Personaje("Vivo", 100, 0,0,0, 10, 0, 0, 0);
        Personaje muerto = new Personaje("Muerto", 0, 0,0,0, 10, 0, 0, 0); // Vida 0

        new Combate(vivo, muerto).pelear();

        // Nadie debe recibir daño porque se anula
        assertEquals(100, vivo.getVida());
    }

    // Nota: Para probar el caso de "Misma Alianza", necesitaríamos una implementación real
    // o un Mock de la clase Alianza. Si tienes la clase Alianza, podrías agregar ese test.
}