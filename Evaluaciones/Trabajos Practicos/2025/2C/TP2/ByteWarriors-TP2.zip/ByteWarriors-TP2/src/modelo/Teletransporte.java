package modelo;

import util.Teclado;

public class Teletransporte extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int posx, posy, posz;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre: (nx, ny, nz) dentro del tablero.
     * Post: el usuario sera teletransportado a esa posicion.
     * @param posx
     * @param posy
     * @param posz
     */
    public Teletransporte(int posx, int posy, int posz) {
        super(TipoCarta.TELETRANSPORTE, "Teletransporta al usuario a una nueva posicion.");
        this.posx = posx;
        this.posy = posy;
        this.posz = posz;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: usuario no nulo.
     * Post: actualiza la posicion del usuario.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.setPosicion(posx, posy, posz);
        Teclado.imprimir(usuario.getNombre() + " se teletransporta a (" + posx + ", " + posy + ", " + posz + ")");
    }

//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
