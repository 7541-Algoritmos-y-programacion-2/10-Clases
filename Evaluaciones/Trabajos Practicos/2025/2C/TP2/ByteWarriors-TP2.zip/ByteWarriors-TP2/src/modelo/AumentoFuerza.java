package modelo;

import util.Teclado;

public class AumentoFuerza extends CartaPoder{
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int aumento;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Crea una carta que aumenta la fuerza del usuario.
     * Pre: aumento > 0.
     * Post: La carta queda inicializada con el valor de aumento.
     * @param aumento
     */
    public AumentoFuerza(int aumento) {
        super(TipoCarta.AUMENTO_FUERZA, "Aumenta la fuerza del usuario.");
        this.aumento = aumento;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE

    /**
     * Pre: usuario no es nulo.
     * Post: aumenta la fuerza del usuario.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.setFuerza(usuario.getFuerza() + aumento);
        Teclado.imprimir(usuario.getNombre() + " gana +" + aumento + " fuerza.");
    }

//METODOS GENERALES
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
