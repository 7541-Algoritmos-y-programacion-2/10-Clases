package modelo;

import modelo.CartaPoder;
import modelo.TipoCarta;
import modelo.Personaje;

public class Empuje extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int distancia;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre: distancia != 0.
     * Post: la carta queda inicializada para mover al objetivo.
     * @param distancia
     */
    public Empuje(int distancia) {
        super(TipoCarta.EMPUJE, "Empuja al objetivo cierta cantidad de casilleros.");
        this.distancia = distancia;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: objetivo no es nulo.
     * Post: modifica la posicion X del objetivo.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        objetivo.setPosicion(objetivo.getX() + distancia, objetivo.getY(), objetivo.getZ());
        System.out.println(objetivo.getNombre() + " es empujado " + distancia + " casilleros.");
    }

//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
