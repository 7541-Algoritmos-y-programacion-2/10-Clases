package modelo;

import util.Teclado;

public class ReflejoMagnetico extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS
//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre:
     * Post: activa el reflejo magnetico por 1 turno.
     */
    public ReflejoMagnetico() {
        super(TipoCarta.REFLEJO_MAGNETICO, "Devuelve cualquier ataque recibido durante un turno.");
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: usuario no es nulo.
     * Post: se activa el estado de reflejo magnetico.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.activarReflejoMagnetico();
        Teclado.imprimir(usuario.getNombre() + " activa REFLEJO MAGNETICO.");
    }

//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
