package modelo;

public class Curacion extends CartaPoder{
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int puntos;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre: puntos > 0.
     * Post: la carta cura la cantidad indicada.
     * @param puntos
     */
    public Curacion(int puntos) {
        super(TipoCarta.CURACION, "Restarua puntos de vida al usuario.");
        this.puntos = puntos;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE

    /**
     * Pre: usuario no nulo.
     * Post: la vida del usuario aument hasta el maximo permitido.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        usuario.recuperarVida(puntos);
    }

//METODOS GENERALES
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
