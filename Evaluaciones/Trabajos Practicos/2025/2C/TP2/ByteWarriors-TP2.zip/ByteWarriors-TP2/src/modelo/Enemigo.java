package modelo;

public class Enemigo extends Personaje {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS
//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Crea un enemigo con los parametros especificados.
     * Pre: Los valores de vida, fuerza, defensa y vision deben ser mayores o iguales a 0.
     * Post: Se inicializa un enemigo con los valores indicados, un tipo definido y un nivel determinado.
     * @param nombre
     * @param vida
     * @param x
     * @param y
     * @param z
     * @param fuerza
     * @param defensa
     * @param vision
     */
    public Enemigo(String nombre, int vida, int x, int y, int z, int fuerza, int defensa, int vision, int porcentajeSalud) {
        super(nombre, vida, x, y, z, fuerza, defensa, vision, porcentajeSalud);
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
