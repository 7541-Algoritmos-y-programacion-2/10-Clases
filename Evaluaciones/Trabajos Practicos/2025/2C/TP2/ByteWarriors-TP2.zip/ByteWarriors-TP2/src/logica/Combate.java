package logica;

import modelo.Personaje;
import util.Teclado;

public class Combate {

    private final Personaje atacante;
    private final Personaje defensor;

    public Combate(Personaje atacante, Personaje defensor) {
        this.atacante = atacante;
        this.defensor = defensor;
    }

    /**
     * Ejecuta un combate de un único intercambio de golpes.
     */
    public void pelear() {

        Teclado.imprimir("---------------------------------------------");
        Teclado.imprimir("Iniciando combate: " + atacante.getNombre() + " vs. " + defensor.getNombre());
        Teclado.imprimir("----------------------------------------------");

        // 1) Validación: no luchar con uno mismo
        if (atacante == defensor) {
            Teclado.imprimir("Un personaje no puede luchar consigo mismo.");
            Teclado.imprimir("Combate anulado.");
            return;
        }

        // 2) Ambos deben estar vivos
        if (!atacante.estaVivo() || !defensor.estaVivo()) {
            Teclado.imprimir("Uno de los combatientes ya está muerto. Combate anulado.");
            return;
        }

        // 3) Alianza (si comparten → no pelean)
        if (atacante.getAlianza() != null &&
                atacante.getAlianza() == defensor.getAlianza()) {

            Teclado.imprimir("¡El contrincante es un amigo!");
            Teclado.imprimir(atacante.getNombre() + " y " + defensor.getNombre() +
                    " pertenecen a la misma alianza.");
            Teclado.imprimir("Combate anulado.");
            return;
        }

        // Combate permitido
        Teclado.imprimir("¡Combate permitido!");
        Teclado.imprimir("--- INICIA DEL COMBATE ---");

        // ATAQUE PRINCIPAL DEL ATACANTE
        Teclado.imprimir(atacante.getNombre() + " (Fuerza: " + atacante.getFuerza() +
                ") ataca a " + defensor.getNombre() +
                " (Defensa: " + defensor.getDefensa() + ")");

        defensor.recibirAtaque(atacante.getFuerza());

        // SI DEFENSOR SIGUE VIVO → CONTRAATACA
        if (defensor.estaVivo()) {
            Teclado.imprimir(defensor.getNombre() + " (Fuerza: " + defensor.getFuerza() +
                    ") contraataca a " + atacante.getNombre() +
                    " (Defensa: " + atacante.getDefensa() + ")");
            atacante.recibirAtaque(defensor.getFuerza());
        } else {
            Teclado.imprimir(defensor.getNombre() + " ha caído. No puede contraatacar.");
        }

        Teclado.imprimir("--- FIN DEL INTERCAMBIO ---");

        // RESULTADO FINAL
        boolean vivoA = atacante.estaVivo();
        boolean vivoD = defensor.estaVivo();

        if (!vivoA && !vivoD) {
            Teclado.imprimir("RESULTADO: ¡Ambos combatientes han caído! Empate.");
        } else if (!vivoA) {
            Teclado.imprimir("RESULTADO: ¡" + defensor.getNombre() + " es el ganador!");
        } else if (!vivoD) {
            Teclado.imprimir("RESULTADO: ¡" + atacante.getNombre() + " es el ganador!");
        } else {
            Teclado.imprimir("RESULTADO: ¡Ambos siguen vivos!");
            Teclado.imprimir(atacante.getNombre() + " - Vida: " + atacante.getVida());
            Teclado.imprimir(defensor.getNombre() + " - Vida: " + defensor.getVida());
        }
    }
}
