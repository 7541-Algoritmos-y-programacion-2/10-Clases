package logica;

import modelo.*;
import util.Teclado;

public class SistemaMovimiento {

    private Tablero3D<Personaje> tablero;
    private SistemaColisiones colisiones;

    public SistemaMovimiento(Tablero3D<Personaje> tablero) {
        this.tablero = tablero;
        this.colisiones = new SistemaColisiones();
    }

    /**
     * Intenta mover un personaje al destino indicado.
     */
    public boolean intentarMover(Personaje p, int xNuevo, int yNuevo, int zNuevo) {

        if (!tablero.existePosicion(xNuevo, yNuevo, zNuevo)) {
            Teclado.imprimir("Movimiento fuera del tablero.");
            return false;
        }

        if (!p.puedeVer(xNuevo, yNuevo, zNuevo)) {
            Teclado.imprimir("Movimiento no permitido: fuera del área de visión.");
            return false;
        }

        if (!tablero.esVecino3D(p.getX(), p.getY(), p.getZ(), xNuevo, yNuevo, zNuevo)) {
            Teclado.imprimir("Movimiento ilegal: solo a casilleros vecinos.");
            return false;
        }

        Casillero<Personaje> destino = tablero.getCasillero(xNuevo, yNuevo, zNuevo);

        if (!destino.esTransitable()) {
            Teclado.imprimir("Movimiento bloqueado: casillero no transitable.");
            return false;
        }

        Object contenido = destino.getContenido();


        // =======================================================================
        // ENEMIGO
        // =======================================================================
        if (contenido instanceof Enemigo enem) {

            Teclado.imprimir(p.getNombre() + " intenta atacar a " + enem.getNombre() + "!");

            new Combate(p, enem).pelear();

            if (!p.estaVivo()) return false;

            Casillero<Personaje> origen =
                    tablero.getCasillero(p.getX(), p.getY(), p.getZ());

            // Si murió enemigo → mover al jugador a ese casillero
            if (!enem.estaVivo()) {
                destino.limpiarContenido();
                origen.limpiarContenido();
                destino.setContenido(p);
                p.setPosicion(xNuevo, yNuevo, zNuevo);
            }

            return true; // <- SUPER IMPORTANTE
        }


        // =======================================================================
        // OTRO JUGADOR
        // =======================================================================
        if (contenido instanceof Personaje otro) {

            if (p.getAlianza() != null && p.getAlianza() == otro.getAlianza()) {
                Teclado.imprimir("¡" + p.getNombre() +
                        " se encontró con su aliado " + otro.getNombre() + "!");
                return false; // no se mueven
            }

            Teclado.imprimir(p.getNombre() + " intenta atacar a " + otro.getNombre() + "!");

            new Combate(p, otro).pelear();

            if (!p.estaVivo()) return false;

            Casillero<Personaje> origen =
                    tablero.getCasillero(p.getX(), p.getY(), p.getZ());

            if (!otro.estaVivo()) {
                destino.limpiarContenido();
                origen.limpiarContenido();
                destino.setContenido(p);
                p.setPosicion(xNuevo, yNuevo, zNuevo);
            }

            return true; // <- MUY IMPORTANTE
        }


        // =======================================================================
        // SI NO HAY PERSONAJE NI ENEMIGO → Movimiento normal
        // =======================================================================

        if (destino.tieneCarta()) {
            CartaPoder carta = destino.recogerCarta();
            p.agregarCarta(carta);
            Teclado.imprimir(p.getNombre() +
                    " ha recogido una carta: " + carta.getDescripcion());
        }

        Casillero<Personaje> origen =
                tablero.getCasillero(p.getX(), p.getY(), p.getZ());

        origen.limpiarContenido();
        destino.setContenido(p);
        p.setPosicion(xNuevo, yNuevo, zNuevo);

        Teclado.imprimir(p.getNombre() +
                " se movió a (" + xNuevo + "," + yNuevo + "," + zNuevo + ").");

        return true;
    }

}
