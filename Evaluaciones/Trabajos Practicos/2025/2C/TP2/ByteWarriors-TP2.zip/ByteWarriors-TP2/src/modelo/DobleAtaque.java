package modelo;

import util.Teclado;

public class DobleAtaque extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS
//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre:
     * Post: permite al usuario tocar dos veces.
     */
    public DobleAtaque() {
        super(TipoCarta.DOBLE_ATAQUE, "Permite al usuario realizar dos ataques este turno.");
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: usuario no es nulo.
     * Post: el usuario tendra doble ataque.
     * @param usuario personaje que usa la carta.
     * @param objetivo se muestra un mensaje informando el efecto aplicado.
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        if (usuario == null) {
            throw new RuntimeException("Usuario nulo.");
        }

        usuario.setEstado(EstadoEspecial.DOBLE_ATAQUE);
        Teclado.imprimir(usuario.getNombre() + " podra atacar dos veces este turno.");
    }

//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
