package modelo;

public enum TipoCasillero {
    VACIO,
    ROCA,
    AGUA,
    FUEGO,
    CARTA,
    PERSONAJE,
    ENEMIGO;
}
