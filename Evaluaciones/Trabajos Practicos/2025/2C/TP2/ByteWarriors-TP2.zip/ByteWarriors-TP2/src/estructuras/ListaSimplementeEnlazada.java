package estructuras;

import estructuras.Nodo;

public class ListaSimplementeEnlazada<T> {
    private Nodo<T> primero;
    private int tamanio;

    public ListaSimplementeEnlazada() {
        primero = null;
        tamanio = 0;
    }

    public void insertarFinal(T valor) {
        Nodo<T> nuevo = new Nodo<>(valor);
        if (primero == null) {
            primero = nuevo;
        } else {
            Nodo<T> aux = primero;
            while (aux.getSiguiente() != null) {
                aux = aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        tamanio++;
    }

    public T obtener(int pos) {
        if (pos < 0 || pos >= tamanio) {
            throw new IndexOutOfBoundsException("Posición fuera de rango");
        }
        Nodo<T> aux = primero;
        for (int i = 0; i < pos; i++) {
            aux = aux.getSiguiente();
        }
        return aux.getValor();
    }

    public int tamanio() { return tamanio; }

    public boolean estaVacia() { return primero == null; }
}

