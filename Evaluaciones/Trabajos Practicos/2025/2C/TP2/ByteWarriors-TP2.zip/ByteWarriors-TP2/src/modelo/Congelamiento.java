package modelo;

import util.Teclado;

public class Congelamiento extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS
//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre:
     * Post: crea una carta que impide el movimiento por 1 turno.
     */
    public Congelamiento() {
        super(TipoCarta.CONGELAMIENTO, "Impide que el objetivo se mueva durante 1 turno.");
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    /**
     * Pre: objetivo no es nulo.
     * Post: el objetivo queda congelado (no puede moverse).
     * @param usuario Personaje que utiliza la carta.
     * @param objetivo Personaje que recibe el efecto.
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        if (usuario == null || objetivo == null) {
            throw new RuntimeException("El usuario u objetivo son nulos.");
        }

        objetivo.setEstado(EstadoEspecial.CONGELADO);
        Teclado.imprimir(objetivo.getNombre() + " queda congelado durante un turno.");
    }
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
