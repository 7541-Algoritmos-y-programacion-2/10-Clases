package test;

import org.junit.jupiter.api.Test;
import modelo.Enemigo;

import static org.junit.jupiter.api.Assertions.*;

class EnemigoTest {

    @Test
    void testCreacionEnemigo() {
        Enemigo enemigo = new Enemigo("Orco", 200, 5, 5, 0, 30, 15, 10, 5);

        assertEquals("Orco", enemigo.getNombre());
        assertEquals(200, enemigo.getVida());
        assertEquals(30, enemigo.getFuerza());
        assertTrue(enemigo.estaVivo());
    }
}
