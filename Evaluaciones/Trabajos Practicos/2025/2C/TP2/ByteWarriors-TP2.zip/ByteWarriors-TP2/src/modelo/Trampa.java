package modelo;

public class Trampa extends CartaPoder {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private int danio;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Pre: danio > 0.
     * Post: queda inicializada una carta que inflije daño directo.
     * @param danio
     */
    public Trampa(int danio) {
        super(TipoCarta.TRAMPA, "Inflige daño directo al objetivo.");
        this.danio = danio;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE

    /**
     * Pre: objetivo no es nulo.
     * Post: el objetivo recibe daño directo sin aplicar defensa.
     * @param usuario
     * @param objetivo
     */
    @Override
    public void aplicar(Personaje usuario, Personaje objetivo) {
        objetivo.recibirAtaque(danio);
    }

//METODOS GENERALES
//METODOS DE COMPORTAMIENTO
//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES
//SETTERS COMPLEJOS
//SETTERS SIMPLES
}
