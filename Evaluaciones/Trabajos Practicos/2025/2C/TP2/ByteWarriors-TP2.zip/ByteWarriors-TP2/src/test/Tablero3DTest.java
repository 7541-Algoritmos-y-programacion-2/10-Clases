package test;

import modelo.Tablero3D;
import modelo.Casillero;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Tablero3DTest {

    @Test
    void testCrearTablero() {
        Tablero3D<String> tablero = new Tablero3D<>(3, 3, 2);

        assertEquals(3, tablero.getAncho());
        assertEquals(3, tablero.getAlto());
        assertEquals(2, tablero.getProfundo());
    }

    @Test
    void testObtenerCasillero() {
        Tablero3D<String> tablero = new Tablero3D<>(3, 3, 2);

        Casillero<String> c = tablero.getCasillero(2, 2, 1);

        // Verificamos que sea el casillero correcto SIN tocar atributos privados
        assertNotNull(c);
        assertEquals(c, tablero.getCasillero(2, 2, 1));
    }

    @Test
    void testEsVecino3D() {
        Tablero3D<String> tablero = new Tablero3D<>(5, 5, 5);

        assertTrue(tablero.esVecino3D(1,1,1, 2,1,1));
        assertTrue(tablero.esVecino3D(3,3,3, 2,2,2));
        assertFalse(tablero.esVecino3D(1,1,1, 4,4,4));
    }

    @Test
    void testExistePosicion() {
        Tablero3D<String> tablero = new Tablero3D<>(3, 3, 2);

        assertTrue(tablero.existePosicion(1,1,1));
        assertFalse(tablero.existePosicion(4,1,1));
        assertFalse(tablero.existePosicion(1,4,1));
        assertFalse(tablero.existePosicion(1,1,3));
    }
}
