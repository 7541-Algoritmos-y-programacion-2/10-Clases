package modelo;

import util.Validaciones;

/**
 * TDA de datos Casillero.
 * Representa una posición del tablero 3D.
 */
public class Casillero<T> {

    private int x, y, z;
    private T contenido; // puede ser Personaje, Carta, etc
    private CartaPoder carta;
    private TipoCasillero tipoCasillero;

    public Casillero(int x, int y, int z, TipoCasillero tipoCasillero) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.contenido = null;
        this.carta = null;
        setTipoCasillero(tipoCasillero);
    }

    /**
     * Devuelve true si el TERRENO no es un obstaculo.
     * @return
     */
    public boolean esTransitable(){
        return tipoCasillero != TipoCasillero.ROCA &&
                tipoCasillero != TipoCasillero.AGUA &&
                tipoCasillero != TipoCasillero.FUEGO;
    }

    /**
     * Devuelve true si NO HAY un Personaje o Enemigo en el casillero.
     * @return
     */
    public boolean estaVacio() {
        return contenido == null; }

    /**
     * Devuelve true si hay una CartaPoder en el suelo
     * @return
     */
    public boolean tieneCarta() {
        return carta != null;
    }

    /**
     * Quita a la entidad del casillero
     */
    public void limpiarContenido() {
        this.contenido = null;
    }

    /**
     * Recoge la carta del suelo.
     * @return la CartaPoder que estaba en el suelo.
     */
    public CartaPoder recogerCarta() {
        CartaPoder cartaRecogida = this.carta;
        this.carta = null;
        this.tipoCasillero = TipoCasillero.VACIO;
        return cartaRecogida;
    }


    public T getContenido() {
        return contenido; }

    public TipoCasillero getTipoCasillero(){
        return tipoCasillero;
    }

    /**
     * Actualiza el tipo de casillero segun el objeto
     * @param contenido
     */
    public void setContenido(T contenido) {
        this.contenido = contenido;

        if (contenido == null) {
            this.tipoCasillero = TipoCasillero.VACIO;
        }
        else if (contenido instanceof Personaje) {
            this.tipoCasillero = TipoCasillero.PERSONAJE;
        }
        else if (contenido instanceof Enemigo) {
            this.tipoCasillero = TipoCasillero.ENEMIGO;
        }
    }

    /**
     * Coloca una CartaPoder en el suelo de este casillero.
     * @param carta
     */
    public void setCarta(CartaPoder carta) {
        this.carta = carta;
        if (carta != null) {
            this.tipoCasillero = TipoCasillero.CARTA;
        } else {
            this.tipoCasillero = TipoCasillero.VACIO;
        }
    }

    private void setX(int x){
        util.Validaciones.validarMayorACero(x, "x");
        this.x = x;
    }

    private void setY(int y){
        util.Validaciones.validarMayorACero(y, "y");
        this.y = y;
    }

    private void setZ(int z){
        util.Validaciones.validarMayorACero(z, "z");
        this.z = z;
    }

    /**
     * Cambia el tipo de TERRENO del casillero
     * @param tipoCasillero
     */
    public void setTipoCasillero(TipoCasillero tipoCasillero){
        Validaciones.esDistintoDeNull(tipoCasillero, "tipo de casillero");
        this.tipoCasillero = tipoCasillero;
    }

    /**
     * 1. Entidad (P/E)
     * 2. Carta (C)
     * 3. Terreno (R, A, .)
     * @return
     */
    @Override
    public String toString() {

        // Contenido (Personaje o Enemigo)
        if (contenido != null) {
            if (contenido instanceof Enemigo) {
                return "[E]";
            }
            return "[P]";
        }
        // Carta en el piso
        if (tieneCarta()) {
            return "[C]";
        }
        // Terreno
        return switch (tipoCasillero) {
            case VACIO -> "[.]";
            case ROCA -> "[R]";
            case AGUA -> "[A]";
            case FUEGO -> "[F]";
            default -> "[?]";
        };
    }

}

