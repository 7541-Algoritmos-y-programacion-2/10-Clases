package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import modelo.Personaje;
import modelo.TipoCarta;
import modelo.CartaPoder;

import static org.junit.jupiter.api.Assertions.*;

class PersonajeTest {

    // ---- Stub interno para evitar tocar el modelo ----
    private static class CartaPoderStub extends CartaPoder {
        public CartaPoderStub() {
            super(TipoCarta.AUMENTO_FUERZA, "Stub");
        }

        @Override
        public void aplicar(Personaje usuario, Personaje objetivo) {
            // Vacío, solo para pruebas
        }
    }

    private Personaje personaje;

    @BeforeEach
    void setUp() {
        personaje = new Personaje("Héroe", 100, 1, 1, 1, 20, 10, 5, 10);
    }

    @Test
    void testConstructor() {
        assertEquals("Héroe", personaje.getNombre());
        assertEquals(100, personaje.getVida());
        assertTrue(personaje.estaVivo());
    }

    @Test
    void testRecibirAtaque() {
        personaje.recibirAtaque(30);
        assertEquals(75, personaje.getVida());
    }

    @Test
    void testDañoMinimo() {
        personaje.recibirAtaque(2);
        assertEquals(99, personaje.getVida());
    }

    @Test
    void testMuerte() {
        personaje.recibirAtaque(200);
        assertEquals(0, personaje.getVida());
        assertFalse(personaje.estaVivo());
    }

    @Test
    void testRecuperarVida() {
        personaje.setVida(50);
        personaje.recuperarVida(20);
        assertEquals(70, personaje.getVida());
    }

    @Test
    void testRecuperarNoSuperaMaximo() {
        personaje.recuperarVida(500);
        assertEquals(100, personaje.getVida());
    }

    @Test
    void testRegenerarSalud() {
        personaje.setVida(50);
        personaje.regenerarSalud();
        assertEquals(60, personaje.getVida()); // 10%
    }

    @Test
    void testInventario() {
        for (int i = 0; i < 10; i++) personaje.agregarCarta(new CartaPoderStub());
        assertEquals(10, personaje.getInventario().size());

        personaje.agregarCarta(new CartaPoderStub());
        assertEquals(10, personaje.getInventario().size());
    }

    @Test
    void testPuedeVer() {
        assertTrue(personaje.puedeVer(2, 2, 2));
        assertTrue(personaje.puedeVer(6, 1, 1));
        assertFalse(personaje.puedeVer(7, 1, 1));
    }

    @Test
    void testSettersLimites() {
        personaje.setFuerza(-10);
        assertEquals(0, personaje.getFuerza());

        personaje.setDefensa(-5);
        assertEquals(0, personaje.getDefensa());
    }
}
