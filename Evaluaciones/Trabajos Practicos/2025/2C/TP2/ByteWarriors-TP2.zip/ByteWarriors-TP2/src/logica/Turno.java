package logica;

import java.util.NoSuchElementException;

/**
 * implementado con lista circular.
 * Controla el orden de jugadores en el juego.
 */
public class Turno<T> {

    private NodoTurno<T> actual;   // referencia al nodo actual
    private int cantidad;

    /**
     * Nodo interno para representar la lista circular.
     */
    private static class NodoTurno<T> {
        T jugador;
        NodoTurno<T> siguiente;

        NodoTurno(T jugador) {
            this.jugador = jugador;
        }
    }

    /** Crea una lista de turnos vacía */
    public Turno() {
        this.actual = null;
        this.cantidad = 0;
    }

    // MÉTODOS PRINCIPALES

    /**
     * Agrega un jugador al ciclo de turnos.
     */

    public void agregarJugador(T jugador) {
        NodoTurno<T> nuevo = new NodoTurno<>(jugador);

        if (actual == null) {
            // primer jugador → se apunta a sí mismo
            actual = nuevo;
            nuevo.siguiente = nuevo;
        } else {
            // insertar después del actual
            nuevo.siguiente = actual.siguiente;
            actual.siguiente = nuevo;
        }
        cantidad++;
    }

    /**
     * Avanza al siguiente jugador del ciclo.
     */

    public void avanzarTurno() {
        if (actual == null) throw new RuntimeException("No hay jugadores en turno.");
        actual = actual.siguiente;
    }

    /**
     * Devuelve el jugador cuyo turno es actualmente.
     */

    public T obtenerJugadorActual() {
        if (actual == null) throw new RuntimeException("No hay jugadores cargados.");
        return actual.jugador;
    }

    /**
     * Salta al siguiente jugador (pierde turno).
     */

    public void saltarTurno() {
        avanzarTurno();
    }

    /**
     * Remueve al jugador actual del ciclo.
     * El turno pasa automáticamente al siguiente.
     */

    public void removerJugadorActual() {
        if (actual == null) throw new RuntimeException("No hay jugadores para remover");

        NodoTurno<T> temp = actual;

        if (cantidad == 1) {
            // queda vacío
            actual = null;
        } else {
            // buscar el nodo anterior
            NodoTurno<T> anterior = actual;
            while (anterior.siguiente != temp) {
                anterior = anterior.siguiente;
            }

            // saltar el nodo actual
            anterior.siguiente = actual.siguiente;
            actual = actual.siguiente;
        }

        cantidad--;
    }

    /** Devuelve cuántos jugadores están en el ciclo */

    public int getCantidad() {
        return cantidad;
    }

    /** Indica si está vacío */

    public boolean estaVacio() {
        return cantidad == 0;
    }
}

