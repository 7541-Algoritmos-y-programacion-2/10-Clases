package test;
import org.junit.jupiter.api.Test;
import modelo.CartaPoder;
import modelo.Personaje;


import modelo.TipoCarta;
import static org.junit.jupiter.api.Assertions.*;

class CartaPoderTest {

    @Test
    void testCreacionCarta() {
        // Asumiendo que tienes un enum TipoCarta.ATAQUE, ajusta según tu enum real.
        // Si no tienes el enum a mano, esto dará error de compilación hasta que lo ajustes.
        TipoCarta tipo = TipoCarta.ATAQUE; // Ajustar esto a tu enum real
        String desc = "Aumenta ataque";

        CartaPoder carta = new CartaPoder(tipo, desc);

        assertEquals(tipo, carta.getNombre());
        assertEquals(desc, carta.getDescripcion());
    }

    @Test
    void testAplicarNoRompe() {
        // El método aplicar en la clase base está vacío, 
        // solo probamos que se pueda llamar sin error.
        CartaPoder carta = new CartaPoder(TipoCarta.DEFENSA, "Desc");
        Personaje p1 = new Personaje("P1", 100,0,0,0,10,10,10,10);
        Personaje p2 = new Personaje("P2", 100,0,0,0,10,10,10,10);

        assertDoesNotThrow(() -> carta.aplicar(p1, p2));
    }
}