package modelo;

import java.util.*;
import modelo.Tablero3D;
import logica.Alianza;
import util.Teclado;

public class Personaje {
//INTERFACES
//ENUMERADOS
//CONSTANTES
//ATRIBUTOS DE CLASE
//ATRIBUTOS

    private String nombre;
    private int vida;
    private int maxVida;
    private int x, y, z;
    private int fuerza;
    private int defensa;
    private int vision;
    private int porcentajeSalud;
    private Alianza alianza;
    private List<CartaPoder> inventario;
    private EstadoEspecial estado = EstadoEspecial.NORMAL;
    private boolean dobleTurnoActivo = false;
    private boolean reflejoMagneticoActivo = false;

//ATRIBUTOS TRANSITORIOS
//CONSTRUCTORES

    /**
     * Crea un nuevo personje con los atributos especificos.
     * Pre: Los parametros deben representar valores validos de vida, fuerza, defensa y vision (mayores o iguales a 0).
     * Post: Se incializa un personaje con los valores indicados y un inventario vacio.
     * @param nombre
     * @param vida
     * @param x
     * @param y
     * @param z
     * @param fuerza
     * @param defensa
     * @param vision
     */
    public Personaje(String nombre, int vida, int x, int y, int z, int fuerza, int defensa, int vision, int porcentajeSalud) {
        this.nombre = nombre;
        this.vida = vida;
        this.maxVida = vida;
        this.x = x;
        this.y = y;
        this.z = z;
        this.fuerza = fuerza;
        this.defensa = defensa;
        this.vision = vision;
        this.inventario = new ArrayList<>();
        this.porcentajeSalud = porcentajeSalud;
    }

//METODOS ABSTRACTOS
//METODOS HEREDADOS(CLASE)
//METODOS HEREDADOS(INTERFACE)
//METODOS DE CLASE
//METODOS GENERALES

    @Override
    public String toString() {
        return nombre + " (vida: " + vida + ", fuerza: " + fuerza + "' defensa: " + defensa + ")";
    }

//METODOS DE COMPORTAMIENTO

    /**
     * Indica si el personaje sigue con vida
     * Pre: Ninguna
     * Post: Devuelve true si la vida es mayor a 0, false en caso contrario.
     * @return devuelve si el personaje esta vivo o no
     */
    public boolean estaVivo() {
        return vida > 0;
    }

    /**
     * Aplica daño al personaje, reduciendo su vida.
     * Pre: El parametro danio debe ser mayor o igual que 0.
     * Post: :a vida del personaje se reduce segun el daño final calculado, sin ser menor que 0.
     * @param danio
     */
    public void recibirAtaque(int danio) {
        int danioFinal = danio - (defensa / 2);
        if (danioFinal < 1) {
            danioFinal = 1;
        }

        vida = vida - danioFinal;

        if (vida < 0) {
            vida = 0;
        }
        Teclado.imprimir(nombre + " recibe " + danioFinal + " puntos de daño. Vida actual: " + vida);
    }

    /**
     * Restaura puntos de vida al personaje hasta un maximo de 100.
     * Pre: El parametro puntos debe ser mayor o igual que 0.
     * Post: La vida del personaje aumenta hasta un maximo de 100.
     * @param puntos
     */
    public void recuperarVida(int puntos) {
        vida = vida + puntos;

        if (vida > 100) {
            vida = 100;
        }

        Teclado.imprimir(nombre + " recupera " + puntos + " puntos de vida. Vida actual: " + vida);
    }

    /**
     * Aplica la regeneracion de salud.
     * Post: La vida del personaje aumenta segun su porcentaje de salud.
     */
    public void regenerarSalud() {
        if (!estaVivo() || vida >= this.maxVida) {
            return;
        }
        int montoDecimal = (this.maxVida * (this.porcentajeSalud / 100));
        int montoCura = (int) Math.ceil(montoDecimal);

        if (montoCura == 0 && this.porcentajeSalud > 0) {
            montoCura = 1;
        }
        this.recuperarVida(montoCura);
    }

    /**
     * Agrega una carta de poder al inventario del personaje.
     * Pre: La carta no debe ser nula. El inventario no debe superar 10 cartas.
     * Post: Si hay espacio disponible, la carta se agrega al inventario.
     * @param carta
     */
    public void agregarCarta(CartaPoder carta){
        if (inventario.size() < 10) {
            inventario.add(carta);
            Teclado.imprimir(nombre + " obtiene la carta.");
        } else {
            Teclado.imprimir(nombre + " no puede agregar mas cartas (inventario lleno).");
        }
    }

    /**
     * Usa una carta den inventario sobre otro personaje.
     * Pre: La carta debe estar en el inventario del personaje.
     * Post: Se aplica el efecto de carta y luego se elimina del inventario.
     * @param indice
     * @param objetivo
     */
    public void usarCarta(int indice, Personaje objetivo){
        if (indice < 0 || indice >= inventario.size()) {
            Teclado.imprimir("Indice invalido, no existe carta en esa posicion.");
            return;
        }
        CartaPoder carta = inventario.get(indice);
        carta.aplicar(this, objetivo);
        inventario.remove(indice);
        Teclado.imprimir(nombre + " usa la carta: " + carta.getNombre() + " sobre " + objetivo.getNombre());
    }

    /**
     * Pre:
     * Post: Devuelve true si el personaje esta dentro del rango de vision.
     * @param xObjetivo
     * @param yObjetivo
     * @param zObjetivo
     * @return
     */
    public boolean puedeVer(int xObjetivo, int yObjetivo, int zObjetivo) {

        int dx = Math.abs(this.x - xObjetivo);
        int dy = Math.abs(this.y - yObjetivo);
        int dz = Math.abs(this.z - zObjetivo);

        return dx <= vision && dy <= vision && dz <= vision;
    }

    /**
     * Pre: a no es null.
     *      El personaje no pertenece ya a otra alianza.
     *Post: el personaje pasa a ser miembro de la alianza a.
     *      La alianza registra al personaje en su lista interna.
     * @param a
     */
    public void unirseA(Alianza a) {
        if (a != null && this.alianza == null) {
            this.alianza = a;
            a.agregarMiembro(this);
        }
    }

    /**
     * Pre: el personaje pertenece a una alianza (alianza != null).
     * Post: el personaje deja de pertenecer a la alianza.
     *      El objeto Alianza actual elimina el personaje de su lista de miembros.
     *      El atributo alianza del personaje queda en null.
     */
    public void salirdeAlianza() {
        if (this.alianza != null) {
            this.alianza.removerMiembro(this);
            this.alianza = null;
        }
    }

    /**
     * Pre:
     * Post: devuelve true si el personaje forma parte de alguna alianza.
     * @return
     */
    public boolean tieneAlianza() {
        return this.alianza != null;
    }

    /**
     * Pre: el personaje pertenece a una alianza (alianza != null).
     * Post: se solicita ayuda a todos los miembros de la alianza, excepto el personaje que hace la peticion.
     *      (La logica interna se delega al metodo pedirAyuda() de Alianza).
     */
    public void pedirAyuda() {
        if (this.alianza != null) {
            this.alianza.pedirAyuda(this);
        }
    }

    /**
     * Pre: aliado no es null.
     *      El personaje pertenece a una alianza (alianza != null).
     *      El aliado tambien pertenece a la misma alianza.
     *      El personaje tiene al menos una carta en su inventario.
     * Post: el personaje entrega una carta de su inventario al aliado.
     *      La gestion del intercambio se delega al metodo compartirCartas().
     * @param aliado
     */
    public void compartirCarta(Personaje aliado) {
        if (this.alianza != null && aliado != null) {
            this.alianza.compartirCartas(this, aliado);
        }
    }

    public boolean esAliadoDe(Personaje otro) {
        if (otro == null) return false;
        return this.alianza != null && this.alianza == otro.getAlianza();
    }


    public void activarDobleTurno() {
        this.dobleTurnoActivo = true;
    }


    public void activarReflejoMagnetico() {
        this.reflejoMagneticoActivo = true;
    }

//METODOS DE CONSULTA DE ESTADO
//GETTERS REDEFINIDOS
//GETTERS INICIALIZADOS
//GETTERS COMPLEJOS
//GETTERS SIMPLES

    /**
     * @return Devuelve el nombre del personaje
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @return Devuelve la vida actual del personaje
     */
    public int getVida() {
        return vida;
    }

    /**
     * @return Devuelve la coordenada X personaje
     */
    public int getX() {
        return x;
    }

    /**
     * @return Devuelve la coordenada Y personaje
     */
    public int getY() {
        return y;
    }

    /**
     * @return Devuelve la coordenada Z personaje
     */
    public int getZ() {
        return z;
    }

    /**
     * @return Devuelve la fuerza actual del personaje
     */
    public int getFuerza() {
        return fuerza;
    }

    /**
     * @return Devuelve la defensa actual del personaje
     */
    public int getDefensa() {
        return defensa;
    }

    /**
     * @return Devuelve la vision del personaje
     */
    public int getVision() {
        return vision;
    }

    /**
     * Pre:
     * Post: devuelve la alianza actual del personaje o null si no tiene.
     * @return
     */
    public Alianza getAlianza() {
        return this.alianza;
    }

    /**
     * Pre: el personaje fue correctamente inicializado.
     * Post: se retorna el estado actual(nunca null).
     * @return
     */
    public EstadoEspecial getEstado() {
        return estado;
    }

    /**
     * Pre: Ninguna
     * Post: Devuelve la lista de cartas en el inventario.
     * @return
     */
    public List<CartaPoder> getInventario() {
        return inventario;
    }

//SETTERS COMPLEJOS
//SETTERS SIMPLES

    /**
     * Pre: nuevaVida >= 0
     * Post: La vida se actualiza sin superar 100 ni ser menor que 0.
     * @param nuevaVida
     */
    public void setVida(int nuevaVida) {
        if (nuevaVida < 0) {
            nuevaVida = 0;
        }

        if (nuevaVida > 100) {
            nuevaVida = 100;
        }

        this.vida = nuevaVida;
    }

    /**
     * Pre: nx, ny, nz son valores enteros validos.
     * Post: Se actualiza la posicion del personaje.
     * @param nx
     * @param ny
     * @param nz
     */
    public void setPosicion(int nx, int ny, int nz) {
        this.x = nx;
        this.y = ny;
        this.z = nz;
    }

    /**
     * Pre: nuevaFuerza >= 0
     * Post: La fuerza se actualiza con el valor indicado.
     * @param nuevaFuerza
     */
    public void setFuerza(int nuevaFuerza) {
        if (nuevaFuerza < 0) {
            nuevaFuerza = 0;
        }

        this.fuerza = nuevaFuerza;
    }

    /**
     * Pre: nuevaDefensa >= 0.
     * Post: La defensa se actualiza con el valor indicado.
     */
    public void setDefensa(int nuevaDefensa) {
        if (nuevaDefensa < 0) {
            nuevaDefensa = 0;
        }

        this.defensa = nuevaDefensa;
    }

    /**
     * Pre: nuevaVision >= 0;
     * Post: Se actualiza el valor de vision del personaje.
     * @param nuevaVision
     */
    private void setVision(int nuevaVision) {
        if (nuevaVision < 0) {
            nuevaVision = 0;
        }

        this.vision = nuevaVision;
    }

    /**
     * Pre: nuevoInventario no es nulo.
     * Post: Se reemplaza el inventario actual por el indicado.
     */
    private void setInventario(List<CartaPoder> nuevoInventario) {
        this.inventario = nuevoInventario;
    }

    /**
     * Modifica el estado especial del personaje.
     * Pre: nuevoEstado no es null.
     * Post: el estado del personaje queda actualizado al valor recibido.
     * @param nuevoEstado
     */
    public void setEstado(EstadoEspecial nuevoEstado) {
        this.estado = nuevoEstado;
    }
}
