package logica;

import modelo.CartaPoder;
import modelo.Casillero;
import modelo.Enemigo;
import modelo.Personaje;
import util.Teclado;

public class SistemaColisiones {

    /**
     * Resuelve qué ocurre cuando un personaje entra en un casillero.
     * No mueve al personaje: sólo se ocupa de efectos (combate, recoger carta, etc.)
     */
    public void resolver(Personaje p, Casillero<?> destino) {

        Object contenido = destino.getContenido();

        if (contenido == null) return;

        // ENEMIGO
        if (contenido instanceof Enemigo ene) {
            Teclado.imprimir("¡Aparece un enemigo! Iniciando combate...");
            new Combate(p, ene).pelear();
            return; // si muere, el movimiento lo manejará el sistema de movimiento
        }

        // CARTA
        if (contenido instanceof CartaPoder carta) {
            Teclado.imprimir("Encontraste una carta: " + carta.getNombre());
            p.agregarCarta(carta);
            destino.setContenido(null); // carta recogida
            return;
        }

        // ALIADO (otro personaje)
        if (contenido instanceof Personaje aliado) {
            Teclado.imprimir("Te encontraste con tu aliado " + aliado.getNombre());
            // Aquí podrías agregar interacción futura
        }
    }
}


