package modelo;

public enum EstadoJuego {
    ACTIVO,
    VICTORIA_SOLITARIA,
    VICTORIA_ALIANZA,
    DERROTA
}
