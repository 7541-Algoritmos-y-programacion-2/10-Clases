package util;

public class Validaciones {
    //las validaciones que son comunes en los TDA las hacemos en una clase nueva, asi puedo validar en una sola linea de codigo
    //en el parcial puedo llamarlo correctamente y no escribirlo, ya sabemos que es asi
// INTERFACES
// ENUMERADOS
// CONSTANTES
// ATRIBUTOS DE CLASE
// ATRIBUTOS
// ATRIBUTOS TRANSITORIOS
// CONSTRUCTORES
// METODOS ABSTRACTOS
// METODOS HEREDADOS (CLASE)
// METODOS HEREDADOS (INTERFACE)
// METODOS DE CLASE

    /**
     *Si el valor es menor a 0, lanza una excepcion
     * @param valor dato a validar
     * @param nombre titulo a mostrar en el error
     */
    public static void validarMayorACero(double valor, String nombre) {
        if (valor < 0) {
            throw new RuntimeException("El " + nombre + " debe ser mayor a 0. Se ingreso " + valor);
        }
    } //es estatico porque hay  una sola en toda la clase(validar mayor a cero)
    public static void validarMayorOIgualACero(double valor, String nombre) {
        if (valor <= 0) {
            throw new RuntimeException("El " + nombre + " debe ser mayor a 0. Se ingreso " + valor);
        }
    }

    /**
     * Valida que la longitud del texto este entre desde y hasta(inclusive).
     * @param valor el valor a validar
     * @param desde cantidad minimo de caracteres(inclusive). Puede ser 0 o mayor.
     * @param hasta cantidad maxima de caracteres(inclusive). Puede ser 0 o mayor.
     * @param nombreDelAtributo nombre del atributo a informar
     * @return lanza excepcion si no cumple la validacion.
     */
    public static void validarLongitudDeTexto(String valor, int desde, Integer hasta, String nombreDelAtributo){
        if ((valor == null) ||
            ((desde > 0) && valor.trim().isEmpty()) ||
            (valor.length() < desde) ||
                (hasta != null) && (valor.length() > hasta)) {
             throw new RuntimeException("El " + nombreDelAtributo + " debe estar entre " + desde + " y " + hasta + " caracteres. Se ingreso  " + valor);
        }
    }

    /**
     * valida que el texto(valor) tenga letras o espacios.
     * @param valor una cadena entre a-z y A-Z con espacios.
     * @param nombreDelAtributo nombre del atributo a informar
     */
    public static void validarCaracteresAlfabeticos(String valor, String nombreDelAtributo){
        if (valor.matches("[a-zA-Z ]+")) {
            throw new RuntimeException("El " + nombreDelAtributo + " debe estar tener solo letras y espacios. Se ingreso  " + valor);
        }
    }
    public static void validarFalso(boolean valor, String texto){
        if (valor) {
            throw new RuntimeException(texto);
        }
    }

    public static void validarVerdadero(boolean valor,String texto){
        validarFalso(valor,texto);
    }

    /**
     * valida que el parametro sea disitnto de nulo
     * @param object
     * @param texto
     */
    public static void esDistintoDeNull(Object object, String texto) {
        if (object == null) {
            throw new RuntimeException("El " + texto + " no puede ser nulo");
        }
    }

    /**
     * Valida el rango de enteros, inclusive
     * @param minimo
     * @param maximo
     * @param valor
     */
    public static void validarRangoNumerico(int valor, int minimo, int maximo, String nombre) {
        if (valor < minimo || valor > maximo) {
            throw new RuntimeException(
                    "El valor de " + nombre + " no está en el rango " +
                            minimo + "-" + maximo + " inclusive. Vale: " + valor
            );
        }
    }


// METODOS GENERALES
// METODOS DE COMPORTAMIENTO
// METODOS DE CONSULTA DE ESTADO
// GETTERS REDEFINIDOS
// GETTERS INICIALIZADOS
// GETTERS COMPLEJOS
// GETTERS SIMPLES
// SETTERS COMPLEJOS
// SETTERS SIMPLES
}
