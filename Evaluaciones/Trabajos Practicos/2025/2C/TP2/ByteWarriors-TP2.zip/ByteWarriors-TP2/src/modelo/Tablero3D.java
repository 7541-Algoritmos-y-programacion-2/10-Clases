package modelo;

import java.util.Objects;
import estructuras.ListaSimplementeEnlazada;
import util.Teclado;
import util.Validaciones;


/**
     * Representa un tablero tridimensional de casilleros, implementado
     * con listas simplemente enlazadas anidadas.
     *
     * @param <T> Tipo de dato contenido en cada casillero.
     */
public class Tablero3D<T> {

// ATRIBUTOS
        private ListaSimplementeEnlazada<
                ListaSimplementeEnlazada<
                        ListaSimplementeEnlazada<Casillero<T>>>> tablero;

        private int ancho;
        private int alto;
        private int profundo;


// CONSTRUCTOR
        /**
         * Crea un tablero tridimensional de ancho x alto x profundidad.
         * Cada casillero se inicializa vacío (sin contenido).
         *
         * @param ancho cantidad de columnas (X)
         * @param alto cantidad de filas (Y)
         * @param profundo cantidad de niveles (Z)
         */
        public Tablero3D(int ancho, int alto, int profundo) {

            setAncho(ancho);
            setAlto(alto);
            setProfundo(profundo);
            this.tablero = new ListaSimplementeEnlazada<>();

            // Construcción de las listas anidadas
            for (int z = 1; z <= profundo; z++) {
                ListaSimplementeEnlazada<ListaSimplementeEnlazada<Casillero<T>>> nivel =
                        new ListaSimplementeEnlazada<>();

                for (int y = 1; y <= alto; y++) {
                    ListaSimplementeEnlazada<Casillero<T>> fila =
                            new ListaSimplementeEnlazada<>();

                    for (int x = 1; x <= ancho; x++) {
                        fila.insertarFinal(new Casillero<>(x, y, z, TipoCasillero.VACIO));
                    }
                    nivel.insertarFinal(fila);
                }
                tablero.insertarFinal(nivel);
            }
        }

// MÉTODOS GENERALES

        @Override
        public String toString() {
            return "Tablero3D de tamaño " + ancho + "x" + alto + "x" + profundo;
        }

        @Override
        public int hashCode() {
            return Objects.hash(ancho, alto, profundo);
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof Tablero3D<?> otro)) return false;
            return ancho == otro.ancho && alto == otro.alto && profundo == otro.profundo;
        }

// MÉTODOS DE CONSULTA

        /**
         * Devuelve el casillero en las coordenadas (x, y, z).
         * @param x posición horizontal
         * @param y posición vertical
         * @param z nivel o profundidad
         * @return el Casillero<T>
         */
        public Casillero<T> getCasillero(int x, int y, int z) {
            Validaciones.validarRangoNumerico(x, 1, ancho , "x");
            Validaciones.validarRangoNumerico(y, 1, alto, "y");
            Validaciones.validarRangoNumerico(z, 1, profundo, "z");

            return tablero.obtener(z-1).obtener(y-1).obtener(x-1);
        }

        public boolean existePosicion(int x, int y, int z) {
            return x >= 1 && x <= ancho &&
                    y >= 1 && y <= alto &&
                    z >= 1 && z <= profundo;
        }

        public boolean esVecino3D(int x1, int y1, int z1, int x2, int y2, int z2) {
            return Math.abs(x1 - x2) <= 1 &&
                    Math.abs(y1 - y2) <= 1 &&
                    Math.abs(z1 - z2) <= 1 &&
                    !(x1 == x2 && y1 == y2 && z1 == z2);
        }
//GETTERS SIMPLES

        public int getAncho() {
            return ancho; }
        public int getAlto() {
            return alto; }
        public int getProfundo() {
            return profundo; }

//SETTERS SIMPLES
        public void setAncho(int ancho){
            util.Validaciones.validarMayorACero(ancho, "ancho");
            this.ancho = ancho;

        }
        public void setAlto(int alto){
            util.Validaciones.validarMayorACero(alto, "alto");
            this.alto = alto;
        }
        public void setProfundo(int profundo){
            util.Validaciones.validarMayorACero(profundo, "profundidad");
            this.profundo = profundo;
        }
// MÉTODOS DE COMPORTAMIENTO
        /**
         * Imprime visualmente un nivel completo (plano Z) del tablero.
         */
        public void imprimirNivel(int z) {
            System.out.println("\n=== NIVEL Z = " + z + " ===");

            for (int y = 1; y <= alto; y++) {
                for (int x = 1; x <= ancho; x++) {

                    Casillero<T> c = getCasillero(x, y, z);
                    Object cont = c.getContenido();

                    // No transitables (roca, agua, fuego…)
                    if (!c.esTransitable()) {
                        System.out.print("[R] ");
                        continue;
                    }
                    // Carta en el piso
                    if (c.tieneCarta()) {
                        System.out.print("[C] ");
                        continue;
                    }


                    // Vacío
                    if (cont == null) {
                        System.out.print("[.] ");
                        continue;
                    }

                    // Enemigo
                    if (cont instanceof Enemigo) {
                        System.out.print("[E] ");
                        continue;
                    }

                    // Jugador = inicial del nombre
                    if (cont instanceof Personaje jugador) {
                        char inicial = Character.toUpperCase(jugador.getNombre().charAt(0));
                        System.out.print("[" + inicial + "] ");
                        continue;
                    }

                    // Carta de poder
                    if (cont instanceof CartaPoder) {
                        System.out.print("[C] ");
                        continue;
                    }

                    // Por si aparece algo inesperado
                    System.out.print("[?] ");
                }
                System.out.println();
            }
        }



}