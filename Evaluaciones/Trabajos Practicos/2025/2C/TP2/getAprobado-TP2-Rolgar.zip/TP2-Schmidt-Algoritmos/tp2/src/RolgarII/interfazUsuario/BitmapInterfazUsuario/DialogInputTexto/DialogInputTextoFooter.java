package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class DialogInputTextoFooter extends JPanel {

    public DialogInputTextoFooter(JButton btnAceptar){
        super();
        setLayout(new FlowLayout(FlowLayout.CENTER));
        setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());
        setBorder(new EmptyBorder(0, 0, 20, 0));

        add(btnAceptar);
    }

}
