package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.PanelBoxContraints;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.clases.SpriteId;

import javax.swing.*;
import java.awt.*;

public class CardTurnoActual extends PanelBoxContraints {

    CardTurnoActualNombreJugadorContainer cardTurnoActualNombreJugadorContainer;
    JLabel labelMovimientosRestantes;

    public CardTurnoActual(double porcentajeY){
        super(0,0,1,porcentajeY);
        this.setBackground(BitmapJuegoColors.HIGH_LIGHT_BG.getColor());
        this.setOpaque(true);
        this.setLayout(new BoxLayout(this,BoxLayout.PAGE_AXIS));
        this.setBorder(BitmapInterfazJuegoHelper.paddingBorder(15,20));

        var labelTitulo = new JLabelTitulo("Turno Actual",30);
        labelTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        labelMovimientosRestantes = new JLabelTitulo("Turno #1",18, BitmapJuegoColors.TEXT_MUTED.getColor());
        labelMovimientosRestantes.setAlignmentX(Component.LEFT_ALIGNMENT);

        cardTurnoActualNombreJugadorContainer = new CardTurnoActualNombreJugadorContainer();
        cardTurnoActualNombreJugadorContainer.setAlignmentX(Component.LEFT_ALIGNMENT);

        add(labelTitulo);
        add(Box.createVerticalStrut(15));
        add(labelMovimientosRestantes);
        add(Box.createVerticalStrut(15));
        add(cardTurnoActualNombreJugadorContainer);
    }

    public void render(JugadorDeRolgar jugadorActual, int movimientosRestantes){
        cardTurnoActualNombreJugadorContainer.render(jugadorActual.getNombre());
        labelMovimientosRestantes.setText(
                "Mov. restantes : " + movimientosRestantes
        );
    }

    static class CardTurnoActualNombreJugadorContainer extends JPanel{
        JLabel labelNombreJugador;
        public CardTurnoActualNombreJugadorContainer(){
            setBackground(BitmapJuegoColors.CARD_BG.getColor());
            setBorder(
                    BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),2,true),
                            BitmapInterfazJuegoHelper.paddingBorder(2,2)
                    )
            );
            setLayout(new BorderLayout());
            setMaximumSize(new Dimension(getMaximumSize().width,150));

            labelNombreJugador = new JLabelTitulo("-",20);
            var labelIconoJugador = new JLabel();
            labelIconoJugador.setIcon(
                    BitmapInterfazJuegoHelper.getImageIconFromSpriteId(SpriteId.JUGADOR)
            );

            add(labelIconoJugador,BorderLayout.WEST);
            add(labelNombreJugador,BorderLayout.CENTER);
        }

        public void render(String nombreJugador){
            this.labelNombreJugador.setText(nombreJugador);
        }
    }
}