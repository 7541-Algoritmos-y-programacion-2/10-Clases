package RolgarII.enemigo;

import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import java.util.List;
import java.util.Random; // <-- Necesitas importar java.util.Random

public class EnemigoFactory {
    private static final String[] nombresPosibles = {"Diablo","Inferno","Creeper", "Esqueleto", "Zombie", "Golem"};

    public static List<Enemigo> generarAleatorios(int cantidadDeEnemigos){
        List<Enemigo> enemigos = new ListaSimplementeEnlazada<>();
        Random random = new Random();

        int tiposDeEnemigo = 3;

        for(int i = 0; i < cantidadDeEnemigos; i++){
            int indiceNombre = random.nextInt(nombresPosibles.length);
            String nombreElegido = nombresPosibles[indiceNombre];

            int tipoAleatorio = random.nextInt(tiposDeEnemigo) + 1;

            int vida;
            int fuerza;

            switch (tipoAleatorio) {
                case 1:
                    vida = 5;
                    fuerza = 10;
                    break;
                case 2:
                    vida = 10;
                    fuerza = 5;
                    break;
                case 3:
                    vida = 4;
                    fuerza = 15;
                    break;
                default:
                    vida = 5;
                    fuerza = 10;
                    break;
            }

            var enemigoGenerado = new Enemigo(
                    nombreElegido,
                    vida,
                    fuerza,
                    1,1,1
            );
            enemigos.add(enemigoGenerado);
        }

        return enemigos;
    }
}