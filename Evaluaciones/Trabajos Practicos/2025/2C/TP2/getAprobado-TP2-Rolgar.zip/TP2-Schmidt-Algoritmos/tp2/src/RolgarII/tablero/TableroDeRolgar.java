package RolgarII.tablero;

import RolgarII.casillero.Casillero3D;
import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.shared.clases.Aleatorio;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

import java.util.List;

public class TableroDeRolgar {

    private final int ancho;
    private final int alto;
    private final int profundo;

    private int tableroId;



    private ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    >
            > grilla;

    /**
     * pre: Las dimensiones (ancho, alto, profundo) deben ser mayores a cero.
     * post: Crea un tablero tridimensional con las dimensiones dadas, rellenado con casilleros vacíos.
     * @param ancho Dimensión X del tablero.
     * @param alto Dimensión Y del tablero.
     * @param profundo Dimensión Z del tablero.
     * @throws RuntimeException si alguna dimensión es cero o negativa.
     */
    public TableroDeRolgar(int ancho, int alto, int profundo,int tableroId) {
        ValidacionesUtiles.validarMayorACero(ancho, "ancho");
        ValidacionesUtiles.validarMayorACero(alto, "alto");
        ValidacionesUtiles.validarMayorACero(profundo, "profundo");
        ValidacionesUtiles.validarMayorACero(tableroId, "tableroId");

        this.ancho = ancho;
        this.alto = alto;
        this.profundo = profundo;
        this.tableroId = tableroId;

        grilla = new ListaSimplementeEnlazada<>();

        for (int x = 1; x <= ancho; x++) {
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    > columna = new ListaSimplementeEnlazada<>();

            for (int y = 1; y <= alto; y++) {
                ListaSimplementeEnlazada<CasilleroDeRolgar> fila = new ListaSimplementeEnlazada<>();

                for (int z = 1; z <= profundo; z++) {
                    fila.add(new CasilleroDeRolgar(TipoDeTerreno.VACIO, x, y, z));
                }
                columna.add(fila);
            }
            grilla.add(columna);
        }
    }

    /**
     * pre: Coordenadas (x, y, z) a verificar.
     * post: Devuelve verdadero si la coordenada está dentro de los límites (1-based) del tablero.
     */
    public boolean existe(int x, int y, int z) {
        return x >= 1 && x <= ancho &&
                y >= 1 && y <= alto &&
                z >= 1 && z <= profundo;
    }

    /**
     * pre: Las coordenadas (x, y, z) deben ser válidas y existir en el tablero (1-based).
     * post: Devuelve el casillero ubicado en la posición (x, y, z).
     * @throws RuntimeException si las coordenadas están fuera de los límites.
     */
    public CasilleroDeRolgar getCasillero(int x, int y, int z) {
        return grilla.get(x-1).get(y-1).get(z-1);
    }

    public ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    >
            > getGrilla() {
        return grilla;
    }

    public void setGrilla(ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    >
            > grilla) {
        this.grilla = grilla;
    }

    /**
     * post: Devuelve el ancho (dimensión X) del tablero.
     */
    public int getAncho() { return ancho; }

    /**
     * post: Devuelve el alto (dimensión Y) del tablero.
     */
    public int getAlto() { return alto; }

    /**
     * post: Devuelve la profundidad (dimensión Z) del tablero.
     */
    public int getProfundo() { return profundo; }

    public CasilleroDeRolgar getCasilleroAleatorio(){
        var xAleatorio = Aleatorio.numeroAleatorio(1, ancho);
        var yAleatorio = Aleatorio.numeroAleatorio(1, alto);
        var zAleatorio = Aleatorio.numeroAleatorio(1, profundo);
        return getCasillero(xAleatorio,yAleatorio,zAleatorio);
    }

    public int getTableroId() {
        return tableroId;
    }

    public void setTableroId(int tableroId) {
        this.tableroId = tableroId;
    }

    public List<List<CasilleroDeRolgar>> getCasillerosPorProfunidad(int profundidad) {
        ValidacionesUtiles.validarRangoNumerico( profundidad,1, this.getProfundo(), "profundidad");
        //todos done z valga la profundidad
        List<List<CasilleroDeRolgar>> resultado = new ListaSimplementeEnlazada<List<CasilleroDeRolgar>>();
        for(int i = 0; i < getAncho(); i++){
            var fila = new ListaSimplementeEnlazada<CasilleroDeRolgar>();

            for(int j = 0; j < getAlto(); j++){
                var casilleroIterado = this.grilla.get(i).get(j).get(profundidad-1);
                fila.add(casilleroIterado);
            }
            resultado.add(fila);
        }
        return resultado;
    }

    /** Retorna el listado de casilleros que se encuentran en ese plano Z
     * donde la distancia al x,z sea menor a la distancia indicada */
    public List<List<CasilleroDeRolgar>> getCasillerosEnElPlanoPorProfundidad(int x,int y,int planoZ, int distanciaLimite){
        List<List<CasilleroDeRolgar>> resultado = new ListaSimplementeEnlazada<>();
        for(int i = 0; i < getAncho(); i++){
            var fila = new ListaSimplementeEnlazada<CasilleroDeRolgar>();
            for(int j = 0; j < getAlto(); j++){
                var casilleroIterado = this.grilla.get(i).get(j).get(planoZ-1);
                var distanciaX = Math.abs(casilleroIterado.getX() - x);
                var distanciaY = Math.abs(casilleroIterado.getY() - y);
                if(distanciaX <= distanciaLimite && distanciaY <= distanciaLimite){
                    fila.add(casilleroIterado);
                }
            }
            resultado.add(fila);
        }
        return resultado;
    }

}