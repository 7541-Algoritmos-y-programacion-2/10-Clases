package RolgarII.interfazUsuario.BitmapInterfazUsuario.ModalMostrarMensaje;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class
ModalMostrarMensaje extends JDialog {
    int tiempoMostrado;
    JTextArea labelMensaje;

    public ModalMostrarMensaje(JFrame frame){
        this(frame,2500);
    }
    public ModalMostrarMensaje(JFrame frame,int tiempoMostrado){
        super(frame,"Mensaje informativo",false);
        setSize(500,300);
        setLocationRelativeTo(null);

        this.tiempoMostrado = tiempoMostrado;
        JPanel panelPrincipal = new JPanel(new BorderLayout());

        panelPrincipal.setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        panelPrincipal.setBorder(BitmapInterfazJuegoHelper.paddingBorder(25));

        labelMensaje = new JTextArea();
        labelMensaje.setOpaque(false);
        labelMensaje.setEditable(false);
        labelMensaje.setLineWrap(true);
        labelMensaje.setForeground(BitmapJuegoColors.TEXT_FOREGROUND.getColor());
        labelMensaje.setFont(new Font("Arial",Font.PLAIN,30));

        panelPrincipal.add(labelMensaje);
        add(panelPrincipal);
    }
    public void mostrarMensaje(String mensaje, Runnable onClose){
        labelMensaje.setText(mensaje);
        setVisible(true);
        var timerCerrarModal = new Timer(this.tiempoMostrado, e -> {
            setVisible(false);
            onClose.run();
            System.out.println("Modal ocultado MSG:"+mensaje);
        });
        timerCerrarModal.setRepeats(false);
        timerCerrarModal.start();
    }


}
