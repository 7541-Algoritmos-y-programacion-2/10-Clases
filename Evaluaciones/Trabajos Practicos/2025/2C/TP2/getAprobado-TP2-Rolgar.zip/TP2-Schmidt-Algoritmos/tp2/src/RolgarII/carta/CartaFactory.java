package RolgarII.carta;

import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

public class CartaFactory {

    private static final Random random = new Random();

    private static final List<Supplier<Carta>> CARTAS_REGISTRADAS = List.of(
            CartaCuracion::new,
            CartaCuracionAliado::new,
            CartaDobleMovimiento::new,
            CartaEscudo::new,
            CartaInvisibilidad::new,
            CartaJocker::new,
            CartaPotenciadorDeDanio::new,
            CartaRobo::new,
            CartaTeletransportacion::new,
            CartaVisibilidad::new
    );

    public static Carta aleatoria() {
        int opcion = random.nextInt(CARTAS_REGISTRADAS.size());
        return CARTAS_REGISTRADAS.get(opcion).get();
    }

    public static List<Carta> aleatorias(int cantidad){
        List<Carta> cartas = new ListaSimplementeEnlazada<>();
        for (int i = 0; i < cantidad; i++) {
            cartas.add(aleatoria());
        }
        return cartas;
    }

    /**
     * Crea una carta específica a partir de un tipo de texto que viene del JSON.
     * Los nombres tienen que coincidir con los que pongas en el JSON.
     *
     * Ejemplos de tipos:
     *  "CURACION"
     *  "CURACION_ALIADO"
     *  "DOBLE_MOVIMIENTO"
     *  "ESCUDO"
     *  "INVISIBILIDAD"
     *  "JOCKER"
     *  "POTENCIADOR_DANIO"
     *  "ROBO"
     *  "TELETRANSPORTACION"
     *  "VISIBILIDAD"
     */
    public static Carta desdeTipo(String tipo) {
        if (tipo == null) {
            throw new IllegalArgumentException("El tipo de carta no puede ser null");
        }
        return switch (tipo.toUpperCase()) {
            case "CURACION" -> new CartaCuracion();
            case "CURACION_ALIADO" -> new CartaCuracionAliado();
            case "DOBLE_MOVIMIENTO" -> new CartaDobleMovimiento();
            case "ESCUDO" -> new CartaEscudo();
            case "INVISIBILIDAD" -> new CartaInvisibilidad();
            case "JOCKER" -> new CartaJocker();
            case "POTENCIADOR_DANIO" -> new CartaPotenciadorDeDanio();
            case "ROBO" -> new CartaRobo();
            case "TELETRANSPORTACION" -> new CartaTeletransportacion();
            case "VISIBILIDAD" -> new CartaVisibilidad();
            default -> throw new IllegalArgumentException("Tipo de carta desconocido: " + tipo);
        };
    }
    /**
     * Alias para compatibilidad con código que llama a crearCartaPorTipo.
     */
    public static Carta crearCartaPorTipo(String tipo) {
        return desdeTipo(tipo);
    }
}
