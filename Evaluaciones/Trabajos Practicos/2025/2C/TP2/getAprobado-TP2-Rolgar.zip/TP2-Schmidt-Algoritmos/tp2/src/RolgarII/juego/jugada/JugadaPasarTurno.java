package RolgarII.juego.jugada;

import RolgarII.juego.turno.Turno;

public class JugadaPasarTurno implements Jugada{

    @Override
    public void ejecutar(Turno turno) {
        turno.consumirTodosLosMovimientos();
    }
}
