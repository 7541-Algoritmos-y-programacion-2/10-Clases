package RolgarII.jugador;

import RolgarII.carta.Carta;
import RolgarII.carta.CartaFactory;
import RolgarII.shared.clases.Aleatorio;

import java.util.List;

public class JugadorFactory {

    private static final int VIDA_MAXIMA_DEFAULT = 100;
    private static final int CANTIDAD_MAXIMA_CARTAS_DEFAULT = 10;
    private static final int CANTIDAD_CARTA_DEFAULT = 5;

    public static JugadorDeRolgar conDatosAleatorios(String nombre,int visionEnJugadores){

        List<Carta> cartasAleatorias = CartaFactory.aleatorias(CANTIDAD_CARTA_DEFAULT);
        var vidaInicial = Aleatorio.numeroAleatorio(10, VIDA_MAXIMA_DEFAULT);
        return new JugadorDeRolgar(
                nombre,
                vidaInicial,
                cartasAleatorias,
                visionEnJugadores,
                15,
                15,
                1, 1, 1,
                VIDA_MAXIMA_DEFAULT,
                CANTIDAD_MAXIMA_CARTAS_DEFAULT
        );
    }

}
