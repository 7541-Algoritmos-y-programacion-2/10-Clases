package RolgarII.juego.jugada;

public enum TipoDeJugada {
    MOVIMIENTO,
    USAR_CARTA,
    PROPONER_ALIANZA,
    PASAR_TURNO,
}
