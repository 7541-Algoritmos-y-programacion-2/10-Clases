package RolgarII.dificultadJuego.JSONDificultadJuegoRepository;

import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.dificultadJuego.DificultadJuegoRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public class JSONDificultadJuegoRepository implements DificultadJuegoRepository {

    private final String baseUrl = "/RolgarII/dificultadJuego/JSONDificultadJuegoRepository/base.json";
    ObjectMapper mapper;

    public JSONDificultadJuegoRepository(){
        mapper = new ObjectMapper();
    }

    @Override
    public DificultadJuego[] getAll() {
        try{

            var baseResource = getClass().getResource(baseUrl);
            var dificultadesDisponibles = mapper.readValue(baseResource,DificultadJuego[].class);
            if(dificultadesDisponibles.length == 0){
                return null;
            }

            return dificultadesDisponibles;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }

    }
}
