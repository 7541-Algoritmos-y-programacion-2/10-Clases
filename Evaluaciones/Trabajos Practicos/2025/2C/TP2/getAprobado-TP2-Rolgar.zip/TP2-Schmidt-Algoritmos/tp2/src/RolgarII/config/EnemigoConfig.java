package RolgarII.config;

public class EnemigoConfig {

    private String nombre;
    private int energia;
    private int ataque;
    private PosicionConfig posicion;

    /**
     * post: Crea una instancia vacía de la configuración de enemigo.
     */
    public EnemigoConfig() {
    }

    /**
     * post: Devuelve el nombre configurado.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * post: Establece el nombre en la configuración.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * post: Devuelve la energía configurada.
     */
    public int getEnergia() {
        return energia;
    }

    /**
     * post: Establece la energía en la configuración.
     */
    public void setEnergia(int energia) {
        this.energia = energia;
    }

    /**
     * post: Devuelve el ataque configurado.
     */
    public int getAtaque() {
        return ataque;
    }

    /**
     * post: Establece el ataque en la configuración.
     */
    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    /**
     * post: Devuelve la posición configurada.
     */
    public PosicionConfig getPosicion() {
        return posicion;
    }

    /**
     * post: Establece la posición en la configuración.
     */
    public void setPosicion(PosicionConfig posicion) {
        this.posicion = posicion;
    }
}