package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarCarta;

import RolgarII.carta.Carta;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import javax.swing.*;
import java.util.List;

public class DialogSeleccionarCarta extends DialogOpciones<Carta> {
    private List<Carta> cartas;
    public DialogSeleccionarCarta(JFrame owner){

        super(owner,"Selector de cartas","Cartas disponibles","seleccione una carta:");
    }
    public void setCartas(List<Carta> cartas){
        this.cartas = cartas;
        var dialogOpciones = new ListaSimplementeEnlazada<DialogOpcionesOpcion>();

        for(int i = 0; i < cartas.size(); i++){
            Carta cartaIterada = cartas.get(i);
            String caracter = Integer.toString(i+1);
            dialogOpciones.add(new DialogOpcionCarta(cartaIterada,caracter));
        }

        setOpciones(dialogOpciones.toArray(new DialogOpcionesOpcion[0]));

    }


}
