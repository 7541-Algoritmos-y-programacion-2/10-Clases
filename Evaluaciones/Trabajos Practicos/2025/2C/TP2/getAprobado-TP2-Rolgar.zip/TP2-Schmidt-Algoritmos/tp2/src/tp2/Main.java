//package tp2;
//
//import RolgarII.carta.Carta;
//import RolgarII.carta.CartaCuracion;
//import RolgarII.carta.CartaEscudo;
//import RolgarII.carta.CartaFactory;
//import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitMapInterfazJuego;
//import RolgarII.interfazUsuario.InterfazJuego;
//import RolgarII.juego.ElementoDeRolgar;
//import RolgarII.juego.Juego;
//import RolgarII.juego.TipoDeTerreno;
//import RolgarII.jugador.JugadorDeRolgar;
//import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
//import RolgarII.shared.teclado.Teclado;
//import RolgarII.tablero.Tablero3D;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class Main {
//
//    public static void main(String[] args) {
//
//
//    }
//}