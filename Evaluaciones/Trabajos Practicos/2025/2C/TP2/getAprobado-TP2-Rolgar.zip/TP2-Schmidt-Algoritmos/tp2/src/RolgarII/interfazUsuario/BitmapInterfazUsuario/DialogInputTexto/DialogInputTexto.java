package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.concurrent.CompletableFuture;

public class DialogInputTexto extends JDialog {

    private JTextField textField;
    private String textoIngresado = null;
    private CompletableFuture<String> resultado;
    private DialogInputTextoHeader header;

    public DialogInputTexto() {
        super((Frame)null, "", true);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setUndecorated(true);

        initUI();
    }

    private void initUI() {
        var mainPanel = new DialogInputTextoMainPanel();
        header = new DialogInputTextoHeader();

        textField = new DialogInputTextoTextField();
        var body = new DialogInputTextoBody(textField);

        var btnAceptar = new DialogInputTextoBtn(this::confirmar);
        var footer = new DialogInputTextoFooter(btnAceptar);


        this.getRootPane().setDefaultButton(btnAceptar);

        mainPanel.add(header, BorderLayout.NORTH);
        mainPanel.add(body, BorderLayout.CENTER);
        mainPanel.add(footer, BorderLayout.SOUTH);
        add(mainPanel);
    }

    private void confirmar() {
        textoIngresado = textField.getText().trim();
        if (textoIngresado.isEmpty()) {
            return;
        }
        setVisible(false);
        resultado.complete(textoIngresado);
    }

    public String getTexto() {
        return textoIngresado;
    }

    public void render(String titulo, CompletableFuture<String> resultado){
        this.resultado = resultado;
        header.render(titulo);
        setVisible(true);
    }
}