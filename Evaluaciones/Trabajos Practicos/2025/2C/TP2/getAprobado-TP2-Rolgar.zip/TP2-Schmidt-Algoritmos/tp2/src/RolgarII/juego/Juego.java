package RolgarII.juego;

import RolgarII.carta.Carta;
import RolgarII.carta.CartaFactory;
import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.dificultadJuego.DificultadJuegoRepository;
import RolgarII.enemigo.Enemigo;
import RolgarII.enemigo.EnemigoFactory;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.juego.dado.Dado;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.jugador.JugadorFactory;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.tablero.TableroRepository;
import RolgarII.validacionesUtiles.ValidacionesUtiles;
import RolgarII.config.ParametrosJuegoConfig;
import RolgarII.tablero.TableroDeRolgar;

import java.util.*;

public class Juego {

    private TableroDeRolgar tablero;
    private final List<JugadorDeRolgar> jugadores;
    private InterfazJuego interfazUsuario;

    private final ListaSimplementeEnlazada<EfectoTemporal> efectosTemporales = new ListaSimplementeEnlazada<>();
    private final ListaSimplementeEnlazada<Alianza> alianzas = new ListaSimplementeEnlazada<>();

    private int indiceTurnoActual = 0;
    private boolean juegoEnCurso = false;

    private final int jugadoresIniciales;

    private double curacionPorMovimiento = 1.0;
    private int minDado = 1;
    private int maxDado = 6;
    private int totalEnemigosVivos = 0;
    private Dado dado;
    private DificultadJuegoRepository dificultadJuegoRepository;
    private TableroRepository tableroRepository;

    /**
     * pre: 'jugadores', 'tablero' e 'interfaz' no deben ser nulos.
     * La lista de jugadores no debe estar vacía.
     * post: Crea una instancia del juego inicializando jugadores,
     * tablero, interfaz y valores por defecto.
     */
    public Juego(List<JugadorDeRolgar> jugadores,
                 TableroDeRolgar tablero,
                 InterfazJuego interfaz,
                 DificultadJuegoRepository dificultadJuegoRepository,
                 TableroRepository tableroRepository
                 ) {

        ValidacionesUtiles.esDistintoDeNull(jugadores, "jugadores");
        ValidacionesUtiles.esDistintoDeNull(tablero, "tablero");
        ValidacionesUtiles.esDistintoDeNull(interfaz, "interfazUsuario");
        ValidacionesUtiles.esDistintoDeNull(dificultadJuegoRepository, "dificultadJuegoRepository");
        ValidacionesUtiles.esDistintoDeNull(tableroRepository, "tableroRepository");

        if (jugadores.isEmpty())
            throw new RuntimeException("Debe haber al menos un jugador.");

        this.jugadores = new ListaSimplementeEnlazada<>();
        this.jugadores.addAll(jugadores);
        this.jugadoresIniciales = this.jugadores.size();

        this.tablero = tablero;
        this.interfazUsuario = interfaz;

        this.dado = new Dado(4);
        this.dificultadJuegoRepository = dificultadJuegoRepository;
        this.tableroRepository = tableroRepository;
    }




    /**
     * pre: ---
     * post: Ejecuta el bucle principal del juego, hasta que quede un ganador.
     */
    public void iniciarJuego() {

        juegoEnCurso = true;

        interfazUsuario.mostrarMensaje("¡Bienvenido a Rolgar II!\nEl juego ha comenzado");

        var dificultadesDisponibles = dificultadJuegoRepository.getAll();

        var dificultadSeleccionada = interfazUsuario.seleccionarDificultad(dificultadesDisponibles);

        var tablero = tableroRepository.obtenerTableroPorId(dificultadSeleccionada.getTableroId());

        this.tablero = tablero;

        var cantidadDeJugadores = interfazUsuario.obtenerOpcionNumerica("Ingrese la cantidad de jugadores: ");

        jugadores.clear();
        for(int i = 0; i < cantidadDeJugadores; i++){
            var nombre = interfazUsuario.obtenerTexto("Ingrese nombre para el jugado "+ (i + 1) +":");
            var jugador = JugadorFactory.conDatosAleatorios(nombre,dificultadSeleccionada.getVisionEnJugadores());
            jugadores.add(jugador);
        }

        var cartasAleatorias = CartaFactory.aleatorias(dificultadSeleccionada.getCantidadDeCartasEnMapa());
        ubicarEnTableroEnPosicionesDisponibles(cartasAleatorias);

        ubicarEnTableroEnPosicionesDisponibles(jugadores);


        var enemigos = EnemigoFactory.generarAleatorios(dificultadSeleccionada.getCantidadDeEnemigos());

        this.totalEnemigosVivos = dificultadSeleccionada.getCantidadDeEnemigos();

        ubicarEnTableroEnPosicionesDisponibles(enemigos);

        while (juegoEnCurso) {

            JugadorDeRolgar actual = null;
            int intentos = 0;

            do {
                pasarTurno();
                actual = jugadores.get(indiceTurnoActual);
                intentos++;

            } while (!actual.estaVivo() && intentos < jugadores.size());

            if (!actual.estaVivo()) {
                interfazUsuario.mostrarMensaje("No quedan jugadores vivos para continuar. Fin del juego.");
                juegoEnCurso = false;
                break;
            }

            int movimientos = solicitarTiroDado(actual);
            ejecutarTurno(actual, movimientos);

        }

        interfazUsuario.mostrarMensaje("El juego ha terminado.");
    }

    public void mostrarMensaje(String m) {
        interfazUsuario.mostrarMensaje(m);
    }

    public JugadorDeRolgar seleccionarJugador() {
        return interfazUsuario.seleccionarJugador(jugadores.toArray(new JugadorDeRolgar[0]));
    }

    public Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador) {
        return interfazUsuario.seleccionarCartaDeJugador(jugador);
    }

    public CasilleroDeRolgar seleccionarCeldaLibre(int ejeZ) {
        return interfazUsuario.seleccionarCeldaLibre(tablero,ejeZ);
    }

    public void renderizarTablero(JugadorDeRolgar jugadorActual,Turno turno) {
        if (!jugadorActual.estaVivo()) {
            return;
        }

        interfazUsuario.renderizarTablero(tablero, jugadorActual,turno);
    }

    public void ejecutarEfectosFinDeTurno(){
        procesarEfectosTemporales();
        procesarAlianzas();
        verificarFinDeJuego();
    }

    public void ubicarEnTableroEnPosicionesDisponibles(List<? extends ElementoDeRolgar> elementos){
        var ubicados = 0;
        while(ubicados < elementos.size()){
            var casilleroAleatorio = tablero.getCasilleroAleatorio();
            if(casilleroAleatorio.esTransitable() && casilleroAleatorio.estaLibreDeEntidad()){
                casilleroAleatorio.ocuparConEntidad(elementos.get(ubicados));
                if(elementos.get(ubicados) instanceof JugadorDeRolgar jugador){
                    jugador.setPosicion(casilleroAleatorio.getX(), casilleroAleatorio.getY(), casilleroAleatorio.getZ());
                }
                ubicados++;
            }
        }
    }

    /**
     * pre: jugador y destino no deben ser nulos.
     * post: Intenta mover al jugador, resolviendo combate y efectos según corresponda.
     */
    public boolean moverJugadorConDestino(JugadorDeRolgar jugador, CasilleroDeRolgar destino) {

        if (!destino.terrenoEsTransitable()) {
            interfazUsuario.mostrarMensaje("No se puede transitar este terreno.");
            return false;
        }

        ElementoDeRolgar contenido = destino.getEntidad();

        if (contenido instanceof Enemigo enemigo) {

            resolverCombateJugadorVsEnemigo(jugador, enemigo);

            if (!jugador.estaVivo()) return true;

            if (!enemigo.estaVivo()) {
                interfazUsuario.mostrarMensaje(enemigo.getNombre() + " ha muerto.");

                destino.vaciarEntidad();

                CasilleroDeRolgar origen = tablero.getCasillero(
                        jugador.getPosX(), jugador.getPosY(), jugador.getPosZ()
                );
                origen.vaciarEntidad();
                destino.ocuparConEntidad(jugador);
                jugador.setPosicion(destino.getX(), destino.getY(), destino.getZ());

                return true;
            }
            return false;
        }

        // --- JUGADOR EN DESTINO ---
        if (contenido instanceof JugadorDeRolgar otro) {

            if (sonAliados(jugador, otro)) {
                interfazUsuario.mostrarMensaje("Casillero ocupado por aliado.");
                return false;
            }

            interfazUsuario.mostrarMensaje("Destino ocupado por " + otro.getNombre());
            interfazUsuario.mostrarMensaje("1- Pelear | 2- Proponer alianza");

            int opcion = interfazUsuario.obtenerOpcionNumerica("Opción: ");

            if (opcion == 2) {
                int turnos = interfazUsuario.obtenerOpcionNumerica("Turnos de alianza: ");
                if (turnos > 0) proponerAlianza(jugador, otro, turnos);
                return false;
            }

            resolverCombateEntreJugadores(jugador, otro);
            return true;
        }

        // --- CARTA EN DESTINO ---
        if (contenido instanceof Carta carta) {
            jugador.agregarCartaAlInventario(carta);
            destino.vaciarEntidad();
            interfazUsuario.mostrarMensaje(jugador.getNombre() + " recogio carta " + carta.getNombre());
        }

        CasilleroDeRolgar origen = tablero.getCasillero(
                jugador.getPosX(), jugador.getPosY(), jugador.getPosZ()
        );

        origen.vaciarEntidad();
        destino.ocuparConEntidad(jugador);
        jugador.setPosicion(destino.getX(), destino.getY(), destino.getZ());


        destino.getTerreno().onEnter(jugador,this);

        return true;
    }

    public boolean moverJugadorConDestino(JugadorDeRolgar jugador,int x,int y,int z) {
        if(!tablero.existe(x,y,z)) return false;
        CasilleroDeRolgar destino = tablero.getCasillero(x,y,z);
        return moverJugadorConDestino(jugador,destino);
    }



    public boolean intentarFormarAlianza(JugadorDeRolgar solicitante, JugadorDeRolgar objetivo) {
        ValidacionesUtiles.esDistintoDeNull(solicitante, "solicitante");
        ValidacionesUtiles.esDistintoDeNull(objetivo, "objetivo");

        if (solicitante.equals(objetivo)) {
            mostrarMensaje("No podés formar una alianza con vos mismo.");
            return false;
        }

        if (!sonAdyacentes(solicitante, objetivo)) {
            mostrarMensaje("Estás demasiado lejos de " + objetivo.getNombre() + " para proponer una alianza.");
            return false;
        }

        if (sonAliados(solicitante, objetivo)) {
            mostrarMensaje("Ya tenés una alianza activa con " + objetivo.getNombre());
            proponerIntercambioDeCartas(solicitante, objetivo);
            return true;
        }

        boolean aceptada = proponerAlianzaInteractiva(solicitante, objetivo);
        if (aceptada) {
            proponerIntercambioDeCartas(solicitante, objetivo);
        }

        return true;
    }

    private boolean proponerAlianzaInteractiva(JugadorDeRolgar solicitante, JugadorDeRolgar objetivo) {
        boolean acepta = interfazUsuario.obtenerConfirmacion(
                objetivo.getNombre() + ", ¿aceptás la alianza propuesta por " + solicitante.getNombre() + "?");

        if (acepta) {
            int duracion = 3;
            alianzas.add(new Alianza(solicitante, objetivo, duracion));
            mostrarMensaje("¡Alianza formada por " + duracion + " turnos!");
            return true;
        } else {
            mostrarMensaje(objetivo.getNombre() + " rechazó la propuesta.");
            return false;
        }
    }

    private void proponerIntercambioDeCartas(JugadorDeRolgar solicitante, JugadorDeRolgar objetivo) {
        boolean quierenIntercambiar = interfazUsuario.obtenerConfirmacion("¿Desean intercambiar cartas?");

        if (quierenIntercambiar) {
            realizarIntercambioDirigido(solicitante, objetivo);
        }
    }

    private void realizarIntercambioDirigido(JugadorDeRolgar j1, JugadorDeRolgar j2) {
        Carta c1 = interfazUsuario.seleccionarCartaDeJugador(j1);
        if (c1 == null) return;
        if(!j2.tieneEspacioEnInventario()){
            mostrarMensaje(j2.getNombre() + " no tiene espacio.");
            return;
        }

        Carta c2 = interfazUsuario.seleccionarCartaDeJugador(j2);
        if (c2 == null) return;

        j1.removerCarta(c1);
        j2.removerCarta(c2);

        j1.agregarCartaAlInventario(c2);
        j2.agregarCartaAlInventario(c1);

        mostrarMensaje("Intercambio exitoso: " + c1.getNombre() + " <-> " + c2.getNombre());
    }

    public void proponerAlianza(JugadorDeRolgar a, JugadorDeRolgar b, int turnos) {
        if (sonAliados(a, b)) {
            mostrarMensaje("Ya son aliados.");
            return;
        }
        boolean acepto = interfazUsuario.obtenerConfirmacion(
                b.getNombre() + ", ¿aceptás la alianza con " + a.getNombre() + "?");
        if (acepto) {
            alianzas.add(new Alianza(a, b, turnos));
            mostrarMensaje("Alianza formada por " + turnos + " turnos.");
        } else {
            mostrarMensaje("Propuesta rechazada.");
        }
    }

    /**
     * pre: jugadores a y b no deben ser nulos.
     * post: Devuelve true si existe una alianza activa entre ambos.
     */
    public boolean sonAliados(JugadorDeRolgar a, JugadorDeRolgar b) {
        for (Alianza al : alianzas)
            if (al.sonAliados(a, b)) return true;
        return false;
    }

    /**
     * pre: params no debe ser nulo.
     * post: Actualiza curación por movimiento y rango del dado según config.
     */
    public void aplicarParametrosDeJuego(ParametrosJuegoConfig params) {

        ValidacionesUtiles.esDistintoDeNull(params, "params");

        if (params.getCuracionPorMovimiento() >= 0)
            this.curacionPorMovimiento = params.getCuracionPorMovimiento();

        if (params.getMinDado() > 0)
            this.minDado = params.getMinDado();

        if (params.getMaxDado() >= minDado)
            this.maxDado = params.getMaxDado();
    }

    /**
     * pre: excluido no debe ser nulo.
     * post: Devuelve un jugador con cartas (distinto del excluido) seleccionado por interfaz.
     */
    public JugadorDeRolgar seleccionarJugadorConCartas(JugadorDeRolgar excluido) {
        List<JugadorDeRolgar> candidatos = new ArrayList<>();
        for (JugadorDeRolgar j : jugadores)
            if (!j.equals(excluido) && j.tieneCartas() && j.estaVivo())
                candidatos.add(j);

        if (candidatos.isEmpty()) {
            interfazUsuario.mostrarMensaje("No hay jugadores con cartas disponibles.");
            return null;
        }
        interfazUsuario.mostrarMensaje("Seleccionar jugador al que robar carta:");
        return interfazUsuario.seleccionarJugador(candidatos.toArray(new JugadorDeRolgar[0]));
    }

    /**
     * pre: turnos > 0, alExpirar != null.
     * post: Registra un nuevo efecto temporal.
     */
    public void registrarEfectoTemporal(int turnos, Runnable alExpirar) {
        ValidacionesUtiles.validarMayorACero(turnos, "turnos");
        ValidacionesUtiles.esDistintoDeNull(alExpirar, "onExpirar");

        efectosTemporales.add(new EfectoTemporal(turnos, alExpirar));
    }

    /**
     * pre: atacante, objetivo y casilleroDestino no deben ser nulos.
     * post: El atacante realiza un ataque contra el objetivo.
     * Si el objetivo muere, se vacía el casillero.
     */
    private void realizarCombateAlMover(JugadorDeRolgar atacante, JugadorDeRolgar objetivo, CasilleroDeRolgar casilleroDestino) {

        if (!atacante.puedeVerA(objetivo)) {
            mostrarMensaje("Objetivo fuera de visión.");
            return;
        }

        atacante.atacar(objetivo);

        mostrarMensaje(atacante.getNombre() + " atacó a " + objetivo.getNombre()
                + " (vida restante: " + objetivo.getVida() + ")");

        if (!objetivo.estaVivo()) {
            mostrarMensaje(objetivo.getNombre() + " ha muerto.");
            casilleroDestino.vaciarEntidad();
        }
    }

    /**
     * pre: jugador no debe ser nulo.
     * post: Devuelve un valor válido de dado; si no es válido, genera uno aleatorio.
     */
    private int solicitarTiroDado(JugadorDeRolgar jugador) {
        int resultado = dado.lanzarDado();
        interfazUsuario.mostrarMensaje("Se lanzo el dado, con resultado : " + resultado + "\nPara el jugador "+ jugador.getNombre());

        return resultado;
    }

    /**
     * pre: jugador no debe ser nulo. movimientos > 0.
     * post: Ejecuta el turno completo: movimientos, uso de cartas y fin de turno.
     */
    private void ejecutarTurno(JugadorDeRolgar jugador, int movimientos) {

        Turno turno = new Turno(this,jugador,movimientos);
        turno.iniciarTurno();
        while (!turno.estaTerminado() && jugador.estaVivo()) {

            renderizarTablero(jugador, turno);
            Jugada jugada = interfazUsuario.seleccionarJugada(jugador);
            jugada.ejecutar(turno);

        }
        turno.finalizar();

    }

    /**
     * pre: atacante no debe ser nulo.
     * post: Ataca a un jugador elegido, verificando alianzas y visión.
     */
    private void atacar(JugadorDeRolgar atacante) {

        JugadorDeRolgar objetivo =
                interfazUsuario.seleccionarJugador(jugadores.toArray(new JugadorDeRolgar[0]));

        if (objetivo == null || objetivo == atacante) {
            mostrarMensaje("Ataque cancelado.");
            return;
        }

        if (sonAliados(atacante, objetivo)) {
            mostrarMensaje("No podés atacar a un aliado.");
            return;
        }

        if (!atacante.puedeVerA(objetivo)) {
            mostrarMensaje("Objetivo fuera de visión.");
            return;
        }

        atacante.atacar(objetivo);

        mostrarMensaje(atacante.getNombre() + " atacó a " + objetivo.getNombre()
                + " (vida restante: " + objetivo.getVida() + ")");

        if (!objetivo.estaVivo()) {
            mostrarMensaje(objetivo.getNombre() + " murió.");
            tablero.getCasillero(objetivo.getPosX(), objetivo.getPosY(), objetivo.getPosZ())
                    .vaciarEntidad();
        }
    }

    /**
     * pre: jugador no debe ser nulo.
     * post: Permite seleccionar aliado y carta, y realizar intercambio.
     */
    private boolean intercambioEntreAliadosViaInterfaz(JugadorDeRolgar jugador) {
        List<JugadorDeRolgar> aliados = new ArrayList<>();

        for (JugadorDeRolgar j : jugadores)
            if (j != jugador && sonAliados(jugador, j) && j.estaVivo())
                aliados.add(j);

        if (aliados.isEmpty()) {
            mostrarMensaje("No hay aliados.");
            return false;
        }

        JugadorDeRolgar destino =
                interfazUsuario.seleccionarJugador(aliados.toArray(new JugadorDeRolgar[0]));

        if (destino == null) return false;

        Carta carta = interfazUsuario.seleccionarCartaDeJugador(jugador);
        if (carta == null) return false;

        return intercambiarCartaEntreAliados(jugador, destino, carta);
    }

    /**
     * pre: origen, destino y carta no deben ser nulos.
     * Deben ser aliados y haber espacio en destino.
     * post: Transfiere la carta de origen a destino.
     */
    private boolean intercambiarCartaEntreAliados(JugadorDeRolgar origen,
                                                  JugadorDeRolgar destino,
                                                  Carta carta) {

        if (!sonAliados(origen, destino)) {
            mostrarMensaje("No son aliados.");
            return false;
        }
        if (!origen.existeLaCarta(carta)) {
            mostrarMensaje("El jugador origen no tiene esa carta.");
            return false;
        }
        if (!destino.tieneEspacioEnInventario()) {
            mostrarMensaje("Inventario destino lleno.");
            return false;
        }

        origen.removerCarta(carta);
        destino.agregarCartaAlInventario(carta);

        mostrarMensaje("Intercambio realizado.");
        return true;
    }

    /**
     * pre: ---
     * post: Finaliza el juego si queda uno o cero jugadores vivos, Y todos los enemigos han sido derrotados.
     */
    private void verificarFinDeJuego() {

        int vivos = 0;
        JugadorDeRolgar ultimo = null;

        for (JugadorDeRolgar j : jugadores) {
            if (j.estaVivo()) {
                vivos++;
                ultimo = j;
            }
        }

        boolean quedaUnGanador = (vivos == 1);
        boolean noQuedanEnemigos = (this.totalEnemigosVivos <= 0);

        if (jugadoresIniciales > 1 && (vivos <= 1) && noQuedanEnemigos) {
            juegoEnCurso = false;

            if (ultimo != null && quedaUnGanador) {
                mostrarMensaje("¡Ganador: " + ultimo.getNombre() + "! Has sobrevivido y liberado el mundo de sus amenazas.");
            } else {
                mostrarMensaje("Todos han muerto, pero los enemigos han sido eliminados. Empate.");
            }
        }
    }

    private void verificarCombateProximidad(JugadorDeRolgar jugador, CasilleroDeRolgar destino) {
        boolean huboCombate = false;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {

                    if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) != 1) continue;

                    int nx = destino.getX() + dx;
                    int ny = destino.getY() + dy;
                    int nz = destino.getZ() + dz;

                    if (!tablero.existe(nx, ny, nz)) continue;
                    CasilleroDeRolgar cas = tablero.getCasillero(nx, ny, nz);
                    if (cas == null) continue;

                    if (cas.getEntidad() instanceof Enemigo enemigo) {
                        interfazUsuario.mostrarMensaje("¡" + enemigo.getNombre() + " te detecta y ataca!");

                        enemigo.atacar(jugador);
                        huboCombate = true;

                        if (!jugador.estaVivo()) {
                            interfazUsuario.mostrarMensaje(jugador.getNombre() + " murió por proximidad.");
                            return;
                        }

                        jugador.atacar(enemigo);

                        if (!enemigo.estaVivo()) {
                            interfazUsuario.mostrarMensaje("¡" + enemigo.getNombre() + " murió!");
                            cas.vaciarEntidad();
                        }
                    }
                }
            }
        }
    }

    private void verificarCombateJugadorVsJugador(JugadorDeRolgar jugador) {
        int x = jugador.getPosX();
        int y = jugador.getPosY();
        int z = jugador.getPosZ();

        for (JugadorDeRolgar otro : jugadores) {
            if (otro == jugador) continue;
            if (!otro.estaVivo()) continue;

            int dx = Math.abs(x - otro.getPosX());
            int dy = Math.abs(y - otro.getPosY());
            int dz = Math.abs(z - otro.getPosZ());

            if (dx + dy + dz == 1) {
                if (sonAliados(jugador, otro)) {
                    interfazUsuario.mostrarMensaje(jugador.getNombre() + " está cerca de su aliado " + otro.getNombre());
                    return;
                }
                interfazUsuario.mostrarMensaje("Encuentro con " + otro.getNombre());
                interfazUsuario.mostrarMensaje("1- Pelear | 2- Proponer alianza");
                int opcion = interfazUsuario.obtenerOpcionNumerica("Opción: ");

                if (opcion == 1) {
                    resolverCombateEntreJugadores(jugador, otro);
                    return;
                }
                if (opcion == 2) {
                    proponerAlianza(jugador, otro, 3);
                    return;
                }
            }
        }
    }

    private void resolverCombateEntreJugadores(JugadorDeRolgar a, JugadorDeRolgar b) {
        interfazUsuario.mostrarMensaje("⚔ ¡Escaramuza: " + a.getNombre() + " vs " + b.getNombre() + "! ⚔");
        int rondasMaximas = 3;
        int rondaActual = 1;

        while (a.estaVivo() && b.estaVivo() && rondaActual <= rondasMaximas) {
            interfazUsuario.mostrarMensaje("--- RONDA " + rondaActual + " ---");
            int tiroA = dado.lanzarDado();
            int tiroB = dado.lanzarDado();

            if (tiroA > tiroB) {
                ejecutarGolpe(a, b, true);
                if (b.estaVivo()) ejecutarGolpe(b, a, false);
            } else if (tiroB > tiroA) {
                ejecutarGolpe(b, a, true);
                if (a.estaVivo()) ejecutarGolpe(a, b, false);
            } else {
                interfazUsuario.mostrarMensaje("¡Choque! Ambos reciben daño leve.");
                a.recibirDanio(2);
                b.recibirDanio(2);
            }
            rondaActual++;
        }

        if (a.estaVivo() && b.estaVivo()) {
            interfazUsuario.mostrarMensaje("Combate terminado. Se separan.");
        } else {
            procesarMuerte(a);
            procesarMuerte(b);
        }
    }

    private void ejecutarGolpe(JugadorDeRolgar atacante, JugadorDeRolgar defensor, boolean esAtaquePrincipal) {
        double danio = esAtaquePrincipal ? atacante.getFuerzaPotenciada() : atacante.getFuerzaPotenciada() * 0.5;
        defensor.recibirDanio(danio);
        String tipo = esAtaquePrincipal ? "ataca" : "contraataca";
        interfazUsuario.mostrarMensaje(atacante.getNombre() + " " + tipo + " a " + defensor.getNombre() + " (Vida: " + defensor.getVida() + ")");
    }

    private void procesarMuerte(JugadorDeRolgar j) {
        if (!j.estaVivo()) {
            interfazUsuario.mostrarMensaje("💀 " + j.getNombre() + " ha caído.");
            tablero.getCasillero(j.getPosX(), j.getPosY(), j.getPosZ()).vaciarEntidad();
            j.marcarMuertoFueraDelTablero();
        }
    }

    private void resolverCombateJugadorVsEnemigo(JugadorDeRolgar jugador, Enemigo enemigo) {
        interfazUsuario.mostrarMensaje("⚔ ¡Combate: " + jugador.getNombre() + " vs " + enemigo.getNombre() + "! ⚔");
        int rondas = 0;

        while (jugador.estaVivo() && enemigo.estaVivo() && rondas < 3) {

            // Turno Jugador
            double danioJugador = jugador.getFuerzaPotenciada();
            enemigo.recibirDanio((int)danioJugador);
            interfazUsuario.mostrarMensaje(jugador.getNombre() + " golpea: " + danioJugador + " daño.");

            if (!enemigo.estaVivo()) {
                interfazUsuario.mostrarMensaje("¡" + enemigo.getNombre() + " ha sido derrotado!");

                this.totalEnemigosVivos--;

                break;
            }

            // Turno Enemigo
            double danioEnemigo = enemigo.getAtaque();
            jugador.recibirDanio(danioEnemigo);
            interfazUsuario.mostrarMensaje(enemigo.getNombre() + " devuelve: " + danioEnemigo + " daño.");

            if (!jugador.estaVivo()) {
                procesarMuerte(jugador);
                break;
            }
            rondas++;
        }

        if (enemigo.estaVivo() && jugador.estaVivo()) {
            interfazUsuario.mostrarMensaje("Combate estancado. Retrocedes.");
        }
    }


    /** PRE : Recibe un jugador inicializado no null, el X destino y el Y destino del
     * mismo plano Z a donde el jugador debera ser movido
     * POS : Mueve el jugador a el casillero que se encuentre en
     * el mismo Z que el jugador y en el xDestino e yDestino enviado por parametro
     * Retorna un booleano indicando si el jugador se pudo mover o no (porque no existe el
     * casillero destino) */
    public boolean moverJugadorEnElPlano(JugadorDeRolgar jugador,int xDestino, int yDestino){
        int zDestino = jugador.getPosZ();
        var existeElDestino = tablero.existe(xDestino, yDestino, zDestino);
        if (!existeElDestino) {
            return false;
        }
        if (!tablero.existe(xDestino, yDestino, zDestino)) {
            mostrarMensaje("¡Cuidado! No puedes moverte fuera del tablero. Pierdes el movimiento.");
            return false;
        }



        var casilleroDestino = tablero.getCasillero(xDestino, yDestino, zDestino);
        return this.moverJugadorConDestino(jugador, casilleroDestino);



    }

    private void procesarEfectosTemporales() {
        var iterator = efectosTemporales.listIterator();
        while(iterator.hasNext()){
            EfectoTemporal e = iterator.next();
            e.avanzarTurno();
            if(e.estaExpirado()) iterator.remove();
        }
    }

    private void procesarAlianzas() {
        int i = 0;
        while (i < alianzas.size()) {
            Alianza a = alianzas.get(i);
            a.avanzarTurno();
            if (a.estaExpirada()) alianzas.remove(i);
            else i++;
        }
    }

    private void pasarTurno() {
        indiceTurnoActual = (indiceTurnoActual + 1) % jugadores.size();
    }

    public JugadorDeRolgar seleccionarCandidatoParaAlianza(JugadorDeRolgar solicitante) {
        List<JugadorDeRolgar> candidatos = new ArrayList<>();
        for (JugadorDeRolgar otro : jugadores) {
            if (!otro.equals(solicitante) && otro.estaVivo() && !sonAliados(solicitante, otro) && sonAdyacentes(solicitante, otro)) {
                candidatos.add(otro);
            }
        }
        if (candidatos.isEmpty()) {
            mostrarMensaje("No hay jugadores cercanos para alianza.");
            return null;
        }
        return interfazUsuario.seleccionarJugador(candidatos.toArray(new JugadorDeRolgar[0]));
    }

    private boolean sonAdyacentes(JugadorDeRolgar j1, JugadorDeRolgar j2) {
        int dx = Math.abs(j1.getPosX() - j2.getPosX());
        int dy = Math.abs(j1.getPosY() - j2.getPosY());
        int dz = Math.abs(j1.getPosZ() - j2.getPosZ());
        return (dx + dy + dz) == 1;
    }

    public boolean moverJugadorVertical(JugadorDeRolgar jugador, int zDestino) {

        int x = jugador.getPosX();
        int y = jugador.getPosY();

        if (!tablero.existe(x, y, zDestino)) {
            mostrarMensaje("No hay plano disponible en Z = " + zDestino);
            return false;
        }

        CasilleroDeRolgar destino = tablero.getCasillero(x, y, zDestino);

        ElementoDeRolgar contenidoDestino = destino.getEntidad();

        if (contenidoDestino != null && !contenidoDestino.equals(jugador)) {
            mostrarMensaje("El destino en Z = " + zDestino + " está ocupado por otra entidad.");
            return false;
        }

        CasilleroDeRolgar origen = tablero.getCasillero(x, y, jugador.getPosZ());
        origen.vaciarEntidad();

        destino.ocuparConEntidad(jugador);
        jugador.setPosicion(x, y, zDestino);

        return true;
    }

}