package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugador;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;
import RolgarII.jugador.JugadorDeRolgar;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class DialogOpcionJugador extends DialogOpcionesOpcion<JugadorDeRolgar> {


    public DialogOpcionJugador(String caracter, JugadorDeRolgar jugador) {
        super(jugador.getNombre(), caracter, jugador);
    }




}
