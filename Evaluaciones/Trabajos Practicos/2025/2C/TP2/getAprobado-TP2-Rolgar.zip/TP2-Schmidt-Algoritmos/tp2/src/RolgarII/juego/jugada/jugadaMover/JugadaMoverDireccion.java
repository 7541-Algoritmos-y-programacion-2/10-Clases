package RolgarII.juego.jugada.jugadaMover;

public enum JugadaMoverDireccion {
    ARRIBA(-1,0,0),
    DERECHA(0,1,0),
    ABAJO(1,0,0),
    IZQUIERDA(0,-1,0);

    private int dx,dy,dz;
    private JugadaMoverDireccion(int dx,int dy,int dz){
        this.dx = dx;
        this.dy = dy;
        this.dz = dz;
    }

    public int getDx() {
        return dx;
    }

    public int getDy() {
        return dy;
    }

    public int getDz() {
        return dz;
    }
}
