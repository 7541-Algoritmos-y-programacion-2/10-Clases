//package tp2.interfazUsuario;
//
//import tp2.carta.Carta;
//import tp2.casillero.Casillero3D;
//import tp2.juego.ElementoDeRolgar;
//import RolgarII.juego.jugada.Jugada;
//import tp2.jugador.JugadorDeRolgar;
//import tp2.tablero.Tablero3D;
//
//public interface InterfazJuego {
//
//    /** Metodos NO legacy: */
//
//    Jugada seleccionarJugada(JugadorDeRolgar jugador);
//
//    /**
//     * post: Muestra un mensaje al usuario.
//     */
//    void mostrarMensaje(String mensaje);
//
//    /**
//     * post: Dibuja el estado actual del tablero para el jugador actual (visión aplicada).
//     * @param tablero: tablero
//     * @param jugadorActual: jugador desde cuya perspectiva se renderiza (puede ser null -> render completo)
//     */
//    void renderizarTablero(Tablero3D<ElementoDeRolgar> tablero, JugadorDeRolgar jugadorActual);
//
//    /**
//     * post: Muestra una lista de jugadores y permite al usuario seleccionar uno.
//     * @param jugadores: El arreglo de jugadores candidatos.
//     * @return El JugadorDeRolgar seleccionado.
//     */
//    JugadorDeRolgar seleccionarJugador(JugadorDeRolgar[] jugadores);
//
//    /**
//     * post: Muestra las cartas de un jugador y permite seleccionar una.
//     * @param jugador: El jugador del cual mostrar las cartas.
//     * @return La Carta seleccionada, o null si se cancela.
//     */
//    Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador);
//
//    /**
//     * post: Permite al usuario seleccionar una celda específica del tablero (por coordenadas).
//     * @param tablero: El tablero del juego.
//     * @return El Casillero3D seleccionado, o null si se cancela o es inválido.
//     */
//    Casillero3D<ElementoDeRolgar> seleccionarCeldaLibre(Tablero3D<ElementoDeRolgar> tablero);
//
//    /**
//     * post: Muestra un menú de acciones de turno y devuelve la opción elegida.
//     * @param jugador El jugador actual.
//     * @param movimientosRestantes: Los movimientos que le quedan.
//     * @return un número entero representando la acción.
//     */
//    int obtenerAccionDeTurno(JugadorDeRolgar jugador, int movimientosRestantes);
//
//    /**
//     * post: Solicita al usuario que ingrese un número (para turnos, etc.)
//     * @param mensaje El mensaje a mostrar.
//     * @return el número ingresado.
//     */
//    int obtenerOpcionNumerica(String mensaje);
//
//    /**
//     * Solicita una confirmación (Sí/No).
//     * @param mensaje El mensaje de pregunta (ej: "Aceptás la alianza?")
//     * @return verdadero si es 'si', falso si es 'no'.
//     */
//    boolean obtenerConfirmacion(String mensaje);
//
//    /**
//     * post: Lanza el dado. La interfaz es quien muestra el resultado y lo devuelve.
//     *
//     * @param jugador jugador que lanza el dado.
//     * @param min valor mínimo (inclusivo)
//     * @param max valor máximo (inclusivo)
//     * @return valor aleatorio entre min y max
//     */
//    int lanzarDado(JugadorDeRolgar jugador, int min, int max);
//
//    /**
//     * post: Permite al usuario moverse usando controles de teclado (WASD) y cambiar niveles
//     * @param jugador El jugador que se está moviendo
//     * @param tablero El tablero del juego
//     * @return Un array con las nuevas coordenadas [x, y, z], o null si se cancela el movimiento
//     */
//    int[] obtenerMovimientoPorTeclado(JugadorDeRolgar jugador, Tablero3D<ElementoDeRolgar> tablero);
//
//    /**
//     * post: Muestra las opciones de movimiento disponibles basado en la posición actual
//     */
//    void mostrarOpcionesMovimiento(JugadorDeRolgar jugador, Tablero3D<ElementoDeRolgar> tablero);
//}