package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogConflicto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.CompletableFuture;

public class DialogConflicto extends JDialog {

    private CompletableFuture<Integer> futuroResultado;

    public DialogConflicto(JFrame frame) {
        super(frame, "Encuentro", true);
        this.setSize(450, 300);
        this.setLocationRelativeTo(frame);
        this.setUndecorated(true);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 2));
        mainPanel.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JPanel header = new JPanel();
        header.setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        header.add(new JLabelTitulo("¡Encuentro!", 20));
        mainPanel.add(header, BorderLayout.NORTH);

        JLabel lblMensaje = new JLabel("<html><center>¿Qué deseas hacer?</center></html>");
        lblMensaje.setForeground(Color.WHITE);
        lblMensaje.setHorizontalAlignment(SwingConstants.CENTER);
        lblMensaje.setFont(new Font("Arial", Font.PLAIN, 16));
        mainPanel.add(lblMensaje, BorderLayout.CENTER);

        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 10, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        panelBotones.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JButton btnPelear = crearBotonAccion("PELEAR (1)", new Color(200, 50, 50)); // Rojo oscuro
        JButton btnAlianza = crearBotonAccion("PROPONER ALIANZA (2)", new Color(50, 100, 200)); // Azul

        btnPelear.addActionListener(e -> resolver(1));
        btnAlianza.addActionListener(e -> resolver(2));

        panelBotones.add(btnPelear);
        panelBotones.add(btnAlianza);

        mainPanel.add(panelBotones, BorderLayout.SOUTH);
        this.add(mainPanel);
    }

    private JButton crearBotonAccion(String texto, Color bg) {
        JButton btn = new JButton(texto);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Arial", Font.BOLD, 14));
        return btn;
    }

    private void resolver(int opcion) {
        this.setVisible(false);
        if (futuroResultado != null) {
            futuroResultado.complete(opcion);
        }
    }

    public void mostrar(String mensaje, CompletableFuture<Integer> futuro) {
        this.futuroResultado = futuro;
        this.setVisible(true);
    }
}