package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared;

import javax.swing.*;
import java.awt.*;

public class JLabelTitulo extends JLabel {

    public JLabelTitulo(String titulo,int size,Color color){
        super(titulo);
        this.setFont(new Font("Arial",Font.BOLD,size));
        this.setForeground(color);
    }

    public JLabelTitulo(String titulo,int size) {
        this(titulo,size,BitmapJuegoColors.TEXT_FOREGROUND.getColor());

    }

}
