/**
 * 
 */
/**
 * 
 */
open module tp2 {
    requires java.desktop;
    requires transitive com.fasterxml.jackson.databind;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;
    exports ejemplos.leer_archivo;
    exports ejemplos.leer_archivo_array;
    exports RolgarII.dificultadJuego;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;
//    requires tp2;

}