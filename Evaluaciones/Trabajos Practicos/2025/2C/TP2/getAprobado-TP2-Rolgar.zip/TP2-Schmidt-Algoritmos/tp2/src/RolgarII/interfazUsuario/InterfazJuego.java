package RolgarII.interfazUsuario;

import RolgarII.carta.Carta;
import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.preguntas.Pregunta;
import RolgarII.tablero.TableroDeRolgar;

public interface InterfazJuego {
    /** Metodos NO legacy: */

    Jugada seleccionarJugada(JugadorDeRolgar jugador);

    String hacerPregunta(Pregunta pregunta);

    DificultadJuego seleccionarDificultad(DificultadJuego[] dificultades);
    /**
     * pre: mensaje no es null.
     * post: Muestra el mensaje al usuario.
     */
    void mostrarMensaje(String mensaje);

    /**
     * pre: tablero y jugadorActual no son null.
     * post: Renderiza el tablero según la visión del jugador actual.
     */
    void renderizarTablero(TableroDeRolgar tablero, JugadorDeRolgar jugadorActual, Turno turno);

    /**
     * pre: jugador y tablero no son null.
     * post: Devuelve un comando de movimiento ingresado por el usuario.
     */
    String leerComandoMovimiento();

    /**
     * pre: jugador y tablero no son null.
     * post: Muestra las opciones de movimiento disponibles.
     */
    void mostrarOpcionesMovimiento(JugadorDeRolgar jugador, TableroDeRolgar tablero);

    /**
     * pre: jugador no es null.
     * post: Devuelve la acción elegida por el usuario para el turno.
     */
    int obtenerAccionDeTurno(JugadorDeRolgar jugador, int movimientosRestantes);

    /**
     * pre: jugadores no es null.
     * post: Devuelve el jugador seleccionado o null si se cancela.
     */
    JugadorDeRolgar seleccionarJugador(JugadorDeRolgar[] jugadores);

    /**
     * pre: jugador no es null.
     * post: Devuelve la carta seleccionada por el usuario o null.
     */
    Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador);

    /**
     * pre: tablero no es null.
     * post: Devuelve un casillero seleccionado o null si el usuario cancela.
     */
    CasilleroDeRolgar seleccionarCeldaLibre(TableroDeRolgar tablero,int ejeZ);

    /**
     * pre: prompt no es null.
     * post: Devuelve un número ingresado por el usuario.
     */
    int obtenerOpcionNumerica(String prompt);

    String obtenerTexto(String prompt);

    /**
     * pre: mensaje no es null.
     * post: Devuelve true si el usuario confirma.
     */
    boolean obtenerConfirmacion(String mensaje);

}

