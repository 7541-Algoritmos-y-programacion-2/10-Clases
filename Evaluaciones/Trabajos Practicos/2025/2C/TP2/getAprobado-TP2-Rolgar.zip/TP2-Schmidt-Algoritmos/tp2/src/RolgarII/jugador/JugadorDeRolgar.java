package RolgarII.jugador;

import RolgarII.carta.Carta;
import RolgarII.enemigo.Enemigo;
import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.Juego;
import RolgarII.shared.clases.SpriteId;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.shared.interfaces.Renderizable;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

import java.util.List;
import java.util.StringJoiner;

public class JugadorDeRolgar extends Jugador implements ElementoDeRolgar, Renderizable {

    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
    //ATRIBUTOS -----------------------------------------------------------------------------------------------
    private double vidaActual;
    private double regeneracionPorTurno;
    private int fuerza;
    private int vision;
    private double vidaMaxima;
    private int maxCartas;
    private int movimientosDisponibles = 0;
    private EstadoJugador estado;
    private List<Carta> poderes = new ListaSimplementeEnlazada<>();

    private EstadoDeEscudo estadoDeEscudo = EstadoDeEscudo.DESACTIVADO;
    private EstadoDeVisibilidad estadoVisibilidad = EstadoDeVisibilidad.SIN_EFECTO;

    private boolean dobleMovimientoActivo = false;
    private boolean invisibilidad = false;
    private double potenciadorDeFuerza = 1.0;
    private int posX;
    private int posY;
    private int posZ;

    //CONSTRUCTORES -------------------------------------------------------------------------------------------
    /**
     * pre: nombre no debe ser nulo; vida >= 0; cartas no nulo; visión > 0; fuerza > 0;
     * regeneración >= 0; vidaMaxima > 0; maxCartas > 0.
     * post: Inicializa un jugador de Rolgar con estadísticas, inventario y posición inicial.
     */
    public JugadorDeRolgar(String nombre,
                           double vida,
                           List<Carta> cartas,
                           int vision,
                           int fuerza,
                           double regeneracionPorTurno,
                           int x, int y, int z,
                           double vidaMaxima,
                           int maxCartas) {

        super(nombre);
        ValidacionesUtiles.validarMayorOIgualACero(vida, "vida");
        ValidacionesUtiles.esDistintoDeNull(cartas, "poderesIniciales");
        ValidacionesUtiles.validarMayorACero(vision, "vision");
        ValidacionesUtiles.validarMayorACero(fuerza, "fuerza");
        ValidacionesUtiles.validarMayorOIgualACero(regeneracionPorTurno, "regeneracionPorTurno");
        ValidacionesUtiles.validarMayorACero(vidaMaxima, "vidaMaxima");
        ValidacionesUtiles.validarMayorACero(maxCartas, "maxCartas");

        this.vidaMaxima = vidaMaxima;
        this.maxCartas = maxCartas;

        setPosicion(x, y, z);
        this.vidaActual = Math.min(this.vidaMaxima, vida);
        this.poderes.addAll(cartas);
        this.vision = vision;
        setFuerza(fuerza);
        this.regeneracionPorTurno = regeneracionPorTurno;
        this.estado = EstadoJugador.VIVO;
    }

    //METODOS -------------------------------------------------------------------------------------------------

    /**
     * pre: enemigo no debe ser nulo.
     * post: Aplica daño al enemigo según la fuerza del jugador.
     */
    public void atacar(Enemigo enemigo) {
        ValidacionesUtiles.esDistintoDeNull(enemigo, "enemigo");
        double danio = fuerza * potenciadorDeFuerza;
        enemigo.recibirDanio((int) danio);
    }

    /**
     * post: Devuelve true si el jugador tiene al menos una carta.
     */
    public boolean tieneCartas() {
        return !this.poderes.isEmpty();
    }

    /**
     * pre: objetivo no debe ser nulo.
     * post: Aplica daño a otro jugador según la fuerza del atacante.
     */
    public void atacar(JugadorDeRolgar objetivo) {
        double danio = fuerza * potenciadorDeFuerza;
        objetivo.recibirDanio(danio);
    }

    /**
     * pre: carta no debe ser nula.
     * post: Agrega la carta si hay espacio disponible.
     */
    public void agregarCarta(Carta carta) {
        ValidacionesUtiles.esDistintoDeNull(carta, "carta");
        if (this.tieneEspacioEnInventario()) {
            this.poderes.add(carta);
        }
    }

    /**
     * pre: objetivo no nulo; daño > 0.
     * post: Aplica daño directo a jugador (sin usar su fuerza).
     */
    public void atacarConDanioJugador(JugadorDeRolgar objetivo, double danio) {
        ValidacionesUtiles.validarMayorACero(danio, "daño");
        objetivo.recibirDanio(danio);
    }

    /**
     * pre: objetivo no nulo; daño > 0.
     * post: Aplica daño directo a enemigo.
     */
    public void atacarConDanioEnemigo(Enemigo objetivo, double danio) {
        ValidacionesUtiles.validarMayorACero(danio, "daño");
        objetivo.recibirDanio((int) danio);
    }

    /**
     * post: Marca al jugador como muerto, dejándolo sin posición válida.
     */
    public void marcarMuertoFueraDelTablero() {
        this.posX = -1;
        this.posY = -1;
        this.posZ = -1;

        this.estado = EstadoJugador.MUERTO;
    }

    /**
     * pre: carta no debe ser nula.
     * post: Devuelve true si la carta está en el inventario.
     */
    public boolean existeLaCarta(Carta carta) {
        ValidacionesUtiles.esDistintoDeNull(carta, "carta");
        return this.poderes.contains(carta);
    }

    /**
     * pre: carta no debe ser nula y debe existir en el inventario.
     * post: Remueve la carta del inventario.
     */
    public void removerCarta(Carta carta) {
        ValidacionesUtiles.esDistintoDeNull(carta, "carta");
        if (!this.existeLaCarta(carta)) {
            throw new RuntimeException("Carta no encontrada");
        }
        this.poderes.remove(carta);
    }

    /**
     * pre: carta no debe ser nula; debe existir en el inventario.
     * post: Usa la carta y la remueve del inventario.
     */
    public void usarCarta(Carta carta, Juego juego) {
        ValidacionesUtiles.esDistintoDeNull(carta, "carta");
        if (!this.existeLaCarta(carta)) {
            throw new RuntimeException("Carta no encontrada");
        }
        carta.usar(this, juego);
        this.poderes.remove(carta);
    }

    /**
     * pre: restarVida > 0; el jugador debe estar vivo.
     * post: Reduce la vida actual sin permitir que sea negativa.
     */
    public void quitarVida(int restarVida) {
        ValidacionesUtiles.validarMayorACero(restarVida, "restar vida");
        if (!estaVivo()) throw new RuntimeException("El jugador no está vivo");
        setVida(getVida() - restarVida);
        comprobarMuerte();
    }

    /**
     * post: Retorna true solo si el estado es VIVO.
     */
    public boolean estaVivo() {
        return this.estado == EstadoJugador.VIVO;
    }

    /**
     * post: Devuelve true si el número de cartas es menor al máximo permitido.
     */
    public boolean tieneEspacioEnInventario() {
        return this.poderes.size() < maxCartas;
    }

    /**
     * pre: otro no debe ser nulo.
     * post: Devuelve true si está dentro del rango de visión.
     */
    public boolean puedeVerA(JugadorDeRolgar otro) {
        if (otro.estaInvisible()) {
            return false; // No puedes ver lo que es invisible.
        }

        int dx = Math.abs(this.posX - otro.posX);
        int dy = Math.abs(this.posY - otro.posY);
        int dz = Math.abs(this.posZ - otro.posZ);
        return dx <= getVision() && dy <= getVision() && dz <= getVision();
        // NOTA: Usé getVision() en lugar de vision para que respete el efecto de MAXIMA visión.
    }

    /**
     * post: Devuelve true si el escudo está activo.
     */
    public boolean tieneEscudoActivo() {
        return this.estadoDeEscudo == EstadoDeEscudo.ACTIVO;
    }

    /**
     * post: Desactiva el escudo del jugador.
     */
    public void desactivarEscudo() {
        this.estadoDeEscudo = EstadoDeEscudo.DESACTIVADO;
    }

    /**
     * post: Devuelve true si el doble movimiento está activo.
     */
    public boolean tieneDobleMovimiento() {
        return this.dobleMovimientoActivo;
    }

    /**
     * post: Desactiva el doble movimiento del jugador.
     */
    public void desactivarDobleMovimiento() {
        this.dobleMovimientoActivo = false;
    }

    /**
     * post: Devuelve el multiplicador de daño actual.
     */
    public double getPotenciadorDeFuerza() {
        return this.potenciadorDeFuerza;
    }

    /** post: Devuelve una copia inmutable de las cartas. */
    public List<Carta> getVerCartas() { return List.copyOf(poderes); }

    public double getVida() { return this.vidaActual; }

    public double getVidaMaxima(){
        return this.vidaMaxima;
    }

    public List<Carta> getPoderes() { return poderes; }

    public int getCantidadDeCartas() {return poderes.size(); }

    public int getFuerza() { return fuerza; }

    /** post: retorna la fuerza potenciada por el potenciador de fuerza. */
    public double getFuerzaPotenciada(){
        return fuerza * potenciadorDeFuerza;
    }

    public boolean tieneFuerzaPotenciada(){
        return this.potenciadorDeFuerza != 1;
    }

    public int getVision() {
        if(this.estadoVisibilidad == EstadoDeVisibilidad.MAXIMA){
            return Integer.MAX_VALUE;
        }
        return vision;
    }

    public double getRegeneracionPorTurno() { return regeneracionPorTurno; }

    public int getPosX() { return posX; }

    public int getPosY() { return posY; }

    public int getPosZ() { return posZ; }

    /**
     * post: Activa visión máxima temporalmente.
     */
    public void ampliarVisibilidadAMaxima() {
        this.estadoVisibilidad = EstadoDeVisibilidad.MAXIMA;
    }

    /**
     * post: Quita cualquier efecto temporal de visión.
     */
    public void removerEfectosEnVisibilidad() {
        this.estadoVisibilidad = EstadoDeVisibilidad.SIN_EFECTO;
    }

    /**
     * post: Recupera vida según la regeneración por turno sin superar el máximo.
     */
    public void recuperarSaludPorTurno() {
        setVida(this.getVida() + regeneracionPorTurno);
    }

    /**
     * pre: daño > 0.
     * post: Si el escudo está activo lo consume; si no, resta vida.
     */
    public void recibirDanio(double danio) {
        if (this.tieneEscudoActivo()) {
            this.desactivarEscudo();
            return;
        }

        setVida(this.vidaActual - danio);

        comprobarMuerte();
    }

    /**
     * pre: vida puede ser cualquier valor.
     * post: Ajusta vida dentro del rango [0, vidaMaxima].
     */
    public void setVida(double vida) {
        this.vidaActual = Math.min(vidaMaxima, Math.max(0, vida));
    }

    /**
     * pre: curación > 0.
     * post: Aumenta vida sin superar el máximo.
     */
    public void curar(double curacion) {
        ValidacionesUtiles.validarMayorACero(curacion, "curación");
        setVida(this.getVida() + curacion);
    }

    public void setVision(Integer vision) {
        ValidacionesUtiles.esDistintoDeNull(vision, "visión");
        ValidacionesUtiles.validarMayorACero(vision, "visión");
        this.vision = vision;
    }

    /**
     * pre: lista no nula.
     * post: Reemplaza el inventario de cartas.
     */
    public void setPoderes(List<Carta> poderes) {
        ValidacionesUtiles.esDistintoDeNull(poderes, "poderes");
        this.poderes = poderes;
    }

    /**
     * pre: x,y,z > 0.
     * post: Actualiza posición 3D del jugador.
     */
    public void setPosicion(int x, int y, int z) {
        ValidacionesUtiles.validarMayorACero(x, "coordenada X");
        ValidacionesUtiles.validarMayorACero(y, "coordenada Y");
        ValidacionesUtiles.validarMayorACero(z, "coordenada Z");
        this.posX = x;
        this.posY = y;
        this.posZ = z;
    }

    public void setFuerza(int fuerza) {
        ValidacionesUtiles.validarMayorACero(fuerza, "fuerza");
        this.fuerza = fuerza;
    }

    public void setRegeneracionPorTurno(double regeneracionPorTurno) {
        ValidacionesUtiles.validarMayorACero(regeneracionPorTurno, "regeneracionPorTurno");
        this.regeneracionPorTurno = regeneracionPorTurno;
    }

    public void activarEscudo() { this.estadoDeEscudo = EstadoDeEscudo.ACTIVO; }

    public void activarDobleMovimiento() { this.dobleMovimientoActivo = true; }

    public void activarInvisibilidad() { this.invisibilidad = true; }

    public void desactivarInvisibilidad() { this.invisibilidad = false; }

    /**
     * pre: potenciador > 0.
     * post: Cambia el multiplicador de daño.
     */
    public void potenciarDanio(double potenciador) {
        ValidacionesUtiles.validarMayorACero(potenciador, "potenciador");
        this.potenciadorDeFuerza = potenciador;
    }

    /**
     * post: Restaura el multiplicador a su valor base.
     */
    public void quitarPotenciadorDeFuerza() { this.potenciadorDeFuerza = 1; }

    public void removerCartaDelInventario(Carta carta) { this.poderes.remove(carta); }

    public void agregarCartaAlInventario(Carta carta) { this.poderes.add(carta); }

    /**
     * post: Devuelve true si el jugador está invisible.
     */
    public boolean estaInvisible() { return this.invisibilidad; }

    @Override
    public SpriteId getSpriteId() {
        return SpriteId.JUGADOR;
    }

    /**
     * post: Devuelve una cadena de texto con los estados activos del jugador.
     */
    public String getDescripcionEstado() {
        StringJoiner estado = new StringJoiner(", ");

        if (tieneEscudoActivo()) estado.add("Escudo");
        if (tieneDobleMovimiento()) estado.add("Doble Mov.");
        if (estaInvisible()) estado.add("Invisible");
        if (tieneFuerzaPotenciada()) estado.add("Daño x" + potenciadorDeFuerza);
        if (estadoVisibilidad == EstadoDeVisibilidad.MAXIMA) estado.add("Visión Max");

        if (estado.length() == 0) return "Sin efectos activos";
        return estado.toString();
    }


    private void comprobarMuerte() {
        if (this.vidaActual <= 0 && this.estado == EstadoJugador.VIVO) {
            this.estado = EstadoJugador.MUERTO;
        }
    }
}