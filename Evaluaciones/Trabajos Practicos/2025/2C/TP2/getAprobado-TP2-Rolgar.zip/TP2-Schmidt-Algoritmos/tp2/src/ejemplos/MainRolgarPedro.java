package ejemplos;

import RolgarII.carta.*;
import RolgarII.dificultadJuego.JSONDificultadJuegoRepository.JSONDificultadJuegoRepository;
import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitMapInterfazJuego;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto.DialogInputTexto;
import RolgarII.juego.Juego;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.tablero.JSONTableroRepository.JSONTableroRepository;
import RolgarII.tablero.TableroDeRolgar;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class MainRolgarPedro {
    public static void main(String[] args) {

        String nombreJ1 = pedirNombre("Nombre del Jugador 1", "Jugador1");
        if (nombreJ1 == null) System.exit(0);

        String nombreJ2 = pedirNombre("Nombre del Jugador 2", "Jugador2");
        if (nombreJ2 == null) System.exit(0);

        BitMapInterfazJuego interfaz = new BitMapInterfazJuego();

        var cartasJugador1 = new ListaSimplementeEnlazada<Carta>();
        cartasJugador1.add(CartaFactory.aleatoria());
        cartasJugador1.add(new CartaVisibilidad());
        cartasJugador1.add(new CartaRobo());

        var jugador1 = new JugadorDeRolgar(
                nombreJ1, 50, cartasJugador1, 2, 25, 25,
                1, 1, 2,
                100, 5
        );

        var cartasJugador2 = new ListaSimplementeEnlazada<Carta>();
        cartasJugador2.add(new CartaTeletransportacion());
        cartasJugador2.add(new CartaCuracion());
        cartasJugador2.add(new CartaEscudo());

        var jugador2 = new JugadorDeRolgar(
                nombreJ2, 60, cartasJugador2, 2, 20, 25,
                6, 8, 2,
                100, 5
        );

        var tablero = new TableroDeRolgar(6, 8, 6,1);

        for (int y = 2; y <= 7; y++) {
            tablero.getCasillero(3, y, 2).setTerreno(TipoDeTerreno.AGUA);
        }

        tablero.getCasillero(2, 4, 2).setTerreno(TipoDeTerreno.ROCA);
        tablero.getCasillero(2, 5, 2).setTerreno(TipoDeTerreno.ROCA);
        tablero.getCasillero(5, 3, 2).setTerreno(TipoDeTerreno.ROCA);
        tablero.getCasillero(5, 4, 2).setTerreno(TipoDeTerreno.ROCA);
        tablero.getCasillero(4, 2, 2).setTerreno(TipoDeTerreno.ROCA);

        tablero.getCasillero(1, 8, 2).setTerreno(TipoDeTerreno.ESCALERA_SUBIDA);
        tablero.getCasillero(1, 8, 3).setTerreno(TipoDeTerreno.ESCALERA_BAJADA);

        tablero.getCasillero(6, 1, 2).setTerreno(TipoDeTerreno.ESCALERA_BAJADA);
        tablero.getCasillero(6, 1, 1).setTerreno(TipoDeTerreno.ESCALERA_SUBIDA);

        tablero.getCasillero(1, 1, 2).ocupar(jugador1);
        tablero.getCasillero(6, 8, 2).ocupar(jugador2);

        var duende = new Enemigo("Duende del Puente", 20, 20, 1, 10, 1);
        tablero.getCasillero(2, 3, 2).ocupar(duende);

        var orco = new Enemigo("Jefe Orco", 50, 50, 1, 25, 1);
        tablero.getCasillero(4, 5, 2).ocupar(orco);

        var espectro = new Enemigo("Espectro", 30, 30, 2, 15, 2);
        tablero.getCasillero(5, 7, 2).ocupar(espectro);

        tablero.getCasillero(1, 8, 3).ocupar(new CartaInvisibilidad());
        tablero.getCasillero(6, 1, 1).ocupar(new CartaPotenciadorDeDanio());
        tablero.getCasillero(3, 1, 2).ocupar(new CartaCuracion());

        var listaDeJugadores = new ListaSimplementeEnlazada<JugadorDeRolgar>();
        listaDeJugadores.add(jugador1);
        listaDeJugadores.add(jugador2);

        var juego = new Juego(listaDeJugadores, tablero, interfaz,new JSONDificultadJuegoRepository(),new JSONTableroRepository());

        interfaz.setJuego(juego);

        juego.iniciarJuego();
    }

    private static String pedirNombre(String mensaje, String porDefecto) {
        try {
            var dialog = new DialogInputTexto();
            var resultado = new CompletableFuture<String>();
            dialog.render(mensaje,resultado);
            String input = resultado.join();
            if (input == null) return null;
            return input.isEmpty() ? porDefecto : input;
        } catch (NoClassDefFoundError e) {
            return JOptionPane.showInputDialog(null, mensaje, porDefecto);
        }
    }
}
