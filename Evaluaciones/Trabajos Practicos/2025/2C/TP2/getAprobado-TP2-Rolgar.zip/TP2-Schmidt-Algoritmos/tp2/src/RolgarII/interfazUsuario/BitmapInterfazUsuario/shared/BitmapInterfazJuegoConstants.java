package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared;

public class BitmapInterfazJuegoConstants {

    public static final String SPRITES_URL = "/resources/assets/sprites/";

    public static final String SPRITE_FILE_NAME_SPRITE_NO_ENCONTRADO = "no_encontrado";

}
