package ejemplos.leer_archivo_array;

public class ClaseSimple {
    private int dato;

    public ClaseSimple(int dato){
        this.dato = dato;
    }
    public ClaseSimple(){}

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }

    @Override
    public String toString() {
        return "ClaseSimple{" +
                "dato=" + dato +
                '}';
    }
}
