package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que permite al jugador robar una carta del inventario
 *       de otro jugador que tenga al menos una carta disponible.
 */
public class CartaRobo extends Carta {

    /**
     * post: Crea una carta de robo, cuyo efecto es apropiarse de una carta
     *       de otro jugador.
     */
    public CartaRobo() {
        super("Carta de robo");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Permite al jugador que usa la carta seleccionar a otro jugador con cartas disponibles.
     *       Si el jugador seleccionado es válido (no es aliado, no es él mismo y no es nulo),
     *       se roba una carta de su inventario y se agrega al inventario del jugador que usa la carta.
     *       Devuelve true si el robo fue exitoso, false en caso contrario.
     */
    @Override
    public boolean usar(JugadorDeRolgar atacante, Juego juego) {

        JugadorDeRolgar objetivo = juego.seleccionarJugadorConCartas(atacante);

        if (objetivo == null) {
            return false;
        }

        Carta cartaRobada = juego.seleccionarCartaDeJugador(objetivo);

        if (cartaRobada == null) {
            juego.mostrarMensaje("Robo cancelado.");
            return false;
        }

        objetivo.removerCartaDelInventario(cartaRobada);
        atacante.agregarCartaAlInventario(cartaRobada);

        juego.mostrarMensaje(atacante.getNombre() + " robó " + cartaRobada.getNombre() + " de " + objetivo.getNombre() + ".");

        return true;
    }
}

