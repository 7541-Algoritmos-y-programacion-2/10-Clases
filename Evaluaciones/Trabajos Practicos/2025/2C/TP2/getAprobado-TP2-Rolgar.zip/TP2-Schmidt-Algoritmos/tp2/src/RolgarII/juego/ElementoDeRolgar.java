package RolgarII.juego;

public interface ElementoDeRolgar {
}
