package RolgarII.shared.json;

import com.fasterxml.jackson.databind.ObjectMapper;

public abstract class JSONRepository {
    protected ObjectMapper mapper;
    public JSONRepository(){
        this.mapper = new ObjectMapper();
    }




}
