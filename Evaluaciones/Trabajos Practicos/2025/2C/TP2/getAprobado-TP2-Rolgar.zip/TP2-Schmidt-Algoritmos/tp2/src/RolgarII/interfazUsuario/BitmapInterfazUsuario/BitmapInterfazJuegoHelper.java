package RolgarII.interfazUsuario.BitmapInterfazUsuario;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapInterfazJuegoConstants;
import RolgarII.shared.bitmap.Bitmap;
import RolgarII.shared.clases.SpriteId;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

import javax.swing.*;
import javax.swing.border.Border;
import java.io.IOException;
import java.net.URL;

public class BitmapInterfazJuegoHelper {

    public static URL getIconUrl(String iconFileName){
        return BitmapInterfazJuegoHelper.class.getResource(
                BitmapInterfazJuegoConstants.SPRITES_URL + iconFileName + ".png"
        );
    }


    public static ImageIcon getImageIconFromSpriteId(SpriteId spriteId){
        ValidacionesUtiles.validarNull(spriteId,"spriteId");
        try{
            var resourceUrl = BitmapInterfazJuegoHelper.getIconUrl(
                    spriteId.getValue()
            );
            if(resourceUrl == null){
                resourceUrl = BitmapInterfazJuegoHelper.getIconUrl(BitmapInterfazJuegoConstants.SPRITE_FILE_NAME_SPRITE_NO_ENCONTRADO);
            }

            Bitmap bitmap = Bitmap.loadFromFile(resourceUrl.getPath());
            return new ImageIcon(bitmap.getImage());

        } catch(IOException e){
            e.printStackTrace();
            throw new RuntimeException("Error al obtener el icono de spriteId: " + spriteId.getValue());
        }

    }


    public static Border paddingBorder(int xPadding,int yPadding){
        return BorderFactory.createEmptyBorder(yPadding,xPadding,yPadding,xPadding);
    }
    public static Border paddingBorder(int padding){
        return BorderFactory.createEmptyBorder(padding,padding,padding,padding);
    }
}
