package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared;

import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

/** Representa el contexto actual al momento de renderizar
 * partes del juego.*/
public class GameRenderContext {

    private Turno turno;

    public GameRenderContext(Turno turno){
        ValidacionesUtiles.esDistintoDeNull(turno,"Turno");
        this.turno = turno;
    }

    public boolean esJugadorDelTurnoActual(JugadorDeRolgar jugador){
        return turno.getJugador().equals(jugador);
    }

    public Turno getTurno(){
        return this.turno;
    }

}
