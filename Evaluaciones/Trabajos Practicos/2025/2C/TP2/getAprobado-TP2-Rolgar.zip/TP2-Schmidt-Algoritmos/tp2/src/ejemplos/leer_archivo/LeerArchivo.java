package ejemplos.leer_archivo;

import com.fasterxml.jackson.databind.ObjectMapper;


public class LeerArchivo {



    public static void main(String[] args) throws Exception {

        var mapper = new ObjectMapper();
        var data = LeerArchivo.class.getResource("/ejemplos/leer_archivo/ejemplo.json");

        var leido = mapper.readValue(data,ClasePrueba.class);

        System.out.println(leido);

    }

}
