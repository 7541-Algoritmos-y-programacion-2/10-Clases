package ejemplos;

import javax.swing.*;

public class PruebaSwing {

    private static class FramePrueba extends JFrame{
        public FramePrueba(){
            super();
            setSize(500,500);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);
        }

    }
    public static void main(String[] args) {
        var frame1 = new FramePrueba();
        var frame2 = new FramePrueba();
    }
}
