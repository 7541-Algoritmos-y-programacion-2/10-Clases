package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.clases.SpriteId;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class JugadorViewEntity extends ViewEntity<JugadorDeRolgar> {
    public JugadorViewEntity(JugadorDeRolgar jugadorDeRolgar) {
        super(jugadorDeRolgar);
    }


    @Override
    public SpriteId getSpriteId(GameRenderContext context) {
        var jugador = getEntidad();


        if(jugador.estaInvisible()){
            if(context.esJugadorDelTurnoActual(jugador)){
                return SpriteId.JUGADOR_INVISIBLE;
            }
            return SpriteId.VACIO;
        }

        return SpriteId.JUGADOR;
    }
}
