package ejemplos.leer_archivo_array;

public enum EnumSimple {
    VALOR1,VALOR2
}
