package RolgarII.jugador;

public enum EstadoDeVisibilidad {

    SIN_EFECTO,MAXIMA

}
