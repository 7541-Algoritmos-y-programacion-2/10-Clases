package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import java.awt.*;

public class DialogInputTextoMainPanel extends JPanel {


    public DialogInputTextoMainPanel() {
        super();
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 2));
        setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());



    }
}
