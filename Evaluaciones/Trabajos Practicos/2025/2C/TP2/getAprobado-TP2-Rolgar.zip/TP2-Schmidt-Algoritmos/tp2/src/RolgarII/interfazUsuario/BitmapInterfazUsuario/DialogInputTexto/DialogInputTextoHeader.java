package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class DialogInputTextoHeader extends JPanel {
    private final JLabelTitulo titulo;

    public DialogInputTextoHeader(){
        super();
        setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        setBorder(new EmptyBorder(10, 10, 10, 10));

        titulo = new JLabelTitulo("",18);

        add(titulo);
    }

    void render(String titulo){
        this.titulo.setText(titulo);
    }
}
