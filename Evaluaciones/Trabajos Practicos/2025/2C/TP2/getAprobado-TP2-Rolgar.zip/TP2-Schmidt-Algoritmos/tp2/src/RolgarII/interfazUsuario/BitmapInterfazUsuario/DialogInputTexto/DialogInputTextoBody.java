package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import java.awt.*;

public class DialogInputTextoBody extends JPanel {

    public DialogInputTextoBody(JTextField textField){
        super();

        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
        setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());
        add(textField);
    }

}
