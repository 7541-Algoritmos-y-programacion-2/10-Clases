package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;

import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntityFactory;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.turno.Turno;
import RolgarII.shared.conjuntos.Conjunto;
import RolgarII.tablero.TableroDeRolgar;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.util.concurrent.CompletableFuture;

public class TableroPanel extends JPanel {

    public TableroPanel() {
        super();
        var layout = new GridLayout();
        this.setLayout(layout);
        setOpaque(false);
        setBorder(
                BorderFactory.createLineBorder(
                        BitmapJuegoColors.BORDER_BOARD.getColor(),5,true
                )
        );

    }

    private void modificarLayout(int rows,int columns){
        this.getLayout().setRows(rows);
        this.getLayout().setColumns(columns);
    }

    public void seleccionarCelda(TableroDeRolgar tablero, int posZ, CompletableFuture<CasilleroDeRolgar> onClickResultado){

        this.removeAll();
        this.modificarLayout(tablero.getAncho(),tablero.getAlto());
        var tablero2d = tablero.getCasillerosPorProfunidad(posZ);
        for(var fila : tablero2d){
            for(var casillero : fila){

                var labelCelda = new JLabelCasilleroSeleccionable(casillero,() -> {
                    onClickResultado.complete(casillero);
                });
                add(labelCelda,true);
            }
        }

        revalidate();
    }

    public void render(TableroDeRolgar tablero, Turno turno, GameRenderContext context){
        this.removeAll();
        this.modificarLayout(tablero.getAncho(),tablero.getAlto());
        var jugador = turno.getJugador();
        var posZ = jugador.getPosZ();

        var tablero2d = tablero.getCasillerosPorProfunidad(posZ);

        var filasCeldasVisibles = tablero.getCasillerosEnElPlanoPorProfundidad(jugador.getPosX(),jugador.getPosY(),posZ,jugador.getVision());
        var celdasVisiblesSet = new Conjunto<CasilleroDeRolgar>();
        filasCeldasVisibles.forEach(celdasVisiblesSet::addAll);

        //Por cada celda del nivel genere el componente que va ahi
        for (var fila : tablero2d) {
            for (var celda : fila) {

                var esVisible = celdasVisiblesSet.contains(celda);
                var label = new JLabelCasillero(celda);
                this.add(label,esVisible);
                label.render(context);

            }
        }
        revalidate();
    }

    @Override
    public GridLayout getLayout() {
        return (GridLayout) super.getLayout();
    }


    public Component add(JLabelCasillero comp,boolean esVisible) {
        var cantidadColumnas = this.getLayout().getColumns();
        int filasOcupadas = this.getComponentCount() / cantidadColumnas;
        var hayCambioDeFila = this.getComponentCount() % cantidadColumnas == 0;
        BitmapJuegoColors color = null;

        Component componenteAComparar = null;
        if(hayCambioDeFila && filasOcupadas >= 1){
            var indicePrimerElementoEnFilaAnterior = this.getComponentCount() - cantidadColumnas;
            componenteAComparar = this.getComponent(indicePrimerElementoEnFilaAnterior);
        } else if(getComponentCount() > 0){
            componenteAComparar = getComponent(getComponentCount()-1);
        }


        if(componenteAComparar != null &&
            (componenteAComparar.getBackground().equals(BitmapJuegoColors.ODD_CELL.getColor()) ||
            componenteAComparar.getBackground().equals(BitmapJuegoColors.ODD_CELL_DARKER.getColor()))
        ){
            color = BitmapJuegoColors.EVEN_CELL;
        } else {
            color = BitmapJuegoColors.ODD_CELL;
        }

        comp.setColor(color);
        if(!esVisible){
            comp.setOculto();
        }
        return super.add(comp);
    }
}
