package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones;

import javax.swing.*;

class PanelOpcionesScrollPane extends JScrollPane {

    public PanelOpcionesScrollPane(PanelOpciones panelOpciones){
        super(panelOpciones);
        setBorder(null);
        setOpaque(false);
        getViewport().setOpaque(false);
    }

    PanelOpciones getPanelOpciones(){
        return (PanelOpciones) getViewport().getView();
    }
}