package RolgarII.casillero;

import java.util.Arrays;
import java.util.Objects;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class Casillero3D<T> {

    private T valor = null;
    protected int[] coordenadas;

    /**
     * pre: 'valor' puede ser nulo. x, y, z deben ser coordenadas válidas.
     * post: Crea un casillero con el valor dado y coordenadas asignadas.
     */
    public Casillero3D(T valor, int x, int y, int z) {
        this.valor = valor;
        this.coordenadas = new int[]{x, y, z};
    }
    public Casillero3D() {

    }

    public void setValor(T valor) {
        this.valor = valor;
    }

    public int[] getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(int[] coordenadas) {
        this.coordenadas = coordenadas;
    }

    @Override
    public String toString() {
        return "Casillero3D [valor=" + valor + ", getX()=" + getX() + ", getY()=" + getY() + ", getZ()=" + getZ() + "]";
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = 31 * result + ((valor == null) ? 0 : valor.hashCode());
        result = 31 * result + Arrays.hashCode(coordenadas);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Casillero3D<?> other = (Casillero3D<?>) obj;
        return Objects.equals(valor, other.valor) &&
                Arrays.equals(coordenadas, other.coordenadas);
    }

    /**
     * post: Devuelve verdadero si el casillero no contiene ningún valor.
     */
    public boolean estaLibre() {
        return this.valor == null;
    }

    /**
     * post: El casillero queda vacío.
     */
    public void vaciar() {
        this.valor = null;
    }

    /**
     * pre: El casillero debe estar libre.
     * post: El casillero pasa a contener el nuevo valor.
     */
    public void ocupar(T nuevoValor) {
        ValidacionesUtiles.validarVerdadero(estaLibre(), "El casillero ya está ocupado");
        this.valor = nuevoValor;
    }

    /**
     * post: Devuelve verdadero si el casillero contiene exactamente el valor especificado.
     */
    public boolean contiene(T valor) {
        return Objects.equals(this.valor, valor);
    }

    /**
     * pre: 'otro' no debe ser null.
     * post: Intercambia los valores entre ambos casilleros.
     */
    public void intercambiarValor(Casillero3D<T> otro) {
        ValidacionesUtiles.esDistintoDeNull(otro, "otro");
        T temp = this.valor;
        this.valor = otro.valor;
        otro.valor = temp;
    }

    /**
     * post: Devuelve verdadero si las coordenadas coinciden con las del casillero.
     */
    public boolean estaEnCoordenada(int x, int y, int z) {
        return getX() == x && getY() == y && getZ() == z;
    }

    /**
     * post: Devuelve el valor almacenado en el casillero.
     */
    public T getValor() {
        return valor;
    }

    /**
     * post: Devuelve la coordenada X del casillero.
     */
    public int getX() {
        return coordenadas[0];
    }

    /**
     * post: Devuelve la coordenada Y del casillero.
     */
    public int getY() {
        return coordenadas[1];
    }

    /**
     * post: Devuelve la coordenada Z del casillero.
     */
    public int getZ() {
        return coordenadas[2];
    }
}
