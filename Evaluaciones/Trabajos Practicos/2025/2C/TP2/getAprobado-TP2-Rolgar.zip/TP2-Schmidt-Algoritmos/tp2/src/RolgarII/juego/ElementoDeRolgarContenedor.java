package RolgarII.juego;

public class ElementoDeRolgarContenedor {

    private TipoDeTerreno terreno;        
    private ElementoDeRolgar entidad;     

    /**
     * pre: 'terreno' y 'entidad' pueden ser nulos.
     * post: Crea un contenedor con el terreno y la entidad especificados.
     */
    public ElementoDeRolgarContenedor(TipoDeTerreno terreno, ElementoDeRolgar entidad) {
        this.terreno = terreno;
        this.entidad = entidad;
    }

    /**
     * post: Devuelve el tipo de terreno almacenado.
     */
    public TipoDeTerreno getTerreno() {
        return terreno;
    }

    /**
     * pre: 'terreno' puede ser nulo.
     * post: Establece el tipo de terreno del contenedor.
     */
    public void setTerreno(TipoDeTerreno terreno) {
        this.terreno = terreno;
    }

    /**
     * post: Devuelve la entidad almacenada.
     */
    public ElementoDeRolgar getEntidad() {
        return entidad;
    }

    /**
     * pre: 'entidad' puede ser nula.
     * post: Establece la entidad del contenedor.
     */
    public void setEntidad(ElementoDeRolgar entidad) {
        this.entidad = entidad;
    }

    /**
     * post: Devuelve verdadero si no hay ninguna entidad (entidad es nula).
     */
    public boolean estaVacioDeEntidad() {
        return entidad == null;
    }
}