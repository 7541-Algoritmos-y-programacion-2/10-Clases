package RolgarII.juego.jugada;

import RolgarII.carta.Carta;
import RolgarII.juego.Juego;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;

public class JugadaUsarCarta implements Jugada{

    private Carta carta;
    public JugadaUsarCarta(Carta carta){
        this.carta = carta;
    }


    @Override
    public void ejecutar(Turno turno) {
        var jugador = turno.getJugador();
        var juego = turno.getJuego();

        var seUsoLaCarta = carta.usar(jugador,juego);
        if(seUsoLaCarta){
            jugador.removerCarta(carta);
        }

        turno.consumirMovimiento();

    }
}
