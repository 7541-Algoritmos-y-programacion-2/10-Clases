package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugada;

import RolgarII.juego.jugada.TipoDeJugada;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

public class JugadaFormatter {

    public static DialogOpcionJugada comoOpcion(TipoDeJugada tipoDeJugada, int i){
        var integerString = Integer.toString(i);
        return switch (tipoDeJugada){
            case TipoDeJugada.MOVIMIENTO -> new DialogOpcionJugada("Mover jugador", integerString, tipoDeJugada);
            case TipoDeJugada.USAR_CARTA -> new DialogOpcionJugada("Usar carta", integerString, tipoDeJugada);
            case TipoDeJugada.PROPONER_ALIANZA -> new DialogOpcionJugada("Proponer Alianza", integerString, tipoDeJugada);
            case TipoDeJugada.PASAR_TURNO -> new DialogOpcionJugada("Pasar Turno / Abandonar", integerString, tipoDeJugada);
        };

    }

    public static DialogOpcionJugada[] jugadasComoOpciones(){
        var resultado = new ListaSimplementeEnlazada<DialogOpcionJugada>();

        int i = 1;
        for(TipoDeJugada tipoDeJugada : TipoDeJugada.values()){
            resultado.add(comoOpcion(tipoDeJugada, i));
            i++;
        }
        return resultado.toArray(new DialogOpcionJugada[0]);
    }
}