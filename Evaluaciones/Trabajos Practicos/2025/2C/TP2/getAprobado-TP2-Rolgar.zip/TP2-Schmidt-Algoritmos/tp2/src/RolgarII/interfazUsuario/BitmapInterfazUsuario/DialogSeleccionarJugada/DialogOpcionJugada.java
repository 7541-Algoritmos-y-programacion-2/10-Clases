package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugada;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;
import RolgarII.juego.jugada.TipoDeJugada;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class DialogOpcionJugada extends DialogOpcionesOpcion<TipoDeJugada> {


    public DialogOpcionJugada(String titulo, String caracter, TipoDeJugada valor) {
        super(titulo, caracter, valor);
    }
}
