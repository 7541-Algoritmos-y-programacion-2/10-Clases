package RolgarII.juego.jugada;

import RolgarII.juego.Juego;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;

public interface Jugada {


    void ejecutar(Turno turno);


}
