package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.PanelBoxContraints;
import RolgarII.tablero.TableroDeRolgar;

import javax.swing.*;
import java.awt.*;

/** Contenido principal de la interfaz de tablero,
 * contiene el Header y el container del tablero*/
public class MainContent extends PanelBoxContraints {

    private TableroPanel tableroPanel;

    public MainContent(double ancho){
        super(0,0,ancho,1);
        this.tableroPanel = new TableroPanel();

        setLayout(new BorderLayout());
        setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());
        setBorder(BorderFactory.createEmptyBorder(0,25,30,25));


        var header = new MainContentHeader();
        var tableroContainer = new TableroPanelContainer(tableroPanel);


        add(header,BorderLayout.NORTH);
        add(tableroContainer,BorderLayout.CENTER);
    }

    public TableroPanel getPanelTablero(){
        return tableroPanel;
    }

}
