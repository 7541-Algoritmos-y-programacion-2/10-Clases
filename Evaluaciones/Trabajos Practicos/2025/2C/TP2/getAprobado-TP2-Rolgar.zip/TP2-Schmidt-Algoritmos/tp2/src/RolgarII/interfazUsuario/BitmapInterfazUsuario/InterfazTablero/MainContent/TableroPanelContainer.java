package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import java.awt.*;

public class TableroPanelContainer extends JPanel {

    public TableroPanelContainer(TableroPanel tableroPanel){
        super();
        setLayout(new BorderLayout());
        setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),2,true),
                BorderFactory.createEmptyBorder(40,40,40,40)
        ));

        add(tableroPanel, BorderLayout.CENTER);
    }
}
