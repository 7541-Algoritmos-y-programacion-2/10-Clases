package RolgarII;

import RolgarII.carta.Carta;
import RolgarII.carta.CartaFactory;
import RolgarII.config.*;
import RolgarII.dificultadJuego.JSONDificultadJuegoRepository.JSONDificultadJuegoRepository;
import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.InterfazConsola;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.juego.Juego;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.tablero.JSONTableroRepository.JSONTableroRepository;
import RolgarII.tablero.TableroDeRolgar;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.util.Scanner;

public class MainRolgar {

    private static final Scanner scanner = new Scanner(System.in);
    private static final String BASE_CONFIG_PATH = "tp2/src/RolgarII/config/";

    public static void main(String[] args) {
        try {
            String archivoConfig = seleccionarConfigPorDificultad(scanner);
            String rutaConfig = BASE_CONFIG_PATH + archivoConfig;
            System.out.println("Cargando configuración desde: " + rutaConfig);

            ConfiguracionDeJuego cfg = cargarConfiguracion(rutaConfig);
            ParametrosJuegoConfig params = cfg.getParametrosJuego();

            TableroDeRolgar tablero = new TableroDeRolgar(
                    cfg.getAncho(),
                    cfg.getAlto(),
                    cfg.getProfundo(),
                    1
            );

            for (TerrenoConfig tCfg : cfg.getTerrenos()) {
                PosicionConfig p = tCfg.getPosicion();
                TipoDeTerreno terreno = TipoDeTerreno.valueOf(tCfg.getTipo());

                tablero.getCasillero(p.getX(), p.getY(), p.getZ())
                        .setTerreno(terreno);
            }

            ListaSimplementeEnlazada<JugadorDeRolgar> jugadores = new ListaSimplementeEnlazada<>();

            for (JugadorConfig jCfg : cfg.getJugadores()) {
                PosicionConfig p = jCfg.getPosicion();

                ListaSimplementeEnlazada<Carta> cartasIniciales = new ListaSimplementeEnlazada<>();
                if (jCfg.getCartasIniciales() != null) {
                    for (String tipo : jCfg.getCartasIniciales()) {
                        Carta c = CartaFactory.crearCartaPorTipo(tipo);
                        if (c != null) cartasIniciales.add(c);
                    }
                }

                JugadorDeRolgar jugador = new JugadorDeRolgar(
                        jCfg.getNombre(),
                        jCfg.getVida(),
                        cartasIniciales,
                        jCfg.getVision(),
                        jCfg.getFuerza(),
                        jCfg.getRegeneracionPorTurno(),
                        p.getX(),
                        p.getY(),
                        p.getZ(),
                        params.getVidaMaximaJugador(),
                        params.getMaxCartasPorJugador()
                );

                jugadores.add(jugador);

                tablero.getCasillero(p.getX(), p.getY(), p.getZ())
                        .ocuparConEntidad(jugador);
            }

            for (EnemigoConfig eCfg : cfg.getEnemigos()) {
                PosicionConfig p = eCfg.getPosicion();

                Enemigo enemigo = new Enemigo(
                        eCfg.getNombre(),
                        eCfg.getEnergia(),
                        eCfg.getAtaque(),
                        p.getX(), p.getY(), p.getZ()
                );

                tablero.getCasillero(p.getX(), p.getY(), p.getZ())
                        .ocuparConEntidad(enemigo);
            }

            for (CartaEnTableroConfig cCfg : cfg.getCartasEnTablero()) {
                PosicionConfig p = cCfg.getPosicion();
                Carta carta = CartaFactory.crearCartaPorTipo(cCfg.getTipoCarta());
                if (carta != null) {
                    tablero.getCasillero(p.getX(), p.getY(), p.getZ())
                            .ocuparConEntidad(carta);
                }
            }

            var ui = new InterfazConsola();
            ui.setJugadoresGlobales(jugadores);

            Juego juego = new Juego(jugadores, tablero, ui,new JSONDificultadJuegoRepository(),new JSONTableroRepository());

            if (params != null) juego.aplicarParametrosDeJuego(params);

            ui.mostrarLeyendaTerrenos();

            juego.iniciarJuego();


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String seleccionarConfigPorDificultad(Scanner scanner) {
        while (true) {
            System.out.println("Seleccione dificultad:");
            System.out.println("  1) FACIL");
            System.out.println("  2) NORMAL");
            System.out.println("  3) DIFICIL");
            System.out.print("Opción: ");

            String input = scanner.nextLine().trim().toUpperCase();

            if (input.equals("1") || input.equals("FACIL") || input.equals("F"))
                return "config-facil.json";

            if (input.equals("2") || input.equals("NORMAL") || input.equals("N"))
                return "config-normal.json";

            if (input.equals("3") || input.equals("DIFICIL") || input.equals("D"))
                return "config-dificil.json";

            System.out.println("Opción inválida, intentá de nuevo.\n");
        }
    }

    private static ConfiguracionDeJuego cargarConfiguracion(String ruta) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(new File(ruta), ConfiguracionDeJuego.class);
    }
}
