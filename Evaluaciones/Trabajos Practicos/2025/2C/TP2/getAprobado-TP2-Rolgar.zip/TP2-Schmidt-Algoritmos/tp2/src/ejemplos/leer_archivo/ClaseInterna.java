package ejemplos.leer_archivo;

public class ClaseInterna{
    private boolean valor1;

    @Override
    public String toString() {
        return "ClaseInterna{" +
                "valor1='" + valor1 + '\'' +
                '}';
    }

    public boolean isValor1() {
        return valor1;
    }

    public void setValor1(boolean valor1) {
        this.valor1 = valor1;
    }
}
