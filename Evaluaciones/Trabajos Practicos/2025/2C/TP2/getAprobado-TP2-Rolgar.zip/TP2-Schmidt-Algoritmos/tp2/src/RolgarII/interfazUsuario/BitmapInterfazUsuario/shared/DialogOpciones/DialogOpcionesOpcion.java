package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.CompletableFuture;

public class DialogOpcionesOpcion<T> extends JPanel {

    private static final Color BG_COLOR = BitmapJuegoColors.BORDER.getColor();
    private static final Color BG_COLOR_HOVER = BitmapJuegoColors.BORDER_HIGHLIGHT.getColor();

    String titulo;
    String caracter;
    CompletableFuture<T> resultado;
    T valor;
    public DialogOpcionesOpcion(String titulo,String caracter,T valor){
        super();
        this.titulo = titulo;
        this.caracter = caracter;
        this.valor = valor;

        var label = new JLabelTitulo(getTituloFormateado(),20);
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(getPreferredSize().width,50));
        setMaximumSize(new Dimension(getMaximumSize().width,70));
        setBackground(BG_COLOR);

        setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BitmapJuegoColors.BORDER_HIGHLIGHT.getColor(),2,true),
                        BitmapInterfazJuegoHelper.paddingBorder(15,0)
                )
        );
        add(label,BorderLayout.WEST);
        inicializarMouseListener();
    }

    private void inicializarMouseListener(){

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(resultado == null){
                    return;
                }
                if(resultado.isDone()){
                    return;
                }
                resultado.complete(valor);
                var window = SwingUtilities.getWindowAncestor(DialogOpcionesOpcion.this);
                window.setVisible(false);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                setBackground(BG_COLOR_HOVER);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                setBackground(BG_COLOR);
                setCursor(Cursor.getDefaultCursor());
            }
        });
    }

    protected String getTituloFormateado(){
        return this.caracter + " - " + this.titulo;
    }

    public void setCompletableFuture(CompletableFuture<T> resultado){
        this.resultado = resultado;
    }

}
