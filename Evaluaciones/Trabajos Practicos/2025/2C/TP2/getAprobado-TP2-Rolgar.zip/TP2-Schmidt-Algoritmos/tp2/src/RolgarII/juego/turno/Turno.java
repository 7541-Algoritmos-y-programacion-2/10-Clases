package RolgarII.juego.turno;

import RolgarII.juego.Juego;
import RolgarII.jugador.Jugador;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class Turno {

    private Juego juego;
    private JugadorDeRolgar jugador;
    private int movimientosRestantes;

    public Turno(Juego juego, JugadorDeRolgar jugador, int movimientosRestantes){
        ValidacionesUtiles.esDistintoDeNull(juego, "juego");
        ValidacionesUtiles.esDistintoDeNull(jugador, "juego");
        ValidacionesUtiles.validarMayorACero(movimientosRestantes, "movimientosRestantes");

        this.juego = juego;
        this.jugador = jugador;
        this.movimientosRestantes = movimientosRestantes;

    }

    public JugadorDeRolgar getJugador(){
        return this.jugador;
    }
    public Juego getJuego(){
        return this.juego;
    }
    public int getMovimientosRestantes(){
        return this.movimientosRestantes;
    }

    /** POS : Inicia el turno, restaurando a 0 los movimientos restantes. */
    public void iniciarTurno(){
        if(jugador.tieneDobleMovimiento()){
            movimientosRestantes *= 2;
            jugador.desactivarDobleMovimiento();
        }
    }

    public void finalizar(){
        movimientosRestantes = 0;
        jugador.recuperarSaludPorTurno();
        juego.ejecutarEfectosFinDeTurno();
    }

    /** POS : Devuelve true si el turno ha terminado.*/
    public boolean estaTerminado(){
        return movimientosRestantes == 0;
    }

    /*POS : Finaliza el turno y restaura a 0 los movimientos restantes.*/
    private void finalizarTurno(){
        movimientosRestantes = 0;
    }

    /*POS : Resta 1 a los movimientos restantes.*/
    public void consumirMovimiento(){
        movimientosRestantes--;
    }

    public void consumirTodosLosMovimientos(){
        movimientosRestantes = 0;
    }
}
