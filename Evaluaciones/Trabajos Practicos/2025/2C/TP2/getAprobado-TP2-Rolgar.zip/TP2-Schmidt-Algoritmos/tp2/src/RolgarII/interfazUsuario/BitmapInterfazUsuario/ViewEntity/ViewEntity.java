package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.turno.Turno;
import RolgarII.shared.clases.SpriteId;
import RolgarII.validacionesUtiles.ValidacionesUtiles;


/**Representa la forma en la que se debe renderizar el
 * icono del objeto en la interfaz de usuario.
 * EJ: Si el jugador tiene invisibilidad no lo renderizada,
 * EJ: Si el enemigo tiene poca vida el ponga un borde rojo.
 * */
public abstract class ViewEntity<T> {

    protected T entity;
    public ViewEntity(T entity){
        ValidacionesUtiles.esDistintoDeNull(entity,"Entity");
        this.entity = entity;
    }

    protected T getEntidad(){
        return this.entity;
    }

    public abstract SpriteId getSpriteId(GameRenderContext context);



}
