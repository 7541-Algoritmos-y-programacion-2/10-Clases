package RolgarII.interfazUsuario.BitmapInterfazUsuario;

import RolgarII.carta.Carta;
import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto.DialogInputTexto;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionadDificultad.DialogSeleccionarDificultad;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarCarta.DialogSeleccionarCarta;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarDireccion.DialogSeleccionarDireccion;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugada.DialogOpcionesSeleccionarJugada;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugador.DialogSeleccionarJugador;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.InterfazTablero;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ModalMostrarMensaje.ModalMostrarMensaje;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntityFactory;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.jugada.JugadaPasarTurno;
import RolgarII.juego.jugada.JugadaUsarCarta;
import RolgarII.juego.jugada.TipoDeJugada;
import RolgarII.juego.Juego;
import RolgarII.juego.jugada.*;
import RolgarII.juego.jugada.jugadaMover.JugadaProponerAlianza;
import RolgarII.juego.jugada.jugadaMover.JugadaMover;
import RolgarII.juego.jugada.jugadaMover.JugadaMoverDireccion;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.Jugador;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.preguntas.Pregunta;
import RolgarII.shared.interfaces.Renderizable;
import RolgarII.shared.teclado.Teclado;
import RolgarII.tablero.TableroDeRolgar;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogConflicto.DialogConflicto;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogConfirmacion.DialogConfirmacion;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.CompletableFuture;

/**
 * Las propiedades que empiezan con 'interfaz' solo se muestra 1 a la vez
 * mediante el cardLayout del panelPrincipal
 **/
public class BitMapInterfazJuego implements InterfazJuego {
    private JFrame frame;
    private JPanel panelPrincipal;
    private InterfazTablero interfazTablero;

    private DialogOpcionesSeleccionarJugada dialogSeleccionarJugada;
    private DialogSeleccionarCarta dialogSeleccionarCarta;
    private ModalMostrarMensaje modalMostrarMensaje;
    private DialogSeleccionarDireccion dialogSeleccionarDireccion;
    private DialogSeleccionarJugador dialogSeleccionarJugador;
    private DialogConfirmacion dialogConfirmacion;
    private DialogConflicto dialogConflicto;
    private DialogInputTexto dialogInputTexto;
    private DialogSeleccionarDificultad dialogSeleccionarDificultad;

    private Juego juego;

    public BitMapInterfazJuego() {
        ViewEntityFactory.inicializar();

        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Juego de Tp");
            frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    int confirm = JOptionPane.showOptionDialog(frame,
                            "¿Estás seguro de que quieres abandonar la partida?",
                            "Abandonar Juego",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null, null, null);

                    if (confirm == JOptionPane.YES_OPTION) {
                        System.exit(0);
                    }
                }
            });

            var layout = new CardLayout();
            panelPrincipal = new JPanel(layout);
            interfazTablero = new InterfazTablero();

            panelPrincipal.add(interfazTablero);
            frame.add(panelPrincipal);

            dialogSeleccionarJugada = new DialogOpcionesSeleccionarJugada(frame);
            dialogSeleccionarCarta = new DialogSeleccionarCarta(frame);
            dialogSeleccionarDireccion = new DialogSeleccionarDireccion(frame);
            dialogSeleccionarJugador = new DialogSeleccionarJugador(frame);
            modalMostrarMensaje = new ModalMostrarMensaje(frame); // Usará el default o el que configures
            dialogConfirmacion = new DialogConfirmacion(frame);
            dialogConflicto = new DialogConflicto(frame);
            dialogInputTexto = new DialogInputTexto();
            dialogSeleccionarDificultad = new DialogSeleccionarDificultad(frame);

            frame.setResizable(true);
            frame.setVisible(true);
            frame.setSize(1000, 800);
        });
    }

    public void setJuego(Juego juego) {
        this.juego = juego;
    }

    @Override
    public String hacerPregunta(Pregunta pregunta) {
        return pregunta.getOpciones().get(0);
    }

    @Override
    public DificultadJuego seleccionarDificultad(DificultadJuego[] dificultades) {

        var resultado = new CompletableFuture<DificultadJuego>();
        SwingUtilities.invokeLater(() -> {
           dialogSeleccionarDificultad.mostrarYSeleccionar(dificultades,resultado);
        });
        var dificultadSeleccionada = resultado.join();
        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarDificultad.ocultar();
        });
        return dificultadSeleccionada;
    }


    private TipoDeJugada solicitarTipoDeJugada(Jugador jugador) {
        CompletableFuture<TipoDeJugada> resultado = new CompletableFuture<>();
        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarJugada.mostrarYSeleccionar(resultado);
        });

        TipoDeJugada tipoDeJugada = resultado.join();

        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarJugada.ocultar();
        });

        return tipoDeJugada;
    }

    @Override
    public Jugada seleccionarJugada(JugadorDeRolgar jugador) {
        TipoDeJugada tipoDeJugada = solicitarTipoDeJugada(jugador);
        if (!jugador.estaVivo()) {
            mostrarMensaje("¡Advertencia!...");
            return new JugadaPasarTurno();
        }
        if (tipoDeJugada == null) return new JugadaPasarTurno();

        switch(tipoDeJugada){
            case MOVIMIENTO:
                JugadaMoverDireccion direccion = dialogSeleccionarDireccion.mostrarYSeleccionarSync();
                return new JugadaMover(direccion);
            case USAR_CARTA:
                Carta carta = seleccionarCartaDeJugador(jugador);
                if (carta == null) return new JugadaPasarTurno();
                return new JugadaUsarCarta(carta);
            case PROPONER_ALIANZA:
                if (juego != null) {
                    JugadorDeRolgar candidato = juego.seleccionarCandidatoParaAlianza(jugador);
                    if(candidato != null) return new JugadaProponerAlianza(candidato);
                } else {
                    System.err.println("Error: La referencia a 'juego' en BitMapInterfazJuego es null. Usa setJuego().");
                    mostrarMensaje("Error interno: No se puede proponer alianza (Juego ref null).");
                }
                return new JugadaPasarTurno();
            default:
                return new JugadaPasarTurno();
        }
    }

    @Override
    public void renderizarTablero(TableroDeRolgar tablero, JugadorDeRolgar jugadorActual, Turno turno){
        //Renderiza la primer capa del tablero 3d
        var context = new GameRenderContext(turno);
        SwingUtilities.invokeLater(() -> {
            interfazTablero.render(tablero,jugadorActual,turno,context);

        });

    }

    @Override
    public String leerComandoMovimiento() {
        return "";
    }

    @Override
    public void mostrarMensaje(String mensaje) {
        CompletableFuture<Void> awaiter = new CompletableFuture<Void>();
        SwingUtilities.invokeLater(() -> {
            modalMostrarMensaje.mostrarMensaje(mensaje,() -> awaiter.complete(null));
        });
        awaiter.join();
    }


    @Override
    public JugadorDeRolgar seleccionarJugador(JugadorDeRolgar[] jugadores) {
        CompletableFuture<JugadorDeRolgar> resultado = new CompletableFuture<>();
        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarJugador.mostrarYSeleccionar(jugadores,resultado);
        });

        var jugadorSeleccionado = resultado.join();
        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarJugador.ocultar();
        });
        return jugadorSeleccionado;
    }

    @Override
    public Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador) {
        CompletableFuture<Carta> resultado = new CompletableFuture<>();
        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarCarta.setCartas(jugador.getPoderes());
            dialogSeleccionarCarta.mostrarYSeleccionar(resultado);
        });

        Carta cartaSeleccionada = resultado.join();

        SwingUtilities.invokeLater(() -> {
            dialogSeleccionarCarta.ocultar();
        });

        return cartaSeleccionada;
    }

    @Override
    public CasilleroDeRolgar seleccionarCeldaLibre(TableroDeRolgar tablero,int ejeZ){
        CompletableFuture<CasilleroDeRolgar> resultado = new CompletableFuture<>();

        SwingUtilities.invokeLater(() -> {
            interfazTablero.getPanelTablero().seleccionarCelda(tablero,ejeZ,resultado);
        });

        var celdaSeleccionada = resultado.join();
        if (celdaSeleccionada == null) {
            mostrarMensaje("Celda no seleccionada");
            return null;
        }
        return celdaSeleccionada;
    }

    @Override
    public int obtenerAccionDeTurno(JugadorDeRolgar jugador, int movimientosRestantes) {
        CompletableFuture<Void> c = new CompletableFuture<>();
        var t = new Timer(6000, e -> {
            c.complete(null);
        });
        t.setRepeats(false);
        t.start();
        c.join();
        return 1;
    }

    @Override
    public boolean obtenerConfirmacion(String mensaje) {
        CompletableFuture<Boolean> resultado = new CompletableFuture<>();

        SwingUtilities.invokeLater(() -> {
            dialogConfirmacion.mostrar(mensaje, resultado);
        });

        return resultado.join();
    }

    @Override
    public int obtenerOpcionNumerica(String mensaje) {
        if (mensaje.toLowerCase().contains("opción") || mensaje.toLowerCase().contains("pelear")) {
            CompletableFuture<Integer> resultado = new CompletableFuture<>();
            SwingUtilities.invokeLater(() -> {
                dialogConflicto.mostrar(mensaje, resultado);
            });
            return resultado.join();
        }

        try {
            String input = javax.swing.JOptionPane.showInputDialog(frame, mensaje);
            if(input == null) return 0;
            return Integer.parseInt(input);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public String obtenerTexto(String prompt) {
        var resultado = new CompletableFuture<String>();
        SwingUtilities.invokeLater(() -> {
            dialogInputTexto.render(prompt, resultado);
        });

        return resultado.join();
    }

    @Override
    public void mostrarOpcionesMovimiento(JugadorDeRolgar jugador, TableroDeRolgar tablero){

    }
}
