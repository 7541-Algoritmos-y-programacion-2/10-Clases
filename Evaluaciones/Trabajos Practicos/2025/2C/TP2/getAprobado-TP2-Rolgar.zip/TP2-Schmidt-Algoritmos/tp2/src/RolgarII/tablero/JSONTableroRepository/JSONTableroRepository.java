package RolgarII.tablero.JSONTableroRepository;

import RolgarII.shared.json.JSONRepository;
import RolgarII.tablero.TableroDeRolgar;
import RolgarII.tablero.TableroRepository;

import java.io.IOException;

public class JSONTableroRepository extends JSONRepository implements TableroRepository {

    private static final String RUTA_BASE = "/RolgarII/tablero/JSONTableroRepository/base.json";

    @Override
    public TableroDeRolgar obtenerTableroPorId(int tableroId) {
        try{

            var resource = getClass().getResource(RUTA_BASE);

            var jsonTablerosDto = mapper.readValue(resource,JsonTableroDto[].class);
            for(var tableroDto : jsonTablerosDto){
                if(tableroDto.tieneElId(tableroId)){
                    return tableroDto.toTableroRolgar();
                }
            }
            return null;
        }catch(IOException e){
            e.printStackTrace();
            return null;
        }

    }
}
