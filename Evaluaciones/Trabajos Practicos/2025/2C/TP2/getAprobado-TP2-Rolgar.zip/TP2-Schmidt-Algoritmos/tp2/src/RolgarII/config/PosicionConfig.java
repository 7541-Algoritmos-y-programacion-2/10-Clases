package RolgarII.config;

public class PosicionConfig {

    private int x;
    private int y;
    private int z;

    /**
     * post: Crea una posición sin inicializar (x, y, z se asignan luego).
     */
    public PosicionConfig() {
    }

    /**
     * post: Devuelve la coordenada X configurada.
     */
    public int getX() {
        return x;
    }

    /**
     * pre: x debe ser mayor o igual a 1.
     * post: Establece el valor de la coordenada X.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * post: Devuelve la coordenada Y configurada.
     */
    public int getY() {
        return y;
    }

    /**
     * pre: y debe ser mayor o igual a 1.
     * post: Establece el valor de la coordenada Y.
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * post: Devuelve la coordenada Z configurada.
     */
    public int getZ() {
        return z;
    }

    /**
     * pre: z debe ser mayor o igual a 1.
     * post: Establece el valor de la coordenada Z.
     */
    public void setZ(int z) {
        this.z = z;
    }
}


