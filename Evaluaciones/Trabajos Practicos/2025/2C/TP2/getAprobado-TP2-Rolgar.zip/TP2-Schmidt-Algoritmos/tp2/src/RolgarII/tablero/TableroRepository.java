package RolgarII.tablero;

public interface TableroRepository {

    TableroDeRolgar obtenerTableroPorId(int tableroId);

}
