package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;


import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import java.awt.*;

public class MainContentHeader extends JPanel {
    public MainContentHeader(){
        super();
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(15,0,15,0));

        setLayout(new FlowLayout(FlowLayout.LEFT));
        var labelHeader = new JLabelTitulo("Juego para Tp schmidt",32);

        add(labelHeader);
    }
}
