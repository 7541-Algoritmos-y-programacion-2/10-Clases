package RolgarII.juego;

import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

/**
 * Representa una alianza temporal entre dos jugadores.
 *
 * Cada alianza tiene una duración en turnos, luego de la cual expira automáticamente.
 */
public class Alianza {
    private final JugadorDeRolgar jugador;
    private final JugadorDeRolgar otroJugador;
    private int turnosRestantes;

    /**
     * post: Crea una alianza entre los dos jugadores indicados por la cantidad de turnos especificada.
     *
     * @param jugador primer jugador que forma parte de la alianza, no puede ser nulo
     * @param otroJugador segundo jugador aliado, no puede ser nulo
     * @param turnos cantidad de turnos que dura la alianza, debe ser mayor a cero
     */
    public Alianza(JugadorDeRolgar jugador, JugadorDeRolgar otroJugador, int turnos) {
        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
        ValidacionesUtiles.esDistintoDeNull(otroJugador, "otroJugador");
        ValidacionesUtiles.validarMayorACero(turnos, "turnos");
        this.jugador = jugador;
        this.otroJugador = otroJugador;
        this.turnosRestantes = turnos;
    }

    /**
     * post: Devuelve true si el jugador indicado forma parte de la alianza.
     *
     * @param jugador jugador a verificar, no puede ser nulo
     * @return true si el jugador pertenece a la alianza, false en caso contrario
     */
    public boolean incluye(JugadorDeRolgar jugador) {
        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
        return this.jugador.equals(jugador) || this.otroJugador.equals(jugador);
    }

    /**
     * post: Devuelve true si ambos jugadores son aliados entre sí dentro de esta alianza.
     *
     * @param jugador primer jugador a verificar
     * @param otro segundo jugador a verificar
     * @return verdadero si ambos jugadores forman parte de la misma alianza.
     */
    public boolean sonAliados(JugadorDeRolgar jugador, JugadorDeRolgar otro) {
        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
        ValidacionesUtiles.esDistintoDeNull(otro, "otro");
        return (this.jugador.equals(jugador) && this.otroJugador.equals(otro))
            || (this.jugador.equals(otro) && this.otroJugador.equals(jugador));
    }

    /**
     * post: Reduce en uno la cantidad de turnos restantes de la alianza.
     */
    public void avanzarTurno() {
        if (turnosRestantes > 0) turnosRestantes--;
    }

    /**
     * post: Indica si la alianza ya no tiene turnos restantes.
     *
     * @return verdadero si la alianza está expirada.
     */
    public boolean estaExpirada() {
        return turnosRestantes == 0;
    }
}
