package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.PanelBoxContraints;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.tablero.TableroDeRolgar;

import java.awt.*;

public class RightSidebar extends PanelBoxContraints {
    private CardTurnoActual cardTurnoActual;
    private CardlInformacionDelNivel cardInformacionDeNivel;
    private CardInformacionJugador cardInformacionJugador;
    public RightSidebar(double ancho){
        super(1,0,ancho,1);

        setLayout(new GridBagLayout());
        setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());

        cardTurnoActual = new CardTurnoActual(0.1);
        cardInformacionDeNivel = new CardlInformacionDelNivel(0.45);
        cardInformacionJugador = new CardInformacionJugador(0.45);


        add(cardTurnoActual,cardTurnoActual.getConstraints());
        add(cardInformacionDeNivel,cardInformacionDeNivel.getConstraints());
        add(cardInformacionJugador, cardInformacionJugador.getConstraints());
    }

    public void render(TableroDeRolgar tablero, JugadorDeRolgar jugador, Turno turno){

        cardTurnoActual.render(jugador,turno.getMovimientosRestantes());

        cardInformacionDeNivel.render(tablero,jugador.getPosZ());

        cardInformacionJugador.render(jugador);

    }

}
