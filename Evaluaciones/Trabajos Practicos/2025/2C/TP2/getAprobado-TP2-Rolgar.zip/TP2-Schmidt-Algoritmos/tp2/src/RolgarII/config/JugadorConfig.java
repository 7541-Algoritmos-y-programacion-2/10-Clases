package RolgarII.config;

public class JugadorConfig {

    private String nombre;
    private double vida;
    private int fuerza;
    private int vision;
    private double regeneracionPorTurno;
    private PosicionConfig posicion;
    private String[] cartasIniciales;

    /**
     * post: Crea una configuración vacía para un jugador.
     */
    public JugadorConfig() {
    }

    /**
     * post: Devuelve el nombre configurado para el jugador.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * pre: nombre no debe ser null.
     * post: Asigna el nombre del jugador.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * post: Devuelve la vida inicial configurada para el jugador.
     */
    public double getVida() {
        return vida;
    }

    /**
     * pre: vida debe ser mayor o igual a 0.
     * post: Establece la vida inicial del jugador.
     */
    public void setVida(double vida) {
        this.vida = vida;
    }

    /**
     * post: Devuelve la fuerza configurada para el jugador.
     */
    public int getFuerza() {
        return fuerza;
    }

    /**
     * pre: fuerza debe ser mayor o igual a 0.
     * post: Establece la fuerza del jugador.
     */
    public void setFuerza(int fuerza) {
        this.fuerza = fuerza;
    }

    /**
     * post: Devuelve el rango de visión configurado para el jugador.
     */
    public int getVision() {
        return vision;
    }

    /**
     * pre: vision debe ser mayor o igual a 1.
     * post: Establece el rango de visión del jugador.
     */
    public void setVision(int vision) {
        this.vision = vision;
    }

    /**
     * post: Devuelve la cantidad de vida regenerada por turno.
     */
    public double getRegeneracionPorTurno() {
        return regeneracionPorTurno;
    }

    /**
     * pre: regeneración debe ser mayor o igual a 0.
     * post: Establece cuánto regenera el jugador cada turno.
     */
    public void setRegeneracionPorTurno(double regeneracionPorTurno) {
        this.regeneracionPorTurno = regeneracionPorTurno;
    }

    /**
     * post: Devuelve la posición inicial configurada para el jugador.
     */
    public PosicionConfig getPosicion() {
        return posicion;
    }

    /**
     * pre: posicion no debe ser null.
     * post: Establece la posición inicial del jugador.
     */
    public void setPosicion(PosicionConfig posicion) {
        this.posicion = posicion;
    }

    /**
     * post: Devuelve las cartas iniciales que tendrá el jugador.
     */
    public String[] getCartasIniciales() {
        return cartasIniciales;
    }

    /**
     * pre: el arreglo puede ser null o contener tipos de carta válidos.
     * post: Establece las cartas iniciales del jugador.
     */
    public void setCartasIniciales(String[] cartasIniciales) {
        this.cartasIniciales = cartasIniciales;
    }
}




