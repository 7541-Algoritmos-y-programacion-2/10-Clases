package RolgarII.interfazUsuario.BitmapInterfazUsuario;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.jugador.JugadorDeRolgar;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.CompletableFuture;

public class ModalSeleccionarJugador extends JDialog {

    private JPanel contentContainer;
    private CompletableFuture<JugadorDeRolgar> futuroResultado;

    public ModalSeleccionarJugador(JFrame frame){
        super(frame,"Selecciona un jugador",true); // Modal
        this.setSize(500, 500);
        this.setLocationRelativeTo(frame);
        this.setUndecorated(true);

        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 2));
        mainPanel.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JPanel tituloContainer = new JPanel(new BorderLayout());
        tituloContainer.setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        tituloContainer.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JLabelTitulo titulo = new JLabelTitulo("Selecciona un jugador", 23);
        tituloContainer.add(titulo, BorderLayout.CENTER);
        mainPanel.add(tituloContainer, BorderLayout.NORTH);

        contentContainer = new JPanel();
        contentContainer.setLayout(new BoxLayout(contentContainer, BoxLayout.Y_AXIS));
        contentContainer.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JScrollPane scrollPane = new JScrollPane(contentContainer);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(Color.RED);
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.addActionListener(e -> cancelar());
        mainPanel.add(btnCancelar, BorderLayout.SOUTH);

        this.add(mainPanel);
    }

    /**
     * Muestra el modal y genera la lista de jugadores dinámicamente.
     */
    public void mostrarYSeleccionar(JugadorDeRolgar[] jugadores, CompletableFuture<JugadorDeRolgar> resultado) {
        this.futuroResultado = resultado;
        contentContainer.removeAll(); // Limpiar residuos anteriores ("Rodrigo")

        int indice = 1;
        for (JugadorDeRolgar j : jugadores) {
            contentContainer.add(crearCardJugador(j, indice));
            contentContainer.add(Box.createRigidArea(new Dimension(0, 10))); // Espacio vertical
            indice++;
        }

        contentContainer.revalidate();
        contentContainer.repaint();
        this.setVisible(true);
    }

    private JPanel crearCardJugador(JugadorDeRolgar jugador, int index) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(BitmapJuegoColors.CARD_BG.getColor());
        card.setMaximumSize(new Dimension(450, 60));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 1, true),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabelTitulo labelNumero = new JLabelTitulo("#" + index, 20);
        labelNumero.setPreferredSize(new Dimension(50, 40));

        JLabelTitulo labelNombre = new JLabelTitulo(jugador.getNombre(), 18);

        JLabel labelVida = new JLabel("HP: " + jugador.getVida());
        labelVida.setForeground(Color.GREEN);
        labelVida.setFont(new Font("Arial", Font.BOLD, 14));

        card.add(labelNumero, BorderLayout.WEST);
        card.add(labelNombre, BorderLayout.CENTER);
        card.add(labelVida, BorderLayout.EAST);

        card.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionar(jugador);
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                card.setBackground(BitmapJuegoColors.CARD_BG.getColor().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                card.setBackground(BitmapJuegoColors.CARD_BG.getColor());
            }
        });

        return card;
    }

    private void seleccionar(JugadorDeRolgar jugador) {
        this.setVisible(false);
        if (futuroResultado != null) {
            futuroResultado.complete(jugador);
        }
    }

    public void ocultar() {
        this.setVisible(false);
    }

    private void cancelar() {
        this.setVisible(false);
        if (futuroResultado != null && !futuroResultado.isDone()) {
            futuroResultado.complete(null);
        }
    }
}