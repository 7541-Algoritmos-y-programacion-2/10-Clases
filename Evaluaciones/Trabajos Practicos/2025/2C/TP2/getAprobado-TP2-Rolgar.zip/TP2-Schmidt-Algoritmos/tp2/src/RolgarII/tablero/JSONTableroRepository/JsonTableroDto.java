package RolgarII.tablero.JSONTableroRepository;

import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.tablero.TableroDeRolgar;

public class JsonTableroDto {
    private int alto;
    private int profundo;
    private int ancho;

    private int tableroId;
    private ListaSimplementeEnlazada<
                ListaSimplementeEnlazada<
                        ListaSimplementeEnlazada<CasilleroDeRolgar>
                        >
            > casilleros;

    public int getAlto() {
        return alto;
    }

    public void setAlto(int alto) {
        this.alto = alto;
    }

    public int getProfundo() {
        return profundo;
    }

    public void setProfundo(int profundo) {
        this.profundo = profundo;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getTableroId() {
        return tableroId;
    }

    public void setTableroId(int tableroId) {
        this.tableroId = tableroId;
    }

    public boolean tieneElId(int tableroId){
        return this.tableroId == tableroId;
    }

    public ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    >
            > getCasilleros() {
        return casilleros;
    }

    public void setCasilleros(ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<CasilleroDeRolgar>
                    >
            > casilleros) {
        this.casilleros = casilleros;
    }

    public TableroDeRolgar toTableroRolgar(){
        var tablero = new TableroDeRolgar(
                ancho,alto,profundo,tableroId
        );
        tablero.setGrilla(casilleros);
        return tablero;
    }

}
