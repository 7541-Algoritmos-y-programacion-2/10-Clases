package RolgarII.juego;

import RolgarII.jugador.Jugador;
import RolgarII.jugador.JugadorDeRolgar;

import RolgarII.jugador.JugadorDeRolgar;

public enum TipoDeTerreno implements ElementoDeRolgar {

    TIERRA("T", true, false),
    ROCA("R", false, false),
    AGUA("A", false, false),
    ESCALERA_SUBIDA("↑", true, true){
        @Override
        public void onEnter(JugadorDeRolgar jugador, Juego juego) {
            juego.moverJugadorVertical(
                    jugador,
                    jugador.getPosZ() + 1
            );
        }
    },
    ESCALERA_BAJADA("↓", true, true){
        @Override
        public void onEnter(JugadorDeRolgar jugador, Juego juego) {
            juego.moverJugadorVertical(
                    jugador,
                    jugador.getPosZ() - 1
            );
        }
    },
    VACIO(".", true, false);

    private final String simbolo;
    private final boolean transitable;
    private final boolean escalera;

    /**
     * pre: 'simbolo' no debe ser nulo. 'transitable' y 'escalera' definen
     * correctamente el comportamiento del terreno.
     * post: Inicializa un tipo de terreno con su símbolo, transitabilidad y si es escalera.
     */
    TipoDeTerreno(String simbolo, boolean transitable, boolean escalera) {
        this.simbolo = simbolo;
        this.transitable = transitable;
        this.escalera = escalera;
    }

    /**
     * post: Devuelve el símbolo que representa al terreno en el mapa.
     */
    public String getSimbolo() {
        return simbolo;
    }

    /**
     * post: Devuelve verdadero si el terreno es transitable.
     */
    public boolean esTransitable() {
        return transitable;
    }

    /**
     * post: Devuelve verdadero si el terreno es una escalera (subida o bajada).
     */
    public boolean esEscalera() {
        return escalera;
    }

    /**
     * post: Devuelve verdadero si el terreno es una escalera de subida.
     */
    public boolean esEscaleraSubida() {
        return this == ESCALERA_SUBIDA;
    }

    /**
     * post: Devuelve verdadero si el terreno es una escalera de bajada.
     */
    public boolean esEscaleraBajada() {
        return this == ESCALERA_BAJADA;
    }


    public void onEnter(JugadorDeRolgar jugador, Juego juego){

    }

}