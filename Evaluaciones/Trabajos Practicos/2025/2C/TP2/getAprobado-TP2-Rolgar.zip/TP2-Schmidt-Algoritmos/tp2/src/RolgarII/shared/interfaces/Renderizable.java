package RolgarII.shared.interfaces;

import RolgarII.shared.clases.SpriteId;


/** Las entidades que implementen esta interfaz y se encuentren dentro del tablero
* seran renderizadas por la implementacion de interfazJuego en uso,
*
* Utilizar la interfaz permite indicar que 'icono' tendra la entidad al
* ser renderizada sin estar acoplada a la implementacion
*
* Ej: Si la implementacion es por bitmap se puede mapear cada SpriteId posible
* a un archivo.png, si la implementacion es por consola se puede mapear cada SpriteId
* a un caracter*/
public interface Renderizable {

    /**Retorna el spriteId de referebcua con el cual
    se debe renderizar la entidad*/
    SpriteId getSpriteId();

}
