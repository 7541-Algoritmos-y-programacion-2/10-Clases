package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity;

import RolgarII.carta.Carta;
import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones.CartaViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones.EnemigoViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones.JugadorViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones.TerrenoViewEntity;
import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import java.util.List;
import java.util.function.Function;

/*Es la factory que recibiendo un elemento de rolgard crea su ViewEntity correspondiente.
* habria sido ideal usar un Map en su lugar, pero aun no lo vimos en la materia,
*
* Usa 2 listas para mapear cada clase de elemento de rolgard a su factory
* La primera 'clasesRegistradas' es una lista de clases,
* la segunda 'factories' es una lista de funciones que reciben un objeto de la primera lista
* y devuelven un ViewEntity, se mapea por indice EJ: si en clasesRegistradas[0] esta la clase Jugador,
* entonces la factory jugador estara en factories[0]
* */
public class ViewEntityFactory {

    private static List<Class<?>> clasesRegistradas;
    private static List<Function<Object,ViewEntity>> factories;

    private static boolean estaInicializado = false;
    public static void inicializar(){
        if(estaInicializado){
            return;
        }
        factories = new ListaSimplementeEnlazada<>();
        clasesRegistradas = new ListaSimplementeEnlazada<>();

        registrar(JugadorDeRolgar.class, JugadorViewEntity::new);
        registrar(Enemigo.class, EnemigoViewEntity::new);
        registrar(Carta.class, CartaViewEntity::new);
        registrar(TipoDeTerreno.class, TerrenoViewEntity::new);

        estaInicializado = true;
    }
    private static <T> void registrar(
            Class<T> clase,
            Function<T,ViewEntity> factory){

        clasesRegistradas.add(clase);
        factories.add( (Function<Object, ViewEntity>) factory);

    }

    public static ViewEntity crear(ElementoDeRolgar elementoDeRolgar){
        if(!estaInicializado){
            throw new RuntimeException("No se ha inicializado la ViewEntityFactory factory.");
        }
        var index = -1;
        for(int i = 0; i < factories.size(); i++){
            var clase = clasesRegistradas.get(i);
            if(clase.isAssignableFrom(elementoDeRolgar.getClass())){
                index = i;
                break;
            }
        }

        return factories.get(index).apply(elementoDeRolgar);

    }





}


