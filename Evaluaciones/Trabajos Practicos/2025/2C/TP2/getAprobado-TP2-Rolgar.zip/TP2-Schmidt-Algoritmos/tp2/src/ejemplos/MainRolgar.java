package ejemplos;

import RolgarII.carta.*;
import RolgarII.dificultadJuego.DificultadJuegoRepository;
import RolgarII.dificultadJuego.JSONDificultadJuegoRepository.JSONDificultadJuegoRepository;
import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitMapInterfazJuego;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.juego.Juego;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.shared.teclado.Teclado;
import RolgarII.tablero.JSONTableroRepository.JSONTableroRepository;
import RolgarII.tablero.TableroDeRolgar;
import RolgarII.tablero.TableroRepository;

public class MainRolgar {
    public static void main(String[] args) {
            Teclado.inicializar();
            InterfazJuego interfaz = new BitMapInterfazJuego();
            DificultadJuegoRepository dificultadJuegoRepository = new JSONDificultadJuegoRepository();
            TableroRepository tableroRepository = new JSONTableroRepository();

            var cartasJugador1 = new ListaSimplementeEnlazada<Carta>();
            cartasJugador1.add(CartaFactory.aleatoria());
            cartasJugador1.add(CartaFactory.aleatoria());
            cartasJugador1.add(CartaFactory.aleatoria());
            cartasJugador1.add(new CartaVisibilidad());
            cartasJugador1.add(new CartaRobo());
            var jugador1 = new JugadorDeRolgar(
                    "Jugador1",
                    50,
                    cartasJugador1,
                    2,
                    25,
                    25,
                    1, 1, 2,
                    100,
                    5
            );

            var cartasJugador2 = new ListaSimplementeEnlazada<Carta>();
            cartasJugador2.add(new CartaTeletransportacion());
            cartasJugador2.add(new CartaCuracion());
            cartasJugador2.add(new CartaDobleMovimiento());
            cartasJugador2.add(new CartaEscudo());
            cartasJugador2.add(new CartaInvisibilidad());
            cartasJugador2.add(new CartaPotenciadorDeDanio());
            cartasJugador2.add(new CartaRobo());
            cartasJugador2.add(new CartaVisibilidad());
            var jugador2 = new JugadorDeRolgar(
                    "Jugador2",
                    50,
                    cartasJugador2,
                    20,
                    25,
                    25,
                    2, 2, 2,
                    100,
                    5
            );

            var carta = new CartaInvisibilidad();
            var enemigo = new Enemigo("Enemigo1",25,25,1,4,2);
            var enemigo2 = new Enemigo("Enemigo2",25,25,1,4,1);
            var tablero = new TableroDeRolgar(6,8,6,1);
            tablero.getCasillero(1,1,2).ocupar(jugador1);
            tablero.getCasillero(2,2,2).ocupar(jugador2);
            tablero.getCasillero(3,3,2).ocupar(carta);
            tablero.getCasillero(1,4,2).ocupar(enemigo);

            tablero.getCasillero(5,5,2).setTerreno(TipoDeTerreno.AGUA);
            tablero.getCasillero(3,2,2).setTerreno(TipoDeTerreno.ESCALERA_BAJADA);
            tablero.getCasillero(3,4,1).ocupar(enemigo2);

            tablero.getCasillero(6,5,2).setTerreno(TipoDeTerreno.ROCA);
            tablero.getCasillero(3,3,2).setTerreno(TipoDeTerreno.ESCALERA_SUBIDA);
            tablero.getCasillero(5,6,3).ocupar(enemigo2);


            var listaDeJugadores = new ListaSimplementeEnlazada<JugadorDeRolgar>();
            listaDeJugadores.add(jugador1);
            listaDeJugadores.add(jugador2);

            var juego = new Juego(listaDeJugadores,tablero,interfaz,dificultadJuegoRepository,tableroRepository);

//            interfaz.renderizarTablero(tablero,jugador1);
            juego.iniciarJuego();

    }
}
