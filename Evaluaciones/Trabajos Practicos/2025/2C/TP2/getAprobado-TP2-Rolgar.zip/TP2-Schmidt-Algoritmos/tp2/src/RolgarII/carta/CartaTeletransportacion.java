package RolgarII.carta;

import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que permite al jugador teletransportarse
 *       instantáneamente a cualquier casillero libre del tablero.
 */
public class CartaTeletransportacion extends Carta {

    /**
     * post: Crea una carta de teletransportación.
     */
    public CartaTeletransportacion() {
        super("Carta de teletransportacion");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Solicita al usuario seleccionar un casillero libre del tablero.
     *       Si el jugador cancela o selecciona una celda inválida, devuelve false.
     *       Si la celda es válida, intenta mover al jugador a esa posición utilizando
     *       la lógica de movimiento central del juego.
     *       Devuelve true si el teletransporte se realizó correctamente, false en caso contrario.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {

        CasilleroDeRolgar celda = juego.seleccionarCeldaLibre(jugador.getPosZ());

        if (celda == null) {
            juego.mostrarMensaje("Teletransportación cancelada.");
            return false;
        }

        boolean movido = juego.moverJugadorConDestino(jugador, celda);

        if (!movido) {
            juego.mostrarMensaje("No se pudo teletransportar a esa celda.");
            return false;
        }

        return true;
    }
}



