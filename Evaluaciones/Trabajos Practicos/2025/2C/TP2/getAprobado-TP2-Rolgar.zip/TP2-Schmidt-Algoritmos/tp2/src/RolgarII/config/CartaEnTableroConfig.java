package RolgarII.config;

public class CartaEnTableroConfig {

    private String tipoCarta;
    private PosicionConfig posicion;

    /**
     * post: Crea una instancia vacía para ser utilizada en la carga de configuración.
     */
    public CartaEnTableroConfig() {
    }

    /**
     * post: Devuelve el tipo de carta configurada.
     */
    public String getTipoCarta() {
        return tipoCarta;
    }

    /**
     * pre: 'tipoCarta' no debe ser nulo.
     * post: Establece el tipo de carta configurada.
     */
    public void setTipoCarta(String tipoCarta) {
        this.tipoCarta = tipoCarta;
    }

    /**
     * post: Devuelve la posición configurada para la carta.
     */
    public PosicionConfig getPosicion() {
        return posicion;
    }

    /**
     * pre: 'posicion' no debe ser nula.
     * post: Establece la posición donde aparecerá la carta en el tablero.
     */
    public void setPosicion(PosicionConfig posicion) {
        this.posicion = posicion;
    }
}



