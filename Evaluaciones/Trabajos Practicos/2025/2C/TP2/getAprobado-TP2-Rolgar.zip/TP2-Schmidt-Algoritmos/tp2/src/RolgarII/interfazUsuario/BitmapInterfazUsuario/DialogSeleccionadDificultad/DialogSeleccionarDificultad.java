package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionadDificultad;

import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class DialogSeleccionarDificultad extends DialogOpciones<DificultadJuego> {


    public DialogSeleccionarDificultad(JFrame owner) {
        super(owner, "Selector de dificultad","Dificultades disponibles","seleccione una dificultad");

    }

    public void mostrarYSeleccionar(DificultadJuego[] dificultadesDisponibles, CompletableFuture<DificultadJuego> resultado) {
        removeOpciones();
        for (int i = 0; i < dificultadesDisponibles.length; i++) {
            var dificultad = dificultadesDisponibles[i];
            var opcion =  new DialogOpcionDificultad(dificultad.getNombre(), Integer.toString(i+1), dificultad);
            addOpcion(opcion);
        }

        super.mostrarYSeleccionar(resultado);
    }
}
