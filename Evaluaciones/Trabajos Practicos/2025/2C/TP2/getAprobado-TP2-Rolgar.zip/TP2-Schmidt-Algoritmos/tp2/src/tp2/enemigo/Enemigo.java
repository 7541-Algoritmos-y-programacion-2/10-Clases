//package tp2.enemigo;
//
//import tp2.juego.ElementoDeRolgar;
//import tp2.jugador.JugadorDeRolgar;
//import RolgarII.shared.clases.SpriteId;
//import RolgarII.shared.interfaces.Renderizable;
//import tp2.validacionesUtiles.ValidacionesUtiles;
//
///**
// * Representa un enemigo dentro del tablero tridimensional del juego.
// *
// * Los enemigos poseen energía, capacidad de ataque y una posición (x, y, z).
// * Pueden recibir daño, atacar y verificar si continúan con vida.
// */
//public class Enemigo implements ElementoDeRolgar, Renderizable {
//    // INTERFACES ----------------------------------------------------------------------------------------------
//    // ENUMERADOS ----------------------------------------------------------------------------------------------
//    // CONSTANTES ----------------------------------------------------------------------------------------------
//
//    private static final int ATAQUE_DEFAULT = 25;
//    private static final int ENERGIA_MAXIMA = 200;
//
//    // ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//    // ATRIBUTOS -----------------------------------------------------------------------------------------------
//
//    private final String nombre;
//    private int energia;
//    private final int ataque;
//    private int posX;
//    private int posY;
//    private int posZ;
//
//    // ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//    // CONSTRUCTORES -------------------------------------------------------------------------------------------
//
//    /**
//     * post: Inicializa un enemigo con los valores indicados.
//     *
//     * @param nombre nombre del enemigo, no nulo
//     * @param energia energía inicial del enemigo, mayor a 0
//     * @param x: la coordenada x.
//     * @param y: la coordenada y.
//     * @param z: la coordenada z.
//     */
//    public Enemigo(String nombre, int energia, int x, int y, int z) {
//        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
//        ValidacionesUtiles.validarMayorACero(energia, "energía");
//        ValidacionesUtiles.validarMayorOIgualACero(x, "x");
//        ValidacionesUtiles.validarMayorOIgualACero(y, "y");
//        ValidacionesUtiles.validarMayorOIgualACero(z, "z");
//
//        this.nombre = nombre;
//        this.energia = Math.min(energia, ENERGIA_MAXIMA);
//        this.ataque = ATAQUE_DEFAULT;
//        this.posX = x;
//        this.posY = y;
//        this.posZ = z;
//    }
//
//    // METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//
//    /**
//     * post: Aplica daño al jugador indicado según el valor de ataque.
//     */
//    public void atacar(JugadorDeRolgar jugador) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//        jugador.recibirDanio(this.ataque);
//    }
//
//    /**
//     * post: Quita energía al enemigo. Si la energía llega a 0, el enemigo muere.
//     *
//     * @param danio cantidad de daño recibida, debe ser mayor a 0.
//     */
//    public void recibirDanio(int danio) {
//        ValidacionesUtiles.validarMayorACero(danio, "daño");
//        this.energia = Math.max(0, this.energia - danio);
//    }
//
//    /**
//     * post: Indica si el enemigo está vivo.
//     */
//    public boolean estaVivo() {
//        return this.energia > 0;
//    }
//
//    /**
//     * post: Devuelve la distancia al jugador.
//     */
//    public int distanciaA(JugadorDeRolgar jugador) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//        int dx = Math.abs(jugador.getPosX() - this.posX);
//        int dy = Math.abs(jugador.getPosY() - this.posY);
//        int dz = Math.abs(jugador.getPosZ() - this.posZ);
//        return dx + dy + dz;
//    }
//
//    // METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
//
//    public String getNombre() {
//        return nombre;
//    }
//
//    public int getEnergia() {
//        return energia;
//    }
//
//    public int getAtaque() {
//        return ataque;
//    }
//
//    public int getPosX() {
//        return posX;
//    }
//
//    public int getPosY() {
//        return posY;
//    }
//
//    public int getPosZ() {
//        return posZ;
//    }
//
//    // SETTERS SIMPLES -----------------------------------------------------------------------------------------
//
//    /**
//     * post: Incrementa la energía del enemigo, sin superar ENERGIA_MAXIMA.
//     */
//    public void curar(int puntos) {
//        ValidacionesUtiles.validarMayorACero(puntos, "curación");
//        this.energia = Math.min(ENERGIA_MAXIMA, this.energia + puntos);
//    }
//
//    @Override
//    public SpriteId getSpriteId() {
//        return SpriteId.ENEMIGO;
//    }
//}
