package RolgarII.juego.jugada.jugadaMover;

import RolgarII.juego.Juego;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class JugadaProponerAlianza implements Jugada {

    private final JugadorDeRolgar objetivo;

    /**
     * Crea una jugada para proponer una alianza a un jugador objetivo.
     * @param objetivo El jugador con el que se desea aliar. No puede ser null.
     */
    public JugadaProponerAlianza(JugadorDeRolgar objetivo) {
        ValidacionesUtiles.esDistintoDeNull(objetivo, "objetivo");
        this.objetivo = objetivo;
    }

    @Override
    public void ejecutar(Turno turno) {
        Juego juego = turno.getJuego();
        JugadorDeRolgar solicitante = turno.getJugador();
        boolean accionRealizada = juego.intentarFormarAlianza(solicitante, objetivo);
        if (accionRealizada) {
            turno.consumirMovimiento();
        }
    }
}