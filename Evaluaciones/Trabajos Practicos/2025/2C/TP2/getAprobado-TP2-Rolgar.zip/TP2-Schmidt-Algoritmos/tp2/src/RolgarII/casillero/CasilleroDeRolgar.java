package RolgarII.casillero;

import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.TipoDeTerreno;

import java.util.Arrays;
import java.util.Objects;

public class CasilleroDeRolgar extends Casillero3D<ElementoDeRolgar> {

    private TipoDeTerreno terreno;
    private ElementoDeRolgar entidad;

    /**
     * pre: (x, y, z) son coordenadas válidas.
     * post: Crea un casillero con el terreno dado y sin entidad.
     */
    public CasilleroDeRolgar(TipoDeTerreno terreno, int x, int y, int z) {
        super(null, x, y, z);
        this.terreno = terreno;
        this.entidad = null;
    }

    public CasilleroDeRolgar() {
        super();
    }

    /**
     * post: Devuelve el tipo de terreno del casillero.
     */
    public TipoDeTerreno getTerreno() {
        return terreno;
    }

    /**
     * pre: terreno no debe ser nulo.
     * post: Asigna un nuevo tipo de terreno al casillero.
     */
    public void setTerreno(TipoDeTerreno terreno) {
        this.terreno = terreno;
    }

    /**
     * post: Devuelve verdadero si el terreno es transitable.
     */
    public boolean terrenoEsTransitable() {
        return terreno == null || terreno.esTransitable();
    }

    /**
     * post: Devuelve verdadero si el casillero es transitable (terreno transitable y sin entidad bloqueante).
     */
    public boolean esTransitable() {
        if (!terrenoEsTransitable()) return false;
        return !(entidad instanceof RolgarII.jugador.JugadorDeRolgar) &&
                !(entidad instanceof RolgarII.enemigo.Enemigo);
    }

    /**
     * post: Devuelve la entidad actual del casillero o null si está vacío.
     */
    public ElementoDeRolgar getEntidad() {
        return entidad;
    }

    /**
     * pre: el casillero debe estar libre de entidad.
     * post: La entidad queda colocada en el casillero.
     * @throws RuntimeException si el casillero ya está ocupado.
     */
    public void ocuparConEntidad(ElementoDeRolgar e) {
        if (this.entidad != null)
            throw new RuntimeException("Casillero ya ocupado por entidad");
        this.entidad = e;
    }

    /**
     * post: El casillero queda sin entidad.
     */
    public void vaciarEntidad() {
        this.entidad = null;
    }

    /**
     * post: Devuelve verdadero si el casillero no tiene entidad.
     */
    public boolean estaLibreDeEntidad() {
        return this.entidad == null;
    }

    /**
     * post: Vacía la entidad del casillero.
     */
    @Override
    public void vaciar() {
        this.entidad = null;
    }

    /**
     * pre: el casillero debe estar libre.
     * post: Ocupa el casillero con la entidad dada.
     * @throws RuntimeException si ya está ocupado.
     */
    @Override
    public void ocupar(ElementoDeRolgar nuevo) {
        this.ocuparConEntidad(nuevo);
    }

    /**
     * post: Devuelve la entidad del casillero.
     */
    @Override
    public ElementoDeRolgar getValor() {
        return entidad;
    }

    /**
     * post: Devuelve verdadero si en este casillero hay una escalera de subida.
     */
    public boolean esEscaleraArriba() {
        return this.terreno == TipoDeTerreno.ESCALERA_SUBIDA;
    }

    /**
     * post: Devuelve verdadero si en este casillero hay una escalera de bajada.
     */
    public boolean esEscaleraAbajo() {
        return this.terreno == TipoDeTerreno.ESCALERA_BAJADA;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if(getClass() != o.getClass()){
            return false;
        }
        var other = (CasilleroDeRolgar) o;
        return Arrays.equals(super.coordenadas, other.coordenadas);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), terreno, entidad);
    }
}
