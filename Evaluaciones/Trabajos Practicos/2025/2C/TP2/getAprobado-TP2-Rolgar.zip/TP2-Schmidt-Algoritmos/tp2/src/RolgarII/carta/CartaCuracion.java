package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

public class CartaCuracion extends Carta {

    private final int PUNTOS_CURACION = 10;

    /**
     * post: Crea una carta de curación con su nombre correspondiente.
     */
    public CartaCuracion() {
        super("Carta de curacion");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Cura al jugador en PUNTOS_CURACION puntos y devuelve true indicando que la carta fue utilizada.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {
        jugador.curar(this.PUNTOS_CURACION);
        return true;
    }

    /**
     * post: Devuelve una nueva instancia de CartaCuracion.
     */
    static CartaCuracion generarAleatoria() {
        return new CartaCuracion();
    }
}


