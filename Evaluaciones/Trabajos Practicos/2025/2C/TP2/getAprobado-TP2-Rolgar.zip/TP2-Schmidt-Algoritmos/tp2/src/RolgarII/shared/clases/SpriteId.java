package RolgarII.shared.clases;

public enum SpriteId {
    JUGADOR,
    ENEMIGO,
    JUGADOR_INVISIBLE,
    VACIO,
    TERRENO_AGUA,
    TERRENO_ROCA,
    TERRENO_RAMPA_ARRIBA,
    TERRENO_RAMPA_ABAJO,
    TERRENO_TIERRA,
    CARTA;

    public String getValue(){
        return this.name().toLowerCase();
    }

}

