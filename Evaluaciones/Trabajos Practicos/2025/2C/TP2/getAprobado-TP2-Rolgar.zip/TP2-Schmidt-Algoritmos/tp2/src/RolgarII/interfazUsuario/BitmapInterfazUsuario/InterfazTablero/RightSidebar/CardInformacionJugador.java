package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.PanelBoxContraints;
import RolgarII.jugador.JugadorDeRolgar;

import javax.swing.*;
import java.awt.*;

public class CardInformacionJugador extends PanelBoxContraints {
    ItemEstadistica itemEstadisticaVida;
    ItemEstadistica itemEstadisticaEscudo;
    ItemEstadistica itemEstadisticaFuerza;
    ItemEstadistica itemEstadisticaEstado;

    public CardInformacionJugador(double porcentajeY){
        super(0,2,1,porcentajeY);
        setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),2,true),
                        BorderFactory.createEmptyBorder(20,10,20,10)
                )
        );

        var JLabelTitulo = new JLabelTitulo("Informacion de jugador",21);
        JLabelTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        itemEstadisticaVida = new ItemEstadistica("Vida","25");
        itemEstadisticaEscudo = new ItemEstadistica("Escudo","");
        itemEstadisticaFuerza = new ItemEstadistica("Fuerza","");
        itemEstadisticaEstado = new ItemEstadistica("Estado", ""); // Nuevo

        add(JLabelTitulo);
        add(Box.createVerticalStrut(15));
        add(itemEstadisticaVida);
        add(Box.createVerticalStrut(15));
        add(itemEstadisticaEscudo);
        add(Box.createVerticalStrut(15));
        add(itemEstadisticaFuerza);
        add(Box.createVerticalStrut(15));
        add(itemEstadisticaEstado);
    }

    public void render(JugadorDeRolgar jugador){
        itemEstadisticaVida.setValor(
                Double.toString(jugador.getVida()) + "/" + Double.toString(jugador.getVidaMaxima())
        );
        itemEstadisticaEscudo.setValor(
                jugador.tieneEscudoActivo() ? "Si" : "No"
        );

        String stringFuerza = "";
        String fuerzaBase = Integer.toString(jugador.getFuerza());
        if(jugador.tieneFuerzaPotenciada()){
            String fuerzaPotenciada = Double.toString(jugador.getFuerzaPotenciada());
            String fuerzaPotenciador = Double.toString(jugador.getPotenciadorDeFuerza());
            stringFuerza = fuerzaBase + "*" + fuerzaPotenciador + " = " + fuerzaPotenciada;
        } else {
            stringFuerza = fuerzaBase;
        }
        itemEstadisticaFuerza.setValor(stringFuerza);

        itemEstadisticaEstado.setValor(jugador.getDescripcionEstado());
    }
}