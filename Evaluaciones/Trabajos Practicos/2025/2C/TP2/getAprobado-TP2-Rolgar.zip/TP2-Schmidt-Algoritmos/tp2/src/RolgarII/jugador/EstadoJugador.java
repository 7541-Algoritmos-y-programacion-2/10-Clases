// EstadoJugador.java
package RolgarII.jugador;

public enum EstadoJugador {
    VIVO,
    MUERTO
}