package RolgarII.juego.jugada.jugadaMover;

import RolgarII.juego.Juego;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class JugadaMover implements Jugada {
    JugadaMoverDireccion direccion;

    public JugadaMover(JugadaMoverDireccion direccion){
        ValidacionesUtiles.validarNull(direccion, "direccion");
        this.direccion = direccion;
    }

    @Override
    public void ejecutar(Turno turno) {
        var jugador = turno.getJugador();
        var juego = turno.getJuego();

        int x = jugador.getPosX();
        int y = jugador.getPosY();
        x += direccion.getDx();
        y += direccion.getDy();

        var seLogroMover = juego.moverJugadorEnElPlano(jugador,x,y);
        if(!seLogroMover) {
            juego.mostrarMensaje("El jugador no puede moverse en esa direccion!.");
            return;
        }
        turno.consumirMovimiento();
    }

}








