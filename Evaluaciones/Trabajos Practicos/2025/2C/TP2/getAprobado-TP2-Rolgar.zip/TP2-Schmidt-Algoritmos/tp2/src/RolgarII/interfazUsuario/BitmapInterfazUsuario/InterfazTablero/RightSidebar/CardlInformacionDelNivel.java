package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.PanelBoxContraints;
import RolgarII.tablero.TableroDeRolgar;

import javax.swing.*;
import java.awt.*;

public class CardlInformacionDelNivel extends PanelBoxContraints {
    ItemEstadistica itemEstadisticaCantidadDeNiveles;
    ItemEstadistica itemEstadisticaNivelActual;

    public CardlInformacionDelNivel(double porcentajeY){
        super(0,1,1,porcentajeY);
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        /*Informacion del nivel*/
        setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),2,true),
                        BorderFactory.createEmptyBorder(20,10,20,10)
                )
        );

        var labelTituloDeNivel = new JLabelTitulo("Informacion del nivel",21);
        labelTituloDeNivel.setAlignmentX(Component.CENTER_ALIGNMENT);

        itemEstadisticaCantidadDeNiveles = new ItemEstadistica("Altura" ,"5");
        itemEstadisticaNivelActual = new ItemEstadistica("Nivel Actual","1");



        add(labelTituloDeNivel);
        add(Box.createVerticalStrut(25));
        add(itemEstadisticaCantidadDeNiveles);
        add(Box.createVerticalStrut(12));
        add(itemEstadisticaNivelActual);

    }

    public void render(TableroDeRolgar tablero,int z){
        itemEstadisticaNivelActual.setValor(Integer.toString(z));
        itemEstadisticaCantidadDeNiveles.setValor(Integer.toString(tablero.getProfundo()));
    }

}
