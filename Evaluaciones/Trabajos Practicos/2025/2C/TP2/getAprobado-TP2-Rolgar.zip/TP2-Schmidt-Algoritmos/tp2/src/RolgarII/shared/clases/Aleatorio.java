package RolgarII.shared.clases;

public class Aleatorio {

    public static int numeroAleatorio(int limiteInferior, int limiteSuperior) {
        return (int) (Math.random() * (limiteSuperior - limiteInferior + 1)) + limiteInferior;
    }

}
