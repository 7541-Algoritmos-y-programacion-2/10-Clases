package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

public class CartaCuracionAliado extends Carta {

    private final int PUNTOS_CURACION = 10;

    /**
     * post: Crea una carta de curación para aliados con su nombre correspondiente.
     */
    public CartaCuracionAliado() {
        super("Carta de curacion para aliados");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Solicita al usuario seleccionar un aliado. Si es válido, lo cura
     * en PUNTOS_CURACION y devuelve true (la carta es consumida).
     * Si no es válido o se cancela, devuelve false (la carta no se usa).
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {

        JugadorDeRolgar jugadorSeleccionado = juego.seleccionarJugador();

        if (jugadorSeleccionado == null) {
            juego.mostrarMensaje("Curación cancelada. No se seleccionó ningún jugador.");
            return false;
        }

        if (jugadorSeleccionado.equals(jugador)) {
            juego.mostrarMensaje("No puedes curarte a ti mismo con esta carta.");
            return false;
        }

        if (!juego.sonAliados(jugador, jugadorSeleccionado)) {
            juego.mostrarMensaje(jugadorSeleccionado.getNombre() + " no es tu aliado.");
            return false;
        }

        jugadorSeleccionado.curar(this.PUNTOS_CURACION);
        juego.mostrarMensaje(jugadorSeleccionado.getNombre() + " ha sido curado por " + this.PUNTOS_CURACION + " puntos.");

        return true;
    }
}

