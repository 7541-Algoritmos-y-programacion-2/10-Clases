package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;

import javax.swing.*;
import java.awt.*;

class PanelOpciones extends JPanel {
    int gapY;
    public PanelOpciones(int gapY){
        this.gapY = gapY;
        setOpaque(false);
        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        setBorder(BitmapInterfazJuegoHelper.paddingBorder(30,15));
    }


    @Override
    public Component add(Component comp) {
        if(this.getComponentCount() > 0){
            super.add(Box.createVerticalStrut(gapY));
        }
        return super.add(comp);
    }
}