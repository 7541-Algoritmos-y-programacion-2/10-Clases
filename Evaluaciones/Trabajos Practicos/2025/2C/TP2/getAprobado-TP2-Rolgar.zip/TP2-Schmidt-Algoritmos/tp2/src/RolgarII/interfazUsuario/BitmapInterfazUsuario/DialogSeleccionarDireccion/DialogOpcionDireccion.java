package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarDireccion;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;
import RolgarII.juego.jugada.jugadaMover.JugadaMoverDireccion;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

public class DialogOpcionDireccion extends DialogOpcionesOpcion<JugadaMoverDireccion> {

    public DialogOpcionDireccion(JugadaMoverDireccion direccion, String caracter){
        super(direccion.name().toLowerCase(),caracter,direccion);
    }
    /*POS : Retorna que string tendra asociada la direccion,
    * es el clasico WASD, no se ingresan estos caracteres
    * detro de la clase pues usar WASD o usar otras teclas no
    * son datos que pertenezcan a la 'direccion' si no que puede ser
    * distinto para cada implementacion de InterfazUsuario*/
    private static String obtenerCaracterPorDireccion(JugadaMoverDireccion direccion){
        return switch (direccion){
            case ARRIBA -> "W";
            case DERECHA -> "D";
            case ABAJO -> "S";
            case IZQUIERDA -> "A";
        };
    }

    static DialogOpcionDireccion[] direccionesComoOpciones(){

        var resultado = new ListaSimplementeEnlazada<DialogOpcionDireccion>();
        for(JugadaMoverDireccion direccion : JugadaMoverDireccion.values()){
            var caracter = obtenerCaracterPorDireccion(direccion);
            resultado.add(new DialogOpcionDireccion(direccion,caracter));
        }
        return resultado.toArray(new DialogOpcionDireccion[0]);

    }

}
