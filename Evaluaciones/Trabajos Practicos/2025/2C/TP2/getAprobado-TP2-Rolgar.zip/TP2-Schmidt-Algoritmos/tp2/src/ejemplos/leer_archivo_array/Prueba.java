package ejemplos.leer_archivo_array;

import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class Prueba {

    public static void main(String[] args) throws Exception{
        var mapper = new ObjectMapper();
        var resource = Prueba.class.getResource("/ejemplos/leer_archivo_array/ejemplo.json");

        var resultado = mapper.readValue(resource, new TypeReference<
                ListaSimplementeEnlazada<
                        ListaSimplementeEnlazada<ClaseSimple>
                        >
                >() {});

        System.out.println(resultado.getClass());
        System.out.println(resultado);
        for(var r : resultado){
            for(var c : r)
                System.out.println(c);
        }
    }

}
