package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones;

import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.turno.Turno;
import RolgarII.shared.clases.SpriteId;

public class EnemigoViewEntity extends ViewEntity<Enemigo> {
    private Enemigo enemigo;

    public EnemigoViewEntity(Enemigo entity) {
        super(entity);

        enemigo = entity;
    }

    @Override
    public SpriteId getSpriteId(GameRenderContext context) {
        return SpriteId.ENEMIGO;
    }



}
