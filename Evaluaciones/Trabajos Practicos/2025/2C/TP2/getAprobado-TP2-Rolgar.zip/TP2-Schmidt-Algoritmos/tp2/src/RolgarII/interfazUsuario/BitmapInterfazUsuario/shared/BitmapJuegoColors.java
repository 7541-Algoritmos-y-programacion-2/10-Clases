package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared;

import RolgarII.shared.bitmap.Bitmap;

import java.awt.*;

public enum BitmapJuegoColors{

    TEXT_FOREGROUND(Color.WHITE),
    TEXT_MUTED(new Color(129,145,169)),// #8191A9
    BORDER(new Color(49,65,88)),// #314158
    BORDER_HIGHLIGHT(new Color(69,85,108)), //#45556c
    PRIMARY_BG(new Color(21,31,51)),// #151F33
    SECONDARY_BG(new Color(28,40,60)),// #1C283C
    CARD_BG(new Color(32,33,71)),// #202147
    HIGH_LIGHT_BG(new Color(41,49,99)),// #293163
    BORDER_BOARD(new Color(123,51,6)),//#7B3306

    BTN_BG(new Color(50, 200, 50)),
    BTN_BG_HOVER(new Color(57, 230, 57)),
    BTN_BLACK_TEXT(Color.black),

    EVEN_CELL_DARKER(new Color(136,54,0)),
    EVEN_CELL_LIGHTER(new Color(204, 71,0)),
    EVEN_CELL(new Color(175,60,0),EVEN_CELL_DARKER,EVEN_CELL_LIGHTER),// #BA4C00

    ODD_CELL_DARKER(new Color(175,87,0)),
    ODD_CELL_LIGHTER(new Color(242, 121,0)),
    ODD_CELL(new Color(225,113,0),ODD_CELL_DARKER,ODD_CELL_LIGHTER);// #E17100


    private final Color color;
    private final BitmapJuegoColors darkerVersion;
    private final BitmapJuegoColors lighterVersion;

    BitmapJuegoColors(Color color){
        this(color,null,null);
    }
    BitmapJuegoColors(
            Color color,
            BitmapJuegoColors darkerVersion,
            BitmapJuegoColors lighterVersion){
        this.color = color;
        this.darkerVersion = darkerVersion;
        this.lighterVersion = lighterVersion;
    }

    public Color getColor(){
        return this.color;
    }

    public BitmapJuegoColors darker(){
        if(darkerVersion == null){
            return this;
        }
        return this.darkerVersion;
    }

    public BitmapJuegoColors lighter(){
        if(lighterVersion == null){
            return this;
        }
        return this.lighterVersion;
    }

}
