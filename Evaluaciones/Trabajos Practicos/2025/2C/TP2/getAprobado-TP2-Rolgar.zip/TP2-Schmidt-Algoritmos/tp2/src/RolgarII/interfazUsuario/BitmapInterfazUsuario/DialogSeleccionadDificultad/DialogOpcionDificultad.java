package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionadDificultad;

import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;

public class DialogOpcionDificultad extends DialogOpcionesOpcion<DificultadJuego> {


    public DialogOpcionDificultad(String titulo, String caracter, DificultadJuego valor) {
        super(titulo, caracter, valor);
    }
}
