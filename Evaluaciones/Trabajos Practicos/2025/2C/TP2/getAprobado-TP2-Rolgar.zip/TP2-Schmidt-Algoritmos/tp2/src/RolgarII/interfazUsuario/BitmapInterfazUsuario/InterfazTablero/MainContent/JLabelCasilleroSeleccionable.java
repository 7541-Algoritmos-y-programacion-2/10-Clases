package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;

import RolgarII.casillero.CasilleroDeRolgar;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**Representa un casillero que se puede seleccionar, se muestran las coordenadas
 * y se solicita que funcion se debe ejecutar al momento de hacerle click*/
public class JLabelCasilleroSeleccionable extends JLabelCasillero{
    private Runnable onClick;

    public JLabelCasilleroSeleccionable(CasilleroDeRolgar casillero, Runnable onClick) {
        super(casillero);
        setText("("+casillero.getX() + "," + casillero.getY() + "," + casillero.getZ()+")");

        this.onClick = onClick;

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                onClick.run();
            }
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setHover();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                setCursor(Cursor.getDefaultCursor());
                setVisible();
            }
        });


    }



}
