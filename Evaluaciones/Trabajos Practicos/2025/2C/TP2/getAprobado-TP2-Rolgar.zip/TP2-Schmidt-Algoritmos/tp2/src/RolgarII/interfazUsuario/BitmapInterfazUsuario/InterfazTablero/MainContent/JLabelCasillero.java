package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent;

import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntityFactory;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.jugador.Jugador;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class JLabelCasillero extends JLabel {
    protected CasilleroDeRolgar casillero;
    protected BitmapJuegoColors color;
    protected JLabelCasilleroEstado estado;
    public JLabelCasillero(CasilleroDeRolgar casillero){
        super();
        ValidacionesUtiles.esDistintoDeNull(casillero,"Casillero");
        this.casillero = casillero;
        setOpaque(true);
        setVerticalAlignment(SwingConstants.CENTER);
        setHorizontalAlignment(SwingConstants.CENTER);
        setVerticalTextPosition(JLabel.BOTTOM);
        setHorizontalTextPosition(JLabel.CENTER);
        setForeground(Color.black);
        estado = JLabelCasilleroEstado.NORMAL;

    }
    public void setOculto(){
        estado = JLabelCasilleroEstado.OCULTO;
        renderBg();
    }
    public void setVisible(){
        estado = JLabelCasilleroEstado.NORMAL;
        renderBg();
    }
    public void setHover(){
        estado = JLabelCasilleroEstado.HOVER;
        renderBg();
    }
    public void setDestacado(){
        estado = JLabelCasilleroEstado.DESTACADO;
    }

    public void setColor(BitmapJuegoColors color){
        this.color = color;
        setBackground(color.getColor());
    }
    private boolean estaOculto(){
        return this.estado == JLabelCasilleroEstado.OCULTO;
    }
    private boolean esVisible(){
        return !estaOculto();
    }
    public void renderBg(){
        switch (estado){
            case NORMAL -> renderBgNormal();
            case OCULTO -> renderBgNotVisible();
            case HOVER -> renderBgHover();
            case DESTACADO -> renderBgDestacado();
        }
    }
    public void render(GameRenderContext context){

        if(esVisible() && casillero.getEntidad() instanceof JugadorDeRolgar jugador){
            setText(jugador.getNombre());
        }

        if(esVisible()){
            //Renderize el terreno que contiene
            var terreno = casillero.getTerreno();
            var terrenoViewEntity = ViewEntityFactory.crear(terreno);

            var spriteId = terrenoViewEntity.getSpriteId(context);
            var imageIcon = BitmapInterfazJuegoHelper.getImageIconFromSpriteId(spriteId);
            setIcon(imageIcon);

            //Renderize el icono de la entidad que contiene (si la contiene)
            var entidad = casillero.getEntidad();
            if(entidad != null){
                var entidadViewEntity = ViewEntityFactory.crear(entidad);
                var spriteEntidad = entidadViewEntity.getSpriteId(context);
                var imageIconEntidad = BitmapInterfazJuegoHelper.getImageIconFromSpriteId(spriteEntidad);
                setIcon(imageIconEntidad);
                //Si el tablero conteine a el jugador del turno actual,
                //se marca el tablero comom destacado
                if(entidad instanceof JugadorDeRolgar jugador && context.esJugadorDelTurnoActual(jugador)){
                    setDestacado();
                }
            }



            renderBg();
        }

    }

    private void renderBgHover(){
        setBackground(this.color.lighter().getColor());
    }
    private void renderBgNormal(){
        setBackground(this.color.getColor());
    }
    private void renderBgNotVisible(){
        setBackground(this.color.darker().getColor());
    }
    private void renderBgDestacado(){
        renderBgNormal();
        setBorder(BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),4));
    }
    public enum JLabelCasilleroEstado{
        NORMAL,OCULTO,HOVER,DESTACADO
    }
}
