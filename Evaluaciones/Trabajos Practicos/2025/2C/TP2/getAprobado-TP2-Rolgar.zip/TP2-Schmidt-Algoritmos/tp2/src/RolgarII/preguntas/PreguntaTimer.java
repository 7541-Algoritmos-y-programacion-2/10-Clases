package RolgarII.preguntas;

import RolgarII.shared.teclado.Teclado;
import RolgarII.enemigo.Enemigo;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.jugador.Jugador;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PreguntaTimer {
    private Pregunta pregunta;
    private Random rand = new Random();
    private InterfazJuego interfazUsuario;

    public  PreguntaTimer(String path,InterfazJuego interfazUsuario) {
        this.interfazUsuario = interfazUsuario;
        ValidacionesUtiles.esDistintoDeNull(path, "Path");
        pregunta=new Pregunta(path);
    }



    /**
     Recibe dos jugadores y desempata por acierto o por el tiempo mas bajo
     */
    public Desempate pelea(JugadorDeRolgar jugador1, JugadorDeRolgar jugador2,InterfazJuego interfazUsuario) {
        ValidacionesUtiles.esDistintoDeNull(jugador1, "Jugador1");
        ValidacionesUtiles.esDistintoDeNull(jugador2, "Jugador2");

        Respuesta respuesta1 = hacerPregunta(jugador1);
        Respuesta respuesta2 = hacerPregunta(jugador2);

        if(respuesta1.respuesta()&&!respuesta2.respuesta()){
            return new Desempate(jugador1, true,respuesta1.tiempo,
                                 jugador2, false, respuesta2.tiempo);
        }
        if(respuesta2.respuesta()&&!respuesta1.respuesta()){
            return new Desempate(jugador2, true, respuesta2.tiempo(),
                                 jugador1, false, respuesta1.tiempo());
        }
        if(respuesta1.tiempo()<respuesta2.tiempo()){
            return new Desempate(jugador1,respuesta1.respuesta, respuesta1.tiempo(),
                                 jugador2,respuesta2.respuesta, respuesta2.tiempo());
        }
        if(respuesta2.tiempo()<respuesta1.tiempo()){
            return new Desempate(jugador2,respuesta2.respuesta, respuesta2.tiempo(),
                                 jugador1,respuesta1.respuesta, respuesta1.tiempo());
        }

        return new Desempate(jugador1,false,0,
                             jugador2,false,0);
    }

    private record Respuesta(boolean respuesta, long tiempo){}

    public record Desempate(JugadorDeRolgar ganador,boolean respuestaGanador,long tiempoGanador,
                            JugadorDeRolgar perdedor,boolean respuestaPerdedor, long tiempoPerdedor){}


    /**
    Realiza la pregunta al jugador, evalua si acerto y toma el tiempo de respuesta
     */
    private Respuesta hacerPregunta(Jugador jugador1) {

        long inicio = System.currentTimeMillis();

        String respuestaDesdeElUsuario = interfazUsuario.hacerPregunta(pregunta);

        long fin = System.currentTimeMillis();

        Respuesta respuesta = new Respuesta(
                pregunta.verificaRespuestaCorrecta(respuestaDesdeElUsuario),
                fin - inicio
        );

        pregunta.generarPregunta();
        return respuesta;
    }

    private void imprimirPregunta(String pregunta, List<String> opciones){
        System.out.println(pregunta+"\n1-"+opciones.get(0)+"\n2-"+opciones.get(1)+"\n3-"+opciones.get(2)+"\n4-"+opciones.get(3));
    }

}
