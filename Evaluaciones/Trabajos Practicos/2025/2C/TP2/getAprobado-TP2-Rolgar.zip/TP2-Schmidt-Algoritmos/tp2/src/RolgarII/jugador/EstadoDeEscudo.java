package RolgarII.jugador;

public enum EstadoDeEscudo {
    ACTIVO, DESACTIVADO
}
