package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;

public class ItemEstadistica extends JPanel {
    JLabel labelValor;

    public ItemEstadistica(
            String titulo,
            String valor
    ) {

        setOpaque(true);
        setBackground(BitmapJuegoColors.CARD_BG.getColor());
        setLayout(new BoxLayout(this,BoxLayout.X_AXIS));
        setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(),2,true),
                        BorderFactory.createEmptyBorder(10,10,10,10)
                )
        );


        var labelTitulo = new JLabelTitulo(titulo,18,BitmapJuegoColors.TEXT_FOREGROUND.getColor());

        labelValor = new JLabelTitulo(valor,20,BitmapJuegoColors.TEXT_FOREGROUND.getColor());

        add(labelTitulo);
        add(Box.createHorizontalGlue());
        add(labelValor);
    }

    public void setValor(String valor){
        labelValor.setText(valor);
    }

}
