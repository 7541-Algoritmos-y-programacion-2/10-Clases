package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugada;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.juego.jugada.TipoDeJugada;

import javax.swing.*;

public class DialogOpcionesSeleccionarJugada extends DialogOpciones<TipoDeJugada> {

    public DialogOpcionesSeleccionarJugada(JFrame owner){
        super(owner,"Seleccione una jugada","Jugadas disponibles","Seleccione una jugada:");

        var jugadaOpciones = JugadaFormatter.jugadasComoOpciones();
        setOpciones(jugadaOpciones);




    }




}
