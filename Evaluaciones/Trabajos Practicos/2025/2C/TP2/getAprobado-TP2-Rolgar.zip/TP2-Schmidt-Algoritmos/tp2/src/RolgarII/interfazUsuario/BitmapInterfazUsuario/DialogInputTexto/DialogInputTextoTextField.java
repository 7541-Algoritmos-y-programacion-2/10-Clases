package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import java.awt.*;

public class DialogInputTextoTextField extends JTextField {

    public DialogInputTextoTextField(){
        super();
        setPreferredSize(new Dimension(250, 40));
        setFont(new Font("Arial", Font.PLAIN, 16));
        setBackground(Color.DARK_GRAY);
        setForeground(Color.WHITE);
        setCaretColor(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 1),
                BitmapInterfazJuegoHelper.paddingBorder(5)
        ));

        addAncestorListener(new AncestorListener() {
            public void ancestorAdded(AncestorEvent evt) {
                selectAll();
                requestFocusInWindow();
            }
            public void ancestorRemoved(AncestorEvent evt) {}
            public void ancestorMoved(AncestorEvent evt) {}
        });
    }
}
