package RolgarII.jugador;

import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class Jugador {

    private final String nombre;
    /**
     * pre: 'nombre' debe ser distinto de null y no debe ser vacío ni solo espacios.
     * post: Crea un jugador con el nombre especificado.
     * @param nombre nombre del jugador.
     * @throws RuntimeException si el nombre es inválido.
     */
    public Jugador(String nombre) {
        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
        ValidacionesUtiles.validarVerdadero(!nombre.isBlank(), "nombre");
        this.nombre = nombre;
    }

    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------

    /**
     * post: Devuelve un código hash basado en el nombre del jugador.
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
        return result;
    }

    /**
     * pre: 'obj' puede ser cualquier objeto.
     * post: Devuelve true si 'obj' es un Jugador con el mismo nombre.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Jugador other = (Jugador) obj;
        if (nombre == null) {
            if (other.nombre != null)
                return false;
        } else if (!nombre.equals(other.nombre))
            return false;
        return true;
    }

    /**
     * post: Devuelve una representación en texto del jugador.
     */
    @Override
    public String toString() {
        return "Jugador [nombre=" + nombre + "]";
    }


    /**
     * post: Devuelve el nombre del jugador.
     */
    public String getNombre() {
        return nombre;
    }

}
