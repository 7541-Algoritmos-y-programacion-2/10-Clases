package RolgarII.config;

public class ParametrosJuegoConfig {

    private double vidaMaximaJugador;
    private int maxCartasPorJugador;
    private double curacionPorMovimiento;
    private int minDado;
    private int maxDado;

    /**
     * post: Crea una configuración vacía de los parámetros generales del juego.
     */
    public ParametrosJuegoConfig() {
    }

    /**
     * post: Devuelve la vida máxima permitida para un jugador.
     */
    public double getVidaMaximaJugador() {
        return vidaMaximaJugador;
    }

    /**
     * pre: vidaMaximaJugador debe ser mayor a 0.
     * post: Establece la vida máxima que puede tener un jugador.
     */
    public void setVidaMaximaJugador(double vidaMaximaJugador) {
        this.vidaMaximaJugador = vidaMaximaJugador;
    }

    /**
     * post: Devuelve la cantidad máxima de cartas que un jugador puede tener.
     */
    public int getMaxCartasPorJugador() {
        return maxCartasPorJugador;
    }

    /**
     * pre: maxCartasPorJugador debe ser mayor o igual a 1.
     * post: Establece el límite de cartas en el inventario de cada jugador.
     */
    public void setMaxCartasPorJugador(int maxCartasPorJugador) {
        this.maxCartasPorJugador = maxCartasPorJugador;
    }

    /**
     * post: Devuelve la cantidad de vida que se cura con cada movimiento.
     */
    public double getCuracionPorMovimiento() {
        return curacionPorMovimiento;
    }

    /**
     * pre: curacionPorMovimiento debe ser mayor o igual a 0.
     * post: Establece la vida que recupera un jugador al moverse.
     */
    public void setCuracionPorMovimiento(double curacionPorMovimiento) {
        this.curacionPorMovimiento = curacionPorMovimiento;
    }

    /**
     * post: Devuelve el valor mínimo que puede resultar en el lanzamiento de un dado.
     */
    public int getMinDado() {
        return minDado;
    }

    /**
     * pre: minDado debe ser mayor o igual a 1.
     * post: Establece el valor mínimo del dado.
     */
    public void setMinDado(int minDado) {
        this.minDado = minDado;
    }

    /**
     * post: Devuelve el valor máximo que puede resultar en el lanzamiento de un dado.
     */
    public int getMaxDado() {
        return maxDado;
    }

    /**
     * pre: maxDado debe ser mayor o igual a minDado.
     * post: Establece el valor máximo del dado.
     */
    public void setMaxDado(int maxDado) {
        this.maxDado = maxDado;
    }
}





