package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarDireccion;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.juego.jugada.jugadaMover.JugadaMoverDireccion;

import javax.swing.*;

public class DialogSeleccionarDireccion extends DialogOpciones<JugadaMoverDireccion> {

    public DialogSeleccionarDireccion(JFrame owner){
        super(owner,"Seleccione una direccion","Direcciones disponibles","Seleccione una direccion");

        var opciones = DialogOpcionDireccion.direccionesComoOpciones();
        setOpciones(opciones);
    }

}
