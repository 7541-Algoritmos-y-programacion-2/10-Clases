package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que incrementa temporalmente
 *       la visibilidad del jugador que la utiliza.
 */
public class CartaVisibilidad extends Carta {

    /** Duración del efecto de visibilidad aumentada (en turnos). */
    private static final int TURNOS_VISIBILIDAD = 2;

    /**
     * post: Crea una carta de visibilidad.
     */
    public CartaVisibilidad() {
        super("Carta de visibilidad");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Aumenta la visibilidad del jugador al máximo permitido por el juego.
     *       Registra un efecto temporal que, tras finalizar los turnos indicados,
     *       restaura la visibilidad a su estado normal mediante
     *       jugador::removerEfectosEnVisibilidad.
     *       Devuelve true siempre que el efecto se haya aplicado correctamente.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {

        jugador.ampliarVisibilidadAMaxima();

        juego.registrarEfectoTemporal(
                TURNOS_VISIBILIDAD,
                jugador::removerEfectosEnVisibilidad
        );

        return true;
    }
}

