package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones;

import RolgarII.carta.Carta;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.turno.Turno;
import RolgarII.shared.clases.SpriteId;

public class CartaViewEntity extends ViewEntity<Carta> {


    public CartaViewEntity(Carta entity) {
        super(entity);
    }

    @Override
    public SpriteId getSpriteId(GameRenderContext context) {
        return SpriteId.CARTA;
    }
}
