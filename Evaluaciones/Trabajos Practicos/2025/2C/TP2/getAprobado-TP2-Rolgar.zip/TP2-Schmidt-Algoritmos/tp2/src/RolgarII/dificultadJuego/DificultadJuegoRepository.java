package RolgarII.dificultadJuego;

public interface DificultadJuegoRepository {

    DificultadJuego[] getAll();



}
