//package tp2.jugador;
//
//import tp2.juego.ElementoDeRolgar;
//import RolgarII.shared.clases.SpriteId;
//import RolgarII.shared.interfaces.Renderizable;
//import tp2.validacionesUtiles.ValidacionesUtiles;
//
//public class Jugador implements Renderizable, ElementoDeRolgar {
//    //INTERFACES ----------------------------------------------------------------------------------------------
//    //ENUMERADOS ----------------------------------------------------------------------------------------------
//    //CONSTANTES ----------------------------------------------------------------------------------------------
//    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//    //ATRIBUTOS -----------------------------------------------------------------------------------------------
//
//    private final String nombre;
//    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//    //CONSTRUCTORES -------------------------------------------------------------------------------------------
//
//    /**
//     * post: Inicializa el jugador con el nombre dado.
//     * pre: El nombre dado debe ser no nulo y no vacío.
//     * @param nombre: el nombre del jugador.
//     */
//    public Jugador(String nombre) {
//        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
//        ValidacionesUtiles.validarVerdadero(!nombre.isBlank(), "nombre");
//        this.nombre = nombre;
//    }
//
//    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//    //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//    //METODOS DE CLASE ----------------------------------------------------------------------------------------
//    //METODOS GENERALES ---------------------------------------------------------------------------------------
//
//    @Override
//    public int hashCode() {
//        final int prime = 31;
//        int result = 1;
//        result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
//        return result;
//    }
//
//
//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj)
//            return true;
//        if (obj == null)
//            return false;
//        if (getClass() != obj.getClass())
//            return false;
//        Jugador other = (Jugador) obj;
//        if (nombre == null) {
//            if (other.nombre != null)
//                return false;
//        } else if (!nombre.equals(other.nombre))
//            return false;
//        return true;
//    }
//
//    @Override
//    public String toString() {
//        return "Jugador [nombre=" + nombre + "]";
//    }
//
//    //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//    //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
//    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//    //GETTERS SIMPLES -----------------------------------------------------------------------------------------
//
//    /**
//     * post: Devuelve el nombre del jugador.
//     * @return el nombre del jugador.
//     */
//    public String getNombre() {
//        return nombre;
//    }
//
//    //SETTERS COMPLEJOS----------------------------------------------------------------------------------------
//    //SETTERS SIMPLES -----------------------------------------------------------------------------------------
//
//
//    @Override
//    public SpriteId getSpriteId() {
//        return SpriteId.JUGADOR;
//    }
//
//}
