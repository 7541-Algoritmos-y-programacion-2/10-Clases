package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que otorga invisibilidad temporal al jugador que la utiliza.
 *       Mientras está activo, el jugador no puede ser detectado o atacado según la lógica de juego.
 */
public class CartaInvisibilidad extends Carta {

    /** Cantidad de turnos que dura la invisibilidad. */
    private final int TURNOS_INVISIBILIDAD = 3;

    /**
     * post: Crea una carta de invisibilidad con su nombre correspondiente.
     */
    public CartaInvisibilidad() {
        super("Carta de invisibilidad");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Activa la invisibilidad en el jugador por TURNOS_INVISIBILIDAD turnos.
     *       Registra un efecto temporal en el juego para desactivar la invisibilidad automáticamente
     *       una vez transcurridos los turnos configurados. Devuelve true indicando que la carta fue
     *       utilizada y consumida exitosamente.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {
        jugador.activarInvisibilidad();

        juego.registrarEfectoTemporal(
                this.TURNOS_INVISIBILIDAD,
                jugador::desactivarInvisibilidad
        );

        return true;
    }
}

