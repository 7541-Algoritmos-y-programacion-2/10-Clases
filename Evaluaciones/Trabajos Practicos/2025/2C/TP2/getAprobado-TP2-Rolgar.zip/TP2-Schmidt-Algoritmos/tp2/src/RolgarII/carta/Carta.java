package RolgarII.carta;

import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public abstract class Carta implements ElementoDeRolgar{
    protected String nombre;

    /**
     * post: Inicializa la carta con el nombre dado.
     * pre: El nombre debe ser no nulo y debe tener al menos 2 caracteres como mńimo y 20 como máximo.
     * @param nombre: el nombre de la carta.
     */
    public Carta(String nombre) {
        setNombre(nombre);
    }

    
    /** 
     * post: Efecto a  implementar, una vez utilizada la carta. Una vez utilizada la carta se removerá del inventario 
     * del jugador.
     * pre : 'jugador' es el Jugador que utiliza la carta, debe ser no nulo.
     *       'juego' debe ser no nulo.
     */
    public abstract boolean usar(JugadorDeRolgar jugador, Juego juego);
    
    /**
     * post: Devuelve el nombre de la carta.
     * @return el nombre de la carta.
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * post: Setea el nombre de la carta. 
     * pre: El nombre debe ser no nulo y debe tener al menos 2 caracteres como mńimo y 20 como máximo.
     * @param nombre: el nombre de la carta.
     */
    protected void setNombre(String nombre){
        ValidacionesUtiles.validarNull(nombre, "nombre");
        ValidacionesUtiles.validarLongitudDeTexto(nombre, 2, 100, "nombre");
        this.nombre = nombre;
    }

}