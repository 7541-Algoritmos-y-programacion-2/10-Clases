//package tp2.juego;
//
//import tp2.carta.Carta;
//import tp2.casillero.Casillero3D;
//import tp2.interfazUsuario.InterfazJuego;
//import tp2.jugador.JugadorDeRolgar;
//import tp2.shared.estructuras.ListaSimplementeEnlazada;
//import tp2.tablero.Tablero3D;
//import tp2.validacionesUtiles.ValidacionesUtiles;
//
//import java.util.*;
//
//public class Juego {
//    // ENUMERADOS ----------------------------------------------------------------------------------------------
//    // ATRIBUTOS -----------------------------------------------------------------------------------------------
//    private Tablero3D<ElementoDeRolgar> tablero;
//    private final List<JugadorDeRolgar> jugadores;
//    private InterfazJuego interfazUsuario;
//    private final ListaSimplementeEnlazada<EfectoTemporal> efectosTemporales = new ListaSimplementeEnlazada<>();
//    private final ListaSimplementeEnlazada<Alianza> alianzas = new ListaSimplementeEnlazada<>();
//    private int indiceTurnoActual = 0;
//    private boolean juegoEnCurso = false;
//    private final Random rnd = new Random();
//
//    // Configuración por defecto
//    private double curacionPorMovimiento = 1.0;
//    private final int MIN_DADOS = 1;
//    private final int MAX_DADOS = 6;
//
//    // CONSTRUCTORES -------------------------------------------------------------------------------------------
//    /**
//     * post: Inicializa el juego con jugadores, tablero e interfaz.
//     *
//     * @param jugadores: lista no nula de jugadores (al menos 1)
//     * @param tablero: el tablero 3D del juego
//     * @param interfaz: la implementación de InterfazJuego
//     */
//    public Juego(List<JugadorDeRolgar> jugadores, Tablero3D<ElementoDeRolgar> tablero, InterfazJuego interfaz) {
//        ValidacionesUtiles.esDistintoDeNull(jugadores, "jugadores");
//        ValidacionesUtiles.esDistintoDeNull(tablero, "tablero");
//        ValidacionesUtiles.esDistintoDeNull(interfaz, "interfazUsuario");
//        if (jugadores.isEmpty()) throw new RuntimeException("Debe haber al menos un jugador.");
//        this.jugadores = new ArrayList<>(jugadores); // TODO: Implementar el constructor necesario en ListaSimplementeEnlazada
//        this.tablero = tablero;
//        this.interfazUsuario = interfaz;
//    }
//
//    // METODOS EXPONIENDO PARCIALMENTE LA UI ------------------------------------------------------------------
//
//    public void mostrarMensaje(String mensaje) {
//        interfazUsuario.mostrarMensaje(mensaje);
//    }
//
//    public JugadorDeRolgar seleccionarJugador() {
//        return interfazUsuario.seleccionarJugador(jugadores.toArray(new JugadorDeRolgar[0]));
//    }
//
//    public Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador) {
//        return interfazUsuario.seleccionarCartaDeJugador(jugador);
//    }
//
//    public Casillero3D<ElementoDeRolgar> seleccionarCeldaLibre() {
//        return interfazUsuario.seleccionarCeldaLibre(tablero);
//    }
//
//    public void renderizarTablero(JugadorDeRolgar jugadorActual) {
//        interfazUsuario.renderizarTablero(tablero, jugadorActual);
//    }
//
//    // METODOS GENERALES ---------------------------------------------------------------------------------------
//
//    /**
//     * post: Registra un efecto temporal que ejecutará 'alExpirar' cuando expire.
//     */
//    public void registrarEfectoTemporal(int turnos, Runnable alExpirar) {
//        ValidacionesUtiles.validarMayorACero(turnos, "turnos");
//        ValidacionesUtiles.esDistintoDeNull(alExpirar, "onExpirar");
//        efectosTemporales.add(new EfectoTemporal(turnos, alExpirar));
//    }
//
//    /**
//     * post: Inicia el loop principal del juego. La interfaz debe encargarse de las entradas
//     * (tirada de dado, selecciones).
//     */
//    public void iniciarJuego() {
//        this.juegoEnCurso = true;
//        interfazUsuario.mostrarMensaje("¡Bienvenido a Rolgar II!");
//        interfazUsuario.mostrarMensaje("El juego ha comenzado.");
//
//        while (juegoEnCurso) {
//            JugadorDeRolgar actual = jugadores.get(indiceTurnoActual);
//
//            if (!actual.estaVivo()) {
//                pasarTurno();
//                continue;
//            }
//
//            int movimientos = this.solicitarTiroDado(actual);
//            this.ejecutarTurno(actual, movimientos);
//
//            this.procesarEfectosTemporales();
//            this.procesarAlianzas();
//            actual.recuperarSaludPorTurno();
//            this.verificarFinDeJuego();
//            pasarTurno();
//        }
//
//        interfazUsuario.mostrarMensaje("El juego ha terminado.");
//    }
//
//    // MÉTODOS DE COMPORTAMIENTO ------------------------------------------------------------------------------
//
//    /**
//     * post: Mueve al jugador al casillero destino validando reglas.
//     * Si destino ocupado por jugador, se maneja combate o la alianza.
//     */
//    public boolean moverJugadorConDestino(JugadorDeRolgar jugador, Casillero3D<ElementoDeRolgar> destino) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//        ValidacionesUtiles.esDistintoDeNull(destino, "destino");
//
//        if (!esTransitable(destino, jugador)) {
//            interfazUsuario.mostrarMensaje("No se puede transitar ese casillero (Roca o Agua sin Rampa).");
//            return false;
//        }
//
//        ElementoDeRolgar contenido = destino.getValor();
//        if (contenido instanceof JugadorDeRolgar otro) {
//            if (sonAliados(jugador, otro)) {
//                interfazUsuario.mostrarMensaje("Destino ocupado por aliado " + otro.getNombre() + ". No puedes moverte allí.");
//                return false;
//            }
//
//            interfazUsuario.mostrarMensaje("Destino ocupado por " + otro.getNombre() + ". 1-Atacar | 2-Proponer alianza | 3-Cancelar");
//            int opcion = interfazUsuario.obtenerOpcionNumerica("Ingrese opción (1-3): ");
//
//            if (opcion == 1) {
//                realizarCombateAlMover(jugador, otro, destino);
//                return true;
//            } else if (opcion == 2) {
//                int turnos = interfazUsuario.obtenerOpcionNumerica("Ingrese turnos para alianza (>0): ");
//                if (turnos > 0) {
//                    interfazUsuario.mostrarMensaje("Proponiendo alianza...");
//                    proponerAlianza(jugador, otro, turnos);
//                } else {
//                    interfazUsuario.mostrarMensaje("Propuesta cancelada.");
//                }
//                return false;
//            } else {
//                interfazUsuario.mostrarMensaje("Acción cancelada.");
//                return false;
//            }
//        }
//
//        if (contenido instanceof Carta cartaEncontrada) {
//            jugador.agregarCartaAlInventario(cartaEncontrada);
//            destino.vaciar();
//            interfazUsuario.mostrarMensaje(jugador.getNombre() + " recogió una carta: " + cartaEncontrada.getNombre());
//        }
//
//        else if (contenido != null) {
//            destino.vaciar();
//        }
//
//        Casillero3D<ElementoDeRolgar> origen = null;
//        try {
//            origen = tablero.getCasillero(jugador.getPosX(), jugador.getPosY(), jugador.getPosZ());
//        } catch (Exception e) {
//        }
//        if (origen != null && origen.getValor() == jugador) origen.vaciar();
//
//        destino.ocupar(jugador);
//        jugador.setPosicion(destino.getX(), destino.getY(), destino.getZ());
//        interfazUsuario.mostrarMensaje(jugador.getNombre() + " se movió a (" + destino.getX() + "," + destino.getY() + "," + destino.getZ() + ")");
//        return true;
//    }
//
//    /**
//     * post: Proponer alianza: La UI debe gestionar la aceptación.
//     */
//    public void proponerAlianza(JugadorDeRolgar jugadorQuePropone, JugadorDeRolgar destinatario, int turnos) {
//        ValidacionesUtiles.esDistintoDeNull(jugadorQuePropone, "proponente");
//        ValidacionesUtiles.esDistintoDeNull(destinatario, "destinatario");
//        ValidacionesUtiles.validarMayorACero(turnos, "turnos");
//
//        if (sonAliados(jugadorQuePropone, destinatario)) {
//            interfazUsuario.mostrarMensaje("Ya son aliados.");
//            return;
//        }
//
//        String prompt = destinatario.getNombre() + ", aceptás la alianza con " + jugadorQuePropone.getNombre() + "?";
//        boolean acepto = interfazUsuario.obtenerConfirmacion(prompt);
//
//        if (acepto) {
//            crearAlianza(jugadorQuePropone, destinatario, turnos);
//            interfazUsuario.mostrarMensaje("Alianza formada por " + turnos + " turnos entre " + jugadorQuePropone.getNombre() + " y " + destinatario.getNombre());
//        } else {
//            interfazUsuario.mostrarMensaje("Propuesta rechazada.");
//        }
//    }
//
//    public void crearAlianza(JugadorDeRolgar a, JugadorDeRolgar b, int turnos) {
//        ValidacionesUtiles.esDistintoDeNull(a, "jugador A");
//        ValidacionesUtiles.esDistintoDeNull(b, "jugador B");
//        if (sonAliados(a, b)) {
//            interfazUsuario.mostrarMensaje("Ya son aliados.");
//            return;
//        }
//        alianzas.add(new Alianza(a, b, turnos));
//    }
//
//    public boolean sonAliados(JugadorDeRolgar a, JugadorDeRolgar b) {
//        for (Alianza al : alianzas) if (al.sonAliados(a, b)) return true;
//        return false;
//    }
//
//    /**
//     * post: Intercambio iniciado por 'iniciador'. La UI selecciona el aliado destino
//     * y luego se delega al método que realiza el intercambio real.
//     */
//    private boolean intercambioEntreAliadosViaInterfaz(JugadorDeRolgar iniciador) {
//        ValidacionesUtiles.esDistintoDeNull(iniciador, "iniciador");
//        JugadorDeRolgar candidato = seleccionarAliadoPara(iniciador);
//        if (candidato == null) return false;
//        return intercambioEntreAliadosViaInterfaz(iniciador, candidato);
//    }
//
//    /**
//     * post: Intercambia una carta entre dos jugadores aliados.
//     */
//    public boolean intercambiarCartaEntreAliados(JugadorDeRolgar origen, JugadorDeRolgar destino, Carta carta) {
//        ValidacionesUtiles.esDistintoDeNull(origen, "origen");
//        ValidacionesUtiles.esDistintoDeNull(destino, "destino");
//        ValidacionesUtiles.esDistintoDeNull(carta, "carta");
//
//        if (!sonAliados(origen, destino)) {
//            interfazUsuario.mostrarMensaje("No son aliados: intercambio denegado.");
//            return false;
//        }
//        if (!origen.existeLaCarta(carta)) {
//            interfazUsuario.mostrarMensaje("El origen no posee la carta solicitada.");
//            return false;
//        }
//        if (!destino.tieneEspacioEnInventario()) {
//            interfazUsuario.mostrarMensaje("El destino no tiene espacio en el inventario.");
//            return false;
//        }
//
//        origen.removerCarta(carta);
//        destino.agregarCartaAlInventario(carta);
//        interfazUsuario.mostrarMensaje("Intercambio realizado: " + origen.getNombre() + " -> " + destino.getNombre() + " : " + carta.getNombre());
//        return true;
//    }
//
//    // CARGA DE MAPA ----------------------------------------
//
//    /**
//     * post: Carga/Construye el tablero a partir de un objeto de configuración.
//     *
//     * Nota: la cátedra te exige que la construcción del mapa venga desde JSON. Aquí dejamos un punto de entrada
//     * (API) para que conectes tu lector JSON → DTOs → este método.
//     *
//     * PRE/CONVENTIÓN esperada (ejemplo):
//     * - 'configuracion' debería ser una instancia de tu DTO (por ejemplo ConfiguracionDeJuego)
//     * - esa DTO contiene: ancho, alto, profundo, y listas de elementos a colocar (terreno, jugadores, cartas, enemigos)
//     *
//     * Implementación sugerida (pseudocódigo):
//     * ConfiguracionDeJuego cfg = (ConfiguracionDeJuego) configuracion;
//     * this.tablero = new Tablero3D<>(cfg.getAncho(), cfg.getAlto(), cfg.getProfundo());
//     * // recorrer cfg y setear tablero.getCasillero(x,y,z).ocupar(...) o setValor(...)
//     *
//     * Aquí no se manipula librería JSON: tu clase lectora (por ejemplo CargadorDeMapas) debe parsear JSON
//     * y llamar a este método con la DTO resultante.
//     */
//    public void cargarMapaDesdeConfiguracion(Object configuracion) {
//        // En este punto no imponemos un tipo específico (para mantener flexibilidad con la cátedra).
//        // Implementación concreta: el equipo debe crear su DTO ConfiguracionDeJuego (en paquete correcto)
//        // y hacer el cast aquí:
//        //
//        //   ConfiguracionDeJuego cfg = (ConfiguracionDeJuego) configuracion;
//        //   this.tablero = new Tablero3D<>(cfg.getAncho(), cfg.getAlto(), cfg.getProfundo());
//        //   // luego recorrer cfg para colocar TipoDeTerreno / Cartas / Jugadores / Enemigos en casilleros.
//        //
//        // Ejemplo mínimo de validaciones (si el objeto es nulo, abortamos):
//        ValidacionesUtiles.esDistintoDeNull(configuracion, "configuracion");
//        // Si querés, lanzamos excepción para forzar uso de DTO concreto (descomentar):
//        // throw new UnsupportedOperationException("Implementar carga desde DTO ConfiguracionDeJuego. Pasa aquí la instancia DTO parseada desde JSON.");
//        //
//        // Nota: la implementación concreta depende de la estructura del DTO que uses.
//    }
//
//    /**
//     * post: Coloca N jugadores en casilleros vacíos al azar.
//     * @throws RuntimeException si no hay suficientes casillas libres.
//     */
//    public void colocarJugadoresAleatorios(long seed) {
//        List<int[]> posicionesLibres = new ArrayList<>();
//        for (int x = 1; x <= tablero.getAncho(); x++) {
//            for (int y = 1; y <= tablero.getAlto(); y++) {
//                for (int z = 1; z <= tablero.getProfundo(); z++) {
//                    Casillero3D<ElementoDeRolgar> c = tablero.getCasillero(x, y, z);
//                    if (c.getValor() == null || (c.getValor() instanceof TipoDeTerreno && c.getValor() == TipoDeTerreno.VACIO)) {
//                        posicionesLibres.add(new int[]{x, y, z});
//                    }
//                }
//            }
//        }
//
//        if (posicionesLibres.size() < jugadores.size()) {
//            throw new RuntimeException("No hay suficientes casillas libres para colocar jugadores.");
//        }
//        Random random = (seed == 0) ? rnd : new Random(seed);
//        Collections.shuffle(posicionesLibres, random);
//        int i = 0;
//        for (JugadorDeRolgar jugador : jugadores) {
//            int[] pos = posicionesLibres.get(i++);
//            Casillero3D<ElementoDeRolgar> casillero = tablero.getCasillero(pos[0], pos[1], pos[2]);
//            casillero.ocupar(jugador);
//            jugador.setPosicion(pos[0], pos[1], pos[2]);
//            interfazUsuario.mostrarMensaje(jugador.getNombre() + " comienza en (" + pos[0] + "," + pos[1] + "," + pos[2] + ")");
//        }
//    }
//
//    /**
//     * post: Coloca una lista de cartas aleatoriamente en casilleros vacíos del tablero.
//     */
//    public void colocarCartasAleatorias(List<Carta> cartas, int maxIntentos) {
//        ValidacionesUtiles.esDistintoDeNull(cartas, "cartas");
//        int intentos = 0;
//        int colocadas = 0;
//        for (Carta carta : cartas) {
//            boolean colocado = false;
//            while (!colocado && intentos < maxIntentos) {
//                int x = rnd.nextInt(tablero.getAncho()) + 1;
//                int y = rnd.nextInt(tablero.getAlto()) + 1;
//                int z = rnd.nextInt(tablero.getProfundo()) + 1;
//                Casillero3D<ElementoDeRolgar> casillero = tablero.getCasillero(x, y, z);
//                if (casillero.getValor() == null || (casillero.getValor() instanceof TipoDeTerreno && casillero.getValor() == TipoDeTerreno.VACIO)) {
//                    casillero.ocupar(carta);
//                    colocado = true;
//                    colocadas++;
//                }
//                intentos++;
//            }
//        }
//        interfazUsuario.mostrarMensaje("Se colocaron " + colocadas + " cartas en el tablero.");
//    }
//
//    /**
//     * post: Devuelve true si el casillero es transitable por el jugador.
//     * Ahora considera los nuevos tipos de terreno.
//     */
//    public boolean esTransitable(Casillero3D<ElementoDeRolgar> casillero, JugadorDeRolgar jugador) {
//        if (casillero == null) return false;
//        ElementoDeRolgar val = casillero.getValor();
//        if (val == null) return true;
//        if (val instanceof TipoDeTerreno) {
//            TipoDeTerreno t = (TipoDeTerreno) val;
//            return t.esTransitable();
//        }
//        if (val instanceof JugadorDeRolgar) return false;
//        if (val instanceof Carta) return true;
//        return true;
//    }
//
//    public boolean esTransitable(Casillero3D<ElementoDeRolgar> casillero) {
//        return esTransitable(casillero, null);
//    }
//
//    /**
//     * post: Retorna un jugador (distinto del pasado por parametro) que tenga cartas; UI puede seleccionar
//     * entre los candidatos. Si no hay candidatos retorna null.
//     */
//    public JugadorDeRolgar seleccionarJugadorConCartas(JugadorDeRolgar excluido) {
//        List<JugadorDeRolgar> candidatos = new ArrayList<>();
//        for (JugadorDeRolgar jugador : jugadores) {
//            if (!jugador.equals(excluido) && jugador.tieneCartas() && jugador.estaVivo()) candidatos.add(jugador);
//        }
//        if (candidatos.isEmpty()) {
//            interfazUsuario.mostrarMensaje("No hay otros jugadores con cartas.");
//            return null;
//        }
//        interfazUsuario.mostrarMensaje("Seleccionar jugador al que robar:");
//        return interfazUsuario.seleccionarJugador(candidatos.toArray(new JugadorDeRolgar[0]));
//    }
//
//    /**
//     * post: Devuelve la lista de jugadores vivos.
//     */
//    public List<JugadorDeRolgar> getJugadoresVivos() {
//        List<JugadorDeRolgar> vivos = new ArrayList<>();
//        for (JugadorDeRolgar jugador : jugadores) if (jugador.estaVivo()) vivos.add(jugador);
//        return vivos;
//    }
//
//    // MÉTODOS PRIVADOS ---------------------------------------------------------------------------
//
//    /**
//     * post: Ejecuta acciones del jugador en su turno, con 'movimientosIniciales' a gastar.
//     */
//    private void ejecutarTurno(JugadorDeRolgar jugador, int movimientosIniciales) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//        int movimientos = Math.max(MIN_DADOS, Math.min(MAX_DADOS, movimientosIniciales));
//        if (jugador.tieneDobleMovimiento()) movimientos = movimientos * 2;
//
//        boolean turnoFinalizado = false;
//        while (movimientos > 0 && !turnoFinalizado) {
//            this.renderizarTablero(jugador);
//            int opcion = interfazUsuario.obtenerAccionDeTurno(jugador, movimientos);
//            switch (opcion) {
//                case 1 -> {
//                    boolean seMovio = intentarMoverJugadorConInteraccion(jugador);
//                    if (seMovio) {
//                        jugador.curar(curacionPorMovimiento);
//                        movimientos--;
//                    }
//
//                }
//                case 2 -> {
//                    atacar(jugador);
//                }
//                case 3 -> {
//                    usarCarta(jugador);
//                }
//                case 4 -> {
//                    intercambioEntreAliadosViaInterfaz(jugador);
//                }
//                case 5 -> turnoFinalizado = true;
//                default -> interfazUsuario.mostrarMensaje("Opción inválida.");
//            }
//
//            if (!jugador.estaVivo()) {
//                interfazUsuario.mostrarMensaje(jugador.getNombre() + " ha muerto. Turno terminado.");
//                break;
//            }
//        }
//        if (jugador.tieneDobleMovimiento()) jugador.desactivarDobleMovimiento();
//    }
//
//    /**
//     * post: Combate que ocurre cuando un atacante pisa la casilla ocupada por objetivo.
//     * Atacante ataca; si objetivo muere, atacante ocupa la casilla.
//     */
//    private void realizarCombateAlMover(JugadorDeRolgar atacante, JugadorDeRolgar objetivo, Casillero3D<ElementoDeRolgar> casilleroDestino) {
//        if (!atacante.puedeVerA(objetivo)) {
//            interfazUsuario.mostrarMensaje("No puedes atacar a ese objetivo (fuera de visión).");
//            return;
//        }
//
//        atacante.atacar(objetivo);
//        interfazUsuario.mostrarMensaje(atacante.getNombre() + " atacó a " + objetivo.getNombre() + ". Vida restante: " + objetivo.getVida());
//
//        if (!objetivo.estaVivo()) {
//            interfazUsuario.mostrarMensaje(objetivo.getNombre() + " eliminado.");
//            casilleroDestino.vaciar();
//        } else {
//            interfazUsuario.mostrarMensaje("El objetivo resistió el ataque.");
//        }
//    }
//
//    /**
//     * post: Atacar a un jugador seleccionado por la interfaz.
//     */
//    private void atacar(JugadorDeRolgar atacante) {
//        ValidacionesUtiles.esDistintoDeNull(atacante, "atacante");
//        interfazUsuario.mostrarMensaje("Seleccioná objetivo para atacar:");
//        JugadorDeRolgar objetivo = interfazUsuario.seleccionarJugador(jugadores.toArray(new JugadorDeRolgar[0]));
//        if (objetivo == null || objetivo.equals(atacante)) {
//            interfazUsuario.mostrarMensaje("Ataque cancelado.");
//            return;
//        }
//        if (sonAliados(atacante, objetivo)) {
//            interfazUsuario.mostrarMensaje("No puedes atacar a un aliado.");
//            return;
//        }
//
//        if (!atacante.puedeVerA(objetivo)) {
//            interfazUsuario.mostrarMensaje("Objetivo fuera de visión.");
//            return;
//        }
//
//        atacante.atacar(objetivo);
//        interfazUsuario.mostrarMensaje(atacante.getNombre() + " atacó a " + objetivo.getNombre() + ". Vida restante: " + objetivo.getVida());
//
//        if (!objetivo.estaVivo()) {
//            interfazUsuario.mostrarMensaje(objetivo.getNombre() + " ha muerto.");
//            Casillero3D<ElementoDeRolgar> cas = tablero.getCasillero(objetivo.getPosX(), objetivo.getPosY(), objetivo.getPosZ());
//            if (cas != null && cas.getValor() == objetivo) cas.vaciar();
//        }
//    }
//
//    /*
//     * post: Intenta mover al jugador usando controles de teclado.
//     * Retorna true si efectivamente se movió y consumió movimiento.
//     */
//    private boolean intentarMoverJugadorConInteraccion(JugadorDeRolgar jugador) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//
//        interfazUsuario.mostrarMensaje("Usando sistema de movimiento por teclado...");
//        int[] nuevasCoordenadas = interfazUsuario.obtenerMovimientoPorTeclado(jugador, tablero);
//
//        if (nuevasCoordenadas == null) {
//            interfazUsuario.mostrarMensaje("Movimiento cancelado.");
//            return false;
//        }
//
//        int nuevaX = nuevasCoordenadas[0];
//        int nuevaY = nuevasCoordenadas[1];
//        int nuevaZ = nuevasCoordenadas[2];
//
//        Casillero3D<ElementoDeRolgar> destino = tablero.getCasillero(nuevaX, nuevaY, nuevaZ);
//        return this.moverJugadorConDestino(jugador, destino);
//}
//
//    // private boolean esMovimientoValido(JugadorDeRolgar jugador, int xDestino, int yDestino, int zDestino) {
//    //     int dx = Math.abs(xDestino - jugador.getPosX());
//    //     int dy = Math.abs(yDestino - jugador.getPosY());
//    //     int dz = Math.abs(zDestino - jugador.getPosZ());
//
//    //     return (dx + dy + dz) == 1;
//    // }
//
//    /**
//     * post: Intercambio entre aliados usando la interfaz para seleccionar carta.
//     */
//    private boolean intercambioEntreAliadosViaInterfaz(JugadorDeRolgar a, JugadorDeRolgar b) {
//        ValidacionesUtiles.esDistintoDeNull(a, "a");
//        ValidacionesUtiles.esDistintoDeNull(b, "b");
//        if (!sonAliados(a, b)) {
//            interfazUsuario.mostrarMensaje("No son aliados.");
//            return false;
//        }
//        interfazUsuario.mostrarMensaje("Seleccioná carta de " + a.getNombre() + " para transferir a " + b.getNombre());
//        Carta carta = interfazUsuario.seleccionarCartaDeJugador(a);
//        if (carta == null) {
//            interfazUsuario.mostrarMensaje("Intercambio cancelado.");
//            return false;
//        }
//        return intercambiarCartaEntreAliados(a, b, carta);
//    }
//
//    private JugadorDeRolgar seleccionarAliadoPara(JugadorDeRolgar iniciador) {
//        List<JugadorDeRolgar> aliados = new ArrayList<>();
//        for (JugadorDeRolgar j : jugadores) {
//            if (!j.equals(iniciador) && sonAliados(iniciador, j) && j.estaVivo()) aliados.add(j);
//        }
//        if (aliados.isEmpty()) {
//            interfazUsuario.mostrarMensaje("No tenés aliados disponibles para intercambiar.");
//            return null;
//        }
//        interfazUsuario.mostrarMensaje("Seleccionar aliado para intercambiar:");
//        return interfazUsuario.seleccionarJugador(aliados.toArray(new JugadorDeRolgar[0]));
//    }
//
//    /**
//     * post: Usar una carta del jugador. Si la carta devuelve true al usarla, se remueve del inventario.
//     */
//    private void usarCarta(JugadorDeRolgar jugador) {
//        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
//        Carta carta = interfazUsuario.seleccionarCartaDeJugador(jugador);
//        if (carta == null) {
//            interfazUsuario.mostrarMensaje("Uso de carta cancelado.");
//            return;
//        }
//
//        boolean consumida = carta.usar(jugador, this);
//        if (consumida) {
//            jugador.removerCartaDelInventario(carta);
//            interfazUsuario.mostrarMensaje(jugador.getNombre() + " usó la carta: " + carta.getNombre());
//        } else {
//            interfazUsuario.mostrarMensaje("La carta " + carta.getNombre() + " no pudo ser usada (ej: no hay objetivos).");
//        }
//    }
//
//    private void verificarFinDeJuego() {
//        int vivos = (int) jugadores.stream().filter(JugadorDeRolgar::estaVivo).count();
//        if (vivos <= 1) {
//            juegoEnCurso = false;
//            JugadorDeRolgar ganador = jugadores.stream().filter(JugadorDeRolgar::estaVivo).findFirst().orElse(null);
//            if (ganador != null) interfazUsuario.mostrarMensaje("¡Fin del juego! Ganador: " + ganador.getNombre());
//            else interfazUsuario.mostrarMensaje("Fin del juego: empate o todos eliminados.");
//        }
//    }
//
//    private void procesarEfectosTemporales() {
//        Iterator<EfectoTemporal> it = efectosTemporales.iterator();
//        while (it.hasNext()) {
//            EfectoTemporal efecto = it.next();
//            efecto.avanzarTurno();
//            if (efecto.estaExpirado()) {
//                interfazUsuario.mostrarMensaje("Un efecto temporal ha expirado.");
//                it.remove();
//            }
//        }
//    }
//
//    private void pasarTurno() {
//        indiceTurnoActual = (indiceTurnoActual + 1) % jugadores.size();
//    }
//
//    private void procesarAlianzas() {
//        Iterator<Alianza> it = alianzas.iterator();
//        while (it.hasNext()) {
//            Alianza alianza = it.next();
//            alianza.avanzarTurno();
//            if (alianza.estaExpirada()) {
//                interfazUsuario.mostrarMensaje("Una alianza ha expirado.");
//                it.remove();
//            }
//        }
//    }
//
//    /**
//     * post: Solicita a la UI el tiro de dado para el jugador.
//     * */
//    private int solicitarTiroDado(JugadorDeRolgar jugador) {
//        int t = interfazUsuario.lanzarDado(jugador, MIN_DADOS, MAX_DADOS);
//        if (t < MIN_DADOS || t > MAX_DADOS) {
//            interfazUsuario.mostrarMensaje("Valor fuera de rango. Lanzando automáticamente...");
//            t = rnd.nextInt(MAX_DADOS) + 1;
//            interfazUsuario.mostrarMensaje("Resultado: " + t);
//        }
//        return t;
//    }
//
//    /**
//     * post: Configura la curación que se aplica por movimiento
//     */
//    public void setCuracionPorMovimiento(double curacion) {
//        ValidacionesUtiles.validarMayorOIgualACero(curacion, "curacionPorMovimiento");
//        this.curacionPorMovimiento = curacion;
//    }
//}