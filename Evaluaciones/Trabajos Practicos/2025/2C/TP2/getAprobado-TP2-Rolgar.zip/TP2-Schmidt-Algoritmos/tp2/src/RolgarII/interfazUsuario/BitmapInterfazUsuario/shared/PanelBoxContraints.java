package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared;

import javax.swing.*;
import java.awt.*;

public class PanelBoxContraints extends JPanel {
    GridBagConstraints gridBagContraints;

    public PanelBoxContraints(int x, int y, double xPercentage, double yPercentage){
        super();
        if(xPercentage > 1 || yPercentage > 1){
            throw new RuntimeException("Las proporciones deben estar entre 0 y 1. Se ingresaron " + xPercentage + " y " + yPercentage + "");
        }

        gridBagContraints = new GridBagConstraints();
        gridBagContraints.gridx = x;
        gridBagContraints.gridy = y;
        gridBagContraints.weightx = xPercentage;
        gridBagContraints.weighty = yPercentage;
        gridBagContraints.fill = GridBagConstraints.BOTH;
    }

    public GridBagConstraints getConstraints(){
        return this.gridBagContraints;
    }
}
