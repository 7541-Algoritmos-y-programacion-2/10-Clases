package RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public abstract class DialogOpciones<T> extends JDialog {
    protected List<DialogOpcionesOpcion<T>> opciones;
    private JPanel panelPrincipal;
    private PanelOpcionesScrollPane panelOpcionesScroll;

    public DialogOpciones(JFrame owner,String titulo,String tituloPrincipal,String subTitulo){
        super(owner,titulo,false);
        setSize(500,605);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        opciones = new ListaSimplementeEnlazada<>();

        panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());

        var panelTitulos = new JPanel();
        panelTitulos.setLayout(new BoxLayout(panelTitulos,BoxLayout.Y_AXIS));
        panelTitulos.setOpaque(false);
        panelTitulos.setBorder(BitmapInterfazJuegoHelper.paddingBorder(30,15));

        var labelTitulo = new JLabelTitulo(tituloPrincipal,28);
        var labelSubtitulo = new JLabel(subTitulo);
        labelSubtitulo.setFont(new Font("Arial",Font.PLAIN,18));
        labelSubtitulo.setForeground(BitmapJuegoColors.TEXT_MUTED.getColor());

        panelTitulos.add(labelTitulo);
        panelTitulos.add(labelSubtitulo);


        var panelOpciones = new PanelOpciones(15);
        panelOpcionesScroll = new PanelOpcionesScrollPane(panelOpciones);



        panelPrincipal.add(panelTitulos,BorderLayout.NORTH);
        panelPrincipal.add(panelOpcionesScroll,BorderLayout.CENTER);
        add(panelPrincipal);
    }

    public void setOpciones(DialogOpcionesOpcion<T>[] opciones){
        this.opciones = List.of(opciones);
        this.renderOpciones();
    }
    public void addOpcion(DialogOpcionesOpcion<T> opcion){
        this.opciones.add(opcion);
        this.renderOpciones();
    }
    public void removeOpciones(){
        this.opciones.clear();
    }

    private void renderOpciones(){
        var panelOpciones = panelOpcionesScroll.getPanelOpciones();
        panelOpciones.removeAll();
        for(DialogOpcionesOpcion<T> opcion : this.opciones){
            panelOpciones.add(opcion);
        }
    }

    public void mostrarYSeleccionar(CompletableFuture<T> resultado){
        for(var opciones : this.opciones){
            opciones.setCompletableFuture(resultado);
        }
        this.mostrar();
    }

    /*POS : utiliza SwingUtilities.invokeLater para renderizar el JDialog,
    * pero bloquea el hilo de ejecucion de forma sincronica hasta
    * que el usuario seleccione una opcion.*/
    public T mostrarYSeleccionarSync(){
        CompletableFuture<T> resultado = new CompletableFuture<T>();
        SwingUtilities.invokeLater(() -> {
            mostrarYSeleccionar(resultado);
        });
        var resultadoSeleccionado = resultado.join();

        SwingUtilities.invokeLater(this::ocultar);

        return resultadoSeleccionado;
    }

    private void mostrar(){
        this.setVisible(true);
    }

    public void ocultar(){
        this.setVisible(false);
    }



}
