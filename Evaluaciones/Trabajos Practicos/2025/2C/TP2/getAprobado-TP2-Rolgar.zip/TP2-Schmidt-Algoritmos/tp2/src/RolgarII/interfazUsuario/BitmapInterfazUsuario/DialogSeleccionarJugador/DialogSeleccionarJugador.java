package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarJugador;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpciones;
import RolgarII.jugador.JugadorDeRolgar;

import javax.swing.*;
import java.util.concurrent.CompletableFuture;

public class DialogSeleccionarJugador extends DialogOpciones<JugadorDeRolgar> {


    public DialogSeleccionarJugador(JFrame owner) {
        super(owner, "Seleccione un jugador","Jugadores disponibles","seleccione un jugador");
    }

    public void mostrarYSeleccionar(JugadorDeRolgar[] jugadores, CompletableFuture<JugadorDeRolgar> resultado){
        removeOpciones();
        for (int i = 0; i < jugadores.length; i++) {
            var jugador = jugadores[i];
            var opcion = new DialogOpcionJugador(Integer.toString(i+1),jugador);
            opcion.setCompletableFuture(resultado);
            addOpcion(opcion);
        }
        setVisible(true);


    }

}
