package RolgarII.config;

public class TerrenoConfig {

    private String tipo;
    private PosicionConfig posicion;

    /**
     * post: Crea una configuración de terreno sin inicializar
     *       (tipo y posición se asignan posteriormente por JSON).
     */
    public TerrenoConfig() {
    }

    /**
     * post: Devuelve el tipo de terreno configurado
     *       (ej: "ROCA", "AGUA", "ESCALERA_SUBIDA").
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * pre: tipo no debe ser null.
     * post: Establece el tipo de terreno.
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * post: Devuelve la posición donde debe colocarse el terreno.
     */
    public PosicionConfig getPosicion() {
        return posicion;
    }

    /**
     * pre: posicion no debe ser null.
     * post: Establece la posición en el mapa donde estará el terreno.
     */
    public void setPosicion(PosicionConfig posicion) {
        this.posicion = posicion;
    }
}
