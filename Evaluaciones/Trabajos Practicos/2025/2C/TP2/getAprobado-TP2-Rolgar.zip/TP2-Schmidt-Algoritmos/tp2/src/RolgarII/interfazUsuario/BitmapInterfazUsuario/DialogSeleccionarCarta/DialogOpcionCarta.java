package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogSeleccionarCarta;

import RolgarII.carta.Carta;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.DialogOpciones.DialogOpcionesOpcion;

public class DialogOpcionCarta extends DialogOpcionesOpcion<Carta> {

    public DialogOpcionCarta(Carta carta,String caracter){
        super(carta.getNombre(),caracter,carta);
    }

}
