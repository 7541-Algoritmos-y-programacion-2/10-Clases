package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogInputTexto;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DialogInputTextoBtn extends JButton {

    public DialogInputTextoBtn(Runnable onClick){
        super();
        setText("Aceptar");
        setBackground(BitmapJuegoColors.BTN_BG.getColor());
        setForeground(BitmapJuegoColors.BTN_BLACK_TEXT.getColor());
        setFocusPainted(false);
        setFont(new Font("Arial", Font.BOLD, 14));
        setPreferredSize(new Dimension(120, 40));


        addActionListener(e -> onClick.run());

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e);
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                setBackground(BitmapJuegoColors.BTN_BG_HOVER.getColor());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e);
                setCursor(Cursor.getDefaultCursor());
                setBackground(BitmapJuegoColors.BTN_BG.getColor());
            }
        });

    }

}
