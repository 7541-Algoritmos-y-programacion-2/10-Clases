package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta comodín (Jocker) capaz de activar aleatoriamente
 *       el efecto de cualquier otra carta existente en el juego.
 */
public class CartaJocker extends Carta {

    /**
     * post: Crea una carta Jocker con su nombre identificatorio.
     */
    public CartaJocker() {
        super("Carta de jocker");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Selecciona una carta aleatoria mediante la CartaFactory,
     *       notifica al jugador del tipo de carta obtenida,
     *       ejecuta su efecto sobre el jugador,
     *       y devuelve true indicando que la carta fue utilizada
     *       y debe ser consumida.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {
        Carta cartaAleatoria = CartaFactory.aleatoria();

        juego.mostrarMensaje("Carta aleatoria utilizada: " + cartaAleatoria.getNombre());

        return cartaAleatoria.usar(jugador, juego);
    }
}

