package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que activa el escudo del jugador que la utiliza.
 *       El escudo permite reducir o bloquear el daño según la lógica interna del jugador.
 */
public class CartaEscudo extends Carta  {

    /**
     * post: Crea una carta de escudo con su nombre correspondiente.
     */
    public CartaEscudo() {
        super("Carta de escudo");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Activa el escudo del jugador, otorgándole protección especial.
     *       Devuelve true indicando que la carta fue utilizada y consumida exitosamente.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {
        jugador.activarEscudo();
        return true;
    }
}

