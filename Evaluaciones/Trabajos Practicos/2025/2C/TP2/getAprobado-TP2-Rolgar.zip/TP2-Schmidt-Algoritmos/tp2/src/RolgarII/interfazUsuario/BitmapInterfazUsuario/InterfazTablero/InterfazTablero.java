package RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitmapInterfazJuegoHelper;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent.MainContent;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.MainContent.TableroPanel;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.InterfazTablero.RightSidebar.RightSidebar;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.interfaces.Renderizable;
import RolgarII.tablero.TableroDeRolgar;

import javax.swing.*;
import java.awt.*;

/*70 - 30*/
public class InterfazTablero extends JPanel {
    TableroDeRolgar tablero;

    TableroPanel panelTablero;
    RightSidebar rightSidebar;

    private static final double ANCHO_PORCENTAJE_TABLERO = 0.6;
    private static final double ANCHO_PORCENTAJE_ESTADISTICAS = 0.4;

    public InterfazTablero(){
        super();
        this.setLayout(new GridBagLayout());
        this.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        this.inicializarPanelTablero();
        this.inicializarPanelEstadisticas();

    }

    public void setTablero(TableroDeRolgar tablero){
        this.tablero = tablero;
    }

    private void inicializarPanelEstadisticas(){

        rightSidebar = new RightSidebar(ANCHO_PORCENTAJE_ESTADISTICAS);

        add(rightSidebar, rightSidebar.getConstraints());

    }
    private void inicializarPanelTablero(){
        var mainContent = new MainContent(ANCHO_PORCENTAJE_TABLERO);
        panelTablero = mainContent.getPanelTablero();
        add(mainContent,mainContent.getConstraints());
    }

    public TableroPanel getPanelTablero(){
        return this.panelTablero;
    }

    public void render(TableroDeRolgar tablero, JugadorDeRolgar jugadorActual, Turno turno, GameRenderContext context){

        panelTablero.render(tablero,turno,context);

        rightSidebar.render(tablero,jugadorActual,turno);

    }

}
