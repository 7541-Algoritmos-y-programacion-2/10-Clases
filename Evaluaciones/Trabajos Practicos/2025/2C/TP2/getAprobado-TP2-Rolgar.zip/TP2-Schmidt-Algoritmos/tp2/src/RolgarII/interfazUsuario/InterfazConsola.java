package RolgarII.interfazUsuario;

import RolgarII.carta.Carta;
import RolgarII.casillero.CasilleroDeRolgar;
import RolgarII.dificultadJuego.DificultadJuego;
import RolgarII.enemigo.Enemigo;
import RolgarII.juego.ElementoDeRolgar;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.preguntas.Pregunta;
import RolgarII.shared.teclado.Teclado;
import RolgarII.tablero.TableroDeRolgar;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class InterfazConsola implements InterfazJuego {

    private static final int ANCHO_CAJA_TURNO = 40;
    private static final int ANCHO_CAJA_DADO = 20;
    private static final int ANCHO_CAJA_CONTROLES = 35;

    private final Scanner scanner;
    private final Random rnd = new Random();
    private List<JugadorDeRolgar> jugadoresGlobales;

    /**
     * post: Inicializa la interfaz y el lector de entrada.
     */
    public InterfazConsola() {
        this.scanner = new Scanner(System.in);
    }



    @Override
    public String hacerPregunta(Pregunta pregunta) {
        return pregunta.getOpciones().get(0);
    }

    @Override
    public DificultadJuego seleccionarDificultad(DificultadJuego[] dificultades) {
        return dificultades[0];
    }

    @Override
    public Jugada seleccionarJugada(JugadorDeRolgar jugador) {
        return null;
    }

    /**
     * pre: mensaje no es null.
     * post: Imprime el mensaje por consola.
     */
    @Override
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    /**
     * pre: tablero y jugadorActual no son null.
     * post: Renderiza el tablero según la posición del jugador.
     */
    @Override
    public void renderizarTablero(TableroDeRolgar tablero, JugadorDeRolgar jugadorActual, Turno turno) {

        int px = jugadorActual.getPosX();
        int py = jugadorActual.getPosY();
        int pz = jugadorActual.getPosZ();

        System.out.println();
        System.out.println("======= MAPA (visión de " + jugadorActual.getNombre() + ") =======");

        for (int z = 1; z <= tablero.getProfundo(); z++) {
            System.out.println("--- Nivel Z=" + z + " ---");

            System.out.print("    ");
            for (int x = 1; x <= tablero.getAncho(); x++) {
                System.out.printf("%2d ", x);
            }
            System.out.println();

            for (int y = 1; y <= tablero.getAlto(); y++) {
                System.out.printf("%2d|", y);

                for (int x = 1; x <= tablero.getAncho(); x++) {

                    if (x == px && y == py && z == pz) {
                        System.out.print("[@]");
                        continue;
                    }

                    boolean otro = false;

                    if (jugadoresGlobales != null) {
                        for (JugadorDeRolgar j : jugadoresGlobales) {
                            if (j != jugadorActual && j.estaVivo() &&
                                    j.getPosX() == x && j.getPosY() == y && j.getPosZ() == z) {
                                System.out.print("[P]");
                                otro = true;
                                break;
                            }
                        }
                    }
                    if (otro) continue;

                    CasilleroDeRolgar cas = tablero.getCasillero(x, y, z);
                    TipoDeTerreno t = cas.getTerreno();
                    ElementoDeRolgar e = cas.getEntidad();

                    char simbolo;

                    if (e instanceof Carta) simbolo = 'C';
                    else if (e instanceof Enemigo) simbolo = 'E';
                    else if (e instanceof JugadorDeRolgar) simbolo = 'P';
                    else if (t == null || t == TipoDeTerreno.VACIO) simbolo = '.';
                    else if (t == TipoDeTerreno.ROCA) simbolo = 'R';
                    else if (t == TipoDeTerreno.AGUA) simbolo = 'A';
                    else if (t == TipoDeTerreno.ESCALERA_SUBIDA) simbolo = '↑';
                    else if (t == TipoDeTerreno.ESCALERA_BAJADA) simbolo = '↓';
                    else simbolo = '.';

                    System.out.print("[" + simbolo + "]");
                }
                System.out.println();
            }
        }
        System.out.println("=====================================");
    }

    /**
     * post: Devuelve un comando ingresado por el usuario.
     */
    @Override
    public String leerComandoMovimiento() {
        System.out.print("Ingrese comando (W/A/S/D/Q/E/X): ");
        return scanner.nextLine().trim().toLowerCase();
    }

    /**
     * pre: jugador y tablero no son null.
     * post: Muestra opciones de movimiento en consola.
     */
    @Override
    public void mostrarOpcionesMovimiento(JugadorDeRolgar jugador, TableroDeRolgar tablero) {
        int x = jugador.getPosX();
        int y = jugador.getPosY();
        int z = jugador.getPosZ();

        System.out.println();
        imprimirLineaCaja('┌', '─', " 🎮 CONTROLES ", '┐', ANCHO_CAJA_CONTROLES);
        System.out.println(String.format("│ %-31s │", "W: Arriba (Y-1)"));
        System.out.println(String.format("│ %-31s │", "A: Izquierda (X-1)"));
        System.out.println(String.format("│ %-31s │", "S: Abajo (Y+1)"));
        System.out.println(String.format("│ %-31s │", "D: Derecha (X+1)"));

        boolean subir = puedeSubirNivel(jugador, tablero);
        boolean bajar = puedeBajarNivel(jugador, tablero);

        System.out.println(String.format("│ %-31s │", "E: Subir nivel (Z+1) " + (subir ? "✅" : "❌")));
        System.out.println(String.format("│ %-31s │", "Q: Bajar nivel (Z-1) " + (bajar ? "❌" : "❌")));

        System.out.println(String.format("│ %-31s │", "X: Cancelar movimiento"));
        imprimirLineaCaja('├', '─', " POSICIÓN ACTUAL ", '┤', ANCHO_CAJA_CONTROLES);
        System.out.println(String.format("│ (%d, %d, %d) Nivel %-16s │", x, y, z, z));
        imprimirLineaCaja('└', '─', null, '┘', ANCHO_CAJA_CONTROLES);
        System.out.println();
    }

    /**
     * pre: jugadores no es null.
     * post: Devuelve el jugador elegido o null si se cancela.
     */
    @Override
    public JugadorDeRolgar seleccionarJugador(JugadorDeRolgar[] jugadores) {
        if (jugadores == null || jugadores.length == 0) return null;

        System.out.println("\n--- Seleccionar Jugador ---");

        JugadorDeRolgar[] vivos =
                java.util.Arrays.stream(jugadores)
                        .filter(JugadorDeRolgar::estaVivo)
                        .toArray(JugadorDeRolgar[]::new);

        if (vivos.length == 0) return null;

        int idx = 1;
        for (JugadorDeRolgar j : vivos) {
            System.out.printf("%d. %s (Vida: %.1f)\n", idx++, j.getNombre(), j.getVida());
        }

        int op = obtenerOpcionNumerica("Ingrese número (0 para cancelar): ");
        if (op > 0 && op <= vivos.length) return vivos[op - 1];

        return null;
    }

    /**
     * pre: jugador no es null.
     * post: Devuelve la carta seleccionada o null.
     */
    @Override
    public Carta seleccionarCartaDeJugador(JugadorDeRolgar jugador) {
        if (jugador == null) return null;

        List<Carta> cartas = jugador.getVerCartas();
        if (cartas.isEmpty()) return null;

        System.out.println("\n--- Cartas de " + jugador.getNombre() + " ---");

        for (int i = 0; i < cartas.size(); i++) {
            System.out.printf("%d. %s\n", i + 1, cartas.get(i).getNombre());
        }

        int op = obtenerOpcionNumerica("Seleccione una carta (0 para cancelar): ");
        if (op > 0 && op <= cartas.size()) return cartas.get(op - 1);

        return null;
    }

    /**
     * pre: tablero no es null.
     * post: Devuelve una celda o null.
     */
    @Override
    public CasilleroDeRolgar seleccionarCeldaLibre(TableroDeRolgar tablero,int ejeZ) {

        System.out.println("\n--- Seleccionar Coordenadas ---");

        Integer x = obtenerCoordenada("X", tablero.getAncho());
        if (x == null) return null;

        Integer y = obtenerCoordenada("Y", tablero.getAlto());
        if (y == null) return null;

        Integer z = obtenerCoordenada("Z", tablero.getProfundo());
        if (z == null) return null;

        return tablero.getCasillero(x, y, z);
    }

    /**
     * pre: jugador no es null.
     * post: Devuelve la acción de turno seleccionada.
     */
    @Override
    public int obtenerAccionDeTurno(JugadorDeRolgar jugador, int movRestantes) {

        String nombre = jugador.getNombre();
        String pos = String.format("(%d,%d,%d)", jugador.getPosX(), jugador.getPosY(), jugador.getPosZ());

        String titulo = String.format(" Turno de %-26s ",
                nombre.length() > 26 ? nombre.substring(0, 26) : nombre);

        String v = String.format("│ Vida: %-10.1f   Movs: %-10d │",
                jugador.getVida(), movRestantes);
        String pc = String.format("│ Pos: %-11s Cartas: %-9d │",
                pos, jugador.getVerCartas().size());

        imprimirLineaCaja('┌', '─', titulo, '┐', ANCHO_CAJA_TURNO);
        System.out.println(v);
        System.out.println(pc);
        imprimirLineaCaja('├', '─', " Opciones ", '┤', ANCHO_CAJA_TURNO);

        System.out.println(String.format("│ %-38s │", "1. Mover (Teclado)"));
        System.out.println(String.format("│ %-38s │", "2. Usar carta"));
        System.out.println(String.format("│ %-38s │", "3. Pasar turno"));

        imprimirLineaCaja('└', '─', null, '┘', ANCHO_CAJA_TURNO);

        return obtenerOpcionNumerica("Seleccione una acción (1-3): ");
    }

    /**
     * pre: prompt no es null.
     * post: Devuelve el entero ingresado por el usuario.
     */
    @Override
    public int obtenerOpcionNumerica(String prompt) {
        System.out.print(prompt);
        while (true) {
            try {
                int v = scanner.nextInt();
                scanner.nextLine();
                return v;
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número válido.");
                System.out.print(prompt);
                scanner.nextLine();
            }
        }
    }

    @Override
    public String obtenerTexto(String prompt) {
        System.out.println(prompt);
        return Teclado.leerString();
    }

    /**
     * pre: mensaje no es null.
     * post: Devuelve true si el usuario elige "1".
     */
    @Override
    public boolean obtenerConfirmacion(String mensaje) {
        String s = "";
        while (!s.equals("1") && !s.equals("2")) {
            System.out.print(mensaje + " (1=Sí, 2=No): ");
            s = scanner.nextLine().trim();
        }
        return s.equals("1");
    }

    /**
     * pre: jugador no es null.
     * post: Devuelve un número aleatorio entre min y max.
     */
    public int lanzarDado(JugadorDeRolgar jugador, int min, int max) {
        if (min > max) { int t = min; min = max; max = t; }

        int r = rnd.nextInt(max - min + 1) + min;

        String nombre = jugador.getNombre();
        String titulo = " Lanzando dado ";
        String jStr = String.format("│ Jugador: %-9s │",
                nombre.length() > 9 ? nombre.substring(0, 9) : nombre);
        String rStr = String.format("│ Resultado: %-2d      │", r);

        System.out.println();
        imprimirLineaCaja('┌', '─', titulo, '┐', ANCHO_CAJA_DADO);
        System.out.println(jStr);
        imprimirLineaCaja('├', '─', null, '┤', ANCHO_CAJA_DADO);
        System.out.println(rStr);
        imprimirLineaCaja('└', '─', null, '┘', ANCHO_CAJA_DADO);
        System.out.println();

        return r;
    }

    /**
     * pre: lista no es null.
     * post: Guarda la lista global de jugadores.
     */
    public void setJugadoresGlobales(List<JugadorDeRolgar> lista) {
        this.jugadoresGlobales = lista;
    }

    /**
     * pre: jugador y tablero no son null.
     * post: Devuelve true si el jugador puede subir un nivel.
     */
    private boolean puedeSubirNivel(JugadorDeRolgar jugador, TableroDeRolgar tablero) {
        int z = jugador.getPosZ() + 1;
        if (!tablero.existe(jugador.getPosX(), jugador.getPosY(), z)) return false;

        TipoDeTerreno t =
                tablero.getCasillero(jugador.getPosX(), jugador.getPosY(), jugador.getPosZ()).getTerreno();

        return t != null && t.esEscaleraSubida();
    }

    /**
     * pre: jugador y tablero no son null.
     * post: Devuelve true si el jugador puede bajar un nivel.
     */
    private boolean puedeBajarNivel(JugadorDeRolgar jugador, TableroDeRolgar tablero) {
        int z = jugador.getPosZ() - 1;
        if (!tablero.existe(jugador.getPosX(), jugador.getPosY(), z)) return false;

        TipoDeTerreno t =
                tablero.getCasillero(jugador.getPosX(), jugador.getPosY(), jugador.getPosZ()).getTerreno();

        return t != null && t.esEscaleraBajada();
    }

    /**
     * pre: tipo no es null.
     * post: Devuelve una coordenada válida o null.
     */
    private Integer obtenerCoordenada(String tipo, int maxValor) {
        while (true) {
            int v = obtenerOpcionNumerica("Ingrese " + tipo + " (1-" + maxValor + ") (0 para cancelar): ");
            if (v == 0) return null;
            if (v >= 1 && v <= maxValor) return v;
        }
    }

    /**
     * pre: caracteres y ancho son válidos.
     * post: Dibuja una línea de caja con el texto centrado.
     */
    private void imprimirLineaCaja(char izq, char linea, String titulo, char der, int ancho) {
        StringBuilder sb = new StringBuilder();
        sb.append(izq);

        if (titulo == null) {
            sb.append(String.valueOf(linea).repeat(ancho - 2));
        } else {
            int extra = ancho - 2 - titulo.length();
            int izqL = extra / 2;
            int derL = extra - izqL;
            sb.append(String.valueOf(linea).repeat(izqL));
            sb.append(titulo);
            sb.append(String.valueOf(linea).repeat(derL));
        }

        sb.append(der);
        System.out.println(sb.toString());
    }

    /**
     * post: Imprime la leyenda de los símbolos.
     */
    public void mostrarLeyendaTerrenos() {
        System.out.println("\n===== LEYENDA DE TERRENOS =====");
        System.out.println("[R] Roca");
        System.out.println("[A] Agua");
        System.out.println("[↑] Escalera subida");
        System.out.println("[↓] Escalera bajada");
        System.out.println("[.] Vacío");
        System.out.println("[E] Enemigo");
        System.out.println("[C] Carta");
        System.out.println("[P] Jugador");
        System.out.println("[@] Tu jugador");
        System.out.println("================================\n");
    }
}
