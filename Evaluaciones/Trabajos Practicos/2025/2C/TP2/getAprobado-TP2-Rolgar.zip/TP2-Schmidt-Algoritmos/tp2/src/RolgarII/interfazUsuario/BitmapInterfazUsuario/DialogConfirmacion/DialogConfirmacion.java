package RolgarII.interfazUsuario.BitmapInterfazUsuario.DialogConfirmacion;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.BitmapJuegoColors;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.JLabelTitulo;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.CompletableFuture;

public class DialogConfirmacion extends JDialog {

    private CompletableFuture<Boolean> futuroResultado;

    public DialogConfirmacion(JFrame frame) {
        super(frame, "Confirmación", true); // Modal
        this.setSize(400, 250);
        this.setLocationRelativeTo(frame);
        this.setUndecorated(true);

        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createLineBorder(BitmapJuegoColors.BORDER.getColor(), 2));
        mainPanel.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JPanel header = new JPanel();
        header.setBackground(BitmapJuegoColors.SECONDARY_BG.getColor());
        header.add(new JLabelTitulo("Confirmación", 18));
        mainPanel.add(header, BorderLayout.NORTH);

        JLabel lblMensaje = new JLabel("¿Confirma la acción?");
        lblMensaje.setForeground(Color.WHITE); // Asumo texto blanco por el fondo oscuro
        lblMensaje.setHorizontalAlignment(SwingConstants.CENTER);
        lblMensaje.setFont(new Font("Arial", Font.BOLD, 14));
        mainPanel.add(lblMensaje, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        footer.setBackground(BitmapJuegoColors.PRIMARY_BG.getColor());

        JButton btnSi = crearBoton("SÍ", Color.GREEN);
        JButton btnNo = crearBoton("NO", Color.RED);

        btnSi.addActionListener(e -> cerrarConResultado(true));
        btnNo.addActionListener(e -> cerrarConResultado(false));

        footer.add(btnSi);
        footer.add(btnNo);
        mainPanel.add(footer, BorderLayout.SOUTH);

        this.add(mainPanel);
    }

    private JButton crearBoton(String texto, Color bg) {
        JButton btn = new JButton(texto);
        btn.setBackground(bg);
        btn.setForeground(Color.BLACK);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
        btn.setPreferredSize(new Dimension(100, 40));
        return btn;
    }

    private void cerrarConResultado(boolean resultado) {
        this.setVisible(false);
        if (futuroResultado != null) {
            futuroResultado.complete(resultado);
        }
    }

    public void mostrar(String mensaje, CompletableFuture<Boolean> futuro) {
        this.futuroResultado = futuro;
        JPanel panel = (JPanel) this.getContentPane().getComponent(0);
        JLabel label = (JLabel) panel.getComponent(1);
        label.setText("<html><center>" + mensaje + "</center></html>");
        this.setVisible(true);
    }
}