package RolgarII.config;

public class ConfiguracionDeJuego {

    private int ancho;
    private int alto;
    private int profundo;

    private String dificultad;

    private ParametrosJuegoConfig parametrosJuego;
    private JugadorConfig[] jugadores;
    private EnemigoConfig[] enemigos;
    private TerrenoConfig[] terrenos;
    private CartaEnTableroConfig[] cartasEnTablero;

    /**
     * post: Crea una instancia vacía de la configuración del juego.
     */
    public ConfiguracionDeJuego() {
    }

    /**
     * post: Devuelve el ancho configurado.
     */
    public int getAncho() {
        return ancho;
    }

    /**
     * post: Establece el ancho en la configuración.
     */
    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    /**
     * post: Devuelve el alto configurado.
     */
    public int getAlto() {
        return alto;
    }

    /**
     * post: Establece el alto en la configuración.
     */
    public void setAlto(int alto) {
        this.alto = alto;
    }

    /**
     * post: Devuelve la profundidad configurada.
     */
    public int getProfundo() {
        return profundo;
    }

    /**
     * post: Establece la profundidad en la configuración.
     */
    public void setProfundo(int profundo) {
        this.profundo = profundo;
    }

    /**
     * post: Devuelve la dificultad configurada.
     */
    public String getDificultad() {
        return dificultad;
    }

    /**
     * post: Establece la dificultad en la configuración.
     */
    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    /**
     * post: Devuelve los parámetros de juego configurados.
     */
    public ParametrosJuegoConfig getParametrosJuego() {
        return parametrosJuego;
    }

    /**
     * post: Establece los parámetros de juego en la configuración.
     */
    public void setParametrosJuego(ParametrosJuegoConfig parametrosJuego) {
        this.parametrosJuego = parametrosJuego;
    }

    /**
     * post: Devuelve el arreglo de configuraciones de jugadores.
     */
    public JugadorConfig[] getJugadores() {
        return jugadores;
    }

    /**
     * post: Establece el arreglo de configuraciones de jugadores.
     */
    public void setJugadores(JugadorConfig[] jugadores) {
        this.jugadores = jugadores;
    }

    /**
     * post: Devuelve el arreglo de configuraciones de enemigos.
     */
    public EnemigoConfig[] getEnemigos() {
        return enemigos;
    }

    /**
     * post: Establece el arreglo de configuraciones de enemigos.
     */
    public void setEnemigos(EnemigoConfig[] enemigos) {
        this.enemigos = enemigos;
    }

    /**
     * post: Devuelve el arreglo de configuraciones de terrenos.
     */
    public TerrenoConfig[] getTerrenos() {
        return terrenos;
    }

    /**
     * post: Establece el arreglo de configuraciones de terrenos.
     */
    public void setTerrenos(TerrenoConfig[] terrenos) {
        this.terrenos = terrenos;
    }

    /**
     * post: Devuelve el arreglo de configuraciones de cartas en el tablero.
     */
    public CartaEnTableroConfig[] getCartasEnTablero() {
        return cartasEnTablero;
    }

    /**
     * post: Establece el arreglo de configuraciones de cartas en el tablero.
     */
    public void setCartasEnTablero(CartaEnTableroConfig[] cartasEnTablero) {
        this.cartasEnTablero = cartasEnTablero;
    }
}