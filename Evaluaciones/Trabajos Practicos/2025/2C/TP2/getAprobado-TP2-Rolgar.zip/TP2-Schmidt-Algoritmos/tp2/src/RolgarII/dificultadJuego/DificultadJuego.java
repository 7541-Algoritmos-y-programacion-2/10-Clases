package RolgarII.dificultadJuego;

public class DificultadJuego {

    private int tableroId;
    private int cantidadDeEnemigos;
    private String nombre;
    private int cantidadDeCartasEnMapa;
    private int cantidadDeCartasPorJugador;
    private int visionEnJugadores;

    public DificultadJuego(){}

    public int getVisionEnJugadores() {
        return visionEnJugadores;
    }

    public void setVisionEnJugadores(int visionEnJugadores) {
        this.visionEnJugadores = visionEnJugadores;
    }

    public int getTableroId() {
        return tableroId;
    }

    public void setTableroId(int tableroId) {
        this.tableroId = tableroId;
    }

    public int getCantidadDeEnemigos() {
        return cantidadDeEnemigos;
    }

    public void setCantidadDeEnemigos(int cantidadDeEnemigos) {
        this.cantidadDeEnemigos = cantidadDeEnemigos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidadDeCartasEnMapa() {
        return cantidadDeCartasEnMapa;
    }

    public void setCantidadDeCartasEnMapa(int cantidadDeCartasEnMapa) {
        this.cantidadDeCartasEnMapa = cantidadDeCartasEnMapa;
    }

    public int getCantidadDeCartasPorJugador() {
        return cantidadDeCartasPorJugador;
    }

    public void setCantidadDeCartasPorJugador(int cantidadDeCartasPorJugador) {
        this.cantidadDeCartasPorJugador = cantidadDeCartasPorJugador;
    }

    @Override
    public String toString() {
        return "DificultadJuego{" +
                "tableroId=" + tableroId +
                ", cantidadDeEnemigos=" + cantidadDeEnemigos +
                ", nombre='" + nombre + '\'' +
                ", cantidadDeCartasEnMapa=" + cantidadDeCartasEnMapa +
                '}';
    }
}
