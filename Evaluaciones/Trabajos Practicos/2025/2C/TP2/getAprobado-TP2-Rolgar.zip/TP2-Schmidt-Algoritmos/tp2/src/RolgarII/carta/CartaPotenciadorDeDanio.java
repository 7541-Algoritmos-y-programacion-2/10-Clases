package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

/**
 * post: Representa una carta que potencia el daño del jugador durante un número limitado de turnos.
 *       El jugador aplicará el multiplicador de daño indicado por la carta.
 */
public class CartaPotenciadorDeDanio extends Carta {

    private final static double POTENCIADOR_POR_DEFECTO = 1.25;
    private final static int TURNOS_POTENCIADOS = 3;

    private int turnosPotenciados;
    private double potenciador;

    /**
     * pre: 'turnosPotenciados' > 0 y 'potenciador' > 1.
     * post: Crea una carta potenciadora de daño con valores personalizados.
     */
    private CartaPotenciadorDeDanio(int turnosPotenciados, double potenciador) {
        super("CARTA DE DANIO");
        this.turnosPotenciados = turnosPotenciados;
        setPotenciador(potenciador);
    }

    /**
     * pre: 'potenciador' debe ser mayor que 1.
     * post: Establece el multiplicador de daño que será aplicado cuando se use la carta.
     */
    public void setPotenciador(double potenciador) {
        ValidacionesUtiles.validarMayorQue(potenciador, 1, "Potenciador de danio");
        this.potenciador = potenciador;
    }

    /**
     * post: Crea una carta potenciadora de daño con valores por defecto:
     *       multiplicador 1.25x y duración de 3 turnos.
     */
    public CartaPotenciadorDeDanio() {
        this(TURNOS_POTENCIADOS, POTENCIADOR_POR_DEFECTO);
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Aplica el multiplicador de daño al jugador,
     *       registra un efecto temporal para removerlo luego de los turnos especificados,
     *       y devuelve true indicando que la carta se ha utilizado correctamente.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {
        jugador.potenciarDanio(this.potenciador);

        juego.registrarEfectoTemporal(
                this.turnosPotenciados,
                jugador::quitarPotenciadorDeFuerza
        );

        return true;
    }
}

