package RolgarII.enemigo;

import RolgarII.juego.ElementoDeRolgar;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.clases.SpriteId;
import RolgarII.shared.interfaces.Renderizable;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class Enemigo implements ElementoDeRolgar, Renderizable {

    private final String nombre;
    private int energia;
    private final int ataque;
    private int posX;
    private int posY;
    private int posZ;

    /**
     * pre: nombre no es null; energia > 0; ataque > 0; x,y,z ≥ 0.
     * post: Crea un enemigo con nombre, energía, ataque y posición inicial.
     */
    public Enemigo(String nombre, int energia, int ataque, int x, int y, int z) {
        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
        ValidacionesUtiles.validarMayorACero(energia, "energia");
        ValidacionesUtiles.validarMayorACero(ataque, "ataque");
        ValidacionesUtiles.validarMayorOIgualACero(x, "x");
        ValidacionesUtiles.validarMayorOIgualACero(y, "y");
        ValidacionesUtiles.validarMayorOIgualACero(z, "z");

        this.nombre = nombre;
        this.energia = energia;
        this.ataque = ataque;
        this.posX = x;
        this.posY = y;
        this.posZ = z;
    }

    /**
     * pre: jugador no debe ser null.
     * post: El jugador recibe daño igual al ataque del enemigo.
     */
    public void atacar(JugadorDeRolgar jugador) {
        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
        jugador.recibirDanio(this.ataque);
    }

    /**
     * pre: danio > 0.
     * post: Reduce la energía del enemigo, quedando como mínimo en 0.
     */
    public void recibirDanio(int danio) {
        ValidacionesUtiles.validarMayorACero(danio, "daño");
        this.energia = Math.max(0, this.energia - danio);
    }

    /**
     * post: Devuelve verdadero si el enemigo tiene energía mayor a 0.
     */
    public boolean estaVivo() {
        return this.energia > 0;
    }

    /**
     * pre: jugador no es null.
     * post: Devuelve la distancia Manhattan entre el enemigo y el jugador.
     */
    public int distanciaA(JugadorDeRolgar jugador) {
        ValidacionesUtiles.esDistintoDeNull(jugador, "jugador");
        int dx = Math.abs(jugador.getPosX() - this.posX);
        int dy = Math.abs(jugador.getPosY() - this.posY);
        int dz = Math.abs(jugador.getPosZ() - this.posZ);
        return dx + dy + dz;
    }

    /**
     * post: Devuelve el nombre del enemigo.
     */
    public String getNombre() { return nombre; }

    /**
     * post: Devuelve la energía actual del enemigo.
     */
    public int getEnergia() { return energia; }

    /**
     * post: Devuelve el valor de ataque del enemigo.
     */
    public int getAtaque() { return ataque; }

    /**
     * post: Devuelve la coordenada X del enemigo.
     */
    public int getPosX() { return posX; }

    /**
     * post: Devuelve la coordenada Y del enemigo.
     */
    public int getPosY() { return posY; }

    /**
     * post: Devuelve la coordenada Z del enemigo.
     */
    public int getPosZ() { return posZ; }

    /**
     * pre: puntos > 0.
     * post: Aumenta la energía del enemigo en la cantidad dada.
     */
    public void curar(int puntos) {
        ValidacionesUtiles.validarMayorACero(puntos, "curación");
        this.energia += puntos;
    }

    @Override
    public SpriteId getSpriteId() { return SpriteId.ENEMIGO; }
}