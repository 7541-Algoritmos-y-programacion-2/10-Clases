package RolgarII.carta;

import RolgarII.juego.Juego;
import RolgarII.jugador.JugadorDeRolgar;

/**
 * post: Representa una carta que otorga al jugador la habilidad de moverse
 * dos casillas por acción de movimiento durante su turno actual.
 */
public class CartaDobleMovimiento extends Carta {

    // Duración de 1 turno: se aplica inmediatamente y se elimina al final del turno.
    private static final int TURNOS_DOBLE_MOVIMIENTO = 1;

    /**
     * post: Crea una carta de doble movimiento con su nombre correspondiente.
     */
    public CartaDobleMovimiento() {
        super("Carta de doble movimiento");
    }

    /**
     * pre: 'jugador' y 'juego' no deben ser nulos.
     * post: Activa en el jugador el estado de "doble movimiento" y registra
     * un efecto temporal para desactivarlo al final del turno.
     * Devuelve true indicando que la carta fue consumida exitosamente.
     */
    @Override
    public boolean usar(JugadorDeRolgar jugador, Juego juego) {

        jugador.activarDobleMovimiento();

        juego.registrarEfectoTemporal(
                TURNOS_DOBLE_MOVIMIENTO,
                jugador::desactivarDobleMovimiento
        );

        return true;
    }
}

