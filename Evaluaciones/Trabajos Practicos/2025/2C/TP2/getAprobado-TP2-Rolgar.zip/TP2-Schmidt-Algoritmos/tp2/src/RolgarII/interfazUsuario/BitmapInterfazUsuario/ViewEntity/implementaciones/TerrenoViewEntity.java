package RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.implementaciones;

import RolgarII.interfazUsuario.BitmapInterfazUsuario.ViewEntity.ViewEntity;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.shared.GameRenderContext;
import RolgarII.juego.TipoDeTerreno;
import RolgarII.juego.turno.Turno;
import RolgarII.shared.clases.SpriteId;

public class TerrenoViewEntity extends ViewEntity<TipoDeTerreno> {


    public TerrenoViewEntity(TipoDeTerreno entity) {
        super(entity);
    }

    @Override
    public SpriteId getSpriteId(GameRenderContext context) {
        return switch (getEntidad()){
            case AGUA -> SpriteId.TERRENO_AGUA;
            case TIERRA -> SpriteId.TERRENO_TIERRA;
            case ROCA -> SpriteId.TERRENO_ROCA;
            case ESCALERA_BAJADA ->  SpriteId.TERRENO_RAMPA_ABAJO;
            case ESCALERA_SUBIDA -> SpriteId.TERRENO_RAMPA_ARRIBA;
            case VACIO -> SpriteId.VACIO;
        };

    }
}
