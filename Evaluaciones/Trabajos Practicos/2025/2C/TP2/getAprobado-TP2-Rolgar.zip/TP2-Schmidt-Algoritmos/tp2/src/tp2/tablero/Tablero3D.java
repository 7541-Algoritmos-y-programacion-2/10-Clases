//package tp2.tablero;
//
//import tp2.casillero.Casillero3D;
//import tp2.validacionesUtiles.ValidacionesUtiles;
//import tp2.shared.estructuras.ListaSimplementeEnlazada;
//
//import java.util.List;
//import java.util.Objects;
//
///**
// * Representa un tablero tridimensional genérico, compuesto por casilleros
// * dispuestos en tres dimensiones (ancho, alto y profundidad).
// * @param <T> tipo del valor almacenado en cada casillero.
// * - ancho, alto y profundo > 0
// * - todos los casilleros están inicializados
// */
//public class Tablero3D<T> {
//	//INTERFACES ----------------------------------------------------------------------------------------------
//	//ENUMERADOS ----------------------------------------------------------------------------------------------
//	//CONSTANTES ----------------------------------------------------------------------------------------------
//	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//	//ATRIBUTOS -----------------------------------------------------------------------------------------------
//
//	private List<List<List<Casillero3D<T>>>> casilleros = null;
//
//	//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//	//CONSTRUCTORES -------------------------------------------------------------------------------------------
//
//	/**
//	 * post: Inicializa un tablero de 'ancho' x 'alto' x 'profundo'.
//	 * @param ancho: mayor o igual 1
//	 * @param alto: mayor o igual 1
//	 * @param profundo: mayor o igual 1
//	 */
//	public Tablero3D(int ancho, int alto, int profundo) {
//		this(ancho, alto, profundo, null);
//	}
//
//	public Tablero3D(int ancho, int alto, int profundo, T valorPorDefecto) {
//		ValidacionesUtiles.validarMayorACero(ancho, "ancho");
//		ValidacionesUtiles.validarMayorACero(alto, "alto");
//		ValidacionesUtiles.validarMayorACero(profundo, "profundo");
//		this.casilleros = new ListaSimplementeEnlazada<List<List<Casillero3D<T>>>>();
//		for(int i = 0; i < ancho; i++) {
//			List<List<Casillero3D<T>>> fila = new ListaSimplementeEnlazada<List<Casillero3D<T>>>();
//			for(int j = 0; j < alto; j++) {
//				List<Casillero3D<T>> columna = new ListaSimplementeEnlazada<Casillero3D<T>>();
//				for(int k = 0; k < profundo; k++) {
//					columna.add(new Casillero3D<T>(valorPorDefecto, i, j, k));
//				}
//				fila.add(columna);
//			}
//			this.casilleros.add(fila);
//		}
//	}
//
//	//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//	//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//	//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//	//METODOS DE CLASE ----------------------------------------------------------------------------------------
//	//METODOS GENERALES ---------------------------------------------------------------------------------------
//
//	@Override
//	public String toString() {
//		return "Tablero de " + this.getAncho() + " x " + this.getAlto() + " x " + this.getProfundo();
//	}
//
//	@Override
//	public int hashCode() {
//		return Objects.hash(casilleros);
//	}
//
//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		Tablero3D<T> other = (Tablero3D<T>) obj;
//		return Objects.equals(casilleros, other.casilleros);
//	}
//
//	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//
//	/**
//	 * post: Devuelve el casillero en la posicion (x, y, z).
//	 * pre: Las coordenadas dadas deben estar dentro de los límites del tablero.
//	 * @param x: de 1 a ancho
//	 * @param y: de 1 a alto
//	 * @param z: de 1 a profundo
//	 * @return el casillero en la posición de coordenadas dadas.
//	 */
//	public Casillero3D<T> getCasillero(int x, int y, int z) {
//		ValidacionesUtiles.validarRangoNumerico( x, 1,this.getAncho(), "x");
//		ValidacionesUtiles.validarRangoNumerico(y, 1,this.getAlto(), "y");
//		ValidacionesUtiles.validarRangoNumerico( z, 1,this.getProfundo(), "z");
//		return this.casilleros.get(x-1).get(y-1).get(z-1);
//	}
//
//	//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
//	//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//	//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//	//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//
//	/**
//	 * post: Devuelve el ancho del tablero
//	 * @return el encho del tablero.
//	 */
//	public int getAncho() {
//		return this.casilleros.size();
//	}
//
//	/**
//	 * post: Devuelve el alto del tablero
//	 * @return el alto del tablero.
//	 */
//	public int getAlto() {
//		return this.casilleros.get(0).size();
//	}
//
//	/**
//	 * post: Devuelve lo profundo del tablero
//	 * @return lo profundo del tablero.
//	 */
//	public int getProfundo() {
//		return this.casilleros.get(0).get(0).size();
//	}
//
//	/**
//	 * post: Devuelve la cantidad total del casilleros que tiene el tablero.
//	 * @return la cantidad total de casilleros.
//	 */
//	public int getCantidadDeCasilleros() {
//		return getAncho() * getAlto() * getProfundo();
//	}
//
//	/**
//	 * post: Devuelve la cantidad de casilleros libres que tiene el tablero.
//	 * @return la cantidad de casilleros libres del tablero.
//	 */
//	public int getCantidadDeCasillerosLibres() {
//		int cantidadDeCasillerosLibres = 0;
//		for(int i = 1; i <= getAncho(); i++) {
//			for(int j = 1; j <= getAlto(); j++) {
//				for(int k = 1; k <= getProfundo(); k++) {
//					if (getCasillero(i, j, k).estaLibre()) {
//						cantidadDeCasillerosLibres++;
//					}
//				}
//			}
//		}
//		return cantidadDeCasillerosLibres;
//	}
//
//	/**
//	 * post: Devuelve una matriz 3x3x3 con los vecinos del casillero en la posición (x, y, z).
//	 * La posición central [1][1][1] corresponde al propio casillero (x, y, z),
//	 * y contendrá null.
//	 * pre: Las coordenadas (x, y, z) deben estar dentro de los límites del tablero.
//	 *
//	 * @param x coordenada x
//	 * @param y coordenada y
//	 * @param z coordenada z
//	 * @return una matriz tridimensional con los casilleros vecinos (o null donde no haya).
//	 */
//	@SuppressWarnings("unchecked")
//	public Casillero3D<T>[][][] getVecinosDe(int x, int y, int z) {
//		ValidacionesUtiles.validarRangoNumerico(x, 1, getAncho(), "x");
//		ValidacionesUtiles.validarRangoNumerico(y, 1, getAlto(), "y");
//		ValidacionesUtiles.validarRangoNumerico(z, 1, getProfundo(), "z");
//
//		Casillero3D<T>[][][] vecinos = (Casillero3D<T>[][][]) new Casillero3D[3][3][3];
//
//		for (int dx = -1; dx <= 1; dx++) {
//			for (int dy = -1; dy <= 1; dy++) {
//				for (int dz = -1; dz <= 1; dz++) {
//					int coordenadaX = x + dx;
//					int coordenadaY = y + dy;
//					int coordenadaZ = z + dz;
//
//					if (dx == 0 && dy == 0 && dz == 0) {
//						vecinos[dx + 1][dy + 1][dz + 1] = null;
//						continue;
//					}
//
//					if (coordenadaX < 1 || coordenadaX > getAncho()
//					|| coordenadaY < 1 || coordenadaY > getAlto()
//					|| coordenadaZ < 1 || coordenadaZ > getProfundo()) {
//						vecinos[dx + 1][dy + 1][dz + 1] = null;
//					} else {
//						vecinos[dx + 1][dy + 1][dz + 1] = getCasillero(coordenadaX, coordenadaY, coordenadaZ);
//					}
//				}
//			}
//		}
//
//		return vecinos;
//	}
//
//	/**
//	 * post: Devuelve el casillero que se encuentra en el centro del tablero.
//	 * @return el casillero del centro del tablero.
//	 */
//	public Casillero3D<T> getCentro() {
//		return this.getCasillero(getAlto() / 2, getAncho() / 2, getProfundo() / 2);
//	}
//
//	/**
//	 * post: Devuelve true si (x, y, z) se encuentra dentro de los límites del tablero.
//	 */
//	public boolean dentroDeLimites(int x, int y, int z) {
//		return x >= 1 && x <= getAncho()
//			&& y >= 1 && y <= getAlto()
//			&& z >= 1 && z <= getProfundo();
//	}
//
//	/**
//	 * post: Devuelve el Casillero3D en la posición indicada, o null si está fuera de rango.
//	 */
//	public Casillero3D<T> getCasilleroSeguro(int x, int y, int z) {
//		if (!dentroDeLimites(x, y, z)) return null;
//		return getCasillero(x, y, z);
//	}
//
//	/**
//	 * post: Devuelve una lista con todos los casilleros dentro del rango de visión dado.
//	 */
//	public List<Casillero3D<T>> getCasillerosEnRango(int x, int y, int z, int rango) {
//		List<Casillero3D<T>> visibles = new ListaSimplementeEnlazada<>();
//		for (int dx = -rango; dx <= rango; dx++) {
//			for (int dy = -rango; dy <= rango; dy++) {
//				for (int dz = -rango; dz <= rango; dz++) {
//					int nx = x + dx, ny = y + dy, nz = z + dz;
//					if (dentroDeLimites(nx, ny, nz)) {
//						visibles.add(getCasillero(nx, ny, nz));
//					}
//				}
//			}
//		}
//		return visibles;
//	}
//
//    public List<List<Casillero3D<T>>> getCasillerosPorProfunidad(int profundidad) {
//        ValidacionesUtiles.validarRangoNumerico( profundidad,1, this.getProfundo(), "profundidad");
//        //todos done z valga la profundidad
//        List<List<Casillero3D<T>>> resultado = new ListaSimplementeEnlazada<List<Casillero3D<T>>>();
//        for(int i = 0; i < getAncho(); i++){
//            var fila = new ListaSimplementeEnlazada<Casillero3D<T>>();
//
//            for(int j = 0; j < getAlto(); j++){
//                var casilleroIterado = this.casilleros.get(i).get(j).get(profundidad-1);
//                fila.add(casilleroIterado);
//            }
//            resultado.add(fila);
//        }
//        return resultado;
//    }
//
//	//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
//	//SETTERS SIMPLES ----------------------------------------------------------------
//
//}
