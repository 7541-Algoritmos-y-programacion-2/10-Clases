package RolgarII.juego.jugada.jugadaMover;

import RolgarII.juego.jugada.Jugada;
import RolgarII.juego.turno.Turno;

public class JugadaPasarTurno implements Jugada {

    @Override
    public void ejecutar(Turno turno) {
        while (!turno.estaTerminado()) {
            turno.consumirMovimiento();
        }
    }
}