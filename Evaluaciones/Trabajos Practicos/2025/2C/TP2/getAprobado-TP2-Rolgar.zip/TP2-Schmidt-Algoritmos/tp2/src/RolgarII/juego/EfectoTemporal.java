package RolgarII.juego;

/**
 * pre: turnos > 0 y alExpirar no es null.
 * post: Representa un efecto que se ejecutará cuando los turnos lleguen a cero.
 */
public class EfectoTemporal {
    private int turnosRestantes;
    private final Runnable alExpirar;

    /**
     * pre: turnos > 0, alExpirar no es null.
     * post: Crea un efecto temporal con turnos iniciales y acción al expirar.
     */
    public EfectoTemporal(int turnos, Runnable alExpirar) {
        this.turnosRestantes = turnos;
        this.alExpirar = alExpirar;
    }

    /**
     * pre: turnosRestantes >= 0.
     * post: Reduce en 1 la cantidad de turnos restantes si es mayor a 0.
     */
    public void avanzarTurno() {
        if (turnosRestantes > 0) {
            turnosRestantes--;
        }
        if(estaExpirado()){
            this.ejecutarAlExpirar();
        }
    }

    /**
     * post: Devuelve verdadero si el efecto ya expiró (turnosRestantes <= 0).
     */
    public boolean estaExpirado() {
        return turnosRestantes <= 0;
    }

    /**
     * post: Ejecuta la acción asociada al efecto temporal.
     */
    public void ejecutarAlExpirar() {
        if (alExpirar != null) {
            alExpirar.run();
        }
    }
}