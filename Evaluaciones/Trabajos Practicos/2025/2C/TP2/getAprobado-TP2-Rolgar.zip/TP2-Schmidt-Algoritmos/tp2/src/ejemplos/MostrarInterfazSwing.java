package ejemplos;

import RolgarII.carta.Carta;
import RolgarII.carta.CartaFactory;
import RolgarII.dificultadJuego.JSONDificultadJuegoRepository.JSONDificultadJuegoRepository;
import RolgarII.interfazUsuario.BitmapInterfazUsuario.BitMapInterfazJuego;
import RolgarII.interfazUsuario.InterfazJuego;
import RolgarII.juego.Juego;
import RolgarII.juego.turno.Turno;
import RolgarII.jugador.JugadorDeRolgar;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;
import RolgarII.tablero.JSONTableroRepository.JSONTableroRepository;
import RolgarII.tablero.TableroDeRolgar;

public class MostrarInterfazSwing {

    public static void main(String[] args) {
        InterfazJuego interfaz = new BitMapInterfazJuego();

        var cartasJugador1 = new ListaSimplementeEnlazada<Carta>();
        cartasJugador1.add(CartaFactory.aleatoria());
        cartasJugador1.add(CartaFactory.aleatoria());
        cartasJugador1.add(CartaFactory.aleatoria());
        var jugador1 = new JugadorDeRolgar(
            "Jugador1",
            50,
            cartasJugador1,
            3,
            25,
            25,
            5, 5, 2,
            200,
            5
        );

        var cartasJugador2 = new ListaSimplementeEnlazada<Carta>();
        cartasJugador2.add(CartaFactory.aleatoria());
        cartasJugador2.add(CartaFactory.aleatoria());
        cartasJugador2.add(CartaFactory.aleatoria());
        var jugador2 = new JugadorDeRolgar(
            "Jugador2",
            50,
            cartasJugador2,
            3,
            25,
            25,
            5, 4, 2,
            200,
            5
        );

        var tablero = new TableroDeRolgar(6,8,6,1);
        tablero.getCasillero(5,5,2).ocupar(jugador1);
        tablero.getCasillero(5,4,2).ocupar(jugador2);

        var listaDeJugadores = new ListaSimplementeEnlazada<JugadorDeRolgar>();
        listaDeJugadores.add(jugador1);
        listaDeJugadores.add(jugador2);

        var juego = new Juego(listaDeJugadores,tablero,interfaz,new JSONDificultadJuegoRepository(),new JSONTableroRepository());
        juego.renderizarTablero(jugador1,new Turno(juego,jugador2,2));

        var cartasDeEjemplo = new ListaSimplementeEnlazada<Carta>();
        cartasDeEjemplo.add(CartaFactory.aleatoria());
        cartasDeEjemplo.add(CartaFactory.aleatoria());
        cartasDeEjemplo.add(CartaFactory.aleatoria());
        cartasDeEjemplo.add(CartaFactory.aleatoria());
    }
}
