package RolgarII.preguntas;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import RolgarII.validacionesUtiles.ValidacionesUtiles;

public class Pregunta {
    private String pregunta;
    private String respuestaCorrecta;
    private final List<String> opciones;
    private final List<Integer> indicesSinUsar;
    private final Path csv;

    /**
     * Devuelve el objeto Pregunta con una pregunta ya cargada
     * @param path el path donde esta el archivo csv con los campos pregunta,opcionCorrecta,opcion1,opcion2,opcion3
     */
    public Pregunta(String path) {
        csv=Path.of(path);
        System.out.println("Buscando CSV en: " + csv.toAbsolutePath());
        limpiarLineasVacias(csv);
        opciones = new ArrayList<>();
        indicesSinUsar = new ArrayList<>();
        cargarIndices();
        generarPregunta();
    }

    /**
     * @return Devuelve la pregunta en un string
     */
    public String getPregunta() {
        return this.pregunta;
    }

    /**
     * @return devuelve una lista con las opciones desordenadas
     */
    public List<String> getOpciones() {
        return new ArrayList<>(this.opciones);
    }

    /**
     * Verficica que la lista no este vacia en caso de que lo este la vuelve a cargar
     * remueve el primer elemento y lo retorna
     * @return retorna un indice aleatorio sin repetir
     */
    private int getIndiceNoRepetido(){
        if(indicesSinUsar.isEmpty()){
            cargarIndices();
        }
        return this.indicesSinUsar.remove(0);
    }


    /**
     * Devuelve una linea segun su indice
     * @param csv ruta donde se va leer la pregunta
     * @param indice indice de la linea
     * @return una linea del csv
     */
    private String leerLinea(Path csv, int indice) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(csv)) {
            for (int i = 0; i < indice; i++) {
                br.readLine();
            }
            return br.readLine();
        }
    }



    /**
     * Obtiene una linea aleatoria y actualiza todos los atributos de la clase
     */
    public void generarPregunta(){
        try {
            String[] campos = leerLinea(csv, getIndiceNoRepetido()).split(",", 5);
            validarColumnas(campos.length);

            this.pregunta = campos[0];
            this.respuestaCorrecta = campos[1];

            this.opciones.clear();
            this.opciones.addAll(Arrays.asList(campos).subList(1, 5));
            Collections.shuffle(this.opciones);

        } catch (IOException e) {
            throw new RuntimeException("Error al leer campos de pregunta ", e);
        }
    }



    /**
     * compara la respuesta correcta con la pasada por parametro ambas normalizadas
     * @param respuesta respuesta a evaluar
     * @return true sin la respuesta es correcta
     */
    public boolean verificaRespuestaCorrecta(String respuesta){
        ValidacionesUtiles.esDistintoDeNull(respuesta, "respuesta");
        return this.respuestaCorrecta.trim().equalsIgnoreCase(respuesta.trim());
    }


    /**
     * Cuenta el total de linea del archivo
     * @return cantidad de lineas del archivo
     */
    private int contarLineas(Path csv){
        try (var lines = Files.lines(csv)) {
            return (int) lines.count();
        }catch (IOException e) {
            throw new RuntimeException("Error al contar la cantidad de lineas ",e);
        }
    }



    /**
     * Carga la lista de indicesSinUsar con el total de indices en el archivo csv
     */
    private void cargarIndices(){
        int total = contarLineas(csv);
        indicesSinUsar.clear();
        for (int i = 0; i < total; i++) {
            indicesSinUsar.add(i);
        }
        Collections.shuffle(indicesSinUsar);
    }

    /**
     * Limpia las lineas vacias del archivo
     * @param csv archivo csv
     */
    private void limpiarLineasVacias(Path csv) {
        try {
            List<String> lineasLimpias = Files.readAllLines(csv)
                    .stream()
                    .filter(line -> !line.trim().isEmpty())
                    .toList();

            Files.write(csv, lineasLimpias);
        } catch (IOException e) {
            throw new RuntimeException("No se pudo limpiar el CSV", e);
        }
    }

    private void validarColumnas(int columnas){
        if (columnas != 5) {
            throw new IllegalStateException("Linea invalida (se esperaban 5 columnas)");
        }
    }

}