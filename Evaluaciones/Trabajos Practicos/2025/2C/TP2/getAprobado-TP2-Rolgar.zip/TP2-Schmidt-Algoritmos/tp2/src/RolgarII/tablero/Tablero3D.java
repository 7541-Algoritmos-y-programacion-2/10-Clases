package RolgarII.tablero;

import RolgarII.casillero.Casillero3D;
import RolgarII.validacionesUtiles.ValidacionesUtiles;
import RolgarII.shared.estructuras.ListaSimplementeEnlazada;

import java.util.List;

public class Tablero3D<T> {

    private final ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<Casillero3D<T>>
                    >
            > casilleros;

    private final int ancho;
    private final int alto;
    private final int profundo;

    public List<List<Casillero3D<T>>> getCasillerosPorProfunidad(int profundidad) {
        ValidacionesUtiles.validarRangoNumerico( profundidad,1, this.getProfundo(), "profundidad");
        //todos done z valga la profundidad
        List<List<Casillero3D<T>>> resultado = new ListaSimplementeEnlazada<List<Casillero3D<T>>>();
        for(int i = 0; i < getAncho(); i++){
            var fila = new ListaSimplementeEnlazada<Casillero3D<T>>();

            for(int j = 0; j < getAlto(); j++){
                var casilleroIterado = this.casilleros.get(i).get(j).get(profundidad-1);
                fila.add(casilleroIterado);
            }
            resultado.add(fila);
        }
        return resultado;
    }
    /**
     * pre: ancho, alto y profundo deben ser > 0.
     * post: Crea un tablero 3D vacío con dimensiones dadas y casilleros sin valor por defecto.
     */
    public Tablero3D(int ancho, int alto, int profundo) {
        this(ancho, alto, profundo, null);
    }

    /**
     * pre: ancho, alto y profundo deben ser > 0.
     * post: Crea un tablero 3D inicializado con un valor por defecto para cada casillero.
     */
    public Tablero3D(int ancho, int alto, int profundo, T valorPorDefecto) {
        ValidacionesUtiles.validarMayorACero(ancho, "ancho");
        ValidacionesUtiles.validarMayorACero(alto, "alto");
        ValidacionesUtiles.validarMayorACero(profundo, "profundo");

        this.ancho = ancho;
        this.alto = alto;
        this.profundo = profundo;

        casilleros = new ListaSimplementeEnlazada<>();

        for (int x = 1; x <= ancho; x++) {
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<Casillero3D<T>>
                    > columna = new ListaSimplementeEnlazada<>();

            for (int y = 1; y <= alto; y++) {
                ListaSimplementeEnlazada<Casillero3D<T>> fila = new ListaSimplementeEnlazada<>();

                for (int z = 1; z <= profundo; z++) {
                    fila.add(new Casillero3D<>(valorPorDefecto, x, y, z));
                }

                columna.add(fila);
            }

            casilleros.add(columna);
        }
    }

    /**
     * post: Devuelve la estructura completa de casilleros del tablero.
     */
    public ListaSimplementeEnlazada<
            ListaSimplementeEnlazada<
                    ListaSimplementeEnlazada<Casillero3D<T>>
                    >
            > getCasilleros() {
        return casilleros;
    }

    /**
     * pre: x ∈ [1, ancho], y ∈ [1, alto], z ∈ [1, profundo].
     * post: Devuelve el casillero ubicado en (x,y,z).
     */
    public Casillero3D<T> getCasillero(int x, int y, int z) {
        ValidacionesUtiles.validarRangoNumerico(x, 1, ancho, "x");
        ValidacionesUtiles.validarRangoNumerico(y, 1, alto, "y");
        ValidacionesUtiles.validarRangoNumerico(z, 1, profundo, "z");

        return casilleros.get(x-1).get(y-1).get(z-1);
    }

    /**
     * pre: ninguna.
     * post: Devuelve true si (x,y,z) está dentro de los límites del tablero.
     */
    public boolean dentroDeLimites(int x, int y, int z) {
        return x >= 1 && x <= ancho &&
                y >= 1 && y <= alto &&
                z >= 1 && z <= profundo;
    }

    /**
     * post: Devuelve el ancho del tablero.
     */
    public int getAncho() { return ancho; }

    /**
     * post: Devuelve el alto del tablero.
     */
    public int getAlto() { return alto; }

    /**
     * post: Devuelve la profundidad del tablero.
     */
    public int getProfundo() { return profundo; }
}

