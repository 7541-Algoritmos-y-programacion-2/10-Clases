package ar.uba.fi.cb100.c2025_02.semana02.jueves;

import java.time.Duration;

import ar.uba.fi.cb100.c2025_02.semana01.jueves.Alumno;
import ar.uba.fi.cb100.c2025_02.semana01.jueves.Guia01;

public class Guia01_Parte02 {

	public static void main(String[] args) {
		ejercicio12(1525846L);
		
		ejercicio12ConVector("Hola");
		ejercicio12ConVector("Hola", 1L);
		ejercicio12ConVector("Hola", 1L, 1L, 1L, 1L);
		
		Alumno alumno = new Alumno();
		int a = 0;
	}
	
	public static void ejercicio12ConVector(String texto, long... vector) {
		for(int i = 0; i < vector.length; i++) {
			Guia01.imprimir(texto + " - " + vector[i]);
		}
		
	}
	
	public static void ejercicio12(long totalSegundos) {
		Duration duracion = Duration.ofSeconds(totalSegundos);
		
		long dias = duracion.toDays();
		long horas = duracion.toHoursPart();
		long minutos = duracion.toMinutesPart();
		long segundos = duracion.toSecondsPart();
		
		String salida = String.format("%d dias, %d horas, %d minutos, %d segundos", dias, horas, minutos, segundos);
		Guia01.imprimir(salida);
		String[] split = salida.split(",");
		Guia01.imprimir("[" + String.join(", ", split) + "]");
	}
	
	
}
