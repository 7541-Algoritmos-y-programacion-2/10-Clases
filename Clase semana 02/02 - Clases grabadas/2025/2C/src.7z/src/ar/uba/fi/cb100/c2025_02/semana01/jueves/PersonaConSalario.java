package ar.uba.fi.cb100.c2025_02.semana01.jueves;

public class PersonaConSalario {

	public String nombre;
	public double salario;
}
