package ar.uba.fi.cb100.semana02.miercoles;

public class Entero {
	public int valor;
	public int valor1;
	public int valor2;
}
