package ar.uba.fi.cb100.semana04.jueves;

public enum TipoDeTransaccion {
	INGRESO,
	EGRESO
}
