package ar.uba.fi.cb100.c2025_02.semana07.miercoles;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;

public class Principal13 {

	public static void main(String[] args) {
		{
			Cuadrado cuadrado = new Cuadrado();
			cuadrado.setBase(10);
			cuadrado.setAltura(10);
			cuadrado.getArea();
			
			Figura figura1 = new Cuadrado(10, 10);
			figura1.getArea();
						
			Figura figura2 = new Cuadrado();
			((Cuadrado) figura2).setBase(10);
			((Cuadrado) figura2).setAltura(10);
			figura2.getArea();
			
			Figura figura3 = new Cuadrado();
			if (figura3 instanceof Cuadrado cuadrado3) {
				cuadrado3.setBase(10);
				cuadrado3.setAltura(10);				
			}
			if (figura3 instanceof Cuadrado) {
				Cuadrado cuadrado3 = (Cuadrado) figura3;
				cuadrado3.setBase(10);
				cuadrado3.setAltura(10);				
			}
			figura3.getArea();
			
			Cuadrado cuadrado4 = new Cuadrado();
			cuadrado4.setBase(10);
			cuadrado4.setAltura(10);
			Figura figura4 = cuadrado4;
			figura4.getArea();
			
			Figura figura5Punto = new Figura() {
				@Override
				public double getArea() {
					return 0;
				}				
			};
		}
		{
			List<String> lista = new ListaSimplementeEnlazada<String>();
		}
		{
			//Recorridos con cursor
			ListaSimplementeEnlazada<String> lista = new ListaSimplementeEnlazada<String>();
			//Recorrido con cursor (casero)
			lista.iniciarCursor();
			while (lista.avanzarCursor()) {
				
			}
			
			lista.add("Hola");
			lista.add("Mundo");
			//Recorrido con for
			for(String valor: lista) {
				System.out.println(valor);
			}
			
			Object[] vectorDeObjeto = lista.toArray();
			String[] vectorDeStrings = lista.toArray(new String[0]);
			
			//Recorrido con iterador
			Iterator<String> iterador = lista.iterator();
			while (iterador.hasNext()) {
				String elemento = iterador.next();
				System.out.println( elemento );
			}
			
			List<String> lista1 = new ListaSimplementeEnlazada<String>();
			lista1.add("A");
			lista1.add("B");
			lista1.add("C");
			lista1.add("D");
			
			List<String> lista2 = new ListaSimplementeEnlazada<String>();
			lista2.add("A");
			lista2.add("B");
			lista2.add("C");
			
			lista1.retainAll(lista2);
			Iterator<String> iterador1 = lista1.iterator();
			while (iterador1.hasNext()) {
				String elemento = iterador1.next();
				System.out.println( elemento );
				if (elemento.equals("A")) {
					iterador1.remove();
				}
			}
			
			{
				List<Integer> lista6 = new ListaSimplementeEnlazada<Integer>();
				lista6.add(10);
				lista6.add(20);
				lista6.add(30);
				lista6.add(10);
				lista6.add(40);
				lista6.add(50);
				lista6.add(10);

				System.out.println(contarApariciones(lista6, 10));
				
				Collections.sort(lista6);
				
				Collections.sort(lista6, new Comparator<Integer>() {
					@Override
					public int compare(Integer o1, Integer o2) {
						
						return o1.compareTo(o2);
					}
				});
			}
		}
	}

	public static long contarApariciones(List<Integer> lista, Integer valor) {
		{ //NOOOOOOOOOOOOOOOOOOO USAR
			int resultado = 0;
			for(int i = 0; i < lista.size(); i++) {
				if (lista.get(i).equals(valor)) {
					resultado++;
				}
			}
			//return resultado;
		}
		{//Iterador
			long resultado = 0;
			Iterator<Integer> iterador = lista.iterator();
			while (iterador.hasNext()) {
				if (iterador.next().equals(valor)) {
					resultado++;
				}
			}
			//return resultado;
		}
		
		{//ListIterator
			long resultado = 0;
			ListIterator<Integer> listIterator = lista.listIterator();
			while (listIterator.hasNext()) {
				if (listIterator.next().equals(valor)) {
					resultado++;
				}
			}
			//return resultado;
		}
		
		{//For each
			long resultado = 0;
			for(Integer actual: lista) {
				if (actual.equals(valor)) {
					resultado++;
				}
			}
			//return resultado;
		}
		
		//Stream
		return lista.stream()
				    	.filter(s -> s.equals(valor))
						.count();
	}
	
}
