package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea01.tablero;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class TableroDeAjedrez {
    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------

    private Resultado[][] tablero;

    //ATRIBUTOS -----------------------------------------------------------------------------------------------
    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
    //CONSTRUCTORES -------------------------------------------------------------------------------------------

    /**
     * post: Inicializa el tablero de ajedrez a partir de la cantidad de
     * jugadores dada.
     * pre: La cantidad de jugadores debe ser mayor a cero.
     * @param cantidadDeJugadores: cantidad de jugadores del torneo.
     */
    public TableroDeAjedrez(int cantidadDeJugadores) {
        ValidacionesUtiles.validarMayorAUno(cantidadDeJugadores, "cantidadDeJugadores");
        this.inicializarTablero(cantidadDeJugadores);
    }

    //MÉTODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //MÉTODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
    //MÉTODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
    //MÉTODOS DE CLASE ----------------------------------------------------------------------------------------
    //MÉTODOS GENERALES ---------------------------------------------------------------------------------------

    @Override
    public String toString() {
        String res = "";
        for (int i = 0; i < this.tablero.length; i++) {
            for (int j = 0; j < this.tablero[0].length; j++) {
                if (i == j) {
                    res = res + "                   \t";
                } else {
                    res = res + "(" + i + ", " + j + "): " + this.tablero[i][j] + "\t";
                }
            }
            res += System.lineSeparator();
        }
        return res;
    }

    //MÉTODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

    /**
     * post: Indica si el torneo está terminado.
     * @return verdadero si el torneo está finalizado.
     */
    public boolean estaFinalizadoElTorneo() {
        for (int i = 0; i < this.tablero.length; i++) {
            for (int j = 0; j < this.tablero.length; j++) {
                if ((i != j) &&
                	(tablero[i][j] == Resultado.PENDIENTE)) {
                	return false;
                }
            }
        }
        return true;
    }

    /**
     * post: Devuelve el puntaje del jugador cuyo número es dado.
     * @param numeroJugador: número del jugador
     * @return el puntaje del jugador.
     * @throws RuntimeException si el número del jugador es inválido.
     */
    public int getPuntajeDelJugador(int numeroDeJugador) {
    	ValidacionesUtiles.validarRangoNumerico(numeroDeJugador, 
    												1, 
    												this.tablero.length,    												
    												"'numeroJugador'");
    	int indiceJugador = numeroDeJugador - 1;        
        int total = 0;
        for (int i = 0; i < this.tablero.length; i++) {
            total += this.getPuntaje(ColorDeFicha.BLANCAS, this.tablero[indiceJugador][i]) +
        			 this.getPuntaje(ColorDeFicha.NEGRAS, this.tablero[i][indiceJugador]);
        }
        return total;
    }

    /**
     * post: Devuelve el número del jugador ganador del torneo, si el torneo
     * está terminado.
     * @return el número del ganador.
     * @throws RuntimeException si el torneo no está terminado.
     */
    public int getJugadorGanador() {
        this.validarEstadoDelTorneo(true);
        Integer jugadorGanador = null;

        for (int i = 1; i <= this.tablero.length ; i++) {
        	if ((jugadorGanador == null) ||
        		(this.getPuntajeDelJugador(jugadorGanador) < this.getPuntajeDelJugador(i))) {
        		jugadorGanador = i;
        	}
        }
        return jugadorGanador;
    }

    /**
     * Carga un resultado en el tablero para los jugadores dados
     * @param jugadorDeBlancas
     * @param jugadorDeNegras
     * @param resultado
     */
    public void cargarResultado(int jugadorDeBlancas, int jugadorDeNegras, Resultado resultado) {
    	validarEstadoDelTorneo(false);
        ValidacionesUtiles.validarRangoNumerico(jugadorDeBlancas, 1, this.tablero.length, "'jugadorDeBlancas'");
        ValidacionesUtiles.validarRangoNumerico(jugadorDeNegras, 1, this.tablero.length, "'jugadorDeBlancas'");
        ValidacionesUtiles.validarVerdadero( jugadorDeBlancas != jugadorDeNegras, "jugadores distintos");
        ValidacionesUtiles.validarRangoDeEnum( resultado, Resultado.GANAN_BLANCAS, Resultado.GANAN_NEGRAS, Resultado.TABLAS);
        //ValidacionesUtiles.validarRangoDeEnum(this.tablero[jugadorDeBlancas-1][jugadorDeNegras-1], Resultado.PENDIENTE);
        this.tablero[jugadorDeBlancas-1][jugadorDeNegras-1] = resultado;
    }
    
    /**
     * Anula una partida mientra el torneo se este jugando
     * @param jugadorDeBlancas
     * @param jugadorDeNegras
     */
    public void anularPartida(int jugadorDeBlancas, int jugadorDeNegras) {
    	validarEstadoDelTorneo(false);
        ValidacionesUtiles.validarRangoNumerico(jugadorDeBlancas, 1, this.tablero.length, "'jugadorDeBlancas'");
        ValidacionesUtiles.validarRangoNumerico(jugadorDeNegras, 1, this.tablero.length, "'jugadorDeBlancas'");
        ValidacionesUtiles.validarVerdadero( jugadorDeBlancas != jugadorDeNegras, "jugadores distintos");
        this.tablero[jugadorDeBlancas-1][jugadorDeNegras-1] = Resultado.ANULADO;    	
    }
    
    //MÉTODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    //GETTERS SIMPLES -----------------------------------------------------------------------------------------
    //MÉTODOS PRIVADOS -----------------------------------------------------------------------------------------

    /**
     * post: Inicializa el tablero de resultados.
     * @param cantidadDeJugadores la cantidad de jugadores del torneo.
     */
    private void inicializarTablero(int cantidadDeJugadores) {
        this.tablero = new Resultado[cantidadDeJugadores][cantidadDeJugadores];
        for (int i = 0; i < cantidadDeJugadores; i++) {
            for (int j = 0; j < cantidadDeJugadores; j++) {
            	this.tablero[i][j] = (i != j) ? Resultado.PENDIENTE : null;
            }
        }
    }

    /**
     * post: Devuelve el puntaje del jugador con piezas blancas correspondiente,
     * según el resultado.
     * @param resultado: el resultado de la partida.
     * @return el puntaje del jugador con blancas.
     */
    public int getPuntaje(ColorDeFicha color, Resultado resultado) {
    	if (resultado != null) {
	        switch (resultado) {
	            case GANAN_BLANCAS: if (color.equals(ColorDeFicha.BLANCAS)) {
							        	return 3;
							        }
	            					return 0;
	            case GANAN_NEGRAS: if (color.equals(ColorDeFicha.BLANCAS)) {
							        	return 0;
							        }
									return 3;
	            case TABLAS: return 1;
	            case ANULADO: return -1;
	            default: return 0;
	        }
    	}
        return 0;
    }

    /**
     * post: Determina si el torneo está terminado.
     */
    private void validarEstadoDelTorneo(boolean finalizado) {
    	Boolean estaFinalizado = this.estaFinalizadoElTorneo(); 
        if (!estaFinalizado.equals(finalizado)) {
       		throw new RuntimeException("El torneo no está terminado");
        }
        
    }
}