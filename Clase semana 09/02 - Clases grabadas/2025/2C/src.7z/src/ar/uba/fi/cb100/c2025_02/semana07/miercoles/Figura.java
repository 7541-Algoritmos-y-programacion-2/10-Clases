package ar.uba.fi.cb100.c2025_02.semana07.miercoles;

public interface Figura {

	public double getArea();
}
