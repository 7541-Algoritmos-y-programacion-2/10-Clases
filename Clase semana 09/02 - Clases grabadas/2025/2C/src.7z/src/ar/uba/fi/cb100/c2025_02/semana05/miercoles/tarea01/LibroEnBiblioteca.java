package ar.uba.fi.cb100.c2025_02.semana05.miercoles.tarea01;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1.Libro;

public class LibroEnBiblioteca {
    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
    //ATRIBUTOS -----------------------------------------------------------------------------------------------
    private Libro libro = null;
    private int cantidadDeCopias;



    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
    //CONSTRUCTORES -------------------------------------------------------------------------------------------
    public LibroEnBiblioteca(Libro libro, int cantidadDeCopias){
        this.libro = libro;
        this.cantidadDeCopias = cantidadDeCopias;

    }
    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
    //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
    //METODOS DE CLASE ----------------------------------------------------------------------------------------
    //METODOS GENERALES ---------------------------------------------------------------------------------------
    //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
    /**
     * aumenta la cantidad de copias del libro que hay en la biblioteca
     * @param cantidad tiene que ser mayor o igual a 0
     */
    public void aumentarCopias(int cantidad) {
        ValidacionesUtiles.validarMayorOIgualACero(cantidad, "el numero de copias");
        this.cantidadDeCopias += cantidad;
    }

    /**
     * disminuye la cantidad de copias del libro que hay en la biblioteca
     * @param cantidad tiene que ser mayor 0 y la cantidad de copias tiene que ser mayor a la cantidad pedida
     */
    public void disminuirCopias(int cantidad) {
        ValidacionesUtiles.validarMayorACero(cantidad, "el numero de copias");
        ValidacionesUtiles.validarVerdadero(this.cantidadDeCopias > cantidad, "no hay suficientes copias para prestar");
        this.cantidadDeCopias -= cantidad;
    }


    /**
     *
     * @param texto tiene que tener entre 1 y 100 caracteres
     * @return devuelve true si el libro esta en la biblioteca
     */
    public boolean estaEnBiblioteca(String texto) {
        ValidacionesUtiles.validarLongitudDeTexto(texto, 1, 100, "titulo del libro");
        return this.libro.contiene(texto);
    }


    //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    //GETTERS SIMPLES -----------------------------------------------------------------------------------------
    /**
     *
     * @return devuelve el libro
     */
    public Libro getLibro() {
        return this.libro;
    }
    /**
     *
     * @return devuelve el numero de copias del libro
     */
    public int getCantidadDeCopias() {
        return this.cantidadDeCopias;
    }
    //SETTERS COMPLEJOS----------------------------------------------------------------------------------------
    //SETTERS SIMPLES -----------------------------------------------------------------------------------------


}
