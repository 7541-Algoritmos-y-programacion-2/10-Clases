package ar.uba.fi.cb100.c2025_02.semana05.jueves;

import java.util.Arrays;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Tablero {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private String titulo = null;
	private Casillero[][][] casilleros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Tablero(int ancho, int alto) {
		this("Sin titulo", ancho, alto, 1);
	}
	
	/**
	 * Crea un tablero de casillero de tamaño alto x ancho
	 * @param ancho
	 * @param alto
	 */
	public Tablero(String titulo, int ancho, int alto, int profundo) {
		ValidacionesUtiles.validarMayorACero(ancho, "ancho");
		ValidacionesUtiles.validarMayorACero(alto, "alto");
		this.casilleros = new Casillero[ancho][alto][profundo];
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				for(int k = 0; k < this.getProfundo(); k++) {
					this.casilleros[i][j][k] = new Casillero();
				}
			}
		}
		this.titulo = titulo;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------		
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Tablero de " + this.getAncho() + " x " + this.getAlto();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(casilleros);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tablero other = (Tablero) obj;
		return Arrays.deepEquals(casilleros, other.casilleros);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public Casillero getCasillero(int x, int y) {
		return this.getCasillero(x, y, 1);
	}
	
	/**
	 * Devuelve un casillero en la posicion (x, y)
	 * @param x: de 1 a ancho
	 * @param y: de 1 a alto
	 * @return
	 */
	public Casillero getCasillero(int x, int y, int z) {
		ValidacionesUtiles.validarMayorACero(x, "X");
		ValidacionesUtiles.validarMayorACero(y, "Y");
		ValidacionesUtiles.validarMayorACero(z, "Z");
		return this.casilleros[x-1][y-1][z-1];
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------

	/**
	 * Devuelve el ancho del tablero
	 * @return
	 */
	public int getAncho() {
		return this.casilleros.length;
	}
	
	/**
	 * Devuelve el alto del tablero
	 * @return
	 */
	public int getAlto() {
		return this.casilleros[0].length;
	}

	public String getTitulo() {
		return titulo;
	}
	
	public int getProfundo() {
		return this.casilleros[0][0].length;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
