package test.ar.uba.fi.cb100.c2025_02.estructuras.bitmap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.bitmap.Bitmap;
import ar.uba.fi.cb100.c2025_02.material.utiles.SistemaUtiles;

public class TestBitmap {

    private Bitmap bmp;
    private final Color RED = Color.RED;
    private final String TMP_FILE = "test_output.bmp";

    @BeforeEach
    public void setUp() {
        bmp = new Bitmap(100, 100);
    }

    @AfterEach
    public void tearDown() {
        File f = new File(TMP_FILE);
        if (f.exists()) f.delete();
    }

    @Test
    public void testDrawPixel() {
        bmp.drawPixel(10, 10, RED);
        int rgb = bmp.getImage().getRGB(10, 10);
        assertEquals(RED.getRGB(), rgb);
    }

    @Test
    public void testDrawLine() {
        bmp.drawLine(0, 0, 10, 0, RED);
        for (int x = 0; x <= 10; x++) {
            assertEquals(RED.getRGB(), bmp.getImage().getRGB(x, 0));
        }
    }

    @Test
    public void testDrawRectangle() {
        bmp.drawRectangle(10, 10, 20, 10, RED);
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(10, 10)); // esquina
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(30, 10)); // otra esquina
    }

    @Test
    public void testDrawCircle() {
        bmp.drawCircle(50, 50, 10, RED);
        // puntos aproximados en la circunferencia
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(60, 50));
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(40, 50));
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(50, 60));
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(50, 40));
    }

    @Test
    public void testDrawText() {
        bmp.drawText("A", 20, 50, new Font("Arial", Font.BOLD, 24), RED, Color.WHITE);
        BufferedImage img = bmp.getImage();

        // Al menos un píxel debería tener el color del texto
        boolean hasRed = false;
        for (int y = 40; y < 60; y++) {
            for (int x = 10; x < 40; x++) {
                if (img.getRGB(x, y) == RED.getRGB()) {
                    hasRed = true;
                    break;
                }
            }
        }
        assertTrue(hasRed, "Debe haberse dibujado texto en el bitmap");
    }

    @Test
    public void testPasteBitmap() {
        Bitmap small = new Bitmap(10, 10);
        small.drawRectangle(0, 0, 9, 9, RED);
        bmp.pasteBitmap(small, 20, 20);
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(20, 20));
    }

    @Test
    public void testSaveAndLoadFile() throws IOException {
        bmp.drawPixel(5, 5, RED);
        String path = bmp.saveToFile(TMP_FILE);
        assertTrue(new File(path).exists());

        Bitmap loaded = Bitmap.loadFromFile(path);
        assertEquals(RED.getRGB(), loaded.getImage().getRGB(5, 5));
    }

    @Test
    public void testDrawLine3D() {
        bmp.drawLine3D(-10, -10, 50, 10, 10, 50, RED);
        // El punto proyectado central debería estar pintado
        int midX = bmp.getImage().getWidth() / 2;
        int midY = bmp.getImage().getHeight() / 2;
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(midX, midY));
    }

    @Test
    public void testDrawCube() {
        bmp.drawCube(50, 0, 0, 50, RED);
        int centerX = bmp.getImage().getWidth() / 2;
        int centerY = bmp.getImage().getHeight() / 2;
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(centerX, centerY));
    }

    @Test
    public void testDrawLetterPattern() {
        // Dibuja una "H" manualmente con líneas
        bmp.drawLine(10, 10, 10, 30, RED);
        bmp.drawLine(20, 10, 20, 30, RED);
        bmp.drawLine(10, 20, 20, 20, RED);

        assertEquals(RED.getRGB(), bmp.getImage().getRGB(10, 20));
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(20, 20));
    }

    @Test
    public void testDrawHouseShape() {
        // Dibuja una casa: cuadrado + triángulo
        bmp.drawRectangle(40, 60, 20, 20, RED); // base
        bmp.drawLine(40, 60, 50, 50, RED);      // techo izq
        bmp.drawLine(60, 60, 50, 50, RED);      // techo der

        assertEquals(RED.getRGB(), bmp.getImage().getRGB(50, 50));
        assertEquals(RED.getRGB(), bmp.getImage().getRGB(40, 60));
    }

    @Test
    public void testGeneral() {
        try {
            Bitmap bmp = new Bitmap(300, 300);

            // Dibuja un píxel
            bmp.drawPixel(10, 10, Color.RED);

            // Dibuja una línea
            bmp.drawLine(20, 20, 100, 100, Color.BLUE);

            // Dibuja un rectángulo
            bmp.drawRectangle(50, 50, 100, 80, Color.GREEN);

            // Dibuja un círculo
            bmp.drawCircle(150, 150, 40, Color.MAGENTA);

            // Escribe un texto
            bmp.drawText("Hola Bitmap!", 10, 200, new Font("Arial", Font.BOLD, 14), Color.WHITE, Color.BLACK);

            // Carga una imagen externa y la pega
            Bitmap ficha = Bitmap.loadFromFile( SistemaUtiles.generarRutaAbsoluta( "src/ar/uba/fi/cb100/c2025_02/material/bitmap/ficha.bmp"));  // Requiere un archivo ficha.png en el mismo directorio
            bmp.pasteBitmap(ficha, 200, 200);

            // Guarda la imagen
            bmp.saveToFile("resultado.bmp");

            
            bmp = new Bitmap(400, 400);
            bmp.drawCube(100, 0, 0, 300, Color.BLUE);
            bmp.drawCube(50, 100, 50, 200, Color.RED);
            System.out.println(bmp.saveToFile("cubo3d.bmp"));

            System.out.println("Cubo 3D dibujado y guardado como cubo3d.png");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
