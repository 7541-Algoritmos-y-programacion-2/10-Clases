package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.parcial_2009.ejercicioBlog;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Comentario {

	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private String 	descripcion = null;
	private int 	calificacion = 0;

	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Dada una descripción y calificación, se crea el comentario.
	 * @param descripcion: Descripcion del comentario
	 * @param calificacion: Calificacion del comentario. Debe estar entre 1 y 10
	 * @return
	 */
	public Comentario(String descripcion, int calificacion) {
		this.setDescripcion(descripcion);
		this.setCalificacion( calificacion );
	}

	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la calificacion del comentario
	 * @return
	 */
	public int getCalificacion() {
		return this.calificacion;
	}

	/**
	 * Deuvelve la descripcion del comentario
	 * @return
	 */
	public String getDescripcion() {
		return descripcion;
	}

//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public void setDescripcion(String descripcion) {
		ValidacionesUtiles.validarNoNulo(descripcion, "La descripción");
		this.descripcion = descripcion;
	}

	public void setCalificacion(int calificacion) {
		ValidacionesUtiles.validarRango(1, calificacion, 10, "La calificación");
		this.calificacion = calificacion;
	}
	
}