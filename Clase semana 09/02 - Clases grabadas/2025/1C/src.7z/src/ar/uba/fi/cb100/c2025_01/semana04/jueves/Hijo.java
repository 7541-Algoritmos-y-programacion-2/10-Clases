package ar.uba.fi.cb100.c2025_01.semana04.jueves;

public class Hijo extends Padre {

	public Hijo() {
		System.out.println("paso por el constructor del hijo");		
	}
	
	@Override
	public double sumar(int numero1) {
		super.sumar(numero1);
		return Double.valueOf(numero1 + this.edad) ;
	}
	
}
