package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.ejercicioTostadora;

public enum EstadoDeTostadora {
	Encendida,
	Apagada
}
