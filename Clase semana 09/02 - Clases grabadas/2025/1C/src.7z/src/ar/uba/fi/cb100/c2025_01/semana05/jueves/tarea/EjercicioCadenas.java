package ar.uba.fi.cb100.c2025_01.semana05.jueves.tarea;

/**
 * Una cadena está compuesta por una secuencia de eslabones.
 * Toda cadena tiene al menos un eslabón. Cada eslabón posee 
 * largo y ancho. Todos los eslabones de la cadena deben 
 * tener el mismo ancho, pero el largo puede diferir. Se
 * debe poder agregar o retirar eslabones de la cadena.
 * Se requiere conocer la longitud total de la cadena.
 * 
 * || Hipotesis: La longitud total de la Cadena está dada 	  ||
 * || por la suma del largo de cada Eslabón. Esta medida es en||
 * || centimetros.											  ||
 * @param args
 */
public class EjercicioCadenas {


	public static void main(String[] args) {
		Eslabon eslabon = new Eslabon(5.0, 10.0);
		Cadena cadena = new Cadena(eslabon,7);
		
		// testing
		for(int i = 1; i < 4; i ++) {
			cadena.agregarEslabon(eslabon); 	// Agrego eslabones de distintas longitudes.
		}
		
		System.out.println(cadena.toString());
		
		for(int i = 0; i < 7; i ++) {
//			 Elimino y agrego eslabones.
			if( i%2 == 0) {
				cadena.retirarEslabon(); 	
			} else {
				cadena.agregarEslabon(eslabon);
			}
		}
		System.out.println(cadena.toString());
		
		// Si se quisiera saber la cantidad de Eslabones de la cadena.
		System.out.println("La cadena tiene " + cadena.getCantidadDeEslabones() + " eslabones.");
		
		
		//Descomentar para ver posibles errores del TDA.
		//
		// cadena.agregarEslabon(4, 2); 		// Eslabón con ancho distinto!
		// cadena.agregarEslabon(3, -1); 		// Eslabón con valor negativo!
		
	}
}
