package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

public interface Contenible<T> {

	public boolean contiene(T dato, Object valor);
}
