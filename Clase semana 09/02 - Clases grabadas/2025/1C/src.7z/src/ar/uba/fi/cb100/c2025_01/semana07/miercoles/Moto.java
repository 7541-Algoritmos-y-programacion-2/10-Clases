package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

public class Moto implements Vehiculo {

	@Override
	public void arrancar() {
		System.out.println("La moto arranca");
	}

	@Override
	public void detener() {
		System.out.println("La moto se detiene");		
	}
	
	@Override
	public void acelerar() {
		System.out.println("La moto acelera");
	}
}
