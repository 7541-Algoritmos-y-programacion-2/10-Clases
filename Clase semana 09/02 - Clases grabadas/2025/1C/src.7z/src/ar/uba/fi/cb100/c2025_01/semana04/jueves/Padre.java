package ar.uba.fi.cb100.c2025_01.semana04.jueves;

public class Padre {

	protected int edad = 0;
	
	public Padre() {
		System.out.println("paso por el constructor del padre");		
	}
	
	public int sumar(int numero1, int numero2) {
		return numero1 + numero2;
	}
	
	public double sumar(int numero1, int numero2, int numero3) {
		return Double.valueOf(numero1 + numero2 + numero3) ;
	}
	
	public double sumar(int numero1) {
		return Double.valueOf(numero1) ;
	}
	
	/**
	 * No es sobrecarga, se tiene que llamar igual
	 * @param numero1
	 * @param numero2
	 * @param numero3
	 * @return
	 */
	public double sumar4(int numero1, int numero2, int numero3) {
		return Double.valueOf(numero1 + numero2 + numero3) ;
	}
}
