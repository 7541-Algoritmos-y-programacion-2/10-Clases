package ar.uba.fi.cb100.c2025_01.semana09.jueves.tarea01;

public enum UnidadDeMedida {
    LITRO,
    KILO
}
