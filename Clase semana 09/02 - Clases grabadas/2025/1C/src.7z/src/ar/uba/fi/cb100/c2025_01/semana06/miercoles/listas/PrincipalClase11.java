package ar.uba.fi.cb100.c2025_01.semana06.miercoles.listas;

import java.util.ArrayList;
import java.util.List;

public class PrincipalClase11 {

	public static void main(String[] args) {
		Lista<String> listaString = new Lista<>();
		listaString.agregar("18");
		listaString.agregar(2, "19");
		
		//Boolean y no boolean;
		//Char y no char
		Lista<Integer> listaInteger = new Lista<>();
		listaInteger.agregar(18);
		listaInteger.agregar(2, 19);
		
	}
}
