package ar.uba.fi.cb100.c2025_01.semana05.miercoles;

public class Clase09 {

	public static int funcion1(int i) {
		return 10 /i;
	}
	
	public static void main(String[] args) throws Exception {
		int i = 0;
		try {
			System.out.println( funcion1(i));
			System.out.print("Posiblemente no se ejecute");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("No se puede");
		} finally {
			try {
				System.out.println("Se ejecuta siempre");
			} catch (Exception e) {
				System.out.println("No se puede");
			}
		}
//		try (abrir el archivo) {
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
	}
}
