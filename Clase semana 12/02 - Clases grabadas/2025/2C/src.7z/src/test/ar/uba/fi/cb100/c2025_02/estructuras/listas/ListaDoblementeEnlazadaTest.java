package test.ar.uba.fi.cb100.c2025_02.estructuras.listas;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaDoblementeEnlazada;

public class ListaDoblementeEnlazadaTest {

    private ListaDoblementeEnlazada<Integer> lista;

    @BeforeEach
    void setUp() {
        lista = new ListaDoblementeEnlazada<>();
    }

    @Test
    void testAddAndSize() {
        assertTrue(lista.isEmpty());
        lista.add(10);
        lista.add(20);
        lista.add(30);
        assertEquals(3, lista.size());
        assertFalse(lista.isEmpty());
    }

    @Test
    void testAddAtIndex() {
        lista.add(10);
        lista.add(30);
        lista.add(1, 20);
        assertEquals(3, lista.size());
        assertEquals(20, lista.get(1));
        assertEquals(30, lista.get(2));
    }

    @Test
    void testGetAndSet() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertEquals(20, lista.get(1));
        assertEquals(20, lista.set(1, 25));
        assertEquals(25, lista.get(1));
    }

    @Test
    void testRemoveByIndex() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertEquals(20, lista.remove(1));
        assertEquals(2, lista.size());
        assertEquals(30, lista.get(1));
    }

    @Test
    void testRemoveByObject() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertTrue(lista.remove((Integer) 20));
        assertFalse(lista.remove((Integer) 40));
        assertEquals(2, lista.size());
    }

    @Test
    void testClear() {
        lista.add(10);
        lista.add(20);
        lista.clear();
        assertTrue(lista.isEmpty());
        assertEquals(0, lista.size());
    }

    @Test
    void testContainsAndContainsAll() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertTrue(lista.contains(20));
        assertFalse(lista.contains(40));

        assertTrue(lista.containsAll(Arrays.asList(10, 20)));
        assertFalse(lista.containsAll(Arrays.asList(10, 40)));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        lista.add(10);
        lista.add(20);
        lista.add(10);

        assertEquals(0, lista.indexOf(10));
        assertEquals(2, lista.lastIndexOf(10));
        assertEquals(-1, lista.indexOf(40));
    }

    @Test
    void testAddAll() {
        lista.addAll(Arrays.asList(10, 20, 30));
        assertEquals(3, lista.size());
        assertEquals(20, lista.get(1));

        lista.addAll(1, Arrays.asList(100, 200));
        assertEquals(5, lista.size());
        assertEquals(100, lista.get(1));
        assertEquals(200, lista.get(2));
    }

    @Test
    void testRemoveAll() {
        lista.addAll(Arrays.asList(10, 20, 30, 40));
        assertTrue(lista.removeAll(Arrays.asList(20, 40)));
        assertEquals(2, lista.size());
        assertFalse(lista.contains(20));
    }

    @Test
    void testRetainAll() {
        lista.addAll(Arrays.asList(10, 20, 30, 40));
        assertTrue(lista.retainAll(Arrays.asList(20, 40, 50)));
        assertEquals(2, lista.size());
        assertTrue(lista.contains(20));
        assertFalse(lista.contains(10));
    }

    @Test
    void testSubList() {
        lista.addAll(Arrays.asList(10, 20, 30, 40, 50));
        List<Integer> sub = lista.subList(1, 4);
        assertEquals(Arrays.asList(20, 30, 40), sub);
    }

    @Test
    void testToArray() {
        lista.addAll(Arrays.asList(10, 20, 30));
        Object[] arr = lista.toArray();
        assertArrayEquals(new Object[]{10, 20, 30}, arr);

        Integer[] arr2 = lista.toArray(new Integer[0]);
        assertArrayEquals(new Integer[]{10, 20, 30}, arr2);
    }

    @Test
    void testIterator() {
        lista.addAll(Arrays.asList(10, 20, 30));
        Iterator<Integer> it = lista.iterator();
        assertTrue(it.hasNext());
        assertEquals(10, it.next());
        assertEquals(20, it.next());
        assertEquals(30, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testListIteratorForwardAndBackward() {
        lista.addAll(Arrays.asList(10, 20, 30));
        ListIterator<Integer> it = lista.listIterator();

        assertTrue(it.hasNext());
        assertEquals(10, it.next());
        assertEquals(20, it.next());

        assertTrue(it.hasPrevious());
        assertEquals(20, it.previous());
        assertEquals(10, it.previous());
    }

    @Test
    void testListIteratorAddSetRemove() {
        lista.addAll(Arrays.asList(10, 20, 30));
        ListIterator<Integer> it = lista.listIterator();

        it.next(); // 10
        it.add(15); // [10, 15, 20, 30]
        assertEquals(4, lista.size());
        assertEquals(15, lista.get(1));

        it.next(); // 20
        it.set(25); // [10, 15, 25, 30]
        assertEquals(25, lista.get(2));

        it.remove(); // elimina 25
        assertEquals(3, lista.size());
        assertEquals(30, lista.get(2));
    }
}