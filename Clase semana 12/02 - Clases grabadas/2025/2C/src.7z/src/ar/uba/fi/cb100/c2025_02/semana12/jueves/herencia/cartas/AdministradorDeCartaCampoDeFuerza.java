package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Juego;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Personaje;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.RolgarII;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Turno;

public class AdministradorDeCartaCampoDeFuerza extends AdministradorDeCarta {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------

	public AdministradorDeCartaCampoDeFuerza(Carta carta) {
		super(carta);
	}

//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	@Override
	public void jugarCarta(Juego juego, Turno turno) {
		if (juego instanceof RolgarII rolgarII) {
			Personaje personaje = rolgarII.getPartida(turno.getJugador()).getPersonaje();
			personaje.incrementarEnergia( getCartaCampoDeFuerza().getValorDelCampoAdicional());
			
			rolgarII.getPartida(turno.getJugador()).agregarCarta(getCartaCampoDeFuerza());
		}
	}

	@Override
	public void avanzarTurno(Juego juego, Turno turno) {
		if (juego instanceof RolgarII rolgarII) {
			if (getCartaCampoDeFuerza().getCantidadDeTurnosRestantes() > 0) {
				this.getCartaCampoDeFuerza().avanzarTurno();
				return;
			}
			Personaje personaje = rolgarII.getBasePrincipal( turno.getJugador());
			personaje.decrementarEnergia( getCartaCampoDeFuerza().getValorDelCampoAdicional() );
			
			rolgarII.getPartida(turno.getJugador()).quitarCarta(getCartaCampoDeFuerza());
		}
	}

//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public CartaCampoDeFuerza getCartaCampoDeFuerza() {
		return (CartaCampoDeFuerza) this.getCarta();
	}
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
