package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista;

public class Comprador {
    private String nombre;
    private double presupuesto;

    public Comprador(String nombre, double presupuesto) {
        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede ser vacío");
        }
        if (presupuesto <= 0) {
            throw new IllegalArgumentException("El presupuesto debe ser mayor que cero");
        }
        this.nombre = nombre;
        this.presupuesto = presupuesto;
    }

    public double getPresupuesto() {
        return presupuesto;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return String.format("%s ($%.2f)", nombre, presupuesto);
    }
}
