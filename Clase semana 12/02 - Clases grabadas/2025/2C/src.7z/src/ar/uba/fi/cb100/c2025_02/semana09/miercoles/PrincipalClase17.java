package ar.uba.fi.cb100.c2025_02.semana09.miercoles;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.semana04.miercoles.personas.Persona;

public class PrincipalClase17 {

	public static void main(String[] args) {
		//Datos
		List<Persona> personas = new ListaSimplementeEnlazada<Persona>();
		Persona persona1 = new Persona("10500500", "Juan");
		personas.add(persona1);
		
		
		//Otra parte del sistema
		Persona persona2 = new Persona("10500500", null);
		Persona persona3 = new Persona("10500500", "Juan Pablo Garcia");
		
		Persona personaCompleto = buscarPersona(personas, persona2);
		if (persona1.equals(persona2)) {
			System.out.println("Son iguales!!!! 1-2");
		}
		if (persona1.equals(persona3)) {
			System.out.println("Son iguales!!!! 1-3");
		}
		
		
	}
	

	private static Persona buscarPersona(List<Persona> personas, Persona persona2) {
		for(Persona persona: personas) {
			if (persona.equals(persona2)) {
				return persona;
			}
		}
		return null;
	}
}
