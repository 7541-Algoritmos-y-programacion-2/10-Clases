package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea02;

import java.util.List;
import java.util.Set;

import ar.uba.fi.cb100.c2025_02.material.estructuras.conjuntos.Conjunto;
import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana07.jueves.Alumno;
import ar.uba.fi.cb100.c2025_02.semana07.jueves.Nota;

public class Profesor {


    /**
     * Busca los mejores alumnos de cada materia segun su promedio de notas
     * @param alumnos no null
     * @param promedios no null
     * @return lista de los alumnos con mejores promedios de cada materia
     */
    public List<Alumno> buscarMejoresAlumnos(List<Alumno> alumnos, List<Nota> promedios){
        ValidacionesUtiles.esDistintoDeNull(alumnos, "alumnos");
        ValidacionesUtiles.esDistintoDeNull(promedios, "promedios");

        Set<String> materias = obtenerMaterias(promedios);
        List<Integer> mejoresPadrones = obtenerMejoresPadrones(promedios, materias);
        List<Alumno> mejoresAlumnos = new ListaSimplementeEnlazada<>();

        for(Integer padron: mejoresPadrones){
            mejoresAlumnos.add(encontrarAlumno(alumnos, padron));
        }

        return mejoresAlumnos;
    }


    /**
     * Dada una lista de notas devuelve un conjunto con todas las materias que hay
     * @param promedios no null
     * @return conjunto de materias
     */
    public Set<String> obtenerMaterias(List<Nota> promedios){
        ValidacionesUtiles.esDistintoDeNull(promedios, "promedios");

        Set<String> materias = new Conjunto<>();
        for(Nota nota: promedios){
            materias.add(nota.getMateria());
        }
        return materias;
    }

    /**
     * Dada una lista de promedios, devuelve una lista con los padrones del mejor alumno de cada materia
     * @param promedios no null, notas de todos los alumnos
     * @param materias no null, materias a buscar el mejor alumno
     * @return Lista donde cada valor es el padron del mejor alumno de una materia distinta
     */
    public List<Integer> obtenerMejoresPadrones(List<Nota> promedios, Set<String> materias){
        ValidacionesUtiles.esDistintoDeNull(promedios, "promedios");
        ValidacionesUtiles.esDistintoDeNull(materias, "materias");
        List<Integer> listaDePadrones = new ListaSimplementeEnlazada<>();

        for(String materia: materias){
            listaDePadrones.add(obtenerMejorPadronDeLaMateria(promedios, materia));

        }
        return listaDePadrones;
    }

    /**
     * Dada una lista de promedios y una materia, devuelve el padron del mejor alumno
     * @param promedios no null, lista de todas las notas
     * @param materia no null, materia a encontrar el padron del mejor alumno
     * @return padron del mejor alumno de la materia
     */
    public int obtenerMejorPadronDeLaMateria(List<Nota> promedios, String materia){
        ValidacionesUtiles.esDistintoDeNull(promedios, "promedios");
        ValidacionesUtiles.esDistintoDeNull(materia, "materia");
        Nota mejorNotaDeLaMateria = null;
        for(Nota nota: promedios){
            if(nota.getMateria().equals(materia)){
                if(mejorNotaDeLaMateria == null || nota.getValor() > mejorNotaDeLaMateria.getValor()){
                    mejorNotaDeLaMateria = nota;
                }
            }
        }
        if(mejorNotaDeLaMateria != null){
            return mejorNotaDeLaMateria.getPadron();
        }
        throw new RuntimeException("No habia notas de esa materia");
    }

    /**
     * @param alumnos no null, lista de alumnos
     * @param padron padron del alumno a buscar
     * @return el alumno de padron 'padron'
     */
    public Alumno encontrarAlumno(List<Alumno> alumnos, int padron){
        for(Alumno alumno: alumnos){
            if(alumno.getPadron() == padron){
                return alumno;
            }
        }
        return null;
    }
}
