package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Coordenada;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Juego;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.RolgarII;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Turno;

public class AdministradorDeCartaDeRastreadorCuantico extends AdministradorDeCarta {

	public AdministradorDeCartaDeRastreadorCuantico(Carta carta) {
		super(carta);
	}

	@Override
	public void jugarCarta(Juego juego, Turno turno) {
		RolgarII rolgarII = getRolgarII(juego);
		Coordenada coordenada = rolgarII.getInterfazGrafica().preguntarCoordenada();
		
		rolgarII.getParteDeTablero(coordenada, getCartaRastreadorCuantico().getRadioDeVision());
		//recorrer e imprimir
	}

	@Override
	public void avanzarTurno(Juego juego, Turno turno) {}

	public CartaRastreadorCuantico getCartaRastreadorCuantico() {
		return (CartaRastreadorCuantico) this.getCarta();
	}
	
	private RolgarII getRolgarII(Juego juego) {
		return (RolgarII) juego;
	}
}
