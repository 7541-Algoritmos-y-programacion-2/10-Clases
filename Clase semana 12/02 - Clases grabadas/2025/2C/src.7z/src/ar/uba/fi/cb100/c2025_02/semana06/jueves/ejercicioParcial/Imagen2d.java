package ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial;

import java.util.Arrays;

import ar.uba.fi.cb100.c2025_02.material.utiles.NumerosUtiles;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Imagen2d {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Pixel[][] pixeles;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Construye una matriz de alto x ancho
	 * @param alto: debe ser mayor o igual a 1
	 * @param ancho: debe ser mayor o igual a 1
	 */
    public Imagen2d(int alto, int ancho){
        ValidacionesUtiles.validarMayorACero(alto, "alto");
        ValidacionesUtiles.validarMayorACero(ancho, "ancho");

        for(int i = 0; i < ancho; i++){
            for(int j = 0; j < alto; j++){
                pixeles[i][j] = Pixel.generarPixelBlanco();
            }
        }
    }
    
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
    
    @Override
	public String toString() {
    	return "Imagen de " + this.getAncho() + " x " + this.getAlto();
	}
    
    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(pixeles);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Imagen2d other = (Imagen2d) obj;
		return Arrays.deepEquals(pixeles, other.pixeles);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
     * Aplica el filtro escala de grises a cada pixel
     */
    public void aplicarFiltroEscalaDeGrises() {
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
            	pixeles[i][j].aplicarFiltroEscalaDeGrises();
            }
        }
    }
    
	/**
     * Aplica el filtro de brillo a cada pixel
     */
    public void aplicarFiltroDeBrillo(int brillo) {
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
            	pixeles[i][j].aplicarFiltroDeBrillo(brillo);
            }
        }
    }
    
    /**
     * Dada una imagen, la invierte horizontalmente
     */
    public void invertirHorizontalmente() {
        for(int i = 0; i < NumerosUtiles.toInt( this.getAncho() / 2d); i++){
            for(int j=0; j < this.getAlto(); j++){
            	Pixel temp = this.pixeles[i][j];
            	this.pixeles[i][j] = this.pixeles[this.getAncho() - i][j];
            	this.pixeles[this.getAncho() - i][j] = temp;
            }
        }
    }
    
    /**
     * Dada una imagen, la invierte verticalmente
     */
    public void invertirVerticalmente() {
        for(int i = 0; i < this.getAncho(); i++){
            for(int j=0; j < NumerosUtiles.toInt(this.getAlto() / 2d); j++){
            	Pixel temp = this.pixeles[i][j];
            	this.pixeles[i][j] = this.pixeles[i][this.getAlto() - j];
            	this.pixeles[i][this.getAlto() - j] = temp;
            }
        }
    }
    
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    
    /**
     * Devuelve el pixel con mas componente rojo
     * @return
     */
    public Pixel getPixelMasRojo(){
        Pixel resultado = null;
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
                if ((resultado == null) ||
                    (pixeles[i][j].getR() > resultado.getR())) {
                	resultado = pixeles[i][j];
                }
            }
        }
        return resultado;
    }
    
    /**
     * Devuelve el pixel con mas componente verde
     * @return
     */
    public Pixel getPixelMasVerde(){
        Pixel resultado = null;
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
                if ((resultado == null) ||
                    (pixeles[i][j].getG() > resultado.getG())) {
                    	resultado = pixeles[i][j];
                    }
            }
        }
        return resultado;
    }

    /**
     * Devuelve el pixel con mas componente verde
     * @return
     */
    public Pixel getPixelMasAzul(){
        Pixel resultado = null;
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
                if ((resultado == null) ||
                    (pixeles[i][j].getB() > resultado.getB())) {
                    	resultado = pixeles[i][j];
                    }
            }
        }
        return resultado;
    }
    
    /**
     * Devuelve el pixel mas intenso de la componente
     * @param componenteDeColor
     * @return
     */
    public Pixel getPixelMasIntenso(ComponenteDeColor componenteDeColor) {
        Pixel resultado = null;
        for(int i = 0; i < this.pixeles.length; i++){
            for(int j=0; j < this.pixeles[0].length; j++){
                if ((resultado == null) ||
                    (pixeles[i][j].getComponente(componenteDeColor) > resultado.getComponente(componenteDeColor))) {
                    	resultado = pixeles[i][j];
                    }
            }
        }
        return resultado;
    }

    /**
     * Devuelve el pixel de la posicion x e y
     * @param x: entre 1 y el ancho de la imagen inclusive
     * @param y: entre 1 y el alto de la imagen inclusive
	 * @return devuelve el pixel indicado
	 */
	public Pixel getPixel(int x, int y) {
		ValidacionesUtiles.validarRangoNumerico(1, getAncho(), x, "ancho");
		ValidacionesUtiles.validarRangoNumerico(1, getAlto(), y, "ancho");
		return this.pixeles[x-1][y-1];
	}
    
//GETTERS SIMPLES -----------------------------------------------------------------------------------------	

	/**
	 * Devuelve el ancho de la imagen en cantidad de pixeles
	 * @return
	 */
	public int getAncho() {
		return this.pixeles.length;
	}
	
	/**
	 * Devuelve el alto de la imagen en cantidad de pixeles
	 * @return
	 */
	public int getAlto() {
		return this.pixeles[0].length;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

}

