package ar.uba.fi.cb100.c2025_02.semana02.jueves;

import ar.uba.fi.cb100.c2025_02.semana01.jueves.Guia01;

public class Guia02 {

	public static void main(String[] args) {
		int[] vector = new int[100];
		for(int i = 0; i < vector.length; i++) {
			vector[i] = i;
		}
		imprimirVector(vector);
		ejercicio8(vector);
		imprimirVector(vector);		
	}
	
	public static void imprimirVector(int[] vector) {
		String resultado = "";
		for(int i = 0; i < vector.length; i++) {
			resultado += vector[i] + ", ";
		}
		Guia01.imprimir( "[" + resultado.substring(0, resultado.length() -2) + "]");
	}
	
	public static void main1(String[] args) {
		ejercicio11(11, 12);
		
		{
			int numero1 = 11;
			int numero2 = 12;
			ejercicio11(numero1, numero2);
			Guia01.imprimir(numero1 + " - " + numero2);
		}		
		{
			Numero numero1 = new Numero();
			numero1.valor = 11;
			
			Numero numero2 = new Numero();
			numero2.valor = 12;
			ejercicio12(numero1, numero2);
			Guia01.imprimir(numero1.valor + " - " + numero2.valor);
		}
		{
			Integer numero1 = Integer.valueOf(11);
			Integer numero2 = Integer.valueOf(12);
			ejercicio11(numero1, numero2);
			Guia01.imprimir(numero1 + " - " + numero2);
		}	
	}
	
	public static void ejercicio11Bis(Integer a, Integer b) {
		Integer temporal = a;
		a = b;
		b = temporal;
		Guia01.imprimir(a + " - " + b);
	}
	
	public static void ejercicio11(int a, int b) {
		int temporal = a;
		a = b;
		b = temporal;
		Guia01.imprimir(a + " - " + b);
	}
	
	public static void ejercicio12(Numero a, Numero b) {
		int temporal = a.valor;
		a.valor = b.valor;
		b.valor = temporal;
		Guia01.imprimir(a.valor + " - " + b.valor);
	}
	
	public static void ejercicio8(int[] vector) {
		if (vector.length > 1) {
			vector[0] = 500;
		}
	}
}
