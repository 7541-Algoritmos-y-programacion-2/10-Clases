package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.tda;

import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista.EstadoDeEstante;

public class Estante {
    private double ancho;
    private double pesoMaximoSoportado;
    private Vector<Libro> libros;
    private EstadoDeEstante estado = EstadoDeEstante.EN_USO;

    /**
     * Crea un estante con el ancho y peso maximo dado, y sin libros con el estado en uso.
     * @param anchoTotal
     * @param pesoMaximo
     */
    public Estante(double ancho, double pesoMaximoSoportado) {
        if (ancho <= 0 || pesoMaximoSoportado <= 0) {
            throw new IllegalArgumentException("El ancho y el peso máximo deben ser mayores que cero");
        }
        this.ancho = ancho;
        this.pesoMaximoSoportado = pesoMaximoSoportado;
        this.libros = new Vector<Libro>(1, null);
    }

    /**
     * Agrega un libro al estante mientras tenga espacio o peso disponible y no este en reparacion
     * @param libro
     */
    public void agregarLibro(Libro libro) {
        if (libro == null) {
            throw new IllegalArgumentException("El libro no puede ser nulo");
        }
        if (estaEnReparacion()) {
            throw new IllegalStateException("No se pueden agregar libros mientras el estante está en reparación");
        }
        if (libro.getAncho() > getAnchoLibre()) {
            throw new IllegalStateException("No hay suficiente espacio en el estante");
        }
        if (libro.getPeso() > getPesoLibre()) {
            throw new IllegalStateException("El estante no soporta más peso");
        }
        libros.agregar(libro);
    }

    /**
     * Quita el primer libro
     * @return
     */
    public Libro quitar(Libro libroAQuitar) {
    	if (estaEnReparacion()) {
    		throw new RuntimeException("El estante esta en reparacion");
    	}
    	for(int i = 1; i <= getCantidadLibros(); i++) {
    		Libro libro = getLibro(i); 
    		if (libro.equals(libroAQuitar)) {        		
        		this.libros.agregar(i, null);
        		return libro;
        	}
        }
    	throw new RuntimeException("No se encontro el libro");
    }
    
    
    public boolean existeElLibro(String titulo) {
    	return existeElLibro(new Libro(titulo, 1, 1));
    }
    
    /**
     * Devuelve si existe el libro en el estante
     * @param titulo
     * @return
     */
    public boolean existeElLibro(Libro libroABuscar) {
    	if (estaEnReparacion()) {
    		throw new RuntimeException("El estante esta en reparacion");
    	}
        for (int i = 1; i < this.libros.getLongitud(); i++) {
        	Libro libro = this.libros.obtener(i);
            if (libro.equals(libroABuscar)) {
                return true;
            }
        }
        return false;
    }
    
    public Libro buscarLibro(String titulo) {
    	return buscarLibro(new Libro(titulo, 1.0, 1.0));
    }
    
    /**
     * Devuelve el numero de libro
     * @param numeroDeLibro
     * @return
     */
    public Libro getLibro(int numeroDeLibro) {
    	if (estaEnReparacion()) {
    		throw new RuntimeException("El estante esta en reparacion");
    	}
    	for(int i = 1; i <= this.libros.getLongitud(); i++) {
    		Libro libro = this.libros.obtener(i);
    		if (libro != null) {
    			numeroDeLibro--;
    			if (numeroDeLibro == 0) {
    				return libro;
    			}
    		}
    	}
    	throw new RuntimeException("No se encontro el libro " + numeroDeLibro);
    }
    
    /**
     * Busca un libro por el titulo
     * @param titulo
     * @return
     */
    public Libro buscarLibro(Libro libroABuscar) {
    	if (estaEnReparacion()) {
    		throw new RuntimeException("El estante esta en reparacion");
    	}
        for (int i = 1; i < this.libros.getLongitud(); i++) {
        	Libro libro = this.libros.obtener(i);
            if ((libro != null) &&
                 libro.equals(libroABuscar)) {
                return libro;
            }
        }
        throw new RuntimeException("No se encontro el libro: " + libroABuscar.getTitulo());
    }

    /**
     * Devuelve la cantidad de libros del estante
     * @return
     */
    public int getCantidadLibros() {
        return libros.getCantidadDeDatos();
    }

    /**
     * Devuelve el ancho ocupado por todos los libros del estante
     * @return
     */
    public double getAnchoOcupado() {
    	double anchoOcupado = 0;
        for (int i = 1; i < this.libros.getLongitud(); i++) {
        	Libro libro = this.libros.obtener(i);
        	if (libro != null) {
        		anchoOcupado += libro.getAncho();
        	}
        }
        return anchoOcupado;
    }
    
    /**
     * Devuelve el peso ocupado por todos los libros del estante
     * @return
     */
    public double getPesoOcupado() {
    	double pesoOcupado = 0;
        for (int i = 1; i < this.libros.getLongitud(); i++) {
        	Libro libro = this.libros.obtener(i);
        	if (libro != null) {
        		pesoOcupado += libro.getPeso();
        	}
        }
        return pesoOcupado;
    }
    
    /**
     * Devuelve el ancho libre del estante para cargar mas libros
     * @return
     */
    public double getAnchoLibre() {
        return ancho - getAnchoOcupado();
    }

    /**
     * Devuelve el peso libre del estante para cargar mas libros
     * @return
     */
    public double getPesoLibre() {
        return pesoMaximoSoportado - getPesoOcupado();
    }

    /**
     * Inicia la reparacion del estante, para eso debe estar vacio
     */
    public void iniciarReparacion() {
        ValidacionesUtiles.validarFalso(estaEnReparacion(), "El estante ya esta en reparacion");
        ValidacionesUtiles.validarFalso(estaVacio(), "El estante esta en uso");
        this.estado = EstadoDeEstante.EN_REPARACION;
    }

    /**
     * Pone el estante en uso para su uso
     */
    public void finalizarReparacion() {
    	ValidacionesUtiles.validarVerdadero(estaEnReparacion(), "El estante no esta en reparacion");
    	this.estado = EstadoDeEstante.EN_USO;
    }

    /**
     * Devuelve verdadero si el estante esta vacio
     * @return
     */
    public boolean estaVacio() {
    	return getCantidadLibros() == 0;
    }
    
    /**
     * Devuelve verdadero si el estante esta en reparacion
     * @return
     */
    public boolean estaEnReparacion() {
        return this.estado.equals( EstadoDeEstante.EN_REPARACION );
    }

    /**
     * Devuelve una cadena de texto representando el estante
     */
    @Override    
    public String toString() {
        return String.format("Estante[libros=%d, ancho libre=%.2f, peso libre=%.2f, en reparación=%b]",
                getCantidadLibros(), getAnchoLibre(), getPesoLibre(), estaEnReparacion());
    }
}
