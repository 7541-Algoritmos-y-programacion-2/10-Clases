package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Juego;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.Turno;

public abstract class AdministradorDeCarta {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Carta carta = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public AdministradorDeCarta(Carta carta) {
		ValidacionesUtiles.esDistintoDeNull(carta, "Carta");
		this.carta = carta;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Aplica la funcionalidad de jugar una carga al momento de jugarla por primera vez
	 */
	public abstract void jugarCarta(Juego juego, Turno turno);
	
	/**
	 * Dada una carta ya jugada, se juega los siguientes turnos de la carta
	 * @param invasionGalactica
	 * @param turno
	 */
	public abstract void avanzarTurno(Juego juego, Turno turno);
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la carta que se esta jugando
	 * @return
	 */
	public Carta getCarta() {
		return carta;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
