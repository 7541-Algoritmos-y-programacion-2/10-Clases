package ar.uba.fi.cb100.c2025_02.semana08.miercoles;

public class Principal_08_01 {

	public static void main(String[] args) {
		Tablero3D<String> tablero = new Tablero3D<String>(5, 5, 5, " ");
		
		tablero.getCasillero(1, 1, 1).setValor("A");
		tablero.getCasillero(2, 2, 2).setValor("A");
		tablero.getCasillero(3, 3, 3).setValor("A");
		tablero.getCasillero(4, 4, 4).setValor("A");
		tablero.getCasillero(5, 5, 5).setValor("A");
		
		tablero.getCasillero(1, 1, 5).setValor("B");
		tablero.getCasillero(1, 2, 5).setValor("B");
		tablero.getCasillero(1, 3, 5).setValor("B");
		tablero.getCasillero(1, 4, 5).setValor("B");
		tablero.getCasillero(1, 5, 5).setValor("B");
		
		tablero.getCasillero(5, 4, 1).setValor("C");
		tablero.getCasillero(5, 4, 2).setValor("C");
		tablero.getCasillero(5, 4, 3).setValor("C");
		tablero.getCasillero(5, 4, 4).setValor("C");
		tablero.getCasillero(5, 4, 5).setValor("C");
		
		
		//tablero.getCasillero(5, 4, 5).getVecino(Inferior).getCoordenadas();
		
		imprimirTablero3D(tablero);
	}
	
	public static void imprimirTablero3D(Tablero3D<String> tablero) {
		System.out.println(tablero.toString());
		System.out.println();
		for(int i = 1; i <= tablero.getAncho(); i++) {
			System.out.println("Plano " + i);
			for(int j = 1; j <= tablero.getAlto(); j++) {
				System.out.print("|");
				for(int k = 1; k <= tablero.getProfundo(); k++) {
					System.out.print(tablero.getCasillero(i, j, k).getValor() + "|");
				}
				System.out.println();
				System.out.println("-----------");
			}
			System.out.println();
			System.out.println();
		}
	}
	
	/**
	 * Main esperado
	 * @param args
	 */
//	public static void mainDelTP2(String[] args) {
//		JuegoRolgar juego = new JuegoRolgar(...);
//		juego.inicializar();
//		juego.jugar();
//	}
}
