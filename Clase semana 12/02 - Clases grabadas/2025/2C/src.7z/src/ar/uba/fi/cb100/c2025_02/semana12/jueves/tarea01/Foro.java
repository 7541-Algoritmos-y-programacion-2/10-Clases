package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea01;

import java.util.List;
import java.util.ListIterator;
import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Foro {

    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
    //ATRIBUTOS -----------------------------------------------------------------------------------------------
    private List<Mensaje> listaDeMensajes;
    private String nombreDelForo;
    private List<String> tematicasDelForo;

    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
    //CONSTRUCTORES -------------------------------------------------------------------------------------------

    /**
     * crea un foro con sus tematicas, y con el nombre del foro
     * @param tematicasDelForo
     * @param nombreDeForo
     */
    public Foro(List<String> tematicasDelForo,String nombreDeForo){
        setNombreForo(nombreDeForo);
        listaDeMensajes = new ListaSimplementeEnlazada<>();
        this.tematicasDelForo = tematicasDelForo;

    }
    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
    //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
    //METODOS DE CLASE ----------------------------------------------------------------------------------------
    //METODOS GENERALES ---------------------------------------------------------------------------------------
    //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

    /**
     * crea un mensaje en el foro con el usuario, contenido del mensaje, y tematica del foro donde se alojara el mensaje
     * @param usuario
     * @param contenidoDelMensaje
     * @param tematicaDelForo
     * @return
     */
    public Mensaje crearMensaje(String usuario,String contenidoDelMensaje,String tematicaDelForo){
        ValidacionesUtiles.esDistintoDeNull(usuario,"usuario");
        ValidacionesUtiles.esDistintoDeNull(contenidoDelMensaje,"contenido del mensaje");
        ValidacionesUtiles.esDistintoDeNull(tematicaDelForo,"tematica Del Foro");
        if(!(this.tematicasDelForo.contains(tematicaDelForo))){
            throw new RuntimeException(tematicaDelForo + "no forma parte de las tematicas de este foro");
        }
        Mensaje mensaje = new Mensaje(usuario,contenidoDelMensaje,tematicaDelForo);
        if(listaDeMensajes.contains(mensaje)){
            throw new RuntimeException("el Mensaje ya existia");                   //puede haber mas de un mensaje igual pero decidi que no
        }
        this.listaDeMensajes.add(mensaje);
        return mensaje;

    }

    /**
     * borra un mensaje colocado en el foro
     * @param mensaje
     */
    public void borrarMensaje(Mensaje mensaje){
        ValidacionesUtiles.esDistintoDeNull(mensaje,"mensaje");

        if(!(listaDeMensajes.contains(mensaje))){
            throw new RuntimeException("el mensaje no se encuentra en el foro");
        }
        listaDeMensajes.remove(mensaje);
    }

    /**
     * vacia el foro y retorna true si se vacio, si no lanza excepcion
     */
    public boolean vaciarForo(){
        if(estaVacioElForo()){
            throw new RuntimeException("EL foro ya estaba vacio");
        }
        listaDeMensajes.clear();
        return true;

    }

    /**
     * devuelve true si el foro esta vacio, false caso contrario
     * @return
     */
    public boolean estaVacioElForo(){
        ListIterator<Mensaje> iterador = listaDeMensajes.listIterator();
        return(!(iterador.hasNext()));
    }

    //to do "agregar tematicas del foro", "sacar tematicas del foro",

    //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------


    /**
     * obtiene los mensajes del usuario del foro en la tematica pasada por parametro
     * @param usuarioBuscado no debe ser Null y debe estar en el foro
     * @param tematicaBuscada no debe ser null
     * @return
     */
    public List<Mensaje> obtenerMensajesDelUsuarioPorTematica(String usuarioBuscado, String tematicaBuscada){
    	ValidacionesUtiles.esDistintoDeNull(usuarioBuscado,"usuario");
    	ValidacionesUtiles.esDistintoDeNull(tematicaBuscada,"tematica");
        List<Mensaje> mensajesDelUsuario = new ListaSimplementeEnlazada<>();
        
        for(Mensaje mensaje : this.listaDeMensajes){
            if(usuarioBuscado.equals(mensaje.getUsuario()) && Objects.equals(tematicaBuscada,mensaje.getTematica())){
                mensajesDelUsuario.add(mensaje);
            }
        }
        return mensajesDelUsuario;
    }
    //GETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     *
     * @return devuelve una lista nueva con los mensajes del foro
     */
    public List<Mensaje> getMensajesDeForo(){
        List<Mensaje> listaDeMensajesNuevo = new ListaSimplementeEnlazada<>();
        ListIterator<Mensaje> iterador = listaDeMensajes.listIterator();
        while(iterador.hasNext()){
            Mensaje mensaje = iterador.next();
            listaDeMensajesNuevo.add(mensaje);
        }
        return listaDeMensajesNuevo;
    }

    /**
     *
     * @return devuelve una lista nueva con las tematicas del foro
     */
    public List<String> getTematicas(){
        List<String> listaDeTematicasNueva = new ListaSimplementeEnlazada<>();
        ListIterator<String> iterador = tematicasDelForo.listIterator();
        while(iterador.hasNext()){
            String tematica = iterador.next();
            listaDeTematicasNueva.add(tematica);
        }
        return listaDeTematicasNueva;
    }

    /**
     * devuelve el nombre del foro
     * @return
     */
    public String getNombreForo(){
        return this.nombreDelForo;

    }
    //SETTERS COMPLEJOS----------------------------------------------------------------------------------------
    //SETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     * modifica el nombre del foro con el String pasado por parametro
     * @param nombreDeForo no debe ser null
     */
    private void setNombreForo(String nombreDeForo){
        ValidacionesUtiles.esDistintoDeNull(nombreDeForo,"nombre de foro");
        this.nombreDelForo = nombreDeForo;
    }

    }
