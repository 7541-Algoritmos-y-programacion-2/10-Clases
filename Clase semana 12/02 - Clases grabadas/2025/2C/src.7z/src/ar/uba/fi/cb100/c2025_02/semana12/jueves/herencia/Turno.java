package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia;

public class Turno {

	public Jugador getJugador() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public PartidaDeRolgarII getPartida() {
		return null;
	}

}
