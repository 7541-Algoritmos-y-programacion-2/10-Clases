package ar.uba.fi.cb100.c2025_02.semana03.jueves.tarea.entrega01;

import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1.Libro;

public class Biblioteca {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Libro[] libros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Biblioteca(int cantidadMaximaDeLibros) {
		this.libros = new Libro[cantidadMaximaDeLibros];
		for(int i = 0; i < this.libros.length; i++) {
			this.libros[i] = null;
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public void agregar(Libro libro) {
		//validar: null, duplicado
        if (libro == null) {
            throw new RuntimeException("El libro no existe");
        }
        if (buscar(libro.getTitulo()) == null) {
            throw new RuntimeException("El libro no se encuentra");
        }
		this.libros[getCantidadDeLibros()] = libro;
    }

	
	public void quitar(Libro libro) {
        if (buscar(libro.getTitulo()) == null) {
            throw new RuntimeException("El libro no existe");
        }
        for (int i = numeroDeLibro(libro); i < this.libros.length; i++) {
            Libro contenedor = this.libros[i];
            this.libros[i] = this.libros[i+1];
            this.libros[i+1] = contenedor;
        }
        this.libros[getCantidadDeLibros()-1] = null;
	}
	
	public void prestar(Libro libro) {
        if (buscar(libro.getTitulo()) == null) {
            throw new RuntimeException("El libro no existe");
        }
        if (this.libros[numeroDeLibro(libro)].getCantidadDeCopias() > 0) {
            this.libros[numeroDeLibro(libro)].setCantidadDeCopias(this.libros[numeroDeLibro(libro)].getCantidadDeCopias() - 1);
        }
    }
	
	public void devolver(Libro libro) {
		if (buscar(libro.getTitulo()) == null) {
            throw new RuntimeException("El libro no existe");
        }
        this.libros[numeroDeLibro(libro)].setCantidadDeCopias(this.libros[numeroDeLibro(libro)].getCantidadDeCopias() + 1);
	}
	
	public Libro buscar(String texto) {
		for(int i = 0; i < this.getCantidadDeLibros(); i++) {
			if (this.libros[i].contiene(texto)) {
				return this.libros[i];
			}
		}
		throw new RuntimeException("No se encuentra el libro");
	}

    public int numeroDeLibro(Libro libro) {
        for(int i = 0; i < this.getCantidadDeLibros(); i++) {
            if (this.libros[i] == libro) {
                return i;
            }
        }
        throw new RuntimeException("No se encuentra el libro");
    }
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	public int getCantidadDeLibros() {
		for(int i = 0; i < this.libros.length; i++) {
			if (this.libros[i] == null) {
				return i;
			}
		}
		return this.libros.length;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}

