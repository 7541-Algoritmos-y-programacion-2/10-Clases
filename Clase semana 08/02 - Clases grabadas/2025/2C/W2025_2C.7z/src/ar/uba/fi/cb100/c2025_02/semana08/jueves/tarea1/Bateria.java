package ar.uba.fi.cb100.c2025_02.semana08.jueves.tarea1;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Bateria {
	//INTERFACES ----------------------------------------------------------------------------------------------
	//ENUMERADOS ----------------------------------------------------------------------------------------------
	//CONSTANTES ----------------------------------------------------------------------------------------------
	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
	private double cargaActual = 0;
	private double capacidadMaximaDeCarga;
	private double comsumoPorKilometro;
	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	/**
	 * crea la bateria con su capacidadMaxima y con su consumoPorKilometro (en kWh)
	 * @param capacidadMaximaDeCarga
	 * @param cargaActual
	 */
	public Bateria(double capacidadMaximaDeCarga, double consumoPorKilometro) {
		setCapacidadMaximaDeCarga(capacidadMaximaDeCarga);
		setConsumoPorKilometro(consumoPorKilometro);
		
	}
	//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
	//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
	//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
	//METODOS DE CLASE ----------------------------------------------------------------------------------------
	//METODOS GENERALES ---------------------------------------------------------------------------------------
	/**
	 * crea el toString de la bateria con su capacidad maxima de carga y con su carga actual
	 */
	@Override
	public String toString() {
		return "Bateria con una capacidad maxima de " + this.getCapacidadMaximaDeCarga() + "kWh. Y una carga actual de " + this.getCargaActual() + "(kWh).";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(capacidadMaximaDeCarga, cargaActual);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bateria other = (Bateria) obj;
		return Double.doubleToLongBits(capacidadMaximaDeCarga) == Double.doubleToLongBits(other.capacidadMaximaDeCarga)
				&& Double.doubleToLongBits(cargaActual) == Double.doubleToLongBits(other.cargaActual);
	}
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	/**
	 * devuelve true si la carga actual es igual a cero
	 * @return
	 */
	public boolean estaVacia() {
		return this.getCargaActual() == 0;
	}
	
	/**
	 * devuelve true si la carga actual es igual a la capacidad maxima de carga
	 * @return
	 */
	public boolean estaLlena() {
		return this.getCargaActual() == this.getCapacidadMaximaDeCarga();
	}
	
	/**
	 * aumenta la carga actual de la bateria (en kHw)
	 * @param valor tiene que ser mayor a 0
	 */
	public void cargarBateria(double valor){
		ValidacionesUtiles.validarMayorACero(valor, "valor");
		if( valor > this.getCargaRestante()) {
			throw new RuntimeException("La carga ingresada sobre pasa la carga restante de la bateria");
		}
		this.cargaActual += valor;
		
	}
	
	/**
	 * consume la carga de la bateria segun los kilometros pasados. si la carga no es suficiente para los kilometros pasados lanza excepcion.
	 * @param kilometros tiene que ser mayor a 0
	 */
	public void desplazar(double kilometros) {
		ValidacionesUtiles.validarMayorACero(kilometros, "kilometros");
		if(kilometros > this.getAutonomia()) {
			throw new RuntimeException("No tienes la suficiente carga para hacer esa cantidad d ekilometros");
		}
		this.cargaActual = kilometros * this.getConsumoPorKilometro();
	}
	
	//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
	//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
	//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
	//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	/**
	 * devuelve la carga actual de la bateria (en kWh)
	 * @return
	 */
	public double getCargaActual() {
		return this.cargaActual;
	}
	
	/**
	 * devuelve la capacidad maxima de carga que tiene la bateria (en kWh)
	 * @return
	 */
	public double getCapacidadMaximaDeCarga() {
		return this.capacidadMaximaDeCarga;
	}
	
	/**
	 * devuelve la carga restante que tiene la bateria (en kWh)
	 * @return
	 */
	public double getCargaRestante() {
		return this.getCapacidadMaximaDeCarga() - this.getCargaActual();
	}
	
	/**
	 * devuelve la autonomia que tiene la bateria segun los kilometros
	 * @return
	 */
	public double getAutonomia() {
		return this.getCargaActual() / this.getConsumoPorKilometro();
	}
	
	/**
	 * devuelve el consumo por kilometros que tiene la bateria
	 * @return
	 */
	private double getConsumoPorKilometro() {
		return this.comsumoPorKilometro;
	}
	
	//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------

	/**
	 * modifica la carga actual de la bateria (en kWh)
	 * @param cargaActual tiene que ser mayor o igual a 0
	 */
	public void setCargaActual(double cargaActual) {
		ValidacionesUtiles.validarMayorOIgualACero(cargaActual, "carga atual");
		this.cargaActual = cargaActual;
	}
	
	/**
	 * modifica la capacidad maxia de carga de la bateria (en kWh)
	 * @param capacidadMaximaDeCarga tiene que ser mayor a 0
	 */
    public void setCapacidadMaximaDeCarga(double capacidadMaximaDeCarga) {
    	ValidacionesUtiles.validarMayorACero(capacidadMaximaDeCarga, "capacidad de carga");
		this.capacidadMaximaDeCarga = capacidadMaximaDeCarga;
	}
    
    /**
     * modificia el consumo por kilometro de carga que tiene la bateria (en kHk)
     * @param consumoPorKilometro tiene que ser mayor a 0
     */
    public void setConsumoPorKilometro(double consumoPorKilometro) {
    	ValidacionesUtiles.validarMayorACero(consumoPorKilometro, "consumo por kilometro");
    	this.comsumoPorKilometro = consumoPorKilometro;
    }
		
		
}
