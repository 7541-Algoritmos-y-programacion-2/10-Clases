package ar.uba.fi.cb100.c2025_02.semana04.miercoles;

import ar.uba.fi.cb100.c2025_02.semana04.miercoles.hijos.Alumno;
import ar.uba.fi.cb100.c2025_02.semana04.miercoles.hijos.Profesor;
import ar.uba.fi.cb100.c2025_02.semana04.miercoles.personas.Persona;

public class Principal {
	
	public static void main(String[] args) {
		{
			Alumno alumno1 = new Alumno("Gustavo 1");
			System.out.println("Padron: " + alumno1.getPadron());
			
			Alumno alumno2 = new Alumno("Gustavo 2");
			System.out.println("Padron: " + alumno2.getPadron());
			
			System.out.println("Ultimo padron utilizado: " + Alumno.getUltimoNumeroDePadronUtilizado());
			
			System.out.println("Ultimo padron libre: " + Alumno.getProximoNumeroDePadronLibre());
			alumno1.setNombre("Gustavo");
		}
		
		
		{
			Persona persona1 = new Persona("Gustavo 2");
			System.out.println( persona1.firmar() );
			//System.out.println( persona1.getPadron() ); no se puede
			
			Alumno persona2 = new Alumno("Alumno 1");
			System.out.println( persona2.firmar() );
			System.out.println( persona2.getPadron() );
			
			Persona persona3 = new Alumno("Alumno 2");
			System.out.println( persona3.firmar() );
			//System.out.println( persona3.getPadron() ); no compila
			System.out.println( persona3.getNombre() );
			
			Persona persona4 = null;
			if (persona2.getPadron() > 10) {
				persona4 = new Alumno("Alumno 4");
			} else if (persona2.getPadron() > 20) {
				persona4 = new Persona("Alumno 4");
			} else {
				persona4 = new Profesor("Profesor 4");
			}
			persona4.firmar();
			
			//Anterior a java 17
			if (persona4 instanceof Alumno) {
				Alumno alumno5 = (Alumno) persona4;
				alumno5.getPadron();
			}
			
			if (persona4 instanceof Alumno alumno5) {
				alumno5.getPadron();
			}
			
			if (persona4 instanceof Persona) {
				
			}
			
			if (persona4 instanceof Profesor profesor) {
				profesor.firmar();
				profesor.ponerNota();
				persona4.firmar();
				//persona4.ponerNota(); no se puede
			}
			
		}
	}
}
