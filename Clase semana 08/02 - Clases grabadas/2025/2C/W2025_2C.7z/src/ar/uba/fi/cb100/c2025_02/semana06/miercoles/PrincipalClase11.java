package ar.uba.fi.cb100.c2025_02.semana06.miercoles;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;

public class PrincipalClase11 {

	public static void main(String[] args) {
		ListaSimplementeEnlazada<Integer> listaDeEnteros = new ListaSimplementeEnlazada<>();
		listaDeEnteros.addSorted(15);
		listaDeEnteros.addSorted(10);
		listaDeEnteros.addSorted(12);
		
		
		listaDeEnteros.iniciarCursor();
		while (listaDeEnteros.avanzarCursor()) {
			Integer entero = listaDeEnteros.obtenerCursor();
			System.out.println(entero);
		}
		
		listaDeEnteros.addSorted(12);
		listaDeEnteros.addSorted(12);
		listaDeEnteros.addSorted(12);
		listaDeEnteros.addSorted(20);
		listaDeEnteros.addSorted(1); //Tarea: agregar ordenado
		listaDeEnteros.addSorted(1);
		
		listaDeEnteros.iniciarCursor();
		while (listaDeEnteros.avanzarCursor()) {
			Integer entero = listaDeEnteros.obtenerCursor();
			System.out.println(entero);
		}
		
		//NO SE PUEDE HACER
		listaDeEnteros.iniciarCursor();
		while (listaDeEnteros.avanzarCursor()) {
			Integer entero = listaDeEnteros.obtenerCursor();
			System.out.println(entero);
			listaDeEnteros.iniciarCursor(); //No se puede
			while (listaDeEnteros.avanzarCursor()) {
				
			}
		}
	}
}
