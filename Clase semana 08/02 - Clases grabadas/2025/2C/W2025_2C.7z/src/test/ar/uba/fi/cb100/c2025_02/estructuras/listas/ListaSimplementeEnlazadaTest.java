package test.ar.uba.fi.cb100.c2025_02.estructuras.listas;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;

class ListaSimplementeEnlazadaTest {

    private ListaSimplementeEnlazada<Integer> lista;

    @BeforeEach
    void setUp() {
        lista = new ListaSimplementeEnlazada<>();
    }

    @Test
    void testAddAndGet() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertEquals(3, lista.size());
        assertEquals(10, lista.get(0));
        assertEquals(20, lista.get(1));
        assertEquals(30, lista.get(2));
    }

    @Test
    void testAddAtIndex() {
        lista.add(10);
        lista.add(30);
        lista.add(1, 20);

        assertEquals(Arrays.asList(10,20,30), Arrays.asList(lista.toArray()));
    }

    @Test
    void testAddLast() {
        lista.addLast(5);
        lista.addLast(15);
        assertEquals(Arrays.asList(5,15), Arrays.asList(lista.toArray()));
    }

    @Test
    void testAddSorted() {
        lista.addSorted(5);
        lista.addSorted(1);
        lista.addSorted(3);
        lista.addSorted(2);
        lista.addSorted(4);

        assertEquals(Arrays.asList(1,2,3,4,5), Arrays.asList(lista.toArray()));
    }

    @Test
    void testSet() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        int old = lista.set(1, 99);
        assertEquals(20, old);
        assertEquals(99, lista.get(1));
    }

    @Test
    void testRemoveByIndex() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        int removed = lista.remove(1);
        assertEquals(20, removed);
        assertEquals(Arrays.asList(10,30), Arrays.asList(lista.toArray()));
    }

    @Test
    void testRemoveByObject() {
        lista.add(10);
        lista.add(20);
        lista.add(30);

        assertTrue(lista.remove(Integer.valueOf(20)));
        assertFalse(lista.remove(Integer.valueOf(100)));
        assertEquals(Arrays.asList(10,30), Arrays.asList(lista.toArray()));
    }

    @Test
    void testContainsAndContainsAll() {
        lista.addAll(Arrays.asList(1,2,3,4,5));
        assertTrue(lista.contains(3));
        assertFalse(lista.contains(99));

        assertTrue(lista.containsAll(Arrays.asList(2,3,4)));
        assertFalse(lista.containsAll(Arrays.asList(2,99)));
    }

    @Test
    void testIndexOfAndLastIndexOf() {
        lista.addAll(Arrays.asList(1,2,3,2,1));

        assertEquals(0, lista.indexOf(1));
        assertEquals(4, lista.lastIndexOf(1));
        assertEquals(-1, lista.indexOf(99));
    }

    @Test
    void testIsEmptyAndClear() {
        assertTrue(lista.isEmpty());
        lista.add(1);
        assertFalse(lista.isEmpty());
        lista.clear();
        assertTrue(lista.isEmpty());
        assertEquals(0, lista.size());
    }

    @Test
    void testToArray() {
        lista.addAll(Arrays.asList(1,2,3));
        Object[] array = lista.toArray();
        assertArrayEquals(new Object[]{1,2,3}, array);
    }

    @Test
    void testSubList() {
        lista.addAll(Arrays.asList(1,2,3,4,5));
        List<Integer> sub = lista.subList(1,4);
        assertEquals(Arrays.asList(2,3,4), sub);
    }

    @Test
    void testIterator() {
        lista.addAll(Arrays.asList(1,2,3));
        var it = lista.iterator();

        assertTrue(it.hasNext());
        assertEquals(1, it.next());
        assertEquals(2, it.next());
        assertEquals(3, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testListIterator() {
        lista.addAll(Arrays.asList(10,20,30));
        var it = lista.listIterator();

        assertTrue(it.hasNext());
        assertEquals(10, it.next());
        assertEquals(1, it.nextIndex());

        assertTrue(it.hasPrevious());
        assertEquals(10, it.previous());
    }

    @Test
    void testAddAll() {
        lista.addAll(Arrays.asList(1,2,3));
        assertEquals(3, lista.size());
    }

    @Test
    void testRemoveAll() {
        lista.addAll(Arrays.asList(1,2,3,4,5));
        lista.removeAll(Arrays.asList(2,4));
        assertEquals(Arrays.asList(1,3,5), Arrays.asList(lista.toArray()));
    }

    @Test
    void testRetainAll() {
        lista.addAll(Arrays.asList(1,2,3,4,5));
        lista.retainAll(Arrays.asList(2,4));
        assertEquals(Arrays.asList(2,4), Arrays.asList(lista.toArray()));
    }

    @Test
    void testExceptions() {
        assertThrows(IndexOutOfBoundsException.class, () -> lista.get(0));
        assertThrows(IndexOutOfBoundsException.class, () -> lista.set(0, 1));
        assertThrows(IndexOutOfBoundsException.class, () -> lista.remove(0));
        assertThrows(IndexOutOfBoundsException.class, () -> lista.add(5, 100));
        assertThrows(IndexOutOfBoundsException.class, () -> lista.subList(2, 1));

        lista.add(1);
        var it = lista.listIterator();
        assertThrows(NoSuchElementException.class, () -> it.previous());
    }
}