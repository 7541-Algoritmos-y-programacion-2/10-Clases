package test.ar.uba.fi.cb100.c2025_02.estructuras.pilas;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Collections;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.pilas.PilaBasica;

class PilaBasicaTest {

    private PilaBasica<Integer> pila;

    @BeforeEach
    void setUp() {
        pila = new PilaBasica<>();
    }

    @Test
    void testPilaNuevaEstaVacia() {
        assertTrue(pila.estaVacia());
        assertEquals(0, pila.contarElementos());
        assertNull(pila.obtener());
        assertNull(pila.desapilar());
    }

    @Test
    void testApilarUnElemento() {
        pila.apilar(10);
        assertFalse(pila.estaVacia());
        assertEquals(1, pila.contarElementos());
        assertEquals(10, pila.obtener());
    }

    @Test
    void testApilarVariosMantieneOrdenLIFO() {
        pila.apilar(1);
        pila.apilar(2);
        pila.apilar(3);

        assertEquals(3, pila.contarElementos());
        assertEquals(3, pila.obtener()); // último apilado
        assertEquals(3, pila.desapilar());
        assertEquals(2, pila.desapilar());
        assertEquals(1, pila.desapilar());
        assertTrue(pila.estaVacia());
    }

    @Test
    void testDesapilarEnPilaVaciaDevuelveNull() {
        assertNull(pila.desapilar());
    }

    @Test
    void testObtenerNoElimina() {
        pila.apilar(5);
        pila.apilar(6);
        assertEquals(6, pila.obtener());
        assertEquals(2, pila.contarElementos());
    }

    @Test
    void testApilarLista() {
        pila.apilar(Arrays.asList(1, 2, 3));
        assertEquals(3, pila.contarElementos());
        assertEquals(3, pila.desapilar()); // se apila en orden → 1 abajo, 3 arriba
        assertEquals(2, pila.desapilar());
        assertEquals(1, pila.desapilar());
        assertTrue(pila.estaVacia());
    }

    @Test
    void testApilarListaVaciaNoCambiaPila() {
        pila.apilar(Collections.emptyList());
        assertTrue(pila.estaVacia());
    }

    @Test
    void testApilarYAListaJuntos() {
        pila.apilar(10);
        pila.apilar(Arrays.asList(20, 30));
        assertEquals(3, pila.contarElementos());
        assertEquals(30, pila.desapilar());
        assertEquals(20, pila.desapilar());
        assertEquals(10, pila.desapilar());
    }

    @Test
    void testDesapilarHastaVacia() {
        pila.apilar(100);
        pila.apilar(200);
        assertEquals(200, pila.desapilar());
        assertEquals(100, pila.desapilar());
        assertTrue(pila.estaVacia());
        assertNull(pila.desapilar());
    }
}