package ar.uba.fi.cb100.c2025_01.semana03.jueves;

public class Clase06 {

	public static int[] v2 = new int[5];
	
	//caso 1
	public static void main1() {
		int[] aux = null;
		{
			int[] v1 = new int[5];
			v1[0] = 98;
			aux = v1;
		}
		{
			int[] v1 = new int[5];
			System.out.println(v1[0] + "-" + v1[6]);
			
			System.out.println(aux[0]);
			
		}
		
	}
	
	
	public static int[] funcion2() {
		int[] v1 = new int[8];
		return v1;
	}
	
	public static void funcion1(int[] v1) {
		v1[0] = 98;
		v2[0] = 99;
	}
	
	//caso 2
	public static void main() {
		int[] v1 = funcion2();
		System.out.println(v1[0]);
		//System.out.println(v2[0]);
	}
}
