package ar.uba.fi.cb100.semana15.miercoles.lucas.v1;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;
import ar.uba.fi.cb100.semana08.miercoles.estructuras.Cola;


public class Mecanico {
	
    /**
     * pre: 
     * post: devuelve una lista de talleres que coinciden con la especialidad y el rango horario especificado.
     * 		 si no hay talleres que cumplan con los criterios, se devuelve una lista vacía.
     *
     * @param talleresDisponibles	la lista de talleres no debe ser nula.
     * @param especialidad		    la especialidad no debe ser una cadena vacía.
     * @param horaDesde             debe ser mayor a 0.
     * @param horaHasta             debe ser mayor a 0.
     * @throws Exception            si la lista de talleres es nula o la especialidad no es válida.
     */
	public ListaConCursor<Taller> filtrarTaller(Cola<Taller> talleresDisponibles, String especialidad, int horaDesde, int horaHasta) throws Exception {
		
		if (talleresDisponibles == null) {
			throw new Exception("La lista de talleres esta vacia");
		}
		if (especialidad.length() == 0) {
			throw new Exception("Especialidad no seleccionada");
		}
		if ((horaDesde <= 0) || (horaHasta <= 0)) {
			return new ListaConCursor<Taller>();
		}
		
		ListaConCursor<Taller> talleresResultantes = new ListaConCursor<Taller>();
		
		while (!talleresDisponibles.estaVacia()) {
			
			Taller taller = talleresDisponibles.desacolar();
			
			if (perteneceALaLista(taller.obtenerEspecialidades(), especialidad)) {
				
				if (hayHorarioDisponible(taller.obtenerTurnos(), horaDesde, horaHasta)) {
					talleresResultantes.agregar(taller);
				}
			}
			
		}
		
		return talleresResultantes;
		
	}
	
	   /**
     * pre: -
     * post:	devuelve true si existe un turno que cubre el rango horario solicitado (horaDesde, horaHasta).
     * 			devuelve false si no hay ningún turno que cubra ese rango horario.
     *
     * @param obtenerTurnos		la lista de turnos no debe ser nula.
     * @param horaDesde         debe ser mayor a 0.
     * @param horaHasta 		debe ser mayor a 0
     * @throws Exception        si la lista de turnos es nula o las horas no son válidas.
     */
	
	private boolean hayHorarioDisponible(ListaConCursor<Turno> obtenerTurnos, int horaDesde, int horaHasta) throws Exception {
		if (obtenerTurnos == null) {
			throw new Exception("La lista de turnos esta vacia");
		}
		
		if ((horaDesde <= 0) || (horaHasta <= 0)) {
			return false;
		}
		
		obtenerTurnos.iniciarCursor();
		
		while (obtenerTurnos.avanzarCursor()) {
			
			Turno turno = obtenerTurnos.obtenerCursor();
			
			if ((turno.obtenerHoraDesde() <= horaDesde) && (turno.obtenerHoraHasta() >= horaHasta)) {
				return true;
			}
		}
		
		return false;
	}

    /**
     * pre: 
     * post:	devuelve true si el string existe en la lista.
 				devuelve false si el string no existe en la lista.
     *
     * @param lista			la lista no debe ser nula.
     * @param string		si es vacio devuelve false.
     * @throws Exception si la lista es nula o el string a comparar es vacío.
     */
	private boolean perteneceALaLista(ListaConCursor<String> lista, String string) throws Exception {
		
		if (lista == null) {
			throw new Exception("La lista esta vacia");
		}
		if (string.length() == 0) {
			return false;
		}
		
		lista.iniciarCursor();
		
		while (lista.avanzarCursor()) {
			
			String stringAComparar = lista.obtenerCursor();
			
			if (stringAComparar.equals(string)) {
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		Double i = 10d;
		
		if (i.equals(0.0)) {
			
		}
		if ( i == null) {
			
		}
	}

}
