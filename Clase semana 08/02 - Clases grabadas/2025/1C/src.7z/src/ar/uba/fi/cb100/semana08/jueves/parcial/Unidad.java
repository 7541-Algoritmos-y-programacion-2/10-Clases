package ar.uba.fi.cb100.semana08.jueves.parcial;

public enum Unidad {
	KILO,
	LITRO
}
