package ar.uba.fi.cb100.semana14.miercoles.lucas.v1;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;
import ar.uba.fi.cb100.semana09.miercoles.tarea.abel.Comentario;
import ar.uba.fi.cb100.semana09.miercoles.tarea.abel.Imagen;

class Editor {
    /**
     * pre: 
     * pos: devuelve la Imagen con mejor promedio de calificaciones
     * @param imagenesDisponibles no debe ser nulo
     * @param cantidadDeComentarios debd ser mayor a 0
     * @throws Exception 
     */
    public Imagen seleccionarImagen(ListaConCursor<Imagen> imagenesDisponibles, int cantidadDeComentarios) throws Exception {
        if (imagenesDisponibles == null){
            throw new Exception ("Lista vacia");
        }
        if (cantidadDeComentarios < 1){
            throw new Exception ("No hay una cantidad de comentarios base");
        }
        
        Imagen imagenResultante = null;
        double mayorPromedio = 0.0;
        
        imagenesDisponibles.iniciarCursor();
        
        while (imagenesDisponibles.avanzarCursor()) {
            Imagen imagen = imagenesDisponibles.obtenerCursor();
            
            if(contarComentarios(imagen.obtenerComentarios()) < cantidadDeComentarios) {
                continue;
            }
            double promedio = obtenerMayorPromedio(imagen.obtenerComentarios());
            
            if(promedio > mayorPromedio) {
                imagenResultante = imagen;
                mayorPromedio = promedio;
            }
        }
        
        return imagenResultante;
    }
    
    /**
     * pre: 
     * pos: devuelve la cantidad de comentarios que tiene una lista de comentarios
     * @param comentarios no debe ser nulo
     * @throws Exception 
     */
    private int contarComentarios(ListaConCursor<Comentario> comentarios) throws Exception {
        if (comentarios == null) {
            throw new Exception("Lista vacia");
        }
        int contador = 0;
        
        comentarios.iniciarCursor();
        
        while (comentarios.avanzarCursor()) {
            contador ++;
        }
        
        return contador;
    }
    /**
     * pre: 
     * pos: devuelve el promedio mas alto de una lista de comentarios
     * @param comentarios no debe ser nulo
     * @throws Exception 
     */
    private double obtenerMayorPromedio (ListaConCursor<Comentario> comentarios) throws Exception {
        if (comentarios == null) {
            throw new Exception("Comentario vacio");
        }
        
        double sumatoria = 0.0;
        int comentariosValidos = 0;
        
        comentarios.iniciarCursor();
        
        while (comentarios.avanzarCursor()) {
            Comentario comentario = comentarios.obtenerCursor();
            int calificacion = comentario.getCalificacion();
            if (calificacion == 0) {
                continue;
            }
            sumatoria += calificacion;
            comentariosValidos ++;
        }
        if (comentariosValidos == 0) {
            return 0.0;
        } 
        return (sumatoria/comentariosValidos);
    }
}