package ar.uba.fi.cb100.semana15.miercoles.lucas.v1;

import java.util.Objects;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class Taller implements Comparable<Taller> {

	private String nombre = null;
	
	public ListaConCursor<String> obtenerEspecialidades() {
		// TODO Auto-generated method stub
		return null;
	}

	public ListaConCursor<Turno> obtenerTurnos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Taller other = (Taller) obj;
		return Objects.equals(nombre, other.nombre);
	}

	@Override
	public int compareTo(Taller o) {
		//validar null
		return this.nombre.compareTo(o.nombre); //1 0 -1
	}
	


}
