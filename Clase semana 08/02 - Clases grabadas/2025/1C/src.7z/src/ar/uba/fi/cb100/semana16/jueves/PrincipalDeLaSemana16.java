package ar.uba.fi.cb100.semana16.jueves;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PrincipalDeLaSemana16 extends Object {

	public static void main(String[] args) {
		List<String> lista = new ArrayList<String>();
		
		lista.add("Juan");
		lista.add("Pedro");
		//lista null
		
		System.out.println("La lista: " + lista);
		
		for(String valor: lista) {
			if (valor.contains("a")) {
				System.out.println(valor);
			}
		}
		
		Map<String, String> mapa = new HashMap<String, String>();
		
		mapa.put("152545", "Juan");
		mapa.put("152546", "Pedro");
		
		System.out.println("El mapa: " + mapa);
		
		for(String clave: mapa.keySet()) {
			System.out.println(mapa.get(clave));	
		}
		
		//String -> StringBuilder
		//Date -> DateTime
	}
}
