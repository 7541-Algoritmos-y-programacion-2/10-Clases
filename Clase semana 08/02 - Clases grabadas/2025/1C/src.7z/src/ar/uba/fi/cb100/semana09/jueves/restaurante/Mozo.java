package ar.uba.fi.cb100.semana09.jueves.restaurante;

public class Mozo {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private double propinaRecaudada = 0;
	
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Mozo() {}

//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public void agregarPropina(double propina) {
		//validar
		this.propinaRecaudada += propina;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(propinaRecaudada);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Mozo other = (Mozo) obj;
		if (Double.doubleToLongBits(propinaRecaudada) != Double.doubleToLongBits(other.propinaRecaudada)) {
			return false;
		}
		return true;
	}

	public double getPropinaRecaudada() {
		return propinaRecaudada;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public void setPropinaRecaudada(double propinaRecaudada) {
		this.propinaRecaudada = propinaRecaudada;
	}

}
