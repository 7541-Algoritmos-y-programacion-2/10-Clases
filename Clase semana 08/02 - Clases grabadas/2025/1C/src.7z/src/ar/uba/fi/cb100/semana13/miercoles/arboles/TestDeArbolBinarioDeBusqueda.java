package ar.uba.fi.cb100.semana13.miercoles.arboles;

public class TestDeArbolBinarioDeBusqueda {

    public static void main(String[] args) {
        ArbolBinarioDeBusqueda<Persona> arbol = new ArbolBinarioDeBusqueda<Persona>();
        
        // Insertar nodos en el árbol
        arbol.insertar(new Persona(50));
        arbol.insertar(new Persona(30));
        arbol.insertar(new Persona(70));
        arbol.insertar(new Persona(20));
        arbol.insertar(new Persona(40));
        arbol.insertar(new Persona(60));
        arbol.insertar(new Persona(80));

        // Buscar un nodo
        System.out.println("¿El valor 40 está en el árbol? " + arbol.buscar( new Persona(40)));

        // Recorridos
        System.out.print("Inorden: ");
        arbol.inorden();
        System.out.println();

        System.out.print("Preorden: ");
        arbol.preorden();
        System.out.println();

        System.out.print("Postorden: ");
        arbol.postorden();
        System.out.println();
    }
}
