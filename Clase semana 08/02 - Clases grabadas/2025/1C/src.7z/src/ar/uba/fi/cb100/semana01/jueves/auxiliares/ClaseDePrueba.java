package ar.uba.fi.cb100.semana01.jueves.auxiliares;

public class ClaseDePrueba {

}
