package ar.uba.fi.cb100.semana14.miercoles.nicolas;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class AdministradorDeClubSocial {

	
	/**
	 	public boolean tuvoDeuda() {
			return false;
		}
		
		public String getGrupoFamiliar() {
			return null;
		}
	 */
	
	
	/**
	 * post: Devuelve una nueva Lista con los socios, uno por familia, cuyo grupo familiar no tubo deudas.
	 * @param socios
	 * @return
	 * @throws Exception 
	 */
	
	public ListaConCursor<Socio> buscarSocioParaDescuento(ListaConCursor<Socio> socios) throws Exception{
		//Pre
		//Validar
		
		ListaConCursor<Socio> sociosParaDescuento = new ListaConCursor<Socio>();
		
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			
			String familia = socioAAnalizar.getGrupoFamiliar();
			
			ListaConCursor<String> listaFamiliasConDeuda = null; //familiasConDeuda( new Lista<Socio>(socios));
			
			boolean tieneDeuda = analizarFamiliasConDeuda(familia, listaFamiliasConDeuda);
			
			
			if (!tieneDeuda) {
				
				sociosParaDescuento.agregar(socioAAnalizar);
			}
		}
		
		return sociosParaDescuento;
		
		
	}
	
	public ListaConCursor<String> familiasConDeuda(ListaConCursor<Socio> socios) throws Exception{
		
		ListaConCursor<String> familiasConDeuda = new ListaConCursor<String>();
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			String grupoFamiliar = socioAAnalizar.getGrupoFamiliar();
			
			if (socioAAnalizar.tuvoDeuda()) {
				familiasConDeuda.agregar(grupoFamiliar);
			}
		}
		
		return familiasConDeuda;
	}
	
	public boolean analizarFamiliasConDeuda(String familia, ListaConCursor<String> familiasConDeuda) {
		
		familiasConDeuda.iniciarCursor();
		
		while (familiasConDeuda.avanzarCursor()) {
			
			String familiaAAnalizar = familiasConDeuda.obtenerCursor();
			
			if (familia.equals(familiaAAnalizar)) {
				
				return true;
			}
		}
		
		return false;
		
	}
	
}

