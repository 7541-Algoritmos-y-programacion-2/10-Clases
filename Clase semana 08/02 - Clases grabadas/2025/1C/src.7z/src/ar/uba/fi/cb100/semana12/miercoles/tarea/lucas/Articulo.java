package ar.uba.fi.cb100.semana12.miercoles.tarea.lucas;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class Articulo {

	public ListaConCursor<String> getPalabrasExcluidas() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getTitulo() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getTexto() {
		// TODO Auto-generated method stub
		return null;
	}

}
