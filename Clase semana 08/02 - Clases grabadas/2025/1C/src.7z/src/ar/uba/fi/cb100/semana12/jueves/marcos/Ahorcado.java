package ar.uba.fi.cb100.semana12.jueves.marcos;

/**
 * 
 * Tips:
 * 1 - Estrategia: hipotesis, simplificar, complejizar 
 * 2 - diseño: tipos de datos correctos, diagrama de estados, varios TDAs si corresponde
 * 3 - encapsular 
 * 4 - solucionar el problema
 * 5 - Pre y post
 * 6 - validar, robusto
 * 7 - modularizar 
 * 8 - conjunto completo de operaciones
 * 9 - get y set si corresponde
 * 
 */

public class Ahorcado {
    private String palabra;
    private int cantidadMaximaDeErrores;
    private Estado estado;
    private int cantidadDeErrores;


    /**
     * Precondiciones:
     * - Palabra no debe ser nula ni vacía.
     * - La cantidadMaximadaDeErrores debe ser un número entero positivo.
     *
     * Postcondiciones:
     * - Inicializa el  juego con la palabra a adivinar y un limite de errores.
     * - Establece el estado del juego en JUGANDO y la cantidad de errores incial en 0.
     */
    public Ahorcado(String palabra, int cantidadMaximadaDeErrores) throws Exception {
        if(palabra == null || palabra.isEmpty()){
            throw new Exception("No se puede iniciar el ahorcado con la palabra vacia");
        }
        if (cantidadMaximadaDeErrores < 0) {
        	throw new Exception("La cantidad de errores debe ser 0 o positiva");
        }
        
        this.palabra = palabra;
        this.cantidadMaximaDeErrores = cantidadMaximadaDeErrores;
        this.estado = Estado.JUGANDO;
        this.cantidadDeErrores = 0;
    }

    /**
     * Precondiciones:
     * - El estado del juego no debe estar en PERDIDO o GANADO.
     *
     * Postcondiciones:
     * - Almacena en cantidadDeApariciones la cantidad de veces que la letra aparece en la palabra.
     * - En caso de no aparecer ni 1 una vez, aumenta la cantidadDeErrores en 1.
     * - En caso de que la cantidadDeErrores sea igual a la cantidadMaximaDeErrores pone el estado de juego en PERDIDO.
     *
     *  @return devuelve la cantidad de veces que aparece la letra en la palabra
     */
    public int proponerLetra(char letra) throws Exception { //Character
        int cantidadDeApariciones = 0;
        if (this.estado != Estado.JUGANDO) {
            throw new Exception("El juego ha terminado");
        }

        for(int i=0; i<this.palabra.length(); i++){
            if(this.palabra.charAt(i) == letra){
                cantidadDeApariciones++;
            }
        }
        if(cantidadDeApariciones == 0){
            this.cantidadDeErrores++;
            if(this.cantidadDeErrores > this.cantidadMaximaDeErrores){
                this.estado = Estado.PERDIDO;
            }
        }
        return cantidadDeApariciones;
    }

    /**
     * Precondiciones:
     * - El estado de juego debe estar en JUGANDO.
     *
     * Postcondiciones:
     * - En caso de que la palabra propuesta sea correcta, se cambia el estado de juego a GANADO.
     * - Caso contrario, se cambia el estado de juego a PERDIDO.
     *
     * @return devuelve true en caso de que la palabra sea correcta, false en caso contrario.
     */
    public boolean arriesgar(String palabra) throws Exception {
        if(this.estado != Estado.JUGANDO){
            throw new Exception("El juego ha terminado");
        }
        if(this.palabra.equals(palabra)){
            estado = Estado.GANADO;
            return true;
        }
        else{
            estado = Estado.PERDIDO;
            return false;
        }
    }

    /**
     * @return devuelve una cadena vacia en caso de que el juego este en estado JUGANDO. Caso contrario devuelve la palabra.
     */
    public String getPalabra(){
        if(this.estado == Estado.JUGANDO){
            return "";
        }
        else{
            return this.palabra;
        }
    }

    /**
     * @return devuelve la cantidad de caracteres de la palabra.
     */
    public int getCantidadLetras(){
        return this.palabra.length();
    }

    /**
     * @return devuelve el estado de juego actual.
     */
    public Estado getEstadoJuego(){
        return this.estado;
    }

    /**
     * @return devuelve la cantidad de errores actual.
     */
    public int getCantidadDeErrores(){
        return this.cantidadDeErrores;
    }

}
