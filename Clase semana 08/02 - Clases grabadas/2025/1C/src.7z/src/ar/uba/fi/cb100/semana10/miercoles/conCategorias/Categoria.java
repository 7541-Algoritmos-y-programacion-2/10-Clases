package ar.uba.fi.cb100.semana10.miercoles.conCategorias;

public class Categoria {
	/*
	* post: inicializa la categoria con el nombre y la * descripción indicadas. 
	*/ 
	public Categoria(String nombre, String descripcion) {} /* post: devuelve el nombre que la identifica. */ 
	
	public String getNombre() {
		return null;
	}
	
	/* post: devuelve la descripción de la categoria. */ 
	public String getDescripcion() {
		return null;
	}
}
