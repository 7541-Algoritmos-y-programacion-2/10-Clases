package ar.uba.fi.cb100.semana10.jueves.tp2;

public class Turno {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Jugador jugador = null;
	private int cantidadDeSubTurnos = 1;
	private int bloqueosRestantes = 0;
	
//CONSTRUCTORES -------------------------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public void incrementarBloqueosRestantes(int cantidadDeBloqueos) {
		this.bloqueosRestantes += cantidadDeBloqueos;
	}

	public void terminarTurno() {
		if (this.bloqueosRestantes > 0) {
			this.bloqueosRestantes--;
		}		
	}
	
	public void iniciarTurno() {
		this.cantidadDeSubTurnos += 1;		
	}
	
	public void agregarSubturno() {
		this.cantidadDeSubTurnos += 1;
	}
	
	public boolean haySubturnos() {
		return this.cantidadDeSubTurnos >= 0;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public Jugador getJugador() {
		return jugador;
	}

	public boolean estaBloqueado() {
		return this.bloqueosRestantes <= 0;
	}

	public int getCantidadDeSubTurnos() {
		return this.cantidadDeSubTurnos;
	}

	public void utilizarSubturno() {
		this.cantidadDeSubTurnos--;		
	}



//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}
