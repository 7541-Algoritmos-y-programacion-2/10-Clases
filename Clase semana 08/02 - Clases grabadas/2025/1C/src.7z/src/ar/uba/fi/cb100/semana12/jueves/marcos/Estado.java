package ar.uba.fi.cb100.semana12.jueves.marcos;

public enum Estado{
    JUGANDO, GANADO, PERDIDO
}
