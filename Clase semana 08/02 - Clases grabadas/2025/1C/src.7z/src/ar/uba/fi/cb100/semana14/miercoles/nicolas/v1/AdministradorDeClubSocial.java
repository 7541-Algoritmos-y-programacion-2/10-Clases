package ar.uba.fi.cb100.semana14.miercoles.nicolas.v1;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;
import ar.uba.fi.cb100.semana14.miercoles.nicolas.Socio;

public class AdministradorDeClubSocial {

	
	/**
	 	public boolean tuvoDeuda() {
			return false;
		}
		
		public String getGrupoFamiliar() {
			return null;
		}
	 */
	
	
	/**
	 * pre: Recibe la lista de socios a analizar.
	 * post: Devuelve una nueva Lista con los socios, uno por familia, cuyo grupo familiar no tuvo deudas.
	 * @param socios
	 * @return
	 * @throws Exception 
	 */
	
	public ListaConCursor<Socio> buscarSocioParaDescuento(ListaConCursor<Socio> socios) throws Exception{
		
		if (socios == null) {
			throw new Exception("Los socios no pueden ser nulos");
		}
		
		if (socios.getLongitud() == 0) {
			throw new Exception("Los socios deben ser mayor a cero");
		}
		
		
		ListaConCursor<String> listaFamiliasConDeuda = familiasConDeuda(socios);
		
		ListaConCursor<Socio> sociosParaDescuento = new ListaConCursor<Socio>();
		
		ListaConCursor<String> familiasSinDeudaAgregadas = new ListaConCursor<String>();
		
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			
			
			if (!listaFamiliasConDeuda.existe(socioAAnalizar.getGrupoFamiliar()) && 
					!familiasSinDeudaAgregadas.existe(socioAAnalizar.getGrupoFamiliar())) {
				
				sociosParaDescuento.agregar(socioAAnalizar);
				familiasSinDeudaAgregadas.agregar(socioAAnalizar.getGrupoFamiliar());
			}
		}
		
		return sociosParaDescuento;

	}
	
	/**
	 * pre: Recibe una lista de socios para analizar
	 * post: Recorre la lista de socios, busca quienes tuvieron deuda y guarda el grupo familiar.
	 * Despues, devuelve esa lista con socios deudores. Si hay algun error, tira excepcion.
	 * @param socios
	 * @return
	 * @throws Exception
	 */
	
	public ListaConCursor<String> familiasConDeuda(ListaConCursor<Socio> socios) throws Exception{
		
		if (socios == null) {
			throw new Exception("Los socios no pueden ser nulos");
		}
		
		if (socios.getLongitud() == 0) {
			throw new Exception("Los socios deben ser mayor a cero");
		}
	
		ListaConCursor<String> familiasConDeuda = new ListaConCursor<String>();
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			
			if (socioAAnalizar.tuvoDeuda() && !familiasConDeuda.existe(socioAAnalizar.getGrupoFamiliar())) {
				familiasConDeuda.agregar(socioAAnalizar.getGrupoFamiliar());
			}
		}
		
		return familiasConDeuda;
	}
	
	
}

