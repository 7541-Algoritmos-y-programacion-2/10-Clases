package ar.uba.fi.cb100.semana12.jueves.emma;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class Foro {

	public ListaConCursor<String> obtenerTematicas() {
		// TODO Auto-generated method stub
		return null;
	}

	public ListaConCursor<Mensaje> obtenerMensajes() {
		// TODO Auto-generated method stub
		return null;
	}

}
