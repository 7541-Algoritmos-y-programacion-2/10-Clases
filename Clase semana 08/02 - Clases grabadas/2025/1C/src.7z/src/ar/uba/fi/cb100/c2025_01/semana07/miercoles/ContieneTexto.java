package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

public class ContieneTexto implements Contenible<String> {

	@Override
	public boolean contiene(String dato, Object valor) {
		String texto = (String) dato;
		return texto.toLowerCase().contains(valor.toString().toLowerCase());
	}

}
