package ar.uba.fi.cb100.semana12.miercoles.parcial;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class TextoUtiles {

	/**
	 * 
	 * @param texto
	 * @param palabrasClaves
	 * @return dado un texto y un conjunto de palabras, devuelve verdadero si el texto tiene a todas las palabras
	 */
	public static boolean contieneTodas(String texto, ListaConCursor<String> palabrasClaves) {
		//validar
		palabrasClaves.iniciarCursor();
		while(palabrasClaves.avanzarCursor()) {
			String palabraClave = palabrasClaves.obtenerCursor();
			if (texto.indexOf(palabraClave) < 0) {
				return false;
			}
		}
		return true;
	}
	
	
	/**
	 * 
	 * @param palabras
	 * @param palabras
	 * @return
	 */
	public static boolean contieneAlguna(ListaConCursor<String> palabrasAChequear, ListaConCursor<String> palabras) {
		//validar
		palabrasAChequear.iniciarCursor();
		while(palabrasAChequear.avanzarCursor()) {
			String palabraAChequear = palabrasAChequear.obtenerCursor();
			if (contiene(palabraAChequear, palabras)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param palabra
	 * @param palabras
	 * @return
	 */
	public static boolean contiene(String palabraAChequear, ListaConCursor<String> palabras) {
		//validar
		palabras.iniciarCursor();
		while(palabras.avanzarCursor()) {
			String palabra = palabras.obtenerCursor();
			if (palabraAChequear.equals(palabra)) {
				return true;
			}
		}
		return false;
	}
}
