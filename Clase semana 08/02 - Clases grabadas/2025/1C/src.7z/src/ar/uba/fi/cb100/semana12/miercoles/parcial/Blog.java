package ar.uba.fi.cb100.semana12.miercoles.parcial;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;
import ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.Articulo;

/**
 * 
 * Tips:
 * 1 - solucionar el problema
 * 2 - Pre y post
 * 3 - validar
 * 4 - modularizar (partir el codigo en partes utiles, la estructura es while / if )
 * 5 - cumplir con TDA (conjunto completo de operaciones)
 * 
 */
public class Blog {

    private ListaConCursor<Articulo> articulos;
    
    public ListaConCursor<Articulo> getArticulos() {
        return articulos;
    }
    
	/**
	 * pre: 
	 * @param palabrasClaves no puede ser nula
	 * @return
	 * @throws Exception 
	 */
	public ListaConCursor<Articulo> buscarArticulos(ListaConCursor<String> palabrasClaves) throws Exception {
		if (palabrasClaves == null) {
			throw new Exception("Las palabras claves no pueden ser nulas");
		}
		
        ListaConCursor<Articulo> resultado = new ListaConCursor<Articulo>();    
        articulos.iniciarCursor();
        
        while(articulos.avanzarCursor()) {
            Articulo articuloARevisar = articulos.obtenerCursor();
            if (TextoUtiles.contieneTodas(articuloARevisar.getTitulo() + " " + articuloARevisar.getTexto(), 
            								palabrasClaves) &&
            	!TextoUtiles.contieneAlguna(articuloARevisar.getPalabrasExcluidas(), palabrasClaves)) {
            	resultado.agregar(articuloARevisar);
            }
        }            
		return resultado;
	}

}
