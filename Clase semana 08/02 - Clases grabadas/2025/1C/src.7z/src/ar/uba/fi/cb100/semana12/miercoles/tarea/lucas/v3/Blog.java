package ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.v3;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;
import ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.Articulo;

public class Blog {
    
    private ListaConCursor<Articulo> articulos;
    
    public ListaConCursor<Articulo> getArticulos() {
        return articulos;
    }
    
    /**
     * busca artículos que contengan alguna de las palabras clave proporcionadas
     * 
     * @param palabrasClaves lista de palabras clave para buscar
     * @return lista de artículos que contienen alguna de las palabras clave
     * @throws Exception si la lista es nula
     * 
     * pre: palabrasClaves no debe ser null
     * pos: devuelve una lista de artículos que contienen alguna de las palabras clave
     * 		y ninguna palabra excluida
     */
    public ListaConCursor<Articulo> buscarArticulos(ListaConCursor<String> palabrasClaves) throws Exception {
        
        if(palabrasClaves == null) {
            throw new Exception("La lista esta vacia");
        } 
        
        ListaConCursor<Articulo> resultado = new ListaConCursor<Articulo>();    
        
        ListaConCursor<Articulo> articulos = this.getArticulos();
        
        articulos.iniciarCursor();
        
        while(articulos.avanzarCursor()) {
            Articulo articuloARevisar = articulos.obtenerCursor();
            
            if (!contieneAlgunaPalabra(articuloARevisar.getPalabrasExcluidas(), palabrasClaves)
            	&& (contieneAlgunaPalabraEnTexto(articuloARevisar.getTitulo() + " " + articuloARevisar.getTexto(), palabrasClaves))) {
            	
            	resultado.agregar(articuloARevisar);  	
            }            
        }        
        return resultado;
    }

    /**
     * verifica si una lista de strings contiene algun string de otra lista de strings proporcionada
     * @param palabrasAComparar lista de palabras a comparar
     * @param palabrasClaves lista de palabras clave a buscar
     * @return true si la lista a comparar contiene alguna palabra de la otra lista, false en caso contrario
     * @throws Exception si alguna lista es nula
     *
     * pre: palabrasAComparar y palabrasClaves no deben ser null
     * pos: devuelve true si se encuentra una palabra en comun, false en caso contrario
     */
	private boolean contieneAlgunaPalabra(ListaConCursor<String> palabrasAComparar, ListaConCursor<String> palabrasClaves) throws Exception {
		
		if ((palabrasAComparar == null) || 
			(palabrasClaves == null)) {
			throw new Exception("No es posible comparar con un nulo");
		}
    		
		palabrasAComparar.iniciarCursor();
		
		while (palabrasAComparar.avanzarCursor()) {
			
			String palabraExcluida = palabrasAComparar.obtenerCursor();
			
			if (continePalabra(palabraExcluida, palabrasClaves)) {
				return true;
			}
		}
    	return false;    	
    }    
    
    /**
     * verifica si un texto contiene alguna de las palabras clave proporcionadas
     * @param texto texto a revisar
     * @param palabrasClaves lista de palabras clave a buscar
     * @return true si el texto contiene alguna de las palabras clave, false en caso contrario
     * @throws Exception si la lista de palabras clave nulo o el texto esta vacio
     *
     * pre: palabrasClaves no debe ser null, texto no debe ser vacio
     * pos: devuelve true si el texto contiene alguna de las palabras clave, false en caso contrario
     */
	private boolean contieneAlgunaPalabraEnTexto(String texto, ListaConCursor<String> palabrasClaves) throws Exception {

		if (texto.isEmpty()) {
			throw new Exception("No hay texto a revisar");
		}		
		if (palabrasClaves == null) {
			throw new Exception("No hay palabras a revisar");
		}
		
    	palabrasClaves.iniciarCursor();
    	
    	while (palabrasClaves.avanzarCursor()) {
    		
    		String palabra = palabrasClaves.obtenerCursor();
    		
    		 if (texto.indexOf(palabra) > 0) {
    	            return true;
    	        }
    	    }
    	
    	    return false;
	}    
    
    /**
     * revisa si una palabra excluida se encuentra dentro de la lista de palabras clave
     *
     * @param frase palabra a buscar en la lista de claves
     * @param palabrasClaves lista de palabras clave
     * @return true si la palabra excluida se encuentra en la lista, false en caso contrario
     * @throws Exception si la lista de palabras clave es nula  o la palabra esta vacia
     *
     * pre: palabrasClaves no debe ser null, palabra no debe estar vacia
     * pos: devuelve true si la palabra excluida se encuentra en la lista, false en caso contrario
     */
    private boolean continePalabra(String frase, ListaConCursor<String> palabrasClaves) throws Exception {
		
    	if (frase.isEmpty()) {
    		throw new Exception("No hay palabra a comparar");
    	}
    	if (palabrasClaves == null) {
    		throw new Exception("No hay una lista valida");
    	}
    	
    	palabrasClaves.iniciarCursor();
    	
    	while (palabrasClaves.avanzarCursor()) {
    		String palabraClave = palabrasClaves.obtenerCursor();
    		
    		if (palabraClave.equals(frase)) {
    			return true;
    		}
    	}
    	return false;		
	}                 
}