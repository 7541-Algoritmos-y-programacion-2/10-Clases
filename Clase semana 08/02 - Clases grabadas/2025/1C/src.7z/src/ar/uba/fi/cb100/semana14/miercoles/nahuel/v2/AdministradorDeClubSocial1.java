package ar.uba.fi.cb100.semana14.miercoles.nahuel.v2;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class AdministradorDeClubSocial1 {
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los socios, uno por familia, cuyo grupo familiar no tubo deudas.
	 */
	public static ListaConCursor<Socio> buscarSociosParaDescuento(ListaConCursor<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		ListaConCursor<String> familiasDeudoras = getFamiliasDeudoras(socios);
		ListaConCursor<String> familiasEnResultado = new ListaConCursor<String>();
		ListaConCursor<Socio> resultado = new ListaConCursor<Socio>();


		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.obtenerCursor();
			if ((!familiasDeudoras.contiene( socio.getGrupoFamiliar())) &&
		            (!familiasEnResultado.contiene( socio.getGrupoFamiliar()))) {
				familiasEnResultado.agregar(socio.getGrupoFamiliar());
				resultado.agregar(socio);
			}
		}
		return resultado;
	}
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los apellidos de las familias de las 
	 * cuales por lo menos 1 integrante tubo deuda.
	 */
	public static ListaConCursor<String> getFamiliasDeudoras(ListaConCursor<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		ListaConCursor<String> resultado = new ListaConCursor<String>();
		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.getCursor();
			if((socio.tuvoDeuda()) && (!resultado.contiene(socio.getGrupoFamiliar()))) {
				resultado.agregar(socio.getGrupoFamiliar());
			}
		}
		return resultado;
	}
	
}
