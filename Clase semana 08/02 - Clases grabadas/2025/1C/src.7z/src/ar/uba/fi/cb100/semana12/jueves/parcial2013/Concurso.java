package ar.uba.fi.cb100.semana12.jueves.parcial2013;

import ar.uba.fi.cb100.material.estructuras.lista.ListaConCursor;

public class Concurso {

	/*  post:  inicializa  el  consurso  sin  participantes
	 *	asociados,  con  el  nombre  indicado.
	 */
	public Concurso(String nombre) {}
	
	
	/*  post:  devuelve  el  nombre  que  identifica  el  consurso.
	 */
	public String getNombre() { return null;}
	
	/*  post:  devuelve  los  participantes  asociados
	 */
	public ListaConCursor<Participante> getParticipante() { return null;}
	/*  post:  devuelve  los  nombres  de  aquellos  participantes
	 *	que  han  sido  premiados  por  su  participación.
	 */
	public ListaConCursor<String> getPremiados() {return null;}
};
