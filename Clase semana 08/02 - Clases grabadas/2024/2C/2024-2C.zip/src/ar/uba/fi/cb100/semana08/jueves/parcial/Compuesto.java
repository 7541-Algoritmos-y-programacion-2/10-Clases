package ar.uba.fi.cb100.semana08.jueves.parcial;

public class Compuesto {

	public Compuesto(String nombre, Unidad unidadDeMedida) {
		
	}
	
	public String getNombre() {
		return null;
	}
	
	public Unidad getUnidadDeMedida() {
		return null;
	}
	
	public double getCantidad() {
		return 0;
	}
	
	void setCantidad(double cantidad) {}
	
}
