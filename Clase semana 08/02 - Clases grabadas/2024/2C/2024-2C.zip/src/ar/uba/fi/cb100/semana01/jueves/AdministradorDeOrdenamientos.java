package ar.uba.fi.cb100.semana01.jueves;

public class AdministradorDeOrdenamientos {

	public static int[] ordenarmientoDeBurbuja(int[] vector) {
		return new int[10];
	}
}
