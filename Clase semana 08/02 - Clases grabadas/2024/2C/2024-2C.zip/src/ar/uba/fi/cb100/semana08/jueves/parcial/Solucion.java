package ar.uba.fi.cb100.semana08.jueves.parcial;

import ar.uba.fi.cb100.semana08.miercoles.estructuras.Lista;

public class Solucion {

	public Solucion(String codigo) {
		
	}
	
	public String getCodigo() {
		return null;
	}
	
	Lista<Compuesto> getCompuestos() {
		return null;
	}
	
}
