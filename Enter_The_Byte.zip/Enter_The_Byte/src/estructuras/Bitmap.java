package estructuras;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import utiles.ValidacionesUtiles;

/**
 * Bitmap.
 */
public class Bitmap {

    private int width;
    private int height;
    private BufferedImage image;
    private double distanceToCamera = 200;

    /**
     * Crea un nuevo objeto Bitmap con el ancho y alto especificados, inicializado como una imagen RGB en blanco.
     * @param width El ancho del bitmap (debe ser mayor a cero).
     * @param height El alto del bitmap (debe ser mayor a cero).
     */
    public Bitmap(int width, int height) {
        ValidacionesUtiles.validarMayorACero(width, "ancho");
        ValidacionesUtiles.validarMayorACero(height, "alto");
        this.width = width;
        this.height = height;
        this.image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    }

    /**
     * Dibuja un único píxel en las coordenadas (x, y) con el color especificado.
     * @param x Coordenada X.
     * @param y Coordenada Y.
     * @param color El color del píxel (no debe ser nulo).
     */
    public void drawPixel(int x, int y, Color color) {
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        if (x >= 0 && x < width && y >= 0 && y < height) {
            image.setRGB(x, y, color.getRGB());
        }
    }

    /**
     * Dibuja una línea entre (x1, y1) y (x2, y2) utilizando el algoritmo de línea de Bresenham.
     * @param x1 Coordenada X de inicio.
     * @param y1 Coordenada Y de inicio.
     * @param x2 Coordenada X de fin.
     * @param y2 Coordenada Y de fin.
     * @param color El color de la línea (no debe ser nulo).
     */
    public void drawLine(int x1, int y1, int x2, int y2, Color color) {
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        int dx = Math.abs(x2 - x1);
        int dy = Math.abs(y2 - y1);
        int sx = x1 < x2 ? 1 : -1;
        int sy = y1 < y2 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            drawPixel(x1, y1, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x1 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y1 += sy;
            }
        }
    }

    /**
     * Dibuja el contorno de un rectángulo en (x, y) con el ancho y alto especificados.
     * @param x Coordenada X de la esquina superior izquierda.
     * @param y Coordenada Y de la esquina superior izquierda.
     * @param width El ancho del rectángulo.
     * @param height El alto del rectángulo.
     * @param color El color del contorno (no debe ser nulo).
     */
    public void drawRectangle(int x, int y, int width, int height, Color color) {
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        drawLine(x, y, x + width, y, color);
        drawLine(x, y, x, y + height, color);
        drawLine(x + width, y, x + width, y + height, color);
        drawLine(x, y + height, x + width, y + height, color);
    }

    /**
     * Rellena un área rectangular en (x, y) con el color especificado.
     * @param x Coordenada X de la esquina superior izquierda.
     * @param y Coordenada Y de la esquina superior izquierda.
     * @param width El ancho del área a rellenar.
     * @param height El alto del área a rellenar.
     * @param color El color de relleno (no debe ser nulo).
     */
    public void drawRectangleFill(int x, int y, int width, int height, Color color) {
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        for (int i = y; i < y + height; i++) {
            for (int j = x; j < x + width; j++) {
                drawPixel(j, i, color);
            }
        }
    }

    /**
     * Dibuja el contorno de un círculo centrado en (centerX, centerY) con un radio dado.
     * @param centerX Coordenada X del centro.
     * @param centerY Coordenada Y del centro.
     * @param radius El radio del círculo (debe ser mayor o igual a cero).
     * @param color El color del contorno (no debe ser nulo).
     */
    public void drawCircle(int centerX, int centerY, int radius, Color color) {
        ValidacionesUtiles.validarRangoNumerico(radius, 0, Math.min(getWidth(), getHeight()), "ancho");
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        int x = radius;
        int y = 0;
        int err = 0;

        while (x >= y) {
            drawPixel(centerX + x, centerY + y, color);
            drawPixel(centerX + y, centerY + x, color);
            drawPixel(centerX - y, centerY + x, color);
            drawPixel(centerX - x, centerY + y, color);
            drawPixel(centerX - x, centerY - y, color);
            drawPixel(centerX - y, centerY - x, color);
            drawPixel(centerX + y, centerY - x, color);
            drawPixel(centerX + x, centerY - y, color);

            y++;
            if (err <= 0) {
                err += 2 * y + 1;
            }
            if (err > 0) {
                x--;
                err -= 2 * x + 1;
            }
        }
    }

    /**
     * Dibuja una cadena de texto en el Bitmap en las coordenadas especificadas, con la fuente, color
     * y color de fondo dados.
     * @param text La cadena de texto a dibujar.
     * @param x Coordenada X de inicio del texto.
     * @param y Coordenada Y de inicio del texto (generalmente la base de la línea).
     * @param font La fuente a utilizar (no debe ser nula).
     * @param color El color del texto (no debe ser nulo).
     * @param background El color de fondo sobre el que se dibuja el texto. Si es null, no se dibuja fondo.
     */
    public void drawText(String text, int x, int y, Font font, Color color, Color background) {
        ValidacionesUtiles.esDistintoDeNull(font, "fuente");
        ValidacionesUtiles.esDistintoDeNull(color, "color");
        Graphics2D g = image.createGraphics();

        if (background != null) g.setColor(background);
        FontMetrics fm = g.getFontMetrics();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        int textAscent = fm.getAscent();
        int paddingSuperior = 5;
        int paddingInferior = 10;
        g.fillRect(x - paddingInferior, y - textAscent - paddingInferior, textWidth + (paddingSuperior*4), textHeight + (paddingSuperior*2));

        g.setFont(font);
        g.setColor(color);
        g.drawString(text, x, y);
        g.dispose();
    }

    /**
     * Pega el contenido de otro Bitmap en este Bitmap en las coordenadas (x, y).
     * @param other El Bitmap de origen que se va a pegar.
     * @param x Coordenada X de la esquina superior izquierda para la colocación.
     * @param y Coordenada Y de la esquina superior izquierda para la colocación.
     */
    public void pasteBitmap(Bitmap other, int x, int y) {
        Graphics2D g = image.createGraphics();
        g.drawImage(other.image, x, y, null);
        g.dispose();
    }

    /**
     * Guarda el contenido del Bitmap en un archivo en la ruta especificada.
     * @param path La ruta completa del archivo de destino.
     * @return La ruta absoluta del archivo guardado.
     * @throws IOException Si ocurre un error de entrada/salida durante la escritura.
     */
    public String saveToFile(String path) throws IOException {
        File output = new File(path);
        ImageIO.write(image, "bmp", output);
        return output.getAbsolutePath();
    }

    /**
     * Carga un Bitmap desde un archivo de imagen en la ruta especificada.
     * @param path La ruta del archivo de imagen (ej. "ruta/imagen.bmp").
     * @return Un nuevo objeto Bitmap con el contenido del archivo.
     * @throws IOException Si ocurre un error de entrada/salida o el archivo no se encuentra.
     */
    public static Bitmap loadFromFile(String path) throws IOException {
        BufferedImage img = ImageIO.read(new File(path));
        Bitmap bmp = new Bitmap(img.getWidth(), img.getHeight());
        bmp.image = img;
        return bmp;
    }

    /**
     * Proyecta una coordenada X 3D a una coordenada X 2D en pantalla.
     * @param x Coordenada X 3D.
     * @param z Coordenada Z 3D.
     * @return Coordenada X 2D proyectada.
     */
    private int projectX(double x, double z) {
        return (int) (this.width / 2 + x * distanceToCamera / (z + distanceToCamera));
    }

    /**
     * Proyecta una coordenada Y 3D a una coordenada Y 2D en pantalla.
     * @param y Coordenada Y 3D.
     * @param z Coordenada Z 3D.
     * @return Coordenada Y 2D proyectada.
     */
    private int projectY(double y, double z) {
        return (int) (this.height / 2 - y * distanceToCamera / (z + distanceToCamera));
    }

    /**
     * Dibuja una línea en un espacio 3D proyectándola al espacio 2D del Bitmap.
     * @param x1 Coordenada X 3D de inicio.
     * @param y1 Coordenada Y 3D de inicio.
     * @param z1 Coordenada Z 3D de inicio.
     * @param x2 Coordenada X 3D de fin.
     * @param y2 Coordenada Y 3D de fin.
     * @param z2 Coordenada Z 3D de fin.
     * @param color El color de la línea.
     */
    public void drawLine3D(double x1, double y1, double z1, double x2, double y2, double z2, Color color) {
        int x1p = projectX(x1, z1);
        int y1p = projectY(y1, z1);
        int x2p = projectX(x2, z2);
        int y2p = projectY(y2, z2);
        this.drawLine(x1p, y1p, x2p, y2p, color);
    }

    /**
     * Dibuja el contorno de un cubo en un espacio 3D proyectándolo al espacio 2D del Bitmap.
     * @param size El tamaño de los lados del cubo.
     * @param cx Coordenada X del centro del cubo.
     * @param cy Coordenada Y del centro del cubo.
     * @param cz Coordenada Z del centro del cubo.
     * @param color El color del cubo.
     */
    public void drawCube(double size, double cx, double cy, double cz, Color color) {
        double[][] vertices = new double[8][3];
        int i = 0;
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dy = -1; dy <= 1; dy += 2) {
                for (int dz = -1; dz <= 1; dz += 2) {
                    vertices[i][0] = cx + dx * size / 2;
                    vertices[i][1] = cy + dy * size / 2;
                    vertices[i][2] = cz + dz * size / 2;
                    i++;
                }
            }
        }

        int[][] edges = {
            {0, 1}, {1, 3}, {3, 2}, {2, 0},
            {4, 5}, {5, 7}, {7, 6}, {6, 4},
            {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };

        for (int[] edge : edges) {
            double[] p1 = vertices[edge[0]];
            double[] p2 = vertices[edge[1]];
            drawLine3D(p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], color);
        }
    }

    /**
     * Devuelve la imagen subyacente de Java (BufferedImage) utilizada para el dibujo.
     * @return La BufferedImage.
     */
    public java.awt.image.BufferedImage getImage() {
        return image;
    }

    /**
     * Devuelve el ancho del Bitmap.
     * @return El ancho en píxeles.
     */
    public int getWidth() {
    	return width;
    }
    
    /**
     * Devuelve el alto del Bitmap.
     * @return El alto en píxeles.
     */
    public int getHeight() {
    	return height;
    }
}


