package estructuras;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import utiles.ValidacionesUtiles;

/**
 * Clase que gestiona la visualización de tres objetos Bitmap (Tablero, Mensajes y Batalla).
 */
public class BitmapViewerTabs {

    private JFrame frame;
    private JTabbedPane tabs;

    private JPanel panelTablero;
    private JPanel panelMensajes;
    private JPanel panelBatalla;

    private final Bitmap tableroBmp;
    private final Bitmap mensajesBmp;
    private final Bitmap batallaBmp;

    /**
     * Iniciamos el visor con los tres Bitmaps principales del juego.
     * @param tablero El Bitmap que contiene la imagen del tablero principal.
     * @param mensajes El Bitmap que contiene la imagen para los mensajes y diálogos.
     * @param batalla El Bitmap que contiene la imagen para la interfaz de batalla.
     */
    public BitmapViewerTabs(Bitmap tablero, Bitmap mensajes, Bitmap batalla) {
    	
    	ValidacionesUtiles.esDistintoDeNull(tablero, "Tablero");
    	ValidacionesUtiles.esDistintoDeNull(mensajes, "Mensajes");
    	ValidacionesUtiles.esDistintoDeNull(batalla, "Batalla");
    	
        this.tableroBmp = tablero;
        this.mensajesBmp = mensajes;
        this.batallaBmp = batalla;
        SwingUtilities.invokeLater(this::createGUI);
    }

    /**
     * Crea la Interfaz Gráfica de Usuario (GUI): inicializa el JFrame, el JTabbedPane,
     * y los JPanels, y añade las pestañas correspondientes a cada Bitmap.
     */
    private void createGUI() {
        frame = new JFrame("Rolgar II - Interfaz");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        tabs = new JTabbedPane();

        panelTablero = createPanelWithBitmap(tableroBmp);
        panelMensajes = createPanelWithBitmap(mensajesBmp);
        panelBatalla = createPanelWithBitmap(batallaBmp);

        tabs.addTab("Tablero", panelTablero);
        tabs.addTab("Mensajes", panelMensajes);
        tabs.addTab("Batalla", panelBatalla);

        frame.add(tabs, BorderLayout.CENTER);

        frame.setSize(1100, 850);
        frame.setVisible(true);
        new Timer(300, e -> refresh()).start();
    }

    /**
     * Crea un JPanel simple que contiene un JLabel con la imagen del Bitmap proporcionado.
     * @param bmp El Bitmap cuya imagen se quiere mostrar.
     * @return Un JPanel configurado para mostrar el contenido del Bitmap.
     */
    private JPanel createPanelWithBitmap(Bitmap bmp) {
    	
    	ValidacionesUtiles.esDistintoDeNull(bmp, "Bitmap");
    	
        JPanel panel = new JPanel(new GridLayout(1, 1));
        JLabel label = new JLabel(new ImageIcon(bmp.getImage()));
        panel.add(label);
        return panel;
    }

    /**
     * Actualiza las imágenes de los JLabels en todas las pestañas 
     * para reflejar los cambios realizados en los objetos Bitmap.
     */
    private void refresh() {
        ((JLabel) panelTablero.getComponent(0)).setIcon(new ImageIcon(tableroBmp.getImage()));
        ((JLabel) panelMensajes.getComponent(0)).setIcon(new ImageIcon(mensajesBmp.getImage()));
        ((JLabel) panelBatalla.getComponent(0)).setIcon(new ImageIcon(batallaBmp.getImage()));
    }
    
    /**
     * Cambia la pestaña seleccionada para mostrar la vista del Tablero.
     */
    public void mostrarTablero() {
        if (tabs != null) tabs.setSelectedIndex(0);
    }

    /**
     * Cambia la pestaña seleccionada para mostrar la vista de Mensajes.
     */
    public void mostrarMensajes() {
        if (tabs != null) tabs.setSelectedIndex(1);
    }

    /**
     * Cambia la pestaña seleccionada para mostrar la vista de Batalla.
     */
    public void mostrarBatalla() {
        if (tabs != null) tabs.setSelectedIndex(2);
    }
}

