package base;

import java.util.List;

/**
 * Partida
 * @param <T>
 */
public interface Partida<T> {
	
	/**
	 * Inicia la partida.
	 */
	void iniciar();

    /**
     * Verificamos si la partida termino.
     * @return
     */
    boolean haTerminado();

    /**
     * Devuelve el ganador de la partida.
     * @return
     */
    default T obtenerGanador() {
    	 throw new UnsupportedOperationException("Este juego no usa getGanador()");
    }

    /**
     * Devuelve el ganador o ganadores de la partida.
     * @return
     */
    default List<T> obtenerGanadorOGanadores() {
    	throw new UnsupportedOperationException("Este juego no usa getGanador()");
    }

    /**
     * Ejecuta los turnos en la partida.
     */
    void ejecutarTurno();
}

