package base;

import enums.EstadoDeBatalla;

import java.util.List;

/**
 * Batalla
 * @param <T>
 */
public interface Batalla <T>{

    /**
     * Inicia batalla para un juego.
     */
    void iniciar(T atacante, T defensor);

    /**
     * Retorna los participantes de una batalla.
     * @return
     */
    List<T> getParticipantes();

    /**
     * Ejecuta el turno de un participante en la pelea.
     */
    void ejecutarTurno();

    /**
     * Retorna de quien es el turno actual.
     * @return
     */
    public T getTurnoActual();

    /**
     * Termina la batalla.
     */
    void terminar();

    /**
     * Verifica si la batlla finalizo.
     * @return
     */
    boolean estaFinalizada();

    /**
     * Retorna el estado de una batalla.
     * @return
     */
    EstadoDeBatalla consultarEstado();

    /**
     * Retorna el ganador de una batalla.
     * @return
     */
    default T getGanador() {
        throw new UnsupportedOperationException("Este juego no usa getGanador()");
    }

    /**
     * Retorna los ganadores de una batalla.
     * @return
     */
    default List<T> getGanadores() {
        throw new UnsupportedOperationException("Este juego no usa getGanadores()");
    }
}