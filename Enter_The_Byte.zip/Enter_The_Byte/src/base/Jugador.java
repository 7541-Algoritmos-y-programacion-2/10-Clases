package base;

import utiles.ValidacionesUtiles;
import java.util.Objects;

/**
 * Representa un jugador genérico para cualquier tipo de juego.
 */
public abstract class Jugador {
	
	protected String nombre;
	
	/**
	 * Creamos un jugador para caulquier juego.
	 * @param nombre: nombre del jugador debe ser no nulo y no vacio.
	 */
	public Jugador(String nombre) {
		
		ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
		ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre del jugador no debe ser vacio");
		
		this.nombre = nombre;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		Jugador other = (Jugador) obj;
		return Objects.equals(nombre, other.getNombre());
	}

	@Override
	public String toString() {
		return "Jugador [Nombre: " + nombre + "]";
	}
	
	/**
	 * Devuelve el nombre del jugador.
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}
}
