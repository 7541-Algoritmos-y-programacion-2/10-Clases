package base;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import estructuras.ListaSimplementeEnlazada;
import utiles.ValidacionesUtiles;

/**
 * Representa una alianza dentro del juego. Una alianza contiene un nombre,
 * un administrador y un conjunto de jugadores miembros.
 * @param <T> tipo de jugador que forma parte de la alianza.
 */
public abstract class Alianza <T extends Jugador> {
	
    protected String nombre;
    protected List<T> miembros;
    protected T administrador; 

    /**
     * Creamos una alianza para un juego
     * @param nombre: nombre de la alianza debe ser no nulo ni vacio
     * @param administrador: creador de la alianza debe ser no nulo
     */
    public Alianza(String nombre, T administrador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
    	ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre de la alianza no debe ser un string vacio");
    	ValidacionesUtiles.esDistintoDeNull(administrador, "Administrador");
    	
        this.nombre = nombre;
        this.miembros = new ListaSimplementeEnlazada<T>();
        this.administrador = administrador;
        this.miembros.add(administrador);
    }
    
    @Override
	public int hashCode() {	
		return Objects.hash(nombre);
	}
    
    @Override
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		Alianza<?> other = (Alianza<?>) obj;
		return Objects.equals(nombre, other.getNombre());
	}
    
    @Override
	public String toString() {
		
		String nombresMiembros = this.miembros.stream() 
                .map(Jugador::getNombre)
                .collect(Collectors.joining(", "));
		
		return "Alianza [Administrador: " + getAdministrador().getNombre() + ", Nombre: " + getNombre() + ", Miembros: " + nombresMiembros + "]";
	}
    
     /**
     * Agregamos un jugador a la alianza
     * @param jugador: jugador a agregar a la alianza debe ser no nulo y no debe pertenecer a la alianza
     */
    public void agregarJugador(T jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.validarFalso(contiene(jugador), "Jugador ya pertenece a la alianza");
    	
        miembros.add(jugador);
    }

    /**
     * Eliminamos un jugador de la alianza
     * @param jugador: jugador a eliminar debe ser no nulo y debe pertenecer a la alianza
     */
    public void eliminarJugador(T jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.validarVerdadero(contiene(jugador), "Jugador a eliminar no pertenece a la alianza");
    	
        miembros.remove(jugador);
    }
    
    /**
     * Devuelve la cantidad de jugadores la alianza
     * @return
     */
    public int getCantidadDeMiembros() {
        return miembros.size();
    }
    
    /**
     * Verifica si dos jugadores pertenecen a una alianza
     * @param a: primer jugador no nulo
     * @param b: segundo jugador no nulo
     * @return
     */
    public boolean sonAliados(T a, T b) {
        return contiene(a) && contiene(b);
    }
    
    /**
     * Verifica si un jugador es el administrador de la alianza
     * @param jugador: debe ser no nulo y pertenecer a la alianza
     * @return
     */
    public boolean esAdministrador(T jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.validarVerdadero(contiene(jugador), "Jugador no pertenece a la alianza");
    	
    	return administrador.equals(jugador);
    }
    
     /**
     * Verifica si un jugador pertenece a la alianza
     * @param jugador: jugador a verificar debe ser no nulo
     * @return
     */
    public boolean contiene(T jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	
        return miembros.contains(jugador);
    }
    
    /**
     * Retorna los nombres de los aliados de un jugador.
     * @return
     */
    public List<String> getNombreDeAliados(T jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.validarVerdadero(contiene(jugador), "Jugador no es parte de alianza");
    	
    	List<String> nombres = new ListaSimplementeEnlazada<String>();
    	
    	for(T otroJugador : miembros) {
    		
    		if(!otroJugador.equals(jugador)) {
    			nombres.add(otroJugador.getNombre());
    		}
    	}
    	
    	return nombres;
    }
    
    /**
     * Devuelve un miembro de una alianza.
     * @param jugadorABuscar: jugador que se quiere buscar debe ser no nulo y pertenecer a la alianza.
     * @return
     */
    public T getMiembro(T jugadorABuscar) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugadorABuscar, "Jugador A Buscar");
    	ValidacionesUtiles.validarVerdadero(contiene(jugadorABuscar), "Jugador no pertenece a la alianza");
    	
    	return miembros.get(miembros.indexOf(jugadorABuscar));
    }

    /**
     * Devuelve el nombre de la alianza
     * @return
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Devuelve una lista con los miembros de la alianza
     * @return
     */
    public List<T> getMiembros() {
        return miembros;
    }
 
	/**
	 * Devuelve el administrador de la alianza
	 * @return
	 */
	public T getAdministrador() {
		return administrador;
	}

	/**
	 * Cambia el nombre de la alianza.
	 * @param nombre: no nulo y no vacio
	 */
	public void setNombre(String nombre) {
		
		ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
		ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre vacio");
		
		this.nombre = nombre;
	}

	/**
	 * Cambia el administrador de la alianza.
	 * @param administrador: nuevo administrador debe ser no nulo y pertenecer a la alianza.
	 */
	public void setAdministrador(T administrador) {
		
		ValidacionesUtiles.esDistintoDeNull(administrador, "Administrador");
		ValidacionesUtiles.validarVerdadero(contiene(administrador), "Nuevo administrador no pertenece a la alianza");
		
		this.administrador = administrador;
	}
}
