package base;

import java.util.List;
import java.util.Objects;

import utiles.ValidacionesUtiles;
import estructuras.ListaSimplementeEnlazada;



/**
 * Tablero 3D
 * @param <T>
 */
public class Tablero<T> {

    private final int ancho;
    private final int alto;
    private final int profundo;

    private List<List<List<Casillero<T>>>> casilleros = null;

    /**
     * Generamos un tablero de ancho x alto x profundo
     * @param ancho: mayor a 0
     * @param alto: mayor a 0
     * @param profundo: mayor a 0
     */
    public Tablero(int ancho, int alto, int profundo, T valorPorDefecto) {

        ValidacionesUtiles.validarMayorACero(ancho, "ancho");
        ValidacionesUtiles.validarMayorACero(alto, "alto");
        ValidacionesUtiles.validarMayorACero(profundo, "profundo");

        this.ancho = ancho;
        this.alto = alto;
        this.profundo = profundo;

        inicializarEstructura(valorPorDefecto);
    }

    private void inicializarEstructura(T valorPorDefecto) {

        this.casilleros = new ListaSimplementeEnlazada<List<List<Casillero<T>>>>();

        for(int x = 0; x < ancho; x++) {

            List<List<Casillero<T>>> fila = new ListaSimplementeEnlazada<List<Casillero<T>>>();

            for(int y = 0; y < alto; y++) {

                List<Casillero<T>> columna = new ListaSimplementeEnlazada<Casillero<T>>();

                for(int z = 0; z < profundo; z++) {

                    columna.add(new Casillero<T>(x + 1, y + 1, z + 1, valorPorDefecto));
                }

                fila.add(columna);
            }

            this.casilleros.add(fila);
        }
    }

    /**
     * Devuelve un casillero en la posicion (x, y, z)
     * @param x
     * @param y
     * @param z
     * @return
     */
    public Casillero<T> getCasillero(int x, int y, int z) {

        ValidacionesUtiles.validarRangoNumerico(1, ancho, x, "X");
        ValidacionesUtiles.validarRangoNumerico(1, alto, y, "Y");
        ValidacionesUtiles.validarRangoNumerico(1, profundo, z, "Z");

        return this.casilleros.get(x - 1).get(y - 1).get(z - 1);
    }

    /**
     * Retorna el casillero buscado.
     * @param coordenadas: no nulas
     * @return
     */
    public Casillero<T> getCasillero(Coordenadas coordenadas){

        ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");

        return getCasillero(coordenadas.getPosX(), coordenadas.getPosY(), coordenadas.getPosZ());
    }

    /**
     * Devuelve ancho del tablero
     * @return
     */
    public int getAncho() {
        return ancho;
    }

    /**
     * Devuelve alto del tablero
     * @return
     */
    public int getAlto() {
        return alto;
    }

    /**
     * Devuelve profundo del tablero
     * @return
     */
    public int getProfundo() {
        return profundo;
    }

    /**
     * Devuelve cantidad de casilleros
     * @return
     */
    public int getCantidadDeCasilleros() {

        return getAncho() * getAlto() * getProfundo();
    }

    /**
     * Verifica si las coordenadas especificadas están dentro de los límites del tablero
     * @param x: mayor o igual a 1, menor o igual a ancho
     * @param y: mayor o igual a 1, menor o igual a alto
     * @param z: mayor o igual a 1, menor o igual a profundo
     * @return
     */
    public boolean estaEnLimite(int x, int y, int z) {
        return x >= 1 && x <= ancho &&
                y >= 1 && y <= alto &&
                z >= 1 && z <= profundo;
    }

    /**
     * Crea una matriz de (vista x 2 + 1) con centro.
     * @param vista: numero de casilleros que se ven a los lados desde el centro, mayor a 0.
     * @param centro: centro de la matriz, no nulo.
     * @return
     */
    public List<List<Casillero<T>>> crearMatrizVista(int vista, Casillero<T> centro) {
    	
    	ValidacionesUtiles.esDistintoDeNull(centro, "Centro");
    	ValidacionesUtiles.validarMayorACero(vista, "Vista");

        int x0 = centro.getCoordenadas().getPosX();
        int y0 = centro.getCoordenadas().getPosY();
        int z0 = centro.getCoordenadas().getPosZ();


        List<List<Casillero<T>>> matriz = new ListaSimplementeEnlazada<List<Casillero<T>>>();

        for (int i = -vista; i <= vista; i++) {
            List<Casillero<T>> fila = new ListaSimplementeEnlazada<Casillero<T>>();

            for (int j = -vista; j <= vista; j++) {

                if (estaEnLimite(x0 + j, y0 + i, z0)) {
                    fila.add(getCasillero(x0 + j, y0 + i, z0));
                    
                } else {
                	fila.add(null);
                }
            }

            matriz.add(fila);
        }
       
        return matriz;
    }

    @Override
    public int hashCode() {
        return Objects.hash(casilleros);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null) {
            return false;
        }
        
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        Tablero<?> other = (Tablero<?>) obj;
        return Objects.equals(casilleros, other.casilleros);
    }

    @Override
    public String toString() {
        return "Tablero de " + this.getAncho() + " x " + this.getAlto() + " x " + this.getProfundo();
    }
}