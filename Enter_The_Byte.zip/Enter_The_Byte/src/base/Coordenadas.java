package base;

import java.util.Objects;
import utiles.ValidacionesUtiles;

/**
 * Posicion
 * Representa una coordenada tridimensional inmutable (x, y, z) en el tablero.
 */
public class Coordenadas {

    private final int posX;
    private final int posY;
    private final int posZ;

    /**
     * Crea una posición 3D inmutable con coordenadas base 1.
     * @param x: Coordenada X, mayor a 0.
     * @param y: Coordenada Y, mayor a 0.
     * @param z: Coordenada Z, mayor a 0.
     */
    public Coordenadas(int x, int y, int z) {

        ValidacionesUtiles.validarMayorACero(x, "X");
        ValidacionesUtiles.validarMayorACero(y, "Y");
        ValidacionesUtiles.validarMayorACero(z, "Z");

        this.posX = x;
        this.posY = y;
        this.posZ = z;
    }

    /**
     * Determina la identidad de la Posicion. Dos posiciones son iguales si sus coordenadas
     * (X, Y y Z) coinciden.
     * @param obj: El objeto a comparar.
     * @return true si ambas posiciones tienen las mismas coordenadas; false en caso contrario.
     */
    @Override
    public boolean equals(Object obj) {

        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Coordenadas other = (Coordenadas) obj;
        return posX == other.posX && posY == other.posY && posZ == other.posZ;
    }

    /**
     * Devuelve el código hash de la Posicion, basado en sus tres coordenadas.
     * @return
     */
    @Override
    public int hashCode() {
        return Objects.hash(posX, posY, posZ);
    }

    /**
     * Devuelve una representación en String de la Posicion.
     * @return Una cadena formateada con los valores de las coordenadas.
     */
    @Override
    public String toString() {
        return "Posicion (" + posX + ", " + posY + ", " + posZ + ")";
    }

    /**
     * Devuelve la distancia entre coordenadas.
     * @param otra: otras coordenadas para comparar, no nulas
     * @return
     */
    public Double getDistanciaEntreCoordenadas(Coordenadas otra) {
    	
    	ValidacionesUtiles.esDistintoDeNull(otra, "Otras Coordenadas");

        int dx = posX - otra.getPosX();
        int dy = posY - otra.getPosY();
        int dz = posZ - otra.getPosZ();

        return Math.sqrt(dx*dx + dy*dy + dz*dz);
    }

    /**
     * Devuelve la coordenada X de la posicion
     * @return
     */
    public int getPosX() {
        return posX;
    }

    /**
     * Devuelve la coordenada Y de la posicion
     * @return
     */
    public int getPosY() {
        return posY;
    }

    /**
     * Devuelve la coordenada Z de la posicion
     * @return
     */
    public int getPosZ() {
        return posZ;
    }
}
