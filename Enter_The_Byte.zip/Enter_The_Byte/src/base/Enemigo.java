package base;

import java.util.Objects;

import utiles.ValidacionesUtiles;

/**
 * Enemigo
 */
public abstract class Enemigo {
	
	protected String nombre;
	
	/**
	 * Creamos un enemigo para cualquier juego.
	 * @param nombre: nombre del enemigo debe ser no nulo y no vacio.
	 */
	public Enemigo(String nombre) {
		
		ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
		ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre del enemigo no debe ser vacio");
		
		this.nombre = nombre;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		Enemigo other = (Enemigo) obj;
		return Objects.equals(nombre, other.getNombre());
	}

	@Override
	public String toString() {
		return "Enemigo [Nombre: " + nombre + "]";
	}
	
	/**
	 * Devuelve el nombre del enemigo.
	 * @return
	 */
	public String getNombre() {	
		return nombre;
	}
}
