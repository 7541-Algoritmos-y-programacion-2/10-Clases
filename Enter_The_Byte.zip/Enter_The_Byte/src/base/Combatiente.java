package base;

/**
 * Combatiente
 */
public interface Combatiente {

	/**
	 * Retorna el nombre del combatiente.
	 * @return
	 */
    String getNombre();
    
    /**
     * Retorna la energia del combatiente.
     * @return
     */
    int getEnergia();
    
    /**
     * Recupera vida
     * @param vida: vida a recuperar debe ser mayor a 0.
     */
    default void recuperarEnergia(int vida) {};
    
    /**
     * Retorna la fuerza para el ataque.
     * @return
     */
    int obtenerFuerzaParaAtaque();

    /**
     * Verifica si el combatiente esta vivo.
     * @return
     */
    boolean estaVivo();
    
    /**
     * Recibe daño, resta la vida.
     * @param cantidad: cantidad de daño a recibir mayor a 0.
     */
    void recibirDaño(int cantidad);

    /**
     * Retorna las coordenadas del combatiente.
     * @return
     */
	Coordenadas getCoordenadas();
	
	/**
	 * Setea las coordenadas del combatiente.
	 * @param coordenadas
	 */
	default void setCoordenadas(Coordenadas coordenadas) {};
}
