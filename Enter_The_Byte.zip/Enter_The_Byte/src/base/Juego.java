package base;

import enums.Dificultad;

/**
 * Juego
 */
public interface Juego {

    /**
     * Iniciamos una partida.
     */
    void iniciarPartida();

    /**
     * Logica para jugar una partida del juego
     */
    void jugarPartida();

    /**
     * Elegimos dificultad para partida.
     * @return
     */
    Dificultad elegirDificultadParaPartida();

    /**
     * Devuelve la partida actual.
     * @return
     */
    Partida<?> getPartidaActual();

    /**
     * Devuelve el nombre del juego
     * @return
     */
    String getNombre();

    /**
     * Finalizamos la partida.
     */
    void finalizarPartida();
}



