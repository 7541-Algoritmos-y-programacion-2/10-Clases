package base;

import java.util.Objects;

import utiles.ValidacionesUtiles;

/**
 * Casillero 3D
 * Representa una celda en un espacio 3D que puede contener un valor genérico T.
 * La identidad de un Casillero está definida únicamente por su posición.
 * 
 * @param <T> El tipo de valor que puede contener el casillero.
 */
public class Casillero<T> {

	private final Coordenadas coordenadas;
	private T valor;

	/**
	 * Crea un casillero en una posición 3D específica con un valor inicial.
	 * 
	 * @param x:     Coordenada X: mayor a 0
	 * @param y:     Coordenada Y, mayor a 0
	 * @param z:     Coordenada Z, mayor a 0
	 * @param valor: Valor inicial, no nulo.
	 */
	public Casillero(int x, int y, int z, T valor) {

		ValidacionesUtiles.validarMayorACero(x, "X");
		ValidacionesUtiles.validarMayorACero(y, "Y");
		ValidacionesUtiles.validarMayorACero(z, "Z");
		ValidacionesUtiles.esDistintoDeNull(valor, "Valor");

		this.coordenadas = new Coordenadas(x, y, z);
		this.valor = valor;
	}

	/**
	 * Devuelve el código hash del casillero, basado en su posición.
	 * 
	 * @return
	 */
	@Override
	public int hashCode() {
		return Objects.hash(coordenadas);
	}

	/**
	 * Define la identidad lógica del Casillero. Dos casilleros son iguales si están
	 * en la misma posición.
	 * 
	 * @param obj El objeto a comparar.
	 * @return true si las posiciones son iguales; false en caso contrario.
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (getClass() != obj.getClass()) {
			return false;
		}

		Casillero<?> other = (Casillero<?>) obj;
		return this.coordenadas.equals(other.coordenadas);
	}

	/**
	 * Devuelve una representación en String del Casillero.
	 * 
	 * @return Una cadena formateada que muestra el valor y la posición.
	 */
	@Override
	public String toString() {
		return "Casillero [Valor = " + valor + "Coordenadas = " + coordenadas + "]";
	}

	/**
	 * Remueve el valor del casillero y deja null
	 * 
	 * @return El valor que estaba almacenado en el casillero.
	 */
	public T removerValor() {

		T valorRemovido = this.valor;

		this.valor = null;

		return valorRemovido;
	}

	/**
	 * Intercambia valores entre casilleros.
	 * 
	 * @param otro: El otro casillero con el que se intercambiará el valor.
	 */
	public void intercambiarValor(Casillero<T> otro) {

		ValidacionesUtiles.esDistintoDeNull(otro, "Casillero");

		T aux = this.valor;

		this.valor = otro.valor;

		otro.valor = aux;
	}

	/**
	 * Verifica si el casillero esta libre
	 * 
	 * @return {@code true} si el valor es null; {@code false} en caso contrario.
	 */
	public boolean estaLibre() {

		return this.valor == null;
	}

	/**
	 * Setea un valor para el casillero.
	 * 
	 * @param valor: El nuevo valor a asignar, debe ser distinto de null.
	 */
	public void setValor(T valor) {

		ValidacionesUtiles.esDistintoDeNull(valor, "Valor");

		this.valor = valor;
	}

	/**
	 * Devuelve el valor del casillero,
	 * 
	 * @return
	 */
	public T getValor() {
		return valor;
	}

	/**
	 * Devuelve la posicion del casillero.
	 * 
	 * @return
	 */
	public Coordenadas getCoordenadas() {
		return coordenadas;
	}
}