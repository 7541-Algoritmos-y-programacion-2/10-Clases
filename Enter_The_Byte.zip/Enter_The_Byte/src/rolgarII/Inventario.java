package rolgarII;

import java.util.List;
import java.util.Objects;
import estructuras.ListaSimplementeEnlazada;
import utiles.ValidacionesUtiles;
import rolgarII.cartas.*;

/**
 * Inventario
 */
public class Inventario {
	
	private List<Carta> cartas;
	private Carta cartaEnUso;
	private int maximoDeCartas;
	
	/**
	 * Creamos un inventario para el personaje de Rolgar II
	 */
	public Inventario() {
		
		this.cartas = new ListaSimplementeEnlazada<Carta>();
		this.maximoDeCartas = 10;
		this.cartaEnUso = null;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(cartaEnUso, cartas);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj == null) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		Inventario other = (Inventario) obj;
		return Objects.equals(cartaEnUso, other.cartaEnUso) && Objects.equals(cartas, other.cartas);
	}

	@Override
	public String toString() {
		
		String nombresDeCartas = String.join(", ", getNombresDeCartas());
		return "Inventario [Cartas: " + nombresDeCartas + "]";
	}
	
	/**
	 * Agrega una carta a cartas si no se paso el maximo.
	 * @param carta: carta a agregar.
	 */
	public void agregarCarta(Carta carta) {
		
		ValidacionesUtiles.esDistintoDeNull(carta, "Carta");
		
		if (cartas.size() < maximoDeCartas) {
			
			cartas.add(carta);
		}
	}
	
	/**
	 * Activa una carta si esta en el inventario y despues de activarla la saca del inventario.
	 * @param carta: carta a activar.
	 */
	public void activarCarta(Carta carta) {
		
		ValidacionesUtiles.validarVerdadero(cartas.contains(carta), "Carta no se encuentra en el inventario");
		ValidacionesUtiles.validarVerdadero(cartaEnUso == null, "Solo se puede activar una carta a la vez");
		
		this.cartaEnUso = carta;
		
		cartas.remove(carta);
	}
	
	/**
	 * Desactiva la carta en uso.
	 */
	public void desactivarCarta() {
		this.cartaEnUso = null;
	}
	
	/**
	 * Elimina una carta del inventario
	 * @param carta
	 */
	public void eliminarCarta(Carta carta) {
		
		ValidacionesUtiles.validarVerdadero(cartas.contains(carta), "Carta a eliminar no se encuentra en el inventario");
	
		cartas.remove(carta);
	}
	
	/**
	 * Verifica si la carta en uso es un tipo especifico.
	 * @param tipo: class de la carta, no nula.
	 * @return
	 */
	public boolean tieneActiva(Class<? extends Carta> tipo) {
		
		ValidacionesUtiles.esDistintoDeNull(tipo, "Tipo");
		
	    return tipo.isInstance(cartaEnUso);
	}
	
	/**
	 * Verifica si el inventario contiene una carta especifica.
	 * @param carta: no nula
	 * @return
	 */
	public boolean tieneCarta(Carta carta) {
		
		ValidacionesUtiles.esDistintoDeNull(carta, "Carta");
		
		return cartas.contains(carta);
	}
    
    /**
	 * Devuelve una carta por su nombre.
	 * @param nombreDeCarta: nombre de la carta a buscar debe ser no nulo y no vacio.
	 * @return
	 */
	public Carta getCartaPorNombre(String nombreDeCarta) {
		
		ValidacionesUtiles.esDistintoDeNull(nombreDeCarta, "Nombre De Carta");
		ValidacionesUtiles.validarFalso(nombreDeCarta.isBlank(), "Nombre de carta no debe ser vacio");
		
		for (Carta carta : cartas) {
			if (carta.getNombre().equalsIgnoreCase(nombreDeCarta)) {
				return carta;
			}
		}
		
		throw new RuntimeException("Carta no se encuentra en el inventario");
	}
	
	/**
	 * Devuelve una lista de los nombres de las cartas en el inventario.
	 * @return
	 */
	public List<String> getNombresDeCartas() {
		
		List<String> nombreDeCartas = new ListaSimplementeEnlazada<String>();
		
		for (Carta carta : cartas) {	
			nombreDeCartas.add(carta.getNombre());
		}
		
		return nombreDeCartas;
	}
    
	/**
	 * Devuelve una carta del inventario
	 * @param cartaABuscar: carta a buscar en inventario, debe ser no nula y pertenecer al mismo.
	 * @return
	 */
	public Carta getCarta(Carta cartaABuscar) {
		
		ValidacionesUtiles.esDistintoDeNull(cartaABuscar, "Carta A Buscar");
		ValidacionesUtiles.validarVerdadero(cartas.contains(cartaABuscar), "Carta no se encuentra en el inventario");

		return cartas.get(cartas.indexOf(cartaABuscar));
	}
	
	/**
	 * Devuelve las cartas del inventario.
	 * @return
	 */
	public List<Carta> getCartas() {
		return cartas;
	}
	
	/**
	 * Devuelve la carta que esta en uso.
	 * @return
	 */
	public Carta getCartaEnUso() {
		return cartaEnUso;
	}

	/**
	 * Cambia las cartas por unas nuevas cartas:
	 * @param cartas
	 */
	public void setCartas(List<Carta> cartas) {
		
		ValidacionesUtiles.esDistintoDeNull(cartas, "Cartas");
		ValidacionesUtiles.validarFalso(cartas.size() > 10, "Cartas no entran en el inventario");
		
		this.cartas = cartas;
	}
}
