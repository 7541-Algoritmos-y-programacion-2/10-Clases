package rolgarII;

import utiles.ValidacionesUtiles;

import java.util.List;

import base.Alianza;
import base.Coordenadas;
import rolgarII.cartas.Carta;
import rolgarII.cartas.CartaInvisibilidad;

/**
 * Representa una alianza dentro del juego Rolgar II.
 */
public class AlianzaRolgarII extends Alianza<JugadorRolgarII> {

    /**
     * Creamos una alianza en Rolgar II
     * @param nombre: nombre de la alianza debe ser no nula ni vacia.
     * @param administrador: administrador y creador de la alianza debe ser no nulo.
     */
	public AlianzaRolgarII(String nombre, JugadorRolgarII administrador) {
		super(nombre, administrador);
	}
	
	/**
	 * Busca el aliado mas cercano a un jugador miembro de la alianza.
	 * @param jugador: debe ser no nulo y pertenecer a la alianza.
	 * @return
	 */
	public JugadorRolgarII getAliadoMasCercano(JugadorRolgarII jugador) {
		
		ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
		ValidacionesUtiles.validarVerdadero(contiene(jugador), "Jugador no pertenece a la alianza" + getNombre());

		JugadorRolgarII aliadoMasCercano = null;

		for (JugadorRolgarII aliado : miembros) {

			if (!jugador.equals(aliado)) {

				if (aliadoMasCercano == null ||
		                aliado.getCoordenadas().getDistanciaEntreCoordenadas(jugador.getCoordenadas())
		                < aliadoMasCercano.getCoordenadas().getDistanciaEntreCoordenadas(jugador.getCoordenadas())) {

		                aliadoMasCercano = aliado;
		            }
		        }
		    }

		    return aliadoMasCercano;
	}
	
	/**
	 * Intercambia completamente las cartas entre dos miembros de la alianza.
	 * @param jugadorA: debe pertenecer a la alianza y ser no nulo.
	 * @param jugadorB: debe pertenecer a la alianza y ser no nulo.
	 */
	public void intercambiarCartasEntreAliados(JugadorRolgarII jugadorA, JugadorRolgarII jugadorB) {
		
		ValidacionesUtiles.esDistintoDeNull(jugadorA, "Jugador A");
		ValidacionesUtiles.esDistintoDeNull(jugadorB, "Jugador B");
		ValidacionesUtiles.validarVerdadero(sonAliados(jugadorA, jugadorB), "Para intercambiar los jugadores deben ser aliados");
		
		List<Carta> listaCartasAux = jugadorA.getInventario().getCartas();
		
		jugadorA.getInventario().setCartas(jugadorB.getInventario().getCartas());
		jugadorB.getInventario().setCartas(listaCartasAux);
	}
	
	/**
	 * Elimina los miembros muertos de la alianza.
	 */
	public void limpiarMuertos() {
	    miembros.removeIf(jugador -> !jugador.estaVivo());
        verificarVidaDeAdministrador();
	}

    /**
     * Verificamos la vida del administrador, si murio asignamos otro.
     */
    private void verificarVidaDeAdministrador() {

        if (!administrador.estaVivo() && miembros.size() >= 1) {
            cambiarDeAdministrador();
        }
    }

    /**
     * El segundo miembro en ingresar se convierte en el nuevo administrador.
     */
    private void cambiarDeAdministrador() {
        this.administrador = miembros.get(0);
    }

    /**
     * Devuelve un string con el nombre y las coordenadas de los aliados de un jugador (omitiendo aliados con invisibilidad activa).
     * @param jugador: jugador al que se le devuelve las coordenadas de sus aliados, debe ser no nulo y pertenecer a la misma.
     * @return
     */
    public String getCoordenadasDeAliados(JugadorRolgarII jugador) {

        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        ValidacionesUtiles.validarVerdadero(contiene(jugador), "Jugador no pertenece a la alianza");

        String coordenadasAliados = "";

        for (JugadorRolgarII aliado : miembros) {

            if (!aliado.equals(jugador) && !aliado.getInventario().tieneActiva(CartaInvisibilidad.class)) {
                Coordenadas coordenadas = aliado.getCoordenadas();
                coordenadasAliados += aliado.getNombre() + " - (" + coordenadas.getPosX() + "," +
                        coordenadas.getPosY() + "," + coordenadas.getPosZ() + ")" + "\n";
            }
        }

        return coordenadasAliados;
    }
}
