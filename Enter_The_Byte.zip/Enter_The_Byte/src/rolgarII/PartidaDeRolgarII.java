package rolgarII;

import java.util.List;

import base.Partida;
import utiles.ValidacionesUtiles;
import interfaz.Interfaz;
import rolgarII.cartas.*;
import rolgarII.contexto.ContextoDeJuego;
import rolgarII.gestores.GestorDeAlianzasActivas;
import rolgarII.gestores.GestorDeEntidadesVivas;
import rolgarII.gestores.GestorDeMapaYCoordenadas;

/**
 * Partida De Rolgar II
 */
public class PartidaDeRolgarII implements Partida<JugadorRolgarII> {

    private ContextoDeJuego contextoJuego;
    private Interfaz interfazGrafica;
    private int indiceTurnos;

    /**
     * Creamos una nueva partida de Rolgar II.
     * @param tablero: tablero para la partida no nulo.
     * @param jugadores: lista de jugadores de la partida no nula.
     * @param enemigos: lista de enemigos de la partida no nula.
     * @param interfazGrafica: interfaz grafica de la partida, no nula.
     * @param prototiposDeCartas: lista de prototipos de cartas no nula.
     */
    public PartidaDeRolgarII(MapaRolgarII tablero, List<JugadorRolgarII> jugadores, List<EnemigoRolgarII> enemigos,
                             Interfaz interfazGrafica, List<Carta> prototiposDeCartas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");

        this.interfazGrafica = interfazGrafica;

        GestorDeEntidadesVivas gestorEntidades = new GestorDeEntidadesVivas(jugadores, enemigos);
        GestorDeAlianzasActivas gestorAlianzas = new GestorDeAlianzasActivas();
        GestorDeMapaYCoordenadas gestorMapaYCoordenadas = new GestorDeMapaYCoordenadas(tablero, prototiposDeCartas);

        this.contextoJuego = new ContextoDeJuego(gestorMapaYCoordenadas, gestorEntidades, gestorAlianzas);
        this.indiceTurnos = 0;
    }

    /**
     * Iniciamos la partida.
     */
    @Override
    public void iniciar() {
        asignarCoordenadasAEntidades();
    }

    /**
     * Le asignamos un lugar para cada jugador y enemigo.
     */
    private void asignarCoordenadasAEntidades() {
    	
        for (JugadorRolgarII jugador : contextoJuego.getGestorDeEntidadesVivas().getJugadores()) {
            jugador.setCoordenadas(contextoJuego.getGestorMapaYCoordenadas().obtenerCoordenadasLibres(
            		contextoJuego.getGestorDeEntidadesVivas().getEntidades()));
        }
        
        for (EnemigoRolgarII enemigo : contextoJuego.getGestorDeEntidadesVivas().getEnemigos()) {
            enemigo.setCoordenadas(contextoJuego.getGestorMapaYCoordenadas().obtenerCoordenadasLibres(
                    contextoJuego.getGestorDeEntidadesVivas().getEntidades()));
        }
    }

    /**
     * Verifica si el juego termino, termino si todos los jugadores murieron o todos los
     * enemigos murieron y los jugadores restantes son aliados.
     */
    public boolean haTerminado() {
        return !contextoJuego.getGestorDeEntidadesVivas().hayEnemigos() &&
                contextoJuego.getGestorDeAlianzasActivas().jugadoresSonPartedeMismaAlianza(contextoJuego.getGestorDeEntidadesVivas().getJugadores()) ||
                !contextoJuego.getGestorDeEntidadesVivas().hayJugadores();
    }

    /**
     * Retorna la interfaz grafica.
     * @return
     */
    public Interfaz getInterfazGrafica() {
        return interfazGrafica;
    }

    /**
     * Ejecuta un turno y aumenta el indiceTurnos si se llego al ultimo jugador el indice vuelve a 0.
     */
    public void ejecutarTurno() {
    	
    	if(indiceTurnos >= contextoJuego.getGestorDeEntidadesVivas().getCantidadJugadores()) {
    		this.indiceTurnos = 0;
    	}
    	
    	JugadorRolgarII jugador = contextoJuego.getGestorDeEntidadesVivas().getJugadores().get(indiceTurnos);
    	
        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        
        Turno turno = new Turno(jugador, interfazGrafica, contextoJuego);
        turno.iniciarTurno();
        
        contextoJuego.getGestorDeEntidadesVivas().limpiarEntidadesMuertas();
        contextoJuego.getGestorDeAlianzasActivas().limpiarAlianzas();
        
        indiceTurnos++;
    }

    /**
     * Devuelve los ganadores de la partida.
     */
    @Override
    public List<JugadorRolgarII> obtenerGanadorOGanadores() {
        ValidacionesUtiles.validarVerdadero(haTerminado(), "No hay ganador porque la partida aun no termino");
        return contextoJuego.getGestorDeEntidadesVivas().getJugadores();
    }

    /**
     * Devuelve el contextoJuego de la partida
     * @return
     */
    public ContextoDeJuego getContextoJuego() {
    	return contextoJuego;
    }

    /**
     * Devuelve el indiceTurno actual de la partida.
     * @return
     */
	public int getIndiceTurnos() {
		return indiceTurnos;
	}
}
