package rolgarII;

import java.util.List;
import utiles.ValidacionesUtiles;
import utiles.GeneradorAleatorio;
import estructuras.ListaSimplementeEnlazada;
import base.Casillero;
import base.Coordenadas;
import base.Tablero;
import enums.TipoTerreno;

/**
 * Mapa de Rolgar II
 */
public class MapaRolgarII extends Tablero<TipoTerreno> {

    List<Coordenadas> casillerosConCarta;

    /**
     * Creamos el mapa del Rolgar 2.
     * @param ancho: debe ser mayor a 0.
     * @param alto: debe ser mayor a 0.
     * @param profundo: debe ser mayor a 0.
     * @param cantidadDeCartas: mayor a 0
     */
    public MapaRolgarII(int ancho, int alto, int profundo, int cantidadDeCartas) {

        super(ancho, alto, profundo, TipoTerreno.Vacio);

        ValidacionesUtiles.validarMayorACero(alto, "Alto");
        ValidacionesUtiles.validarMayorACero(profundo, "Profundo");
        ValidacionesUtiles.validarMayorACero(ancho, "Ancho");
        ValidacionesUtiles.validarMayorACero(cantidadDeCartas, "Cantidad de cartas");

        this.casillerosConCarta = new ListaSimplementeEnlazada<Coordenadas>();

        generarTerreno();
        
        for(int i = 0; i < cantidadDeCartas; i++) {
        	asignarCasillerosParaCartas();
        }
    }

    /**
     * Asigna lugar para las cartas en el mapa.
     */
    private void asignarCasillerosParaCartas() {

        int x, y, z;

        do {

            x = GeneradorAleatorio.generarNumeroRandom(getAncho()) + 1;
            y = GeneradorAleatorio.generarNumeroRandom(getAlto()) + 1;
            z = GeneradorAleatorio.generarNumeroRandom(getProfundo()) + 1;

        } while(terrenoNoTransitable(x, y, z) ||
        		casillerosConCarta.contains(getCasillero(x, y, z).getCoordenadas()));

        this.casillerosConCarta.add(getCasillero(x, y, z).getCoordenadas());
    }

    /**
     * Asignamos lugar vacio para un tipo de terreno.
     * @param tipoTerreno: no nulo
     * @param z: nivel del tablero
     */
    private void asignarLugarTipoTerreno(TipoTerreno tipoTerreno, int z) {

        ValidacionesUtiles.esDistintoDeNull(tipoTerreno, "TipoTerreno");
        ValidacionesUtiles.validarMayorACero(z, "Z");

        int x, y;

        do {

            x = GeneradorAleatorio.generarNumeroRandom(getAncho()) + 1;
            y = GeneradorAleatorio.generarNumeroRandom(getAlto()) + 1;


        } while(getCasillero(x, y, z).getValor() != TipoTerreno.Vacio);

        getCasillero(x, y, z).setValor(tipoTerreno);
    }

    /**
     * Asignamos lugar vacio para lago (4 pixeles de agua).
     * @param z: nivel del tablero mayor a 0.
     */
    private void asignarLugarLago(int z) {
    	
    	ValidacionesUtiles.validarMayorACero(z, "Z");

        int x, y;

        do {

            x = GeneradorAleatorio.generarNumeroRandom(getAncho()) + 1;
            y = GeneradorAleatorio.generarNumeroRandom(getAlto()) + 1;

        } while (!esBloqueAguaValido(x, y, z));

        getCasillero(x, y, z).setValor(TipoTerreno.Agua);
        getCasillero(x + 1, y, z).setValor(TipoTerreno.Agua);
        getCasillero(x, y + 1, z).setValor(TipoTerreno.Agua);
        getCasillero(x + 1, y + 1, z).setValor(TipoTerreno.Agua);
    }

    /**
     * Verificamos si es un lugar valido para asignar el lago
     * @param x0
     * @param y0
     * @param z0
     * @return
     */
    private boolean esBloqueAguaValido(int x0, int y0, int z0) {

        int[][] puntos = {
                {x0, y0},
                {x0 + 1, y0},
                {x0, y0 + 1},
                {x0 + 1, y0 + 1}
        };


        for (int[] punto : puntos) {
            int x = punto[0];
            int y = punto[1];

            if (!estaEnLimite(x, y, z0) ||
                    getCasillero(x, y, z0).getValor() != TipoTerreno.Vacio) {

                return false;
            }
        }

        return true;
    }

    /**
     * Generamos terreno para el mapa
     */
    private void generarTerreno() {

        for (int i = 1; i <= getProfundo(); i++) {
            for (int j = 0; j < 2; j++) {
                asignarLugarLago(i);
            }

            for (int j = 0; j < 6; j++) {
                asignarLugarTipoTerreno(TipoTerreno.Roca, i);
            }

            for (int j = 0; j < 4; j++) {
                asignarLugarTipoTerreno(TipoTerreno.Rampa, i);
            }
            
            for (int j = 0; j < 4; j++) {
            	asignarLugarTipoTerreno(TipoTerreno.Agujero, i);
            }
        }
    }

    /**
     * Verificamos si el terreno es transitable
     * @param x: entre 0 y ancho del tablero
     * @param y: entre 0 y alto del tablero
     * @param z: entre 0 y profundo del tablero
     * @return
     */
    public boolean terrenoNoTransitable(int x, int y, int z) {

        ValidacionesUtiles.validarRangoNumerico(1, getAncho(), x, "Coordenada X fuera de rango");
        ValidacionesUtiles.validarRangoNumerico(1, getAlto(), y, "Coordenada Y fuera de rango");
        ValidacionesUtiles.validarRangoNumerico(1, getProfundo(), z, "Coordenada Z fuera de rango");

        return getCasillero(x, y, z).getValor() == TipoTerreno.Roca ||
                getCasillero(x, y, z).getValor() == TipoTerreno.Agua;
    }

    /**
     * Devuelve los casilleros que tienen carta
     * @return
     */
    public List<Coordenadas> getCasillerosConCarta(){
        return casillerosConCarta;
    }
    
    /**
     * Verifica si una coordenada tiene carta.
     * @param coordenadas: no nulas.
     * @return
     */
    public boolean coordenadasTieneCartas(Coordenadas coordenadas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	
    	return casillerosConCarta.contains(coordenadas);
    }

    /**
     * Busca y retorna un casillero transitable random.
     * @return
     */
    public Casillero<TipoTerreno> obtenerCasilleroTransitableRandom() {
        
        int intentos = 0;
        int maxIntentos = 200;

        while (intentos < maxIntentos) {
            
            int x = GeneradorAleatorio.generarNumeroRandom(getAncho()) + 1;
            int y = GeneradorAleatorio.generarNumeroRandom(getAlto()) + 1;
            int z = GeneradorAleatorio.generarNumeroRandom(getProfundo()) + 1;

            if (!terrenoNoTransitable(x, y, z)) {
                return getCasillero(x, y, z);
            }
            
            intentos++;
        }
        
        return null;
    }

    /**
     * Crea una matriz con los nombres del tipo de terreno de cada coordenada.
     * @param vista: cantidad de casilleros que se ven a los costados del centro, mayor a 0.
     * @param centro: centro de la matriz, no nulo.
     * @return
     */
    public List<List<String>> crearMatrizTerrenos(int vista, Coordenadas centro) {
    	
    	ValidacionesUtiles.esDistintoDeNull(centro, "Centro");
    	ValidacionesUtiles.validarMayorACero(vista, "Vista");

        List<List<Casillero<TipoTerreno>>> matrizCasilleros = crearMatrizVista(vista, getCasillero(centro));
        List<List<String>> matrizTerrenos = new ListaSimplementeEnlazada<List<String>>();

        for (List<Casillero<TipoTerreno>> filaCasilleros : matrizCasilleros) {
            List<String> filaTerrenos = new ListaSimplementeEnlazada<String>();

            for (Casillero<TipoTerreno> casillero : filaCasilleros) {
            	
            	if (casillero == null) {
            		filaTerrenos.add("Afuera");
            	
            	} else {
            		filaTerrenos.add(casillero.getValor().name());
            	}
            }

            matrizTerrenos.add(filaTerrenos);
        }

        return matrizTerrenos;
    }

    /**
     * Elimina una coordenada con carta de la lista de coordenadas con cartas.
     * @param coordenadas: no nula y debe pertenecer a la lista.
     */
	public void eliminarCasillaConCarta(Coordenadas coordenadas) {
		
		ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
		ValidacionesUtiles.validarVerdadero(coordenadasTieneCartas(coordenadas), "Coordenada no tiene carta");
		
		this.casillerosConCarta.remove(coordenadas);
	}
}