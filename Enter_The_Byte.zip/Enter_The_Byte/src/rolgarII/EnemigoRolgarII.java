package rolgarII;

import utiles.ValidacionesUtiles;
import base.Combatiente;
import base.Coordenadas;
import base.Enemigo;

/**
 * Enemigo de Rolgar II
 */
public class EnemigoRolgarII extends Enemigo implements Combatiente{
	
	private int energia;
	private int fuerza;
	private Coordenadas coordenadas;

	/**
	 * Creamos un enemigo para Rolgar II.
	 * @param nombre: nombre del enemigo debe ser no nulo y no vacio.
	 * @param fuerza: fuerza del enemigo debe ser mayor a 0.
	 */
	public EnemigoRolgarII(String nombre, int fuerza) {
		super(nombre);
		
		ValidacionesUtiles.validarMayorACero(fuerza, "Fuerza");
		
		this.energia = 100;
		this.fuerza = fuerza;
		this.coordenadas = null;
	}

	/**
	 * Devuelve la energia del enemigo.
	 * @return
	 */
	@Override
	public int getEnergia() {
		return energia;
	}

	/**
	 * Devuelve la fuerza del enemigo.
	 * @return
	 */
	@Override
	public int obtenerFuerzaParaAtaque() {
		return fuerza;
	}
	
	/**
	 * Setea unas nuevas coordenadas para el enemigo.
	 */
	@Override
	public void setCoordenadas(Coordenadas coordenadas) {
		
		ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
		
		this.coordenadas = coordenadas;
	}

	/**
	 * Devuelve las coordenadas del enemigo.
	 * @return
	 */
	@Override
	public Coordenadas getCoordenadas() {
		return coordenadas;
	}
	
	/**
	 * Resta el daño recibido a la energia del enemigo, si la energia es menor a 0 se ajusta a 0.
	 * @param daño: mayor a 0.
	 */
	@Override
	public void recibirDaño(int daño) {
		
		ValidacionesUtiles.validarMayorACero(daño, "Daño recibido");
		
		this.energia -= daño;
		
		if (energia < 0) {
			
			this.energia = 0;
		}
	}

	@Override
	public String toString() {
		String mensajeCoordenadas = (coordenadas == null) ? "(sin coordenadas)" : coordenadas.toString();
		
		return "Enemigo De Rolgar II [Energia: " + energia + ", Fuerza: " + fuerza + ", " + mensajeCoordenadas + "]";
	}

	/**
	 * Verifica si el enemigo esta vivo.
	 */
	@Override
	public boolean estaVivo() {
		return energia > 0;
	}
}
