package rolgarII.cartas;

import java.util.Objects;

import interfaz.Interfaz;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

/**
 * Base de Carta
 */
public abstract class Carta {
    protected String nombre;
    protected String descripcion;

    /**
     * Creamos la carta.
     */
    public Carta(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    /**
     * @return Devuelve el nombre asigado a la carta.
     */
    public String getNombre() {
        return this.nombre;
    }

    /**
     * @return Devuelve el String de la descripcion aplicada a la carta.
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Realiza el efecto que tiene cada carta.
     * @param jugador no debe ser null.
     * @param partida debe estar inicializado.
     */
    public abstract void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica);

    /**
     * Usa la intefaz para imprimir el mesaje que contiene la carta.
     */
    protected void imprimirMensaje(String mensaje, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	ValidacionesUtiles.esDistintoDeNull(mensaje, "Mensaje");
    	
        interfazGrafica.mostrarMensaje(mensaje);
    }

	@Override
	public String toString() {
		return "Carta [Nombre: " + nombre + ", Descripcion: " + descripcion + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Carta other = (Carta) obj;
		return Objects.equals(nombre, other.nombre);
	}
}