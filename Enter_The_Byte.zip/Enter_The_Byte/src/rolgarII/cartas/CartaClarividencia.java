package rolgarII.cartas;

import interfaz.Interfaz;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

public class CartaClarividencia extends Carta {

    /**
     * Creamos la carta.
     */
    public CartaClarividencia() {
        
        super("Clarividencia", "Revela posiciones.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
    	jugador.getInventario().eliminarCarta(this);

        imprimirMensaje("--- Coordenadas Reveladas ---", interfazGrafica);

        String info = contextoJuego.getGestorDeEntidadesVivas().getCoordenadasDeJugadores(jugador);
        
        if (info != null) {
            imprimirMensaje(info, interfazGrafica);

        } else {
            imprimirMensaje("No hay coordenadas para revelar.", interfazGrafica);
        }
    }
}