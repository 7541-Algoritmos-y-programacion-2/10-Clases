package rolgarII.cartas;

import interfaz.Interfaz;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

/**
 * Carta que realiza un ataque doble.
 */
public class CartaAtaqueDoble extends Carta {
    /**
     * Creamos la carta.
     */
    public CartaAtaqueDoble() {
        super("Ataque Doble", "Duplica el proximo ataque.");
    }

    /**
     * Duplica el ataque del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
        jugador.getInventario().activarCarta(this);
        imprimirMensaje("Ataque Doble activado.", interfazGrafica);
    }
}