package rolgarII.cartas;

import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;
import base.Casillero;
import enums.TipoTerreno;
import interfaz.Interfaz;

public class CartaTeletransportacion extends Carta {

    /**
     * Creamos la carta.
     */
    public CartaTeletransportacion() {
        super("Teletransportacion", "Mueve a celda aleatoria transitable.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
    	jugador.getInventario().eliminarCarta(this);
        
    	Casillero<TipoTerreno> destino = contextoJuego.getGestorMapaYCoordenadas().getMapa().obtenerCasilleroTransitableRandom();

        if (destino != null) {
            jugador.setCoordenadas(destino.getCoordenadas());
            imprimirMensaje("Jugador teletransportado a zona segura.", interfazGrafica);

        } else {
            imprimirMensaje("No hay terreno seguro para teletransportar.", interfazGrafica);
        }
    }
}