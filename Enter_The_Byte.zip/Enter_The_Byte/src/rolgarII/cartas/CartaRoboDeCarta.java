package rolgarII.cartas;

import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

import java.util.List;

import interfaz.Interfaz;
import rolgarII.Inventario;

public class CartaRoboDeCarta extends Carta {

    /**
     * Creamos la carta.
     */
    public CartaRoboDeCarta() {
        
        super("Robo de Carta", "Roba carta a otro jugador.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
    	jugador.getInventario().eliminarCarta(this);

        JugadorRolgarII victima = contextoJuego.getGestorDeEntidadesVivas().buscarJugadorRivalMasCercano(
        		jugador, contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugador));

            if (victima != null) {
                
                Inventario inventarioVictima = victima.getInventario();
                List<Carta> cartasVictima = inventarioVictima.getCartas();

                if (!cartasVictima.isEmpty()) {
                    Carta robada = cartasVictima.get(0);
                    cartasVictima.remove(robada);
                    jugador.getInventario().agregarCarta(robada);
                    imprimirMensaje("Le robaste " + robada.getNombre() + " a " + victima.getNombre(), interfazGrafica);

                } else {
                    
                    imprimirMensaje(victima.getNombre() + " no tiene cartas para robar.", interfazGrafica);
                }
            } else {
                
                imprimirMensaje("No hay jugadores rivales cerca.", interfazGrafica);
            }
    }
}