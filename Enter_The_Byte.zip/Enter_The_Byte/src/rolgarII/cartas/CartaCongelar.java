package rolgarII.cartas;

import interfaz.Interfaz;
import rolgarII.AlianzaRolgarII;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

public class CartaCongelar extends Carta {

    /**
     * Creamos la carta.
     */
    public CartaCongelar() {
        super("Congelar", "Congela a un jugador no aliado.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
        jugador.getInventario().activarCarta(this);
        
        AlianzaRolgarII alianza = contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugador);
        
        JugadorRolgarII rival = contextoJuego.getGestorDeEntidadesVivas().buscarJugadorRivalMasCercano(
        		jugador, alianza);
        
        if (rival != null) {
        	rival.setCongelado(true);
        	imprimirMensaje(rival.getNombre() + " fue congelado.", interfazGrafica);
        	
        } else {
        	imprimirMensaje("No se encontro rival.", interfazGrafica);
        }
    }
}