package rolgarII.cartas;

import interfaz.Interfaz;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

public class CartaAumentoVida extends Carta {
    private static final int ENERGIA_RECUPERADA = 50;
    /**
     * Creamos la carta.
     */
    public CartaAumentoVida() {
        super("Aumento de Vida", "Restaura energia.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
    	jugador.getInventario().eliminarCarta(this);

        jugador.recuperarEnergia(ENERGIA_RECUPERADA);
        imprimirMensaje(jugador.getNombre() + " recupera vida.", interfazGrafica);
    }
}