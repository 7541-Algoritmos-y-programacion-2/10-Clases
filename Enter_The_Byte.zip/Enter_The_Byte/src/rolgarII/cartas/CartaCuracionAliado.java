package rolgarII.cartas;

import interfaz.Interfaz;
import rolgarII.JugadorRolgarII;
import rolgarII.contexto.ContextoDeJuego;
import utiles.ValidacionesUtiles;

public class CartaCuracionAliado extends Carta {
    /**
     * Creamos la carta.
     */
    public CartaCuracionAliado() {
        super("Curacion de Aliado", "Cura a un aliado cercano.");
    }

    /**
     * Aumenta la vida del jugador enviado como parametro.
     * @param jugador no puede ser nulo.
     * @param contextoJuego no nulo.
     * @param interfazGrafica no nula.
     */
    @Override
    public void aplicarEfecto(JugadorRolgarII jugador, ContextoDeJuego contextoJuego, Interfaz interfazGrafica) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
    	ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz Grafica");
    	
    	jugador.getInventario().eliminarCarta(this);
    	
    	if(contextoJuego.getGestorDeAlianzasActivas().tieneAlianza(jugador)) {
    		JugadorRolgarII aliado = contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugador).getAliadoMasCercano(jugador);

    		if (aliado != null) {
    			aliado.recuperarEnergia(30);
    			imprimirMensaje("Aliado curado.", interfazGrafica);

    		} else {
    			imprimirMensaje("No hay aliados cerca.", interfazGrafica);
    		}
    		
    	} else {
    		imprimirMensaje("Jugador no tiene alianza", interfazGrafica);
    	}
    }
}