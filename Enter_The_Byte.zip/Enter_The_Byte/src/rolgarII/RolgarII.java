package rolgarII;

import java.util.List;
import java.util.stream.Collectors;

import interfaz.Interfaz;
import estructuras.ListaSimplementeEnlazada;
import utiles.ValidacionesUtiles;
import enums.Dificultad;
import base.Juego;
import base.Jugador;
import base.Partida;
import rolgarII.cartas.*;

/**
 * Rolgar II
 */
public class RolgarII implements Juego {

    private String nombre;
    private Interfaz interfazGrafica;
    private PartidaDeRolgarII partidaActual;
    private List<Carta> prototiposDeCartas;

    /**
     * Creamos el juego Rolgar II
     */
    public RolgarII() {

        this.nombre = "Rolgar II";
        this.interfazGrafica = new Interfaz();
        this.prototiposDeCartas = inicializarPrototiposDeCartas();
        this.partidaActual = null;
    }

    /**
     * Iniciamos los prototipos de cartas que tiene el juego.
     * @return
     */
    private List<Carta> inicializarPrototiposDeCartas() {
    	
        List<Carta> lista = new ListaSimplementeEnlazada<>();
        
        lista.add(new CartaAtaqueDoble());
        lista.add(new CartaAumentoVida());
        lista.add(new CartaClarividencia());
        lista.add(new CartaDobleMovimiento());
        lista.add(new CartaCuracionAliado());
        lista.add(new CartaEscudo());
        lista.add(new CartaCongelar());
        lista.add(new CartaInvisibilidad());
        lista.add(new CartaRoboDeCarta());
        lista.add(new CartaTeletransportacion());
        
        return lista;
    }

    /**
     * Iniciamos una nueva partida.
     */
    @Override
    public void iniciarPartida() {

        Dificultad dificultad = elegirDificultadParaPartida();

        MapaRolgarII mapa = new MapaRolgarII(
                dificultad.getDimensionesTablero(),
                dificultad.getDimensionesTablero(),
                dificultad.getDimensionesTablero(),
                dificultad.getCantidadDeCartasEnMapa()
        );

        this.partidaActual = new PartidaDeRolgarII(mapa, iniciarJugadores(),
                iniciarEnemigos(dificultad.getCantidadEnemigos(), dificultad.getDañoBaseEnemigo()),
                interfazGrafica, prototiposDeCartas);

        partidaActual.iniciar();

        interfazGrafica.iniciarUI(partidaActual);
    }

    /**
     * Iniciamos los enemigos de la partida
     * @param cantidadDeEnemigos: depende la dificultad, debe ser mayor a 0.
     * @param fuerzaEnemigos: depende la dificultad, debe ser mayor a 0.
     * @return
     */
    private List<EnemigoRolgarII> iniciarEnemigos(int cantidadDeEnemigos, int fuerzaEnemigos) {
    	
    	ValidacionesUtiles.validarMayorACero(cantidadDeEnemigos, "Cantidad De Enemigos");
    	ValidacionesUtiles.validarMayorACero(fuerzaEnemigos, "Fuerza Enemigos");
    	
        List<EnemigoRolgarII> enemigos = new ListaSimplementeEnlazada<>();
        
        for(int i = 1; i <= cantidadDeEnemigos; i++) {
            EnemigoRolgarII enemigo = new EnemigoRolgarII("Enemigo " + i, fuerzaEnemigos);
            enemigos.add(enemigo);
        }
        
        return enemigos;
    }

    /**
     * Iniciamos los jugadores de la partida eligiendo cantidad y nombre para cada uno.
     * @return
     */
    private List<JugadorRolgarII> iniciarJugadores() {
    	
        List<JugadorRolgarII> jugadores = new ListaSimplementeEnlazada<>();

        int cantidadDeJugadores = interfazGrafica.pedirEntero("Elije la cantidad de jugadores (1-6):", 1, 6);

        for(int i = 1; i <= cantidadDeJugadores; i++) {
            String nombre = interfazGrafica.pedirString("Ingrese nombre para Jugador N°" + i);
            
            ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
            ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre no puede ser vacio");
            
            JugadorRolgarII jugador = new JugadorRolgarII(nombre, 3, 15, 3);
            jugadores.add(jugador);
        }

        return jugadores;
    }

    /**
     * Juega la partida hasta que termine.
     */
    @Override
    public void jugarPartida() {
    	
        ValidacionesUtiles.esDistintoDeNull(partidaActual, "Partida Activa");
        
        while(!partidaActual.haTerminado()) {
            partidaActual.ejecutarTurno();
        }
    }

    /**
     * Elige dificultad para la nueva partida y la devuelve.
     */
    @Override
    public Dificultad elegirDificultadParaPartida() {
    	
        int opcion = interfazGrafica.preguntarConOpciones("Elije una dificultad para empezar:", List.of("FACIL","NORMAL","DIFICIL"));
        switch (opcion) {
            case 0: return Dificultad.FACIL;
            case 1: return Dificultad.NORMAL;
            case 2: return Dificultad.DIFICIL;
            default: return Dificultad.NORMAL;
        }
    }

    /**
     * Finaliza la partida y muestra a los ganadores.
     */
    @Override
    public void finalizarPartida() {
    	
        ValidacionesUtiles.validarVerdadero(partidaActual.haTerminado(), "Partida no termino");
        
        if (partidaActual.obtenerGanadorOGanadores() != null && !partidaActual.obtenerGanadorOGanadores().isEmpty()) {
        	
            String nombresDeGanadores = partidaActual.obtenerGanadorOGanadores().stream()
                    .map(Jugador::getNombre)
                    .collect(Collectors.joining(", "));
            interfazGrafica.mostrarMensaje("Ganadores de la partida: " + nombresDeGanadores);
            
        } else {        	
            interfazGrafica.mostrarMensaje("DERROTA. Todos los jugadores han caído");
        }
    }

    /**
     * Devuelve la partida actual.
     */
    @Override
    public Partida<?> getPartidaActual() {
    	return partidaActual;
    }

    /**
     * Devuelve el nombre del juego.
     */
    @Override
    public String getNombre() {
    	return nombre;
    }
}
