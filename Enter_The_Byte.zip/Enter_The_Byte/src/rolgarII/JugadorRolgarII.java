package rolgarII;

import java.util.Objects;

import utiles.ValidacionesUtiles;
import base.Coordenadas;
import base.Jugador;
import rolgarII.cartas.CartaAtaqueDoble;
import rolgarII.cartas.CartaEscudo;
import base.Combatiente;

/**
 * Jugador de Rolgar II.
 */
public class JugadorRolgarII extends Jugador implements Combatiente{
	
	private int energia;
	private int recuperacion;
	private int fuerza;
	private int vision;
	private Inventario inventario;
	private Coordenadas coordenadas;
	private boolean congeladoActivo = false;

	/**
	 * Creamos un jugador para Rolgar II.
	 * @param nombre: nombre para jugador, debe ser no nulo y no vacio.
	 * @param vision: vision del jugador debe ser mayor a 0.
	 * @param fuerza: fuerza del jugador debe ser mayor a 0.
	 * @param recuperacion: recuperacion del jugador debe ser mayor a 0.
	 */
	public JugadorRolgarII(String nombre, int vision , int fuerza, int recuperacion) {
		super(nombre);
		
		ValidacionesUtiles.validarMayorACero(vision, "Vision");
		ValidacionesUtiles.validarMayorACero(fuerza, "Fuerza");
		ValidacionesUtiles.validarMayorACero(recuperacion, "Recuperacion");
		
		this.recuperacion = recuperacion;
		this.coordenadas = null;
		this.fuerza = fuerza;
		this.vision = vision;
		this.energia = 100;
		this.inventario = new Inventario();
	}
	
	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(coordenadas);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (!super.equals(obj)) {
			return false;
		}
		
		if (getClass() != obj.getClass()) {
			return false;
		}
		
		JugadorRolgarII other = (JugadorRolgarII) obj;
		return Objects.equals(coordenadas, other.coordenadas);
	}

	@Override
	public String toString() {
		
		String mensajeCoordenadas = (coordenadas == null) ? "(sin coordenadas)" : coordenadas.toString();
		
		return "Jugador De Rolgar II [Nombre: " + nombre + ", Energia: " + energia + ", Fuerza: " + fuerza +
				", " + inventario.toString() + ", " + mensajeCoordenadas + "]";
	}
	
	/**
	 * Recupera energia del jugador.
	 * @param energiaRecuperada: cantidad de energia para recuperar debe ser mayor a 0.
	 */
	@Override
	public void recuperarEnergia(int energiaRecuperada) {
		
		ValidacionesUtiles.validarMayorACero(energiaRecuperada, "Energia Recuperada");
		
		this.energia += energiaRecuperada;
		
		if (energia > 100) {
			this.energia = 100;
		}
	}
	
	/**
	 * Setea coordenadas para el jugador.
	 * @param coordenadas: nuevas coordenadas del jugador deben ser no nulas.
	 */
	@Override
	public void setCoordenadas(Coordenadas coordenadas) {
		
		ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
		
		this.coordenadas = coordenadas;
	}
	
	/**
	 * Retorna las coordenadas del jugador.
	 * @return
	 */
	@Override
	public Coordenadas getCoordenadas() {
		return coordenadas;
	}
	
	/**
	 * Retorna la energia del jugador.
	 * @return
	 */
	@Override
	public int getEnergia() {
		return energia;
	}
	
	@Override
	public int obtenerFuerzaParaAtaque() {
		
	    if(inventario.tieneActiva(CartaAtaqueDoble.class)) {	
	        inventario.desactivarCarta();
	        return fuerza * 2;
	    }
	    
	    return fuerza;
	}
	
	/**
	 * Resta un daño recibido a la energia del jugador.
	 * @param daño: daño a recibir debe ser mayor a 0.
	 */
	@Override
	public void recibirDaño(int daño) {
		
		ValidacionesUtiles.validarMayorACero(daño, "Daño");
		
		if (inventario.tieneActiva(CartaEscudo.class)) {
			daño /= 2;
			
			inventario.desactivarCarta();
		}
		
		this.energia -= daño;
		
		if (energia < 0) {
			this.energia = 0;
		}
	}
	
	/**
	 * Recupera energia del jugador.
	 */
	public void recuperarEnergia() {
		
		this.energia += recuperacion;
		
		if (energia > 100) {
			this.energia = 100;
		}
	}
	
	/**
	 * Verifica si el jugador esta vivo.
	 */
	public boolean estaVivo() {
		return energia > 0;
	}
	
	/**
	 * Retorna la recuperacion del jugador.
	 * @return
	 */
	public int getRecuperacion() {
		return recuperacion;
	}
	
	/**
	 * Retorna la fuerza del jugador.
	 * @return
	 */
	public int getFuerza() {
		return fuerza;
	}

	/**
	 * Retorna la vision del jugador.
	 * @return
	 */
	public int getVision() {
		return vision;
	}

	/**
	 * Retorna el inventario del jugador.
	 * @return
	 */
	public Inventario getInventario() {
		return inventario;
	}
	
    /**
     * Retorna el estado de congelado.
     */
    public boolean estaCongelado() {
        return this.congeladoActivo;
    }

	/**
	 * Setea un inventario para el jugador.
	 * @param inventario: nuevo inventario del jugador debe ser no nulo.
	 */
	public void setInventario(Inventario inventario) {
		
		ValidacionesUtiles.esDistintoDeNull(inventario, "Inventario");
		
		this.inventario = inventario;
	}

	/**
	 * Setea unas coordenadas nuevas para el jugador.
	 * @param x: mayor a 0.
	 * @param y: mayor a 0.
	 * @param z: mayor a 0.
	 */
	public void setCoordenada(int x, int y, int z) {
		setCoordenadas(new Coordenadas(x, y, z));
	}
	
    /**
     * Cambia el estado de congelado.
     */
    public void setCongelado(boolean estado) {
        this.congeladoActivo = estado;
    }
}
