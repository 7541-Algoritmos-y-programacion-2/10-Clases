package rolgarII.contexto;

import rolgarII.gestores.GestorDeAlianzasActivas;
import rolgarII.gestores.GestorDeEntidadesVivas;
import rolgarII.gestores.GestorDeMapaYCoordenadas;
import utiles.ValidacionesUtiles;

/**
 * Contexto global del juego.
 */
public class ContextoDeJuego {

    private GestorDeAlianzasActivas gestorAlianzas;
    private GestorDeEntidadesVivas gestorEntidades;
    private GestorDeMapaYCoordenadas gestorMapaYCoordenadas;
    
    /**
     * Método para inicializar el contexto (Llamado solo por PartidaDeRolgarII).
     * @param gestorMapa: Gestor del mapa no nulo.
     * @param gestorEntidades: Gestor de entidades no nulo.
     * @param gestorAlianzas: Gestor de alianzas no nulo.
     */
    public ContextoDeJuego(GestorDeMapaYCoordenadas gestorMapa, 
                                  GestorDeEntidadesVivas gestorEntidades, 
                                  GestorDeAlianzasActivas gestorAlianzas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(gestorMapa, "Gestor Mapa");
    	ValidacionesUtiles.esDistintoDeNull(gestorAlianzas, "GestorAlianzas");
    	ValidacionesUtiles.esDistintoDeNull(gestorEntidades, "Gestor Entidades");
        
        this.gestorMapaYCoordenadas = gestorMapa;
        this.gestorEntidades = gestorEntidades;
        this.gestorAlianzas = gestorAlianzas;
    }

    /**
     * Devuelve el gestor de mapa y coordenadas.
     * @return
     */
    public GestorDeMapaYCoordenadas getGestorMapaYCoordenadas() {
        return gestorMapaYCoordenadas;
    }

    /**
     * Devuelve el gestor de entidades.
     * @return
     */
    public GestorDeEntidadesVivas getGestorDeEntidadesVivas() {
        return gestorEntidades;
    }

    /**
     * Devuelve el gestor de alianzas.
     * @return
     */
    public GestorDeAlianzasActivas getGestorDeAlianzasActivas() {
        return gestorAlianzas;
    }
}
