package rolgarII.gestores;

import java.util.List;
import rolgarII.AlianzaRolgarII;
import rolgarII.JugadorRolgarII;
import utiles.ValidacionesUtiles;
import estructuras.ListaSimplementeEnlazada;

/**
 * Encargado de gestionar las alianzas de la partida.
 */
public class GestorDeAlianzasActivas {

    private List<AlianzaRolgarII> alianzasActivas;

    /**
     * Iniciamos el gestor.
     */
    public GestorDeAlianzasActivas() {
        this.alianzasActivas = new ListaSimplementeEnlazada<>();
    }

    /**
     * Agrega una nueva alianza a alianzas activas.
     * @param nombre: nombre de la nueva alianza no nulo ni vacio.
     * @param fundador: fundador de la alianza no nulo y no puede pertenecer a otras alianzas.
     */
    public void agregarNuevaAlianza(String nombre, JugadorRolgarII fundador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(fundador, "Fundador");
    	ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre Alianza");
    	ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre alianza vacio");
        ValidacionesUtiles.validarFalso(tieneAlianza(fundador), "Fundador ya tiene alianza");
        
        this.alianzasActivas.add(new AlianzaRolgarII(nombre, fundador));
    }

    /**
     * Elimina una alianza de las alianzas activas.
     * @param alianza: alianza a eliminar no nula y debe pertenecer a alianzas activas.
     */
    public void eliminarAlianza(AlianzaRolgarII alianza) {
    	
        ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
        ValidacionesUtiles.validarVerdadero(alianzasActivas.contains(alianza), "Alianza no pertenece a la partida");
        
        this.alianzasActivas.remove(alianza);
    }
    
    /**
     * Limpia las alianzas de los muertos y elimina las alianzas vacias.
     */
    public void limpiarAlianzas() {
    	
        for (AlianzaRolgarII alianza : alianzasActivas) {
            alianza.limpiarMuertos();
        }
        
        alianzasActivas.removeIf(alianza -> alianza.getMiembros().size() < 1);
    }

    /**
     * Devuelve la alianza de un jugador
     * @param jugador: no nulo.
     * @return
     */
    public AlianzaRolgarII getAlianzaDeJugador(JugadorRolgarII jugador) {
    	
        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        
        for (AlianzaRolgarII alianza : alianzasActivas) {
        	
        	ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
        	
            if (alianza.contiene(jugador)) {
                return alianza;
            }
        }
        
        return null;
    }

    /**
     * Verifica si un jugador tiene alianza.
     * @param jugador: no nulo
     * @return
     */
    public boolean tieneAlianza(JugadorRolgarII jugador) {
        
        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        
        for (AlianzaRolgarII alianza : alianzasActivas) {
        	
        	ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
        	
            if (alianza.contiene(jugador)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Devuelve la cantidad de alianzas activas.
     * @return
     */
    public int getCantidadDeAlianzas() {
    	return alianzasActivas.size();
    }
    
    /**
     * Agregar un jugador a una alianza activa.
     * @param alianza: alianza no nula y perteneciente a alianzas activas.
     * @param nuevoMiembro: nuevo miembro no nulo y no debe tener otra alianza.
     */
    public void agregarMiembroAAlianza(AlianzaRolgarII alianza, JugadorRolgarII nuevoMiembro) {
    	
    	ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
    	ValidacionesUtiles.validarVerdadero(alianzasActivas.contains(alianza), "Alianza no pertenece a la partida");
    	ValidacionesUtiles.esDistintoDeNull(nuevoMiembro, "Nuevo Miembro");
    	ValidacionesUtiles.validarFalso(tieneAlianza(nuevoMiembro), "Jugador ya tiene alianza");
       
        alianza.agregarJugador(nuevoMiembro);
    }
    
    /**
     * elimina un miembro de una aliaza activa.
     * @param alianza: alianza no nula y perteneciente a las alianzas activas
     * @param miembroAEliminar: miembro a eliminar no nulo y perteneciente a la alianza.
     */
    public void eliminarMiembroDeAlianza(AlianzaRolgarII alianza, JugadorRolgarII miembroAEliminar) {
    	
    	ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
    	ValidacionesUtiles.validarVerdadero(alianzasActivas.contains(alianza), "Alianza no pertenece a la partida");
    	ValidacionesUtiles.esDistintoDeNull(miembroAEliminar, "Miembro");
    	ValidacionesUtiles.validarVerdadero(alianza.contiene(miembroAEliminar), "Miembro no pertenece a alianza");
       
        alianza.eliminarJugador(miembroAEliminar);
    }

    /**
     * Devuelve las alianzas activas.
     * @return
     */
	public List<AlianzaRolgarII> getAlianzasActivas() {
		return alianzasActivas;
	}
	
	/**
	 * Devuelve los nombres de los jugadores sin alianza.
	 * @param jugadores: lista de jugadores no nula.
	 * @return
	 */
	public List<String> obtenerNombresDeJugadoresSinAlianza(List<JugadorRolgarII> jugadores){
		
		ValidacionesUtiles.esDistintoDeNull(jugadores, null);
		
		List<String> nombres = new ListaSimplementeEnlazada<String>();
    	
    	for(JugadorRolgarII jugador : jugadores) {
    		
    		if(!tieneAlianza(jugador)) {
    			nombres.add(jugador.getNombre());
    		}
    	}
    	
    	return nombres;
	}
	
	/**
	 * Verifica si varios jugadores son parte de la misma alianza.
	 * @param jugadoresAliados: lista de jugadores no nula ni vacia.
	 * @return
	 */
	public boolean jugadoresSonPartedeMismaAlianza(List<JugadorRolgarII> jugadoresAliados) {
		
		ValidacionesUtiles.esDistintoDeNull(jugadoresAliados, "Jugadores Aliados");
		ValidacionesUtiles.validarFalso(jugadoresAliados.size() < 1, "Lista de jugadores vacia");
		
		AlianzaRolgarII alianza = getAlianzaDeJugador(jugadoresAliados.get(0));
		
		for (JugadorRolgarII aliado : jugadoresAliados) {
			
			ValidacionesUtiles.esDistintoDeNull(aliado, "Aliado");
			
			if (alianza == null || !alianza.equals(getAlianzaDeJugador(aliado))) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Verifica si una alianza esta activa
	 * @param alianza: alianza no nula.
	 * @return
	 */
	public boolean alianzaEstaActiva(AlianzaRolgarII alianza) {
		
		ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
		
		return alianzasActivas.contains(alianza);
	}
	
	/**
	 * Busca una alianza entre las alianzas activas.
	 * @param alianza: no nula y perteneciente a alianzas activas.
	 * @return
	 */
	public AlianzaRolgarII getAlianza(AlianzaRolgarII alianza) {
		
		ValidacionesUtiles.esDistintoDeNull(alianza, "Alianza");
		ValidacionesUtiles.validarVerdadero(alianzasActivas.contains(alianza), "Alianza no pertenece a la partida");
		
		return alianzasActivas.get(alianzasActivas.indexOf(alianza));
	}
}
