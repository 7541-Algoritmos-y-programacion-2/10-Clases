package rolgarII.gestores;

import java.util.List;

import estructuras.ListaSimplementeEnlazada;
import rolgarII.JugadorRolgarII;
import rolgarII.cartas.CartaInvisibilidad;
import utiles.ValidacionesUtiles;
import rolgarII.AlianzaRolgarII;
import rolgarII.EnemigoRolgarII;
import base.Combatiente;
import base.Coordenadas;

/**
 * Gestor de entidades vivas de una partida.
 */
public class GestorDeEntidadesVivas {
	
	private List<JugadorRolgarII> jugadores;
	private List<EnemigoRolgarII> enemigos;
	
	/**
	 * Constructor que inicializa el gestor con las listas iniciales de jugadores y enemigos.
	 * @param jugadores La lista de jugadores activos en la partida. No debe ser nula.
	 * @param enemigos La lista de enemigos activos en la partida. No debe ser nula.
	 */
	public GestorDeEntidadesVivas(List<JugadorRolgarII> jugadores, List<EnemigoRolgarII> enemigos) {
		
		ValidacionesUtiles.esDistintoDeNull(jugadores, "Jugadores");
		ValidacionesUtiles.esDistintoDeNull(enemigos, "Enemigos");
		
		this.jugadores = jugadores;
		this.enemigos = enemigos;
	}

	/**
	 * Devuelve los jugadores.
	 * @return
	 */
	public List<JugadorRolgarII> getJugadores() {
		return jugadores;
	}

	/**
	 * Devuelve los enemigos.
	 * @return
	 */
	public List<EnemigoRolgarII> getEnemigos() {
		return enemigos;
	}
    
	/**
	 * Devuelve una lista con ambos enemigos y juugadores.
	 * @return
	 */
    public List<Combatiente> getEntidades() {
    	
    	List<Combatiente> listaEntidades = new ListaSimplementeEnlazada<Combatiente>();
    	
    	listaEntidades.addAll(jugadores);
    	listaEntidades.addAll(enemigos);
    	
    	return listaEntidades;
    }
    
    /**
     * Elimina las entidades muertas.
     */
    public void limpiarEntidadesMuertas() {

        jugadores.removeIf(jugador -> !jugador.estaVivo());
        enemigos.removeIf(enemigo -> !enemigo.estaVivo());
    }
    
    /**
     * Elimina a un enemigo enviado por parametro
     * @param enemigo debe pertenecer a enemigos y no ser nulo.
     */
    public void eliminarEnemigo(EnemigoRolgarII enemigo) {
    	
    	ValidacionesUtiles.esDistintoDeNull(enemigo, "Enemigo");
    	ValidacionesUtiles.validarVerdadero(enemigos.contains(enemigo), "Enemigo no pertenece a la partida");
    	
        enemigos.remove(enemigo);
    }
    
    /**
     * Devuelve la cantidad de jugadores en la partida
     * @return
     */
    public int getCantidadJugadores() {
        return jugadores.size();
    }
    
    /**
     * Devuelve la cantidad de jugadores en la partida
     * @return
     */
    public int getCantidadEnemigos() {
        return enemigos.size();
    }
    
    /**
     * Busca y devuelve la instancia de un jugador que ya está en la lista de jugadores de la partida.
     * @param jugador El objeto jugador que se desea buscar.
     * @return
     */
    public JugadorRolgarII getJugador(JugadorRolgarII jugador) {

        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        ValidacionesUtiles.validarVerdadero(jugadores.contains(jugador), "Jugador no pertenece a la partida");
        
        return jugadores.get(jugadores.indexOf(jugador));
    }
    
    /**
     * Busca y devuelve la instancia de un enemigo que ya está en la lista de enemigos de la partida.
     * @param enemigo El objeto enemigo que se desea buscar.
     * @return
     */
    public EnemigoRolgarII getEnemigo(EnemigoRolgarII enemigo) {

        ValidacionesUtiles.esDistintoDeNull(enemigo, "Enemigo");
        ValidacionesUtiles.validarVerdadero(enemigos.contains(enemigo), "Enemigo no pertenece a la partida");
        
        return enemigos.get(enemigos.indexOf(enemigo));
    }
    
    /**
     * Busca un jugador por el nombre.
     * @param nombreDeJugadorABuscar: nombre del jugador que se quiere buscar debe ser no nulo y pertenecer a la partida.
     * @return
     */
    public JugadorRolgarII getJugadorPorNombre(String nombreDeJugadorABuscar) {
    	
    	ValidacionesUtiles.esDistintoDeNull(nombreDeJugadorABuscar, "Nombre De Jugador A Buscar");

        for (JugadorRolgarII jugador : jugadores) {

            if (nombreDeJugadorABuscar.equalsIgnoreCase(jugador.getNombre())) {
                return jugador;
            }
        }

        throw new RuntimeException("nombre no pertenece a nungun jugador");
    }
    
    /**
     * Genera un string con las coordenadas de todos los demás jugadores de la partida, 
     * excluyendo al jugador de referencia y a cualquier jugador con la carta de invisibilidad activa.
     * @param jugador El jugador cuyas coordenadas de los demás se quieren obtener. No puede ser nulo y debe pertenecer a la partida.
     * @return Una cadena de texto con el nombre y coordenadas (X, Y, Z) de los jugadores visibles, separados por saltos de línea.
     */
    public String getCoordenadasDeJugadores(JugadorRolgarII jugador) {

        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        ValidacionesUtiles.validarVerdadero(jugadores.contains(jugador), "Jugador no pertenece a la partida");
        
        String coordenadasDeTodos = "";

        for (JugadorRolgarII otroJugador : jugadores) {

            if (!otroJugador.equals(jugador) && !otroJugador.getInventario().tieneActiva(CartaInvisibilidad.class)) {
                Coordenadas coordenadas = otroJugador.getCoordenadas();

                coordenadasDeTodos += otroJugador.getNombre() + " - (" + coordenadas.getPosX() + "," +
                        coordenadas.getPosY() + "," + coordenadas.getPosZ() + ")" + "\n";
            }
        }

        return coordenadasDeTodos;
    }
    
    /**
     * Determina si dos combatientes pueden iniciar una lucha.
     * Siempre se puede luchar contra un enemigo (no JugadorRolgarII).
     * Si la entidad es otro jugador, la lucha solo es posible si no son aliados (o si el jugador actual no tiene alianza).
     * @param entidad El otro combatiente que se encuentra en la posición (atacado).
     * @param jugador El jugador que se mueve a la posición (atacante).
     * @param alianzaJugador La alianza a la que pertenece el jugador (puede ser {@code null}).
     * @return {@code true} si la lucha es posible; {@code false} en caso contrario (son aliados).
     */
    public boolean puedenLuchar(Combatiente entidad, JugadorRolgarII jugador, AlianzaRolgarII alianzaJugador){
        
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(entidad, "Entidad");
    	
    	if (!(entidad instanceof JugadorRolgarII jugadorAliado)) {
            return true;
        }

        return alianzaJugador == null || !alianzaJugador.sonAliados(jugador, jugadorAliado);
    }
    
    /**
     * Devuelve al jugador rival (no aliado) más cercano al jugador enviado por parámetro.
     * Si no hay rivales visibles o en la partida, devuelve {@code null}.
     * @param jugador El jugador de referencia. No puede ser nulo y debe pertenecer a la partida.
     * @param alianza La alianza del jugador de referencia (puede ser {@code null}).
     * @return El Jugador que es el rival más cercano, o {@code null}.
     */
    public JugadorRolgarII buscarJugadorRivalMasCercano(JugadorRolgarII jugador, AlianzaRolgarII alianza) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.validarVerdadero(jugadores.contains(jugador), "Jugador no pertenece a la partida");
        
        JugadorRolgarII rivalMasCercano = null;

        for (JugadorRolgarII otroJugador : jugadores) {
        	
        	ValidacionesUtiles.esDistintoDeNull(otroJugador, "Jugador");

            if (!otroJugador.equals(jugador)) {
            	
            	if (alianza == null || !alianza.sonAliados(jugador, otroJugador)) {
                
            		if ((rivalMasCercano == null ||
            				otroJugador.getCoordenadas().getDistanciaEntreCoordenadas(jugador.getCoordenadas())
            				< rivalMasCercano.getCoordenadas().getDistanciaEntreCoordenadas(jugador.getCoordenadas()))) {
                    
            			rivalMasCercano = otroJugador;
            		}
            	}
            }
        }
        
        return rivalMasCercano;
    }

    /**
     * Verifica si hay jugadores.
     * @return
     */
	public boolean hayJugadores() {
		return jugadores.size() > 0;
	}
	
	/**
	 * Verifica si hay enemigos.
	 * @return
	 */
	public boolean hayEnemigos() {
		return enemigos.size() > 0;
	}
}
