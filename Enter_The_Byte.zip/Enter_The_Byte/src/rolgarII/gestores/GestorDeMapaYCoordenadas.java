package rolgarII.gestores;

import java.util.List;

import base.Combatiente;
import base.Coordenadas;
import enums.TipoTerreno;
import rolgarII.EnemigoRolgarII;
import rolgarII.JugadorRolgarII;
import rolgarII.MapaRolgarII;
import rolgarII.cartas.Carta;
import utiles.GeneradorAleatorio;
import utiles.ValidacionesUtiles;

/**
 * Encargado de gestionar el mapa y coordenadas de la partida.
 */
public class GestorDeMapaYCoordenadas {
	
	private MapaRolgarII mapa;
	private List<Carta> prototiposDeCartas;
	
	/**
	 * Constructor para inicializar el gestor de mapa.
	 * @param mapa El Mapa que contiene la estructura del tablero. No debe ser nulo.
	 * @param prototipoDeCartas La lista de prototipos de cartas que pueden ser recolectadas.
	 */
	public GestorDeMapaYCoordenadas(MapaRolgarII mapa, List<Carta> prototipoDeCartas) {
		
		ValidacionesUtiles.esDistintoDeNull(mapa, "Mapa");
		ValidacionesUtiles.esDistintoDeNull(prototipoDeCartas, "Prototipos de cartas");
		
		this.mapa = mapa;
		this.prototiposDeCartas = prototipoDeCartas;
	}
	
	/**
	 * Devuelve el mapa.
	 * @return
	 */
    public MapaRolgarII getMapa() {
		return mapa;
	}
    
    /**
     * Verifica si el tipo de terreno de las coordenadas dadas coincide con el TipoTerreno especificado.
     * @param coordenadas Las coordenadas a verificar.
     * @param tipoTerreno El tipo de terreno a buscar.
     * @return {@code true} si el casillero en esas coordenadas tiene el tipo de terreno buscado; {@code false} en caso contrario.
     */
    public boolean hayTipoTerrenoEnCoordenada(Coordenadas coordenadas, TipoTerreno tipoTerreno) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	ValidacionesUtiles.esDistintoDeNull(tipoTerreno, "Tipo Terreno");
    	
    	return tipoTerreno.equals(mapa.getCasillero(coordenadas).getValor());
    }

    /**
     * Busca coordenadas libres de entidades.
     * @param entidades Lista de combatientes activos en el juego.
     * @return Coordenadas que representa una posición libre.
     */
    public Coordenadas obtenerCoordenadasLibres(List<Combatiente> entidades) {
    	
    	ValidacionesUtiles.esDistintoDeNull(entidades, "Entidades");

        Coordenadas coordenadas;

        do {
            coordenadas = mapa.obtenerCasilleroTransitableRandom().getCoordenadas();

        } while(hayEntidadEnCoordenadas(coordenadas, entidades));

        return coordenadas;
    }
    
    /**
     * Mueve el jugador a una nueva posición relativa.
     * @param dx El cambio en la coordenada X.
     * @param dy El cambio en la coordenada Y.
     * @param dz El cambio en la coordenada Z.
     * @param jugador El jugador a mover. No debe ser nulo.
     */
    public void moverJugador(int movimientoEnX, int movimientoEnY, int movimientoEnZ, JugadorRolgarII jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");

        int x = movimientoEnX + jugador.getCoordenadas().getPosX();
        int y = movimientoEnY + jugador.getCoordenadas().getPosY();
        int z = movimientoEnZ + jugador.getCoordenadas().getPosZ();

        if (mapa.estaEnLimite(x,y,z) && !mapa.terrenoNoTransitable(x,y,z)) {
            jugador.setCoordenada(x, y, z);
            jugador.recuperarEnergia();
        }
    }
    
    /**
     * Recibe unas coordenadas y devuelve la carta en esas coordenadas o null si no hay.
     * @param coordenadas: no nulas
     * @return
     */
    public Carta getCartaEnCoordenadas(Coordenadas coordenadas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	
    	if (hayCartaEnCoordenadas(coordenadas)) {
            return GeneradorAleatorio.elegirObjetoRandomDeLista(prototiposDeCartas);
    	}
    	
    	return null;
    }
    
    /**
     * Verifica si existe una carta para recolectar en las coordenadas especificadas.
     * @param coordenadas Las coordenadas a verificar. No deben ser nulas.
     * @return {@code true} si hay una carta en las coordenadas; {@code false} en caso contrario.
     */
    public boolean hayCartaEnCoordenadas(Coordenadas coordenadas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	
    	return mapa.getCasillerosConCarta().contains(coordenadas);
    }
    
    /**
     * Devuelve la vision del personaje con los tipo terreno y los enemigos y jugadores.
     * @param jugador El jugador que está visualizando el mapa.
     * @param entidades La lista completa de todas las entidades (jugadores y enemigos) en la partida.
     * @return
     */
    public List<List<String>> getEstadosParaVisualizar(JugadorRolgarII personaje, List<Combatiente> entidades) {
    	
    	ValidacionesUtiles.esDistintoDeNull(personaje, "Personaje");
    	ValidacionesUtiles.esDistintoDeNull(entidades, "Entidades");

        List<List<String>> matriz = mapa.crearMatrizTerrenos(personaje.getVision(), personaje.getCoordenadas());

        for (int i = 0; i < matriz.size(); i++) {
            for (int j = 0; j < matriz.get(i).size(); j++) {
                
            	if (!(matriz.get(i).get(j).equals("Afuera"))) {
            	
            		int x = personaje.getCoordenadas().getPosX() + (j - personaje.getVision());
            		int y = personaje.getCoordenadas().getPosY() + (i - personaje.getVision());
            		int z = personaje.getCoordenadas().getPosZ();

            		Object entidad = getEntidadEnCoordenadas(x, y, z, entidades);	

            		if (entidad instanceof JugadorRolgarII)
            			matriz.get(i).set(j, "Personaje");

            		else if (entidad instanceof EnemigoRolgarII)
            			matriz.get(i).set(j, "Enemigo");
            	}
            }
        }

        return matriz;
    }
    
    /**
     * Busca un prototipo de carta por nombre.
     * @param nombreDeCarta: nombre de la carta no nula.
     * @return
     */
    public Carta getPrototipoDeCartaPorNombre(String nombreDeCarta){
    	
    	ValidacionesUtiles.esDistintoDeNull(nombreDeCarta, "Nombre De Carta");

        for (Carta prototipoDeCarta : prototiposDeCartas) {

            if (prototipoDeCarta.getNombre().equalsIgnoreCase(nombreDeCarta)) {
                return prototipoDeCarta;
            }
        }

        throw new RuntimeException("Carta no existe");
    }

    /**
     * Devuelve la lista de prototipos de cartas que se pueden obtener en el juego.
     * @return
     */
	public List<Carta> getPrototiposDeCartas() {
		return prototiposDeCartas;
	}
	
	/**
     * Devuelve la entidad que se encuentra en las coordenadas dadas.
     * @param coordenadas Las coordenadas a verificar. No deben ser nulas.
     * @param entidades La lista de combatientes activos en la partida.
     * @return
     */
    public Combatiente getEntidadEnCoordenadas(Coordenadas coordenadas, List<Combatiente> entidades) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	ValidacionesUtiles.esDistintoDeNull(entidades, "Entidades");
    	
    	return getEntidadEnCoordenadas(coordenadas.getPosX(), coordenadas.getPosY(), coordenadas.getPosZ(), entidades);
    }
    
    /**
     * Devuelve la entidad en las coordenadas pasadas
     * @param x: mayor a 0
     * @param y: mayor a 0
     * @param z: mayor a 0
     * @return
     */
    public Combatiente getEntidadEnCoordenadas(int x, int y, int z, List<Combatiente> entidades) {
    	
    	ValidacionesUtiles.esDistintoDeNull(entidades, "Entidades");

        for (Combatiente entidad : entidades) {
        	
        	ValidacionesUtiles.esDistintoDeNull(entidad, "Entidad");
        	
        	if (entidad.getCoordenadas() != null) {
        		if (entidad.getCoordenadas().getPosX() == x &&
        			entidad.getCoordenadas().getPosY() == y &&
        			entidad.getCoordenadas().getPosZ() == z) {
        			
        			return entidad;
        		}
        	}
        }
        
        return null;
    }
    
    /**
     * Verifica si hay entidad en las coordenadas pasadas
     * @param coordenadas: no nulas
     * @param entidades: lista de entidades activas no nula
     * @return
     */
    public boolean hayEntidadEnCoordenadas(Coordenadas coordenadas, List<Combatiente> entidades) {
    	
    	ValidacionesUtiles.esDistintoDeNull(coordenadas, "Coordenadas");
    	ValidacionesUtiles.esDistintoDeNull(entidades, "Entidades");
    	
        return getEntidadEnCoordenadas(coordenadas, entidades) != null;
    }
    
    /**
     * verifica si hay entidad en las coordenadas pasadas.
     * @param x: mayor a 0
     * @param y: mayor a 0
     * @param z: mayor a 0
     * @param entidades: lista de entidades activas.
     * @return
     */
    public boolean hayEntidadEnCoordenada(int x, int y, int z, List<Combatiente> entidades) {
        return getEntidadEnCoordenadas(x, y, z, entidades) != null;
    }
}
