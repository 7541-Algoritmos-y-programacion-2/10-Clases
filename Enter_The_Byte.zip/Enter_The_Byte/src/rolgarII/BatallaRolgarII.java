package rolgarII;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import estructuras.ListaSimplementeEnlazada;
import utiles.GeneradorAleatorio;
import utiles.ValidacionesUtiles;
import base.Batalla;
import base.Combatiente;
import enums.EstadoDeBatalla;
import enums.TurnoBatalla;

/**
 * Batalla en Rolgar II
 */
public class BatallaRolgarII implements Batalla<Combatiente> {
	
	private List<Combatiente> equipo1;
	private List<Combatiente> equipo2;
	private EstadoDeBatalla estadoDeBatalla;
	private TurnoBatalla turno;

    /**
     * Creamos una batalla para Rolgar II.
     */
	public BatallaRolgarII() {
		
		this.equipo1 = new ListaSimplementeEnlazada<Combatiente>();
		this.equipo2 = new ListaSimplementeEnlazada<Combatiente>();
		this.estadoDeBatalla = EstadoDeBatalla.Iniciando;
		this.turno = null;
	}

    /**
     * Inicia batalla para Rolgar II.
     * @param atacante Objeto atacante no debe ser nulo
     * @param defensor Objeto defensor no debe ser nulo
     */
	@Override
	public void iniciar(Combatiente atacante, Combatiente defensor) {
		
		ValidacionesUtiles.esDistintoDeNull(atacante, "Atacante");
		ValidacionesUtiles.esDistintoDeNull(defensor, "Defensor");
		
		this.equipo1.add(atacante);
		this.equipo2.add(defensor);
		
		this.estadoDeBatalla = EstadoDeBatalla.Peleando;
		this.turno = TurnoBatalla.TurnoEquipo1;
	}

    /**
     * Agrega un aliado para el equipo atacante dentro del combate.
     * @param aliado Objeto aliado no debe ser nulo
     */
    public void agregarAliado(Combatiente aliado) {
    	
    	ValidacionesUtiles.esDistintoDeNull(aliado, "Aliado");
    	
    	if(turno.equals(TurnoBatalla.TurnoEquipo1)) {
    		ValidacionesUtiles.validarVerdadero(
    				equipo1.size() > 0 && equipo1.get(0) instanceof JugadorRolgarII,
    				"Solo jugadores puede agregar a un aliado");
    		
    		ValidacionesUtiles.validarFalso(equipo1.size() > 1, "Equipo lleno");
    		
    		equipo1.add(aliado);
    		
    	} else {
    		ValidacionesUtiles.validarVerdadero(
    				equipo2.size() > 0 && equipo2.get(0) instanceof JugadorRolgarII,
    				"Solo jugadores puede agregar a un aliado");
    		
    		ValidacionesUtiles.validarFalso(equipo2.size() > 1, "Equipo lleno");
    		
    		equipo2.add(aliado);
    	}
    }
    
    /**
     * Devuelve el equipo que le toca (equipo atacante)
     * @return
     */
    public List<Combatiente> getEquipoAtacante() {
        if (turno.equals(TurnoBatalla.TurnoEquipo1)) {
            return equipo1;
            
        } else {
            return equipo2;
        }
    }
    
    /**
     * Devuelve el equipo que no le toca (equipo defensor).
     * @return
     */
    public List<Combatiente> getEquipoDefensor() {
        if (turno.equals(TurnoBatalla.TurnoEquipo1)) {
            return equipo2;
            
        } else {
            return equipo1;
        }
    }

    /**
     * Busca si el participante que se desea buscar es parte del combate. Si lo se devuelve.
     * @param partcipanteABuscar el objeto participante que se desea buscar no debe ser nulo.
     * @return Participante buscado.
     */
	public Combatiente getParticipante(Combatiente participante) {
		
		List<Combatiente> participantes = getParticipantes();
		
		ValidacionesUtiles.esDistintoDeNull(participante, "Participante");
		ValidacionesUtiles.validarVerdadero(participantes.contains(participante), "Combatiente no pertenece a la batalla");
		
		return  participantes.get(participantes.indexOf(participante));
	}

    /**
     * Devuelve en una lista el equipo 1 que pertenecen al combate.
     * @return
     */
	public List<Combatiente> getEquipo1() {
		return equipo1;
	}

    /**
     * Devuelve en una lista el equipo 2 que pertenecen al combate.
     * @return
     */
	public List<Combatiente> getEquipo2() {
		return equipo2;
	}

    /**
     * Devuelve en una lista todos los participantes que pertenecen al combate.
     * @return Participantes.
     */
	@Override
	public List<Combatiente> getParticipantes() {
		
		List<Combatiente> participantes = new ListaSimplementeEnlazada<Combatiente>();
		
		participantes.addAll(getEquipo1());
		participantes.addAll(getEquipo2());
		
		return participantes;
	}

    /**
     * Ejecuta el turno actual: el primer combatiente del equipo atacante ataca a un defensor aleatorio.
     * Si el defensor muere, se elimina. Si el equipo defensor queda vacío, la batalla finaliza.
     * Si no finaliza, se rota el equipo atacante y se cambia el turno.
     */
	@Override
	public void ejecutarTurno() {
		
		if (equipo1.isEmpty() || equipo2.isEmpty()) {	
			return;
		}
		
		Combatiente atacante = getEquipoAtacante().get(0);
		Combatiente defensor = GeneradorAleatorio.elegirObjetoRandomDeLista(getEquipoDefensor());
		
        defensor.recibirDaño(atacante.obtenerFuerzaParaAtaque());

        if (!defensor.estaVivo()) {
        	eliminarDefensor(defensor);
        }
        
        if (getEquipoDefensor().isEmpty()) {
            terminar();
            
        } else {
        	cambiarTurno();
        }
	}

	/**
	 * Elimina un defensor de su equipo.
	 * @param defensor: no nulo y debe pertenecer a el grupo.
	 */
    private void eliminarDefensor(Combatiente defensor) {
		
    	ValidacionesUtiles.esDistintoDeNull(defensor, "Defensor");
    	
    	if(turno.equals(TurnoBatalla.TurnoEquipo1)) {
    		
    		ValidacionesUtiles.validarVerdadero(equipo2.contains(defensor), "No pertenece al equipo");
    		
    		this.equipo2.remove(defensor);
    		
    	} else {
    		
    		ValidacionesUtiles.validarVerdadero(equipo1.contains(defensor), "No pertenece al equipo");
   
    		this.equipo1.remove(defensor);
    	}
	}

	/**
     * Usando una lista de combatientes, mueven de lugar al primero que combate por el siguiente y se manda al primero
     * al final de la lista.
     * @param lista de combatientes no nula.
     */
	private void rotarLista(List<Combatiente> lista) {
		
		ValidacionesUtiles.esDistintoDeNull(lista, "Lista");
		
	    if (lista.size() > 1) {
	    	
	        Combatiente primero = lista.remove(0);
	        lista.add(primero);
	    }
	}

    /**
     * Cambia el turno, si le tocaba a equipo 1 ahora le toca al 2.
     */
	private void cambiarTurno() {
		
		rotarLista(getEquipoAtacante());
		
	    if(turno.equals(TurnoBatalla.TurnoEquipo1)) {
	    	this.turno = TurnoBatalla.TurnoEquipo2;
	    	
	    } else {
	    	this.turno = TurnoBatalla.TurnoEquipo1;
	    }
	}

    /**
     * Devuelve el atacante que deberia atacar en el turno en el que se encuentra el combate.
     * @return Combatiente que esta primero en la lista de atacantes.
     */
	@Override
	public Combatiente getTurnoActual() {
		return getEquipoAtacante().isEmpty() ? null : getEquipoAtacante().get(0);
	}

    /**
     * Cambia el estado de la batalla a finalizada
     */
	@Override
	public void terminar(){
		this.estadoDeBatalla = EstadoDeBatalla.Finalizada;
	}

    /**
     * Verifica si el combate sigue en curso.
     * @return True si la batalla finalizo.
     */
	@Override
	public boolean estaFinalizada() {	
        return estadoDeBatalla == EstadoDeBatalla.Finalizada
                || equipo1.isEmpty()
                || equipo2.isEmpty();
	}

    /**
     * @return Devuelve el estado de la batalla
     */
	@Override
	public EstadoDeBatalla consultarEstado() {
		return estadoDeBatalla;
	}

    /**
     * @return  Devuelve la lista de combatientes que haya terminado ganadora.
     */
	@Override
	public List<Combatiente> getGanadores() {

        if (!equipo1.isEmpty() && equipo2.isEmpty()) {
        	return equipo1;
        }
        
        if (equipo1.isEmpty() && !equipo2.isEmpty()) {
        	return equipo2;
        }
        
        return null;
	}

	@Override
	public int hashCode() {
		return Objects.hash(equipo1, equipo2);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BatallaRolgarII other = (BatallaRolgarII) obj;
		return Objects.equals(equipo1, other.equipo1)
				&& Objects.equals(equipo2, other.equipo2);
	}

	@Override
	public String toString() {
		
		String nombresEquipo1 = this.equipo1.stream() 
                .map(Combatiente::getNombre)
                .collect(Collectors.joining(", "));
		
		String nombresEquipo2 = this.equipo2.stream() 
                .map(Combatiente::getNombre)
                .collect(Collectors.joining(", "));
		
		return "BatallaRolgarII [[" + nombresEquipo1 + "] VS [" + nombresEquipo2 + "]";
	}
}
