package rolgarII;

import utiles.ValidacionesUtiles;
import rolgarII.cartas.*;
import rolgarII.contexto.ContextoDeJuego;
import utiles.GeneradorAleatorio;
import enums.EstadoDeBatalla;
import enums.Movimientos;
import enums.TipoTerreno;
import interfaz.Interfaz;
import base.Combatiente;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Turno
 */
public class Turno {

    private final JugadorRolgarII jugadorActual;
    private Interfaz interfazGrafica;
    private ContextoDeJuego contextoJuego;
    
    /**
     * Constructor para inicializar un turno.
     * @param jugador El jugador cuyo turno se va a gestionar. No debe ser nulo.
     * @param interfazGrafica La interfaz para la comunicación con el usuario. No debe ser nula.
     * @param contextoJuego El contexto global del juego para acceder a mapas, entidades y alianzas. No debe ser nulo.
     */
    public Turno(JugadorRolgarII jugador, Interfaz interfazGrafica, ContextoDeJuego contextoJuego) {

        ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
        ValidacionesUtiles.esDistintoDeNull(contextoJuego, "Contexto Juego");
        ValidacionesUtiles.esDistintoDeNull(interfazGrafica, "Interfaz");

        this.jugadorActual = jugador;
        this.interfazGrafica = interfazGrafica;
        this.contextoJuego = contextoJuego;
    }

    /**
     * Inicia el flujo principal del turno del jugador.
     * Muestra el estado actual del juego, las estadísticas, las cartas, 
     * verifica el estado de congelación y presenta el menú de acciones al jugador.
     */
    public void iniciarTurno() {
    	
        interfazGrafica.mostrarTablero(contextoJuego.getGestorMapaYCoordenadas().getEstadosParaVisualizar(
                jugadorActual, contextoJuego.getGestorDeEntidadesVivas().getEntidades()));

        interfazGrafica.mostrarEstadisticas(jugadorActual.getNombre(),
                jugadorActual.getFuerza(), jugadorActual.getEnergia());
        
        interfazGrafica.mostrarCarta(jugadorActual.getInventario().getCartas());
    	
        if (jugadorActual.estaCongelado()) {
        	
            interfazGrafica.mostrarMensaje("¡" + jugadorActual.getNombre() + " está congelado y pierde su turno!");
            jugadorActual.setCongelado(false); 
            return;
        }

        jugadorActual.getInventario().desactivarCarta();

        boolean movimientoRealizado = false;

        while(!movimientoRealizado) {

            String prompt = "¡Tu Turno " + jugadorActual.getNombre() + "!\n\n"
                    + "1. Mover Jugador\n"
                    + "2. Utilizar Carta\n"
                    + "3. Opciones De Alianza";

            int opcionElegida = interfazGrafica.preguntarConOpciones(prompt, List.of("Mover", "Usar Carta", "Alianzas"));

            switch(opcionElegida) {
                case 0:
                    menuRealizarMovimiento();
                    movimientoRealizado = true;
                    break;

                case 1:
                    if (jugadorActual.getInventario().getCartas().size() >= 1) {
                        menuUtilizarCarta(jugadorActual);
                    } else {
                        interfazGrafica.mostrarMensaje("No tenes cartas para usar");
                    }
                    break;

                case 2:
                    menuDeAlianza();
                    break;

                default:
                    interfazGrafica.mostrarMensaje("Accion cancelada o inválida");
                    return;
            }
        }
    }

    /**
     * Muestra el menú de opciones de alianza. 
     * Permite crear una nueva alianza o redirige al menú de miembro/administrador si ya pertenece a una.
     */
    private void menuDeAlianza() {

        if (contextoJuego.getGestorDeAlianzasActivas().tieneAlianza(jugadorActual)) {
            AlianzaRolgarII alianza = contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugadorActual);

            if (alianza.esAdministrador(jugadorActual)) {
                menuAlianzasParaAministrador(alianza);

            } else {
                menuAlianzasParaMiembro(alianza);
            }
        } else {
            int opcionElegida = interfazGrafica.preguntarConOpciones("Menu Alianzas", List.of("Crear Alianza", "Cancelar"));
            if (opcionElegida == 0) elegirNombreParaNuevaAlianza();
        }
    }

    /**
     * Muestra las opciones disponibles para un miembro regular de una alianza.
     * Incluye intercambiar cartas, salir y ver coordenadas de aliados.
     * @param alianza La alianza a la que pertenece el jugador.
     */
    public void menuAlianzasParaMiembro(AlianzaRolgarII alianza) {

        int opcionElegida = interfazGrafica.preguntarConOpciones("Menu Alianzas",
                List.of("Intercambiar Cartas Con Miembro", "Salir De Alianza", "Ver Coordenadas de aliados", "Cancelar"));

        switch(opcionElegida) {
            case 0:
            	JugadorRolgarII aliadoParaIntercambiar = elegirJugador("¿Que aliado queres intercambiar cartas?",
            			alianza.getNombreDeAliados(jugadorActual));
            	
            	if(aliadoParaIntercambiar != null) {
            		alianza.intercambiarCartasEntreAliados(jugadorActual, aliadoParaIntercambiar);
            	}
            	
                break;

            case 1:
                alianza.eliminarJugador(jugadorActual);
                break;

            case 2:
                interfazGrafica.mostrarMensaje(alianza.getCoordenadasDeAliados(jugadorActual));
                break;

            default:
                break;
        }
    }

    /**
     * Muestra las opciones disponibles para el administrador de una alianza.
     * Incluye agregar/eliminar miembros, intercambiar cartas, eliminar la alianza y ver coordenadas.
     * @param alianza La alianza que administra el jugador.
     */
    public void menuAlianzasParaAministrador(AlianzaRolgarII alianza) {

        int opcionElegida = interfazGrafica.preguntarConOpciones("Menu Alianzas",
                List.of("Agregar Miembro", "Intercambiar Cartas Con Miembro", "Eliminar Miembro", "Eliminar Alianza", "Ver Coordenadas De Aliados", "Cancelar"));

        switch(opcionElegida) {
            case 0:
            	JugadorRolgarII jugadorAAgregar = elegirJugador("¿Que jugador queres agregar a tu alianza?",
            			contextoJuego.getGestorDeAlianzasActivas().obtenerNombresDeJugadoresSinAlianza(
            					contextoJuego.getGestorDeEntidadesVivas().getJugadores()));
            	
            	if(jugadorAAgregar != null) {
            		contextoJuego.getGestorDeAlianzasActivas().agregarMiembroAAlianza(alianza, jugadorAAgregar);
            	}
            		
            	break;

            case 1:
            	JugadorRolgarII aliadoParaIntercambiar = elegirJugador("¿Que aliado queres intercambiar cartas?",
            			alianza.getNombreDeAliados(jugadorActual));
            	
            	if(aliadoParaIntercambiar != null) {
            		alianza.intercambiarCartasEntreAliados(jugadorActual, aliadoParaIntercambiar);
            	}
            	
                break;

            case 2:
            	JugadorRolgarII aliadoAEliminar = elegirJugador("¿Que miembro de tu alianza queres eliminar?",
            			alianza.getNombreDeAliados(jugadorActual));
            	
            	if(aliadoAEliminar != null) {
            		contextoJuego.getGestorDeAlianzasActivas().eliminarMiembroDeAlianza(alianza, aliadoAEliminar);
            	}
            	
            	break;

            case 3:
                contextoJuego.getGestorDeAlianzasActivas().eliminarAlianza(alianza);
                break;

            case 4:
                interfazGrafica.mostrarMensaje(alianza.getCoordenadasDeAliados(jugadorActual));
                break;

            default:
                break;
        }
    }
    
    /**
     * Muestra una lista de nombres de jugadores para que el usuario elija uno, incluyendo la opción "Salir".
     * @param mensaje El mensaje a mostrar en el prompt de la interfaz.
     * @param nombresDeJugadores La lista de nombres de jugadores disponibles para elegir. No debe ser nula.
     * @return El objeto JugadorRolgarII seleccionado, o {@code null} si el usuario elige "Salir".
     */
    private JugadorRolgarII elegirJugador(String mensaje, List<String> nombresDeJugadores) {
    	
    	ValidacionesUtiles.esDistintoDeNull(nombresDeJugadores, "Nombres");
    	ValidacionesUtiles.esDistintoDeNull(mensaje, "Mensaje");
    	
    	nombresDeJugadores.add("Salir");
    	
    	int opcionElegida = interfazGrafica.preguntarConOpciones(mensaje, nombresDeJugadores);
    	
    	if (opcionElegida == nombresDeJugadores.size() - 1) {
    		return null;
    	}
    	
    	return contextoJuego.getGestorDeEntidadesVivas().getJugadorPorNombre(nombresDeJugadores.get(opcionElegida));
    }

    /**
     * Pide al usuario el nombre para una nueva alianza y la crea.
     */
    private void elegirNombreParaNuevaAlianza() {
        String nombreAlianza = interfazGrafica.pedirString("Ingrese nombre de la alianza:");
        contextoJuego.getGestorDeAlianzasActivas().agregarNuevaAlianza(nombreAlianza, jugadorActual);
    }

    /**
     * Muestra el inventario de cartas y permite al jugador elegir y usar una.
     * @param jugador El jugador que va a utilizar la carta.
     */
    private void menuUtilizarCarta(JugadorRolgarII jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	
        interfazGrafica.mostrarCarta(jugador.getInventario().getCartas());
        
        int opcionElegida = interfazGrafica.preguntarConOpciones("Elige carta por nombre:", jugador.getInventario().getNombresDeCartas());

        Carta cartaElegida = jugador.getInventario().getCartaPorNombre(jugador.getInventario().getNombresDeCartas().get(opcionElegida));
        
        cartaElegida.aplicarEfecto(jugador, contextoJuego, interfazGrafica);
    }

    /**
     * Muestra las opciones de movimiento posibles para el jugador (incluyendo movimientos en z
     * si está sobre un Agujero o Rampa) y ejecuta el movimiento elegido.
     */
    private void menuRealizarMovimiento() {
        String movimientos;
        List<String> opciones;
        
        if (contextoJuego.getGestorMapaYCoordenadas().hayTipoTerrenoEnCoordenada(jugadorActual.getCoordenadas(), TipoTerreno.Agujero)) {
            movimientos = Movimientos.listarMovimientosConAbajo();
            opciones = Movimientos.listarTeclasConAbajo();
        } else if (contextoJuego.getGestorMapaYCoordenadas().hayTipoTerrenoEnCoordenada(jugadorActual.getCoordenadas(), TipoTerreno.Rampa)) {
            movimientos = Movimientos.listarMovimientosConArriba();
            opciones = Movimientos.listarTeclasConArriba();
        } else {
            movimientos = Movimientos.listarMovimientos();
            opciones = Movimientos.listarTeclas();
        }

        int index = interfazGrafica.preguntarConOpciones("Para donde queres moverte?\n" + movimientos, opciones);

        Movimientos movimientoElegido = Movimientos.obtenerPorTecla(opciones.get(index));
        int dx = movimientoElegido.getMovimientoEnX();
        int dy = movimientoElegido.getMovimientoEnY();
        int dz = movimientoElegido.getMovimientoEnZ();

        if (jugadorActual.getInventario().tieneActiva(CartaDobleMovimiento.class)) {
            dx *= 2; dy *= 2; dz *= 2;
        }

        Combatiente entidadEnPosicion = contextoJuego.getGestorMapaYCoordenadas().getEntidadEnCoordenadas(
                jugadorActual.getCoordenadas().getPosX() + dx,
                jugadorActual.getCoordenadas().getPosY() + dy,
                jugadorActual.getCoordenadas().getPosZ() + dz,
                contextoJuego.getGestorDeEntidadesVivas().getEntidades()
        );

        contextoJuego.getGestorMapaYCoordenadas().moverJugador(dx, dy, dz, jugadorActual);

        mostrarEstadoPostMovimiento(entidadEnPosicion);
    }

    /**
     * Muestra el estado del jugador después del movimiento, verifica si recoge una carta
     * o si inicia una batalla con una entidad en la nueva posición.
     * @param entidadEnPosicion La entidad que se encuentra en la nueva coordenada del jugador, o {@code null}.
     */
    private void mostrarEstadoPostMovimiento(Combatiente entidadEnPosicion) {

        interfazGrafica.mostrarEstadisticas(jugadorActual.getNombre(),
                jugadorActual.getFuerza(), jugadorActual.getEnergia());

        if (contextoJuego.getGestorMapaYCoordenadas().hayCartaEnCoordenadas(jugadorActual.getCoordenadas())) {
            jugadorActual.getInventario().agregarCarta(
                    GeneradorAleatorio.elegirObjetoRandomDeLista(
                            contextoJuego.getGestorMapaYCoordenadas().getPrototiposDeCartas()));
            
            contextoJuego.getGestorMapaYCoordenadas().getMapa().eliminarCasillaConCarta(jugadorActual.getCoordenadas());
        }

        if (entidadEnPosicion != null && contextoJuego.getGestorDeEntidadesVivas().puedenLuchar(
                entidadEnPosicion, jugadorActual, contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugadorActual))) {

            comenzarBatalla(entidadEnPosicion);
        }
    }

    /**
     * Permite al jugador elegir opciones durante su turno en una batalla (usar carta o llamar a un aliado).
     * @param batalla La instancia de la batalla en curso.
     * @param jugador El jugador (miembro de la batalla) que debe tomar decisiones.
     */
    public void elegirOpcionesBatalla(BatallaRolgarII batalla, JugadorRolgarII jugador) {
    	
    	ValidacionesUtiles.esDistintoDeNull(jugador, "Jugador");
    	ValidacionesUtiles.esDistintoDeNull(batalla, "Batalla");

        if(!(jugador.getInventario().getCartas().size() < 1)) {
        	
            int opcionElegida = interfazGrafica.preguntarConOpciones("Queres usar carta?", List.of("SI","NO"));
            
            if (opcionElegida == 0) {
            	menuUtilizarCarta((JugadorRolgarII)batalla.getTurnoActual());
            }
        }

        if(contextoJuego.getGestorDeAlianzasActivas().tieneAlianza(jugador) && !(batalla.getEquipoAtacante().size() > 1)) {

            AlianzaRolgarII alianza = contextoJuego.getGestorDeAlianzasActivas().getAlianzaDeJugador(jugador);

            if(alianza.getMiembros().size() > 1) {
                int index = interfazGrafica.preguntarConOpciones("Queres llamar a un aliado?", List.of("SI","NO"));
                
                if (index == 0) {
                    batalla.agregarAliado(alianza.getAliadoMasCercano(jugador));
                }
            }
        }
    }

    /**
     * Inicializa y gestiona el ciclo completo de una batalla hasta su finalización.
     * @param entidadEnPosicion La entidad (Combatiente) con la que el jugador inicia el combate.
     */
    private void comenzarBatalla(Combatiente entidadEnPosicion) {

        interfazGrafica.mostrarMensaje("Te encontraste con " + entidadEnPosicion.getNombre() + ", comienza batalla");
        
        BatallaRolgarII batalla = new BatallaRolgarII();
        batalla.iniciar(jugadorActual, entidadEnPosicion);

        while (batalla.consultarEstado() != EstadoDeBatalla.Finalizada) {
            
        	interfazGrafica.mostrarBatalla(batalla.getEquipo1(), batalla.getEquipo2());

            if(batalla.getTurnoActual() instanceof JugadorRolgarII jugador) {
                elegirOpcionesBatalla(batalla, jugador);
            }

            batalla.ejecutarTurno();
        }
        
        String mensajeGanadores = null;
        
        if(batalla.getGanadores() != null) {
        	mensajeGanadores = "Fin de la batalla, Ganadores: ";
        	
    		mensajeGanadores += batalla.getGanadores().stream() 
                    .map(Combatiente::getNombre)
                    .collect(Collectors.joining(", "));
    		
        } else {
        	mensajeGanadores = "No hay ganadores";
        }

        interfazGrafica.mostrarMensaje(mensajeGanadores);
    }

    /**
     * Devuelve el jugador al que pertenece este turno.
     * @return El objeto JugadorRolgarII actual.
     */
    public JugadorRolgarII getJugador() {
        return jugadorActual;
    }
}
