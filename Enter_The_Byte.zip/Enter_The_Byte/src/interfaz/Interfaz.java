package interfaz;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import base.Combatiente;
import estructuras.Bitmap;
import estructuras.BitmapViewerTabs;
import rolgarII.EnemigoRolgarII;
import rolgarII.PartidaDeRolgarII;
import rolgarII.cartas.Carta;
import utiles.ValidacionesUtiles;
import utiles.SistemaUtiles;

/**
 * Gestiona la carga de recursos gráficos (Bitmaps) y contiene los métodos 
 * para renderizar el tablero, mensajes, estadísticas y batallas, 
 * así como métodos para capturar la entrada del usuario.
 */
public class Interfaz {

    private final Bitmap bmpTablero;
    private final Bitmap bmpMensajes;
    private final Bitmap bmpBatalla;
    private final Font tipografia = new Font("Arial", Font.BOLD, 12);
    private BitmapViewerTabs viewer;

    /**
     * Constructor que inicializa los tres Bitmaps principales de la interfaz.
     * Carga las imágenes base desde archivos; si falla, crea Bitmaps negros de respaldo.
     */
    public Interfaz() {
    	
        Bitmap baseTablero;
        Bitmap baseMensajes;
        Bitmap baseBatalla;
        
        try {
            baseTablero = Bitmap.loadFromFile("src/Imagenes/Interfaz.bmp");
            baseMensajes = Bitmap.loadFromFile("src/Imagenes/Mensajes.bmp");
            baseBatalla = Bitmap.loadFromFile("src/Imagenes/Batalla.bmp");
            
        } catch (IOException e) {
            baseTablero = new Bitmap(1000, 800);
            baseTablero.drawRectangle(0, 0, 1000, 800, Color.BLACK);
            baseMensajes = new Bitmap(1000, 800);
            baseMensajes.drawRectangle(0, 0, 1000, 800, Color.BLACK);
            baseBatalla = new Bitmap(1000, 800);
            baseBatalla.drawRectangle(0, 0, 1000, 800, Color.BLACK);
        }

        this.bmpTablero = new Bitmap(baseTablero.getWidth(), baseTablero.getHeight());
        this.bmpTablero.pasteBitmap(baseTablero, 0, 0);

        this.bmpMensajes = new Bitmap(baseMensajes.getWidth(), baseMensajes.getHeight());
        this.bmpMensajes.pasteBitmap(baseMensajes, 0, 0);

        this.bmpBatalla = new Bitmap(baseBatalla.getWidth(), baseBatalla.getHeight());
        this.bmpBatalla.pasteBitmap(baseBatalla, 0, 0);
    }
    
    /**
     * Dibuja el estado actual del mapa en el bitmap del tablero, basándose en la matriz de estados.
     * @param matrizEstados Matriz que contiene las claves (nombres de archivos) de los gráficos a dibujar. No nula.
     */
    public synchronized void mostrarTablero(List<List<String>> matrizEstados) {
    	
    	ValidacionesUtiles.esDistintoDeNull(matrizEstados, "Matriz Estados");
    	
        getBitmapTablero().drawRectangleFill(196, 19, 575, 398, Color.BLACK);

        int casillaSize = 50;

        int startX = 230;
        int startY = 40;

    	int y = startY;

        for (int fila = 0; fila < matrizEstados.size(); fila++) {
        	int x = startX;

            for (int col = 0; col < matrizEstados.get(fila).size(); col++) {
            	 String estado = matrizEstados.get(fila).get(col);
            	
                getBitmapTablero().pasteBitmap(getArchivo(estado), x, y);

                x += casillaSize;
            }

            y += casillaSize;
        }
        
        if (viewer != null) {
        	viewer.mostrarTablero();
        }
    }

    /**
     * Muestra las estadísticas básicas (nombre, fuerza, energía) del personaje principal 
     * en la interfaz del tablero.
     * @param nombre Nombre del personaje. No nulo.
     * @param fuerza Valor de fuerza. Mayor que cero.
     * @param energia Valor de energía. Mayor o igual a cero.
     */
    public synchronized void mostrarEstadisticas(String nombre, int fuerza, int energia) {
    	
        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
        ValidacionesUtiles.validarMayorACero(fuerza, "Fuerza");
        ValidacionesUtiles.validarMayorOIgualACero(energia, "Energia");
        
        bmpTablero.drawText("PERSONAJE: " + nombre, 39, 12, tipografia, Color.WHITE, Color.BLACK);
        bmpTablero.drawText("FUERZA: " + fuerza, 405, 12, tipografia, Color.WHITE, Color.BLACK);
        bmpTablero.drawText("ENERGIA: " + energia, 505, 12, tipografia, Color.WHITE, Color.BLACK);
        
        if (viewer != null) {
        	viewer.mostrarTablero();
        }
    }
    
    /**
     * Dibuja la mano de cartas del jugador en el área designada del bitmap del tablero.
     * @param listaCartas La lista de objetos Carta a dibujar, no nola.
     */
    public synchronized void mostrarCarta(List<Carta> listaCartas) {
    	
    	ValidacionesUtiles.esDistintoDeNull(listaCartas, "Lista De Cartas");

        int x = 42, y = 124;
        getBitmapTablero().pasteBitmap(getArchivo("LimpiarInterfazCartas"), 41, 123);

        for (Carta carta : listaCartas) {
        	
            if (y == 124) {
                getBitmapTablero().pasteBitmap(getArchivo(carta.getNombre()), x, y);
                x += 30;

                if (x == 192) {
                    x = 42;
                    y += 49;
                }

            } else if (y == 173) {
                getBitmapTablero().pasteBitmap(getArchivo(carta.getNombre()), x, y);
                x += 30;
            }
        }
    }
    
    /**
     * Muestra un mensaje en el área de mensajes, gestionando el salto de línea.
     * Limpia el área antes de dibujar y espera 3 segundos después de mostrarlo.
     * @param mensaje El texto a mostrar, no nulo.
     */
    public synchronized void mostrarMensaje(String mensaje) {
    	
    	ValidacionesUtiles.esDistintoDeNull(mensaje, "Mensaje");
    	
    	final int MAX_ANCHO_LINEA = 36; 
    	
        int y = 250;
        
        Color colorFondoPergamino = Color.decode("#F5F5DC");

        getBitmapMensajes().drawRectangleFill(230, 220, 255, 308, colorFondoPergamino);

        for (int i = 0; i < mensaje.length();) {
            String listaMensaje;

            if (i + MAX_ANCHO_LINEA <= mensaje.length()) {
                listaMensaje = mensaje.substring(i, i + MAX_ANCHO_LINEA);
                
            } else {
                listaMensaje = mensaje.substring(i);
            }

            getBitmapMensajes().drawText(listaMensaje, 246, y, tipografia, Color.BLACK, colorFondoPergamino);

            i += MAX_ANCHO_LINEA; 
            y += 25;
        }
        
        if (viewer != null) {
        	viewer.mostrarMensajes();
        }
        
        SistemaUtiles.esperar(3000);
    }

    /**
     * Inicia la interfaz de batalla cargando el fondo adecuado según el número y tipo de combatientes.
     * Muestra las estadísticas de batalla y cambia la pestaña a Batalla.
     * @param equipo1 Lista de combatientes del equipo del jugador (atacantes), no nula.
     * @param equipo2 Lista de combatientes del equipo defensor (enemigos o jugadores), no nula.
     */
    public synchronized void mostrarBatalla(List<Combatiente> equipo1, List<Combatiente> equipo2) {
    	
    	ValidacionesUtiles.esDistintoDeNull(equipo1, "Equipo 1");
    	ValidacionesUtiles.esDistintoDeNull(equipo2, "Equipo 2");
    	
    	String archivo = null;
    	
        if(equipo2.size() < 2) {
        	
        	if(equipo1.size() > 1) {
        		
        		if(equipo2.get(0) instanceof EnemigoRolgarII) {
        			archivo = "Batalla2VS1Enemigo";
        			
        		} else {	
        			archivo = "Batalla2VS1";
        		}
        		
        	} else {
        		
        		if(equipo2.get(0) instanceof EnemigoRolgarII) {
        			archivo = "Batalla1VS1Enemigo";
        			
        		} else {	
        			archivo = "Batalla1VS1";
        		}
        	}
        	
        } else {
        	archivo = "Batalla2VS2";
        }
        
        getBitmapBatalla().pasteBitmap(getArchivo(archivo), 0, 0);
        
        mostrarEstadisticasBatalla(equipo1, equipo2);
        
        if (viewer != null) {
        	viewer.mostrarBatalla();
        }
        
        SistemaUtiles.esperar(3000);
    }
    
    /**
     * Dibuja las estadísticas de los combatientes de ambos equipos en el bitmap de batalla.
     * Muestra la información de los jugadores de forma horizontal.
     * @param equipo1 Lista de Combatientes del Equipo 1 (Celeste).
     * @param equipo2 Lista de Combatientes del Equipo 2 (Rojo).
     */
    private synchronized void mostrarEstadisticasBatalla(List<Combatiente> equipo1, List<Combatiente> equipo2) {
    	
    	final Color COLOR_EQUIPO_1 = Color.CYAN;
        final Color COLOR_EQUIPO_2 = Color.RED;

        final int Y_POS_STATS = 30;
        
        final int SPACING_X = 200; 

        int xPosEquipo1 = 10;

        for (int i = 0; i < equipo1.size() && i < 2; i++) {
            Combatiente c = equipo1.get(i);
            int xPos = xPosEquipo1 + (i * SPACING_X); 

            String stats = String.format("%s: %d", c.getNombre(), c.getEnergia());

            bmpBatalla.drawText(stats, xPos, Y_POS_STATS, tipografia, COLOR_EQUIPO_1, Color.BLACK);
        }
        
        int xPosEquipo2 = 450;

        for (int i = 0; i < equipo2.size() && i < 2; i++) {
            Combatiente c = equipo2.get(i);
            
            int xPos = xPosEquipo2 + (i * SPACING_X); 

            String stats = String.format("%s: %d", c.getNombre(), c.getEnergia());

            bmpBatalla.drawText(stats, xPos, Y_POS_STATS, tipografia, COLOR_EQUIPO_2, Color.BLACK);
        }
    }
    
    /**
     * Carga un Bitmap desde un archivo dentro de la carpeta "src/Imagenes/".
     * Lanza una RuntimeException si el archivo no se encuentra.
     * @param nombre El nombre base del archivo (sin la extensión .bmp). No nulo ni vacío.
     * @return El objeto Bitmap cargado.
     */
    private Bitmap getArchivo(String nombre) {
    	
    	ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre de Archivo");
    	ValidacionesUtiles.validarFalso(nombre.isBlank(), "Nombre de archivo vacio");
    	
        try {
            String nombreArchivo = "src/Imagenes/" + nombre + ".bmp";
            return Bitmap.loadFromFile(nombreArchivo);
            
        } catch (IOException e) {
                throw new RuntimeException("No se encuentra el path en la carpeta" + nombre);
        }
    }

    /**
     * Inicia la UI (ventana con pestañas). Llamar después de crear la Partida.
     */
    public void iniciarUI(PartidaDeRolgarII partida) {
    	
        SwingUtilities.invokeLater(() -> {
            viewer = new BitmapViewerTabs(bmpTablero, bmpMensajes, bmpBatalla);
            viewer.mostrarTablero();
        });
    }

    /**
     * Muestra un diálogo con opciones y devuelve el índice seleccionado (bloqueante).
     * Si el usuario cierra el diálogo devuelve -1.
     * @return
     */
    public int preguntarConOpciones(String pregunta, List<String> opciones) {

        Object[] opts = opciones.toArray(new Object[0]);
        
        int selection = JOptionPane.showOptionDialog(
                null,
                pregunta,
                "Elegí una opción",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opts,
                opts.length > 0 ? opts[0] : null
        );

        return selection;
    }

    /**
     * Pide un string al usuario (bloqueante). Devuelve null si cerró.
     * @return
     */
    public String pedirString(String mensaje) {
    	
    	ValidacionesUtiles.esDistintoDeNull(mensaje, "Mensaje");
    	
        String resp = JOptionPane.showInputDialog(null, mensaje);
        return resp;
    }

    /**
     * Pide un entero entre min y max (bloqueante). Reintenta hasta recibir un entero válido o cancelar (devuelve -1).
     * @return
     */
    public int pedirEntero(String mensaje, int min, int max) {
    	
        while (true) {
            String s = JOptionPane.showInputDialog(null, mensaje);
            
            if (s == null) {
            	return -1;
            }
            
            try {
                int v = Integer.parseInt(s);
                if (v < min || v > max) {
                    JOptionPane.showMessageDialog(null, "Valor fuera de rango. Ingresá entre " + min + " y " + max);
                    continue;
                }
                
                return v;
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "No es un número válido. Volvé a intentar.");
            }
        }
    }

    /**
     * Devuelve el bitmap tablero.
     * @return
     */
    public Bitmap getBitmapTablero() {
    	return bmpTablero;
    }
    
    /**
     * Devuelve el bitmap mensajes.
     * @return
     */
    public Bitmap getBitmapMensajes() {
    	return bmpMensajes;
    }
    
    /**
     * Devuelve el bitmap batalla.
     * @return
     */
    public Bitmap getBitmapBatalla() {
    	return bmpBatalla;
    }
}
