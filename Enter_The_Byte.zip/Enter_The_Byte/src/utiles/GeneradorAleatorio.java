package utiles;

import java.util.Random;
import java.util.List;

/**
 * Generador Aleatorio
 */
public class GeneradorAleatorio {
    
    private static final Random random = new Random();

    /**
     * Genera un numero aleatorio entre 0 y un maximo dado.
     * @param maximo: mayor a 0.
     */
    public static int generarNumeroRandom(int maximo) {
    	
    	ValidacionesUtiles.validarMayorACero(maximo, "Maximo");
        
        int numero = random.nextInt(maximo);
        return numero;
    }
    
    /**
     * Elige un elemento random de una lista y lo devuelve.
     * @param <T>: clase del objeto
     * @param lista: lista no nula
     * @return
     */
    public static <T> T elegirObjetoRandomDeLista(List<T> lista) {
    	
    	ValidacionesUtiles.esDistintoDeNull(lista, "Lista");
    	
    	int numero = generarNumeroRandom(lista.size());
    	return lista.get(numero);
    }
}
