package main;

import rolgarII.RolgarII;

public class Main {
	public static void main(String[] args) {
		
		RolgarII juego = new RolgarII();
		
		juego.iniciarPartida();
		
		juego.jugarPartida();
		
		juego.finalizarPartida();
	}
}
