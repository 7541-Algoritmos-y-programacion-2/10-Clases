package enums;

/**
 * Define los niveles de dificultad y sus parámetros asociados.
 * (Cant. Enemigos, Daño Base, Ancho, Alto, Profundo del Tablero)
 */
public enum Dificultad {

    FACIL(5, 10, 8, 50),
    NORMAL(8, 15, 10, 40),
    DIFICIL(12, 20, 12, 30);

    private final int cantidadEnemigos;
    private final int dañoBaseEnemigo;
    private final int dimensionesTablero;
    private final int cantidadDeCartasEnMapa;

    /**
     * Constructor para los niveles de dificultad.
     */
    private Dificultad(int cantidadEnemigos, int dañoBaseEnemigo, int dimensionesTablero, int cantidadDeCartasEnMapa) {

        this.cantidadEnemigos = cantidadEnemigos;
        this.dañoBaseEnemigo = dañoBaseEnemigo;
        this.dimensionesTablero = dimensionesTablero;
        this.cantidadDeCartasEnMapa = cantidadDeCartasEnMapa;
    }
    
    /**
     * Devuelve la cantidad de cartas en el mapa.
     * @return
     */
    public int getCantidadDeCartasEnMapa() {
		return cantidadDeCartasEnMapa;
	}

	/**
     * Devuelve la cantidad de enemigos de la dificultad.
     * @return
     */
    public int getCantidadEnemigos() {
        return cantidadEnemigos;
    }

    /**
     * Devuelve el daño base de los enemigos en la dificultad.
     * @return
     */
    public int getDañoBaseEnemigo() {
        return dañoBaseEnemigo;
    }

    /**
     * Devuelve las dimensiones del tablero.
     * @return
     */
    public int getDimensionesTablero() {
        return dimensionesTablero;
    }
}

