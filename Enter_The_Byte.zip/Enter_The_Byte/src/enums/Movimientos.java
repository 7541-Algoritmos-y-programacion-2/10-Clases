package enums;

import java.util.List;

import utiles.ValidacionesUtiles;
import estructuras.ListaSimplementeEnlazada;

/**
 * Define las distintas formas en las que se podria mover un objeto dentro del tablero y los valores de sus movimientos,
 * sus direcciones y la tecla asignada ).
 */
public enum Movimientos {
	
    Derecha ("Derecha (X + 1)", "D", 1, 0, 0),
    Izquierda ("Izquierda (X - 1)", "A", -1, 0, 0),
    Adelante ("Adelante (Y + 1)", "S", 0, 1, 0),
    Atras ("Atras (Y - 1)", "W", 0, -1, 0), 
    DerechaAdelante ("Derecha Adelante (X + 1, Y + 1)", "Q", 1, 1, 0),
    IzquierdaAdelante ("Izquierda Adelante (X - 1, Y + 1)", "E", -1, 1, 0),
    DerechaAtras ("Derecha Atras (X + 1, Y - 1)", "R", 1, -1, 0),
    IzquierdaAtras ("Izquierda Atras (X - 1, Y - 1)", "T", -1, -1, 0), 
    Abajo ("Abajo (Z - 1)", "C", 0, 0 ,-1),
    Arriba ("Arriba (Z + 1)", "V", 0, 0, 1);
	
	private final String mensaje;
	private final String tecla;
	private final int movimientoEnX;
	private final int movimientoEnY;
	private final int movimientoEnZ;

    /** Constructor para los movimientos
     * @param mensaje debe ser un String valido
     * @param tecla debe ser una tecla valida para usar.
     */
	private Movimientos(String mensaje, String tecla, int movimientoEnX, int movimientoEnY, int movimientoEnZ) {
		
		this.mensaje = mensaje;
		this.tecla = tecla;
		this.movimientoEnX = movimientoEnX;
		this.movimientoEnY = movimientoEnY;
		this.movimientoEnZ = movimientoEnZ;
		
	}

    /**
     * @return Devuelve el mensaje que contiene el movimiento.
     */
	public String getMensaje() {

		return mensaje;
	}

    /**
     * @return Devuelve la tecla asignada a un movimiento.
     */
	public String getTecla() {

		return tecla;
	}

    /**
     * @return Devuelve la cantidad de movimientos que se hacen en la direccion X asignada a un movimiento
     */
    public int getMovimientoEnX() {
        return movimientoEnX;
    }

    /**
     * @return Devuelve la cantidad de movimientos que se hacen en la direccion Y asignada a un movimiento
     */
	public int getMovimientoEnY() {
		return movimientoEnY;
	}

    /**
     * @return Devuelve la cantidad de movimientos que se hacen en la direccion Z asignada a un movimiento
     */
	public int getMovimientoEnZ() {
		return movimientoEnZ;
	}

    /**
     * Compara las teclas asignadas a cada movimiento y si alguno es igual a el parametro se lo devuelve.
     * @param tecla La tecla debe estar asignada a un movimiento dentro del tablero.
     * @return el movimiento relacionado a la tecla.
     */
	public static Movimientos obtenerPorTecla(String tecla) {
		
		ValidacionesUtiles.esDistintoDeNull(tecla, "Tecla");
        
        for (Movimientos movimiento : Movimientos.values()) {
            if (movimiento.getTecla().equalsIgnoreCase(tecla)) {
                return movimiento;
            }
        }
        
        return null; 
    }
	
	/**
	 * Lista las teclas, menos arriba y abajo.
	 * @return
	 */
	 public static List<String> listarTeclas() {
		 
		 List<String> teclas = new ListaSimplementeEnlazada<String>();
		 
		 for (Movimientos movimiento : values()) {
			 
			 if(!movimiento.equals(Movimientos.Arriba) && !movimiento.equals(Movimientos.Abajo)) {
				 teclas.add(movimiento.getTecla());
			 }
		 }
		 
		 return teclas;
	 }
	 
		/**
		 * Lista las teclas, menos abajo.
		 * @return
		 */
	 public static List<String> listarTeclasConArriba() {
		 
		 List<String> teclas = new ListaSimplementeEnlazada<String>();
		 
		 for (Movimientos movimiento : values()) {
			 
			 if(!movimiento.equals(Movimientos.Abajo)) {
				 teclas.add(movimiento.getTecla());
			 }
		 }
		 
		 return teclas;
	 }
	 
		/**
		 * Lista las teclas, menos arriba.
		 * @return
		 */
	 public static List<String> listarTeclasConAbajo() {
		 
		 List<String> teclas = new ListaSimplementeEnlazada<String>();
		 
		 for (Movimientos movimiento : values()) {
			 
			 if(!movimiento.equals(Movimientos.Arriba)) {
				 teclas.add(movimiento.getTecla());
			 }
		 }
		 
		 return teclas;
	 }


    /**
     * @return Devuelve un String donde se anidan todos las teclas de movimentos a sus respectivos mensajes,
     * menos arriba y abajo.
     */
    public static String listarMovimientos() {
    	
        String listaMovimientos = "";
        
        for (Movimientos movimiento : values()) {
        	
        	if(!movimiento.equals(Movimientos.Arriba) && !movimiento.equals(Movimientos.Abajo)) {
        	
        		listaMovimientos += movimiento.getTecla();
            	listaMovimientos += ": ";
            	listaMovimientos += movimiento.getMensaje();
            	listaMovimientos += "\n";
        	}
        }
        
        return listaMovimientos;
    }
    
    /**
     * @return Devuelve un String donde se anidan todos las teclas de movimentos a sus respectivos mensajes,
     * menos abajo.
     */
    public static String listarMovimientosConArriba() {
    	
        String listaMovimientos = "";
        
        for (Movimientos movimiento : values()) {
        	
        	if(!movimiento.equals(Movimientos.Abajo)) {
            	
        		listaMovimientos += movimiento.getTecla();
            	listaMovimientos += ": ";
            	listaMovimientos += movimiento.getMensaje();
            	listaMovimientos += "\n";
        	}
        }
        
        return listaMovimientos;
    }
    
    /**
     * @return Devuelve un String donde se anidan todos las teclas de movimentos a sus respectivos mensajes,
     * menos arriba.
     */
    public static String listarMovimientosConAbajo() {
    	
        String listaMovimientos = "";
        
        for (Movimientos movimiento : values()) {
        	
        	if(!movimiento.equals(Movimientos.Arriba)) {
            	
        		listaMovimientos += movimiento.getTecla();
            	listaMovimientos += ": ";
            	listaMovimientos += movimiento.getMensaje();
            	listaMovimientos += "\n";
        	}
        }
        
        return listaMovimientos;
    }
}
