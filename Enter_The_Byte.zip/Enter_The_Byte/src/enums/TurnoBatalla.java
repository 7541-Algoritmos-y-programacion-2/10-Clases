package enums;

/**
 * Los turnos en la batalla.
 */
public enum TurnoBatalla {
	
	TurnoEquipo1,
	TurnoEquipo2;
}
