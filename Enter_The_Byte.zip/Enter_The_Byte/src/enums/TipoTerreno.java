package enums;

import utiles.ValidacionesUtiles;

/**
 * Enum Tipo De Terreno
 */
public enum TipoTerreno {
	
	Roca("R", false),
	Vacio(".", true),
	Rampa("/", true),
	Agua("~", false),
	Agujero("O", true);
	
	private final String simbolo;
	private final boolean esTransitable;
	
	/**
	 * Constructor para los tipos de terrenos
	 * @param simbolo
	 * @param esTransitable
	 */
	private TipoTerreno(String simbolo, boolean esTransitable) {
		this.simbolo = simbolo;
		this.esTransitable = esTransitable;
	}

	/**
	 * Devuelve el simbolo del terreno
	 * @return
	 */
	public String getSimbolo() {
		return simbolo;
	}

	/**
	 * Devuelve si es transitable el terreno
	 * @return
	 */
	public boolean getEsTransitable() {
		return esTransitable;
	}
	
	/**
	 * Retorna el tipo terreno asociado a un simbolo.
	 * @param simbolo: no nulo
	 * @return
	 */
    public static TipoTerreno fromSimbolo(String simbolo) {
    	
    	ValidacionesUtiles.esDistintoDeNull(simbolo, "Simbolo");
    	
        for (TipoTerreno tipoTerreno : TipoTerreno.values()) {
        	
            if (tipoTerreno.simbolo.equals(simbolo)) {
                return tipoTerreno;
            }
        }
        
        throw new IllegalArgumentException("Símbolo de terreno inválido: " + simbolo);
    }
}
