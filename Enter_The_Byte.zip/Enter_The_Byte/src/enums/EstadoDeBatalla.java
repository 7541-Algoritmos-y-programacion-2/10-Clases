package enums;

/**
 * Define los posibles estados de una batalla.
 */
public enum EstadoDeBatalla {

    Iniciando,
    Peleando,
    Finalizada
}
