package ar.uba.fi.cb100.semana13.miercoles.arboles;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class ArbolBinarioDeBusqueda<T extends Comparable<T>> {
	
    private NodoDeArbol<T> raiz = null;

    public ArbolBinarioDeBusqueda() {
        raiz = null;
    }

    // Método para insertar un nuevo nodo en el árbol
    public void insertar(T valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    private NodoDeArbol<T> insertarRecursivo(NodoDeArbol<T> nodo, T valor) {
        if (nodo == null) {
            return new NodoDeArbol<T>(valor);
        }

        if (valor.compareTo(nodo.getValor()) == -1) {
            nodo.setIzquierdo( insertarRecursivo(nodo.getIzquierdo(), valor) );
        } else if (valor.compareTo(nodo.getValor()) == 1) {
            nodo.setDerecho( insertarRecursivo(nodo.getDerecho(), valor));
        }

        return nodo;
    }

    // Método para buscar un valor en el árbol
    public boolean buscar(T valor) {
        return buscarRecursivo(raiz, valor);
    }

    private boolean buscarRecursivo(NodoDeArbol<T> nodo, T valor) {
        if (nodo == null) {
            return false;
        }

        if (valor.equals(nodo.getValor())) {
            return true;
        }

        
        return valor.compareTo(nodo.getValor()) == -1
                ? buscarRecursivo(nodo.getIzquierdo(), valor)
                : buscarRecursivo(nodo.getDerecho(), valor);
    }

    public boolean estaVacio() {
    	return this.raiz == null;
    }
    
    //FIXME: agregar el eliminar en la guia
    
    // Recorridos en el árbol

    // Inorden (izquierda, raíz, derecha)
    public void inorden() {
        inordenRecursivo(raiz);
    }

    private Lista<T> inordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            inordenRecursivo(nodo.getIzquierdo());
            //FIXME: devolver como lista el recorrido. Tarea
            System.out.print(nodo.getValor() + " ");
            inordenRecursivo(nodo.getDerecho());
        }
        return null;
    }

    // Preorden (raíz, izquierda, derecha)
    public void preorden() {
        preordenRecursivo(raiz);
    }

    private void preordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            System.out.print(nodo.getValor() + " ");
            preordenRecursivo(nodo.getIzquierdo());
            preordenRecursivo(nodo.getDerecho());
        }
    }

    // Postorden (izquierda, derecha, raíz)
    public void postorden() {
        postordenRecursivo(raiz);
    }

    private void postordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            postordenRecursivo(nodo.getIzquierdo());
            postordenRecursivo(nodo.getDerecho());
            System.out.print(nodo.getValor() + " ");
        }
    }

	protected NodoDeArbol<T> getRaiz() {
		return raiz;
	}

	protected void setRaiz(NodoDeArbol<T> raiz) {
		this.raiz = raiz;
	}
    
    
}