package ar.uba.fi.cb100.semana12.jueves.parcial2013;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

/**
 * 
 * Tips:
 * 1 - Estrategia: hipotesis, simplificar, complejizar 
 * 2 - solucionar el problema
 * 3 - Pre y post
 * 4 - validar
 * 5 - modularizar (partir el codigo en partes utiles, la estructura es while / if )
 * 6 - cumplir con TDA (conjunto completo de operaciones)
 */
public class AuditorDeConcursos {

	/*  
	 * pre: la lista no puede ser nula
	 * post:  busca  en  concursosAuditados  aquellos  Concursos  que  tengan  entre  sus  premiados  algún  nombre  que  no
	*	corresponda  con  el  de  un  Participante  asociado  al  Concurso.
	*	Devuelve  una  nueva  Lista  con  todos  los  Concursos  en  esta  condición.  */
	public Lista<Concurso> buscarConcursosIrregulares(Lista<Concurso> concursosAuditados) throws Exception {
		if (concursosAuditados == null) {
			throw new Exception("La lista no puede ser nula");
		}
		Lista<Concurso> resultado = new Lista<Concurso>();
		concursosAuditados.iniciarCursor();		
		while (concursosAuditados.avanzarCursor()) {
			Concurso concurso = concursosAuditados.obtenerCursor();
			if (validarConcursoIrregular(concurso)) {
				resultado.agregar(concurso);
			}
		}
		
		//ejemplo
		//concurso.getParticipante().contieneS3( new Participante("Gustavo"));
		//concurso.getParticipante().contieneS3( "Gustavo");
		//concurso.getParticipante().contieneS3( concurso.getParticipante().obtener(1));
		//concurso.getParticipante().contieneS3( concurso );
		return resultado;
	}

	public boolean validarConcursoIrregular(Concurso concurso) throws Exception {
		if (concurso == null) {
			throw new Exception("");
		}
		concurso.getPremiados().iniciarCursor();
		while(concurso.getPremiados().avanzarCursor()) {
			String premiado = concurso.getPremiados().obtenerCursor();
			//Solucion 1:
			if (!contiene(concurso.getParticipante(), premiado)) {
				return true;
			}
						
			//Solucion 2:
			if (!concurso.getParticipante().contieneS2(premiado)) {
				return true;
			}
			
			//Solucion 3: esta es la correcta
			if (!concurso.getParticipante().contieneS3(premiado)) {
				return true;
			}
			
			//Solucion 4:
			if (!concurso.getParticipante().contieneS4(premiado)) {
				return true;
			}
		}
		return false;
	}
	
	//Solucion 1
	//pre 
	public boolean contiene(Lista<Participante> participantes, String nombre) {
		//Validar
		participantes.iniciarCursor();
		while (participantes.avanzarCursor()) {
			Participante participante = participantes.obtenerCursor();
			if (participante.getNombre().equals(nombre)) {
				return true;
			}
		}
		return false;
	}
}

