package ar.uba.fi.cb100.semana14.miercoles.nahuel.v2;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class AdministradorDeClubSocial2 {
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los socios, uno por familia, cuyo grupo familiar no tubo deudas.
	 */
	public static Lista<Socio> buscarSociosParaDescuento(Lista<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		Lista<String> familiasDeudoras = getFamiliasDeudoras(socios);
		Lista<Socio> resultado = new Lista<Socio>();


		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.getCursor();
			if ((!familiasDeudoras.contiene( socio.getGrupoFamiliar())) &&
				 (!contieneGrupoFamiliar( resultado, socio))) {
				resultado.agregar(socio);
			}
		}
		return resultado;
	}
	
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los apellidos de las familias de las 
	 * cuales por lo menos 1 integrante tubo deuda.
	 */
	public static Lista<String> getFamiliasDeudoras(Lista<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		Lista<String> resultado = new Lista<String>();
		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.getCursor();
			if((socio.tuvoDeuda()) && (!resultado.contiene(socio.getGrupoFamiliar()))) {
				resultado.agregar(socio.getGrupoFamiliar());
			}
		}
		return resultado;
	}
	/**
	 * pre:
	 * @param sociosConDescuento no puede ser nula
	 * @param socio no puede ser nulo
	 * @return
	 * @throws Exception
	 * post: devuelve true si el socio ya tiene un familiar agregado en la lista y false en caso contrario
	 */
	public static boolean contieneGrupoFamiliar(Lista<Socio> sociosConDescuento, Socio socio) throws Exception{
		if((sociosConDescuento == null) || (socio == null)) {
			throw new Exception("resultado y socio no pueden ser nulos");
		}
		sociosConDescuento.iniciarCursor();
		while(sociosConDescuento.avanzarCursor()) {
			if(sociosConDescuento.getCursor().getGrupoFamiliar() == socio.getGrupoFamiliar()) {
				return true;
			}
		}
		return false;
	}
	
}
