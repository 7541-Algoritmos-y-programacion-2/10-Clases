package ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.v2;

import ar.uba.fi.cb100.semana07.miercoles.Lista;
import ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.Articulo;

public class Blog {
    
    private Lista<Articulo> articulos;
    
    public Lista<Articulo> getArticulos() {
        return articulos;
    }
    
    /**
     * busca artículos que contengan alguna de las palabras clave proporcionadas
     * 
     * @param palabrasClaves lista de palabras clave para buscar
     * @return lista de artículos que contienen alguna de las palabras clave
     * @throws Exception si la lista es nula
     * 
     * pre: palabrasClaves no debe ser null
     * pos: devuelve una lista de artículos que contienen alguna de las palabras clave
     * 		y ninguna palabra excluida
     */
    public Lista<Articulo> buscarArticulos(Lista<String> palabrasClaves) throws Exception {
        
        if(palabrasClaves == null) {
            throw new Exception("La lista esta vacia");
        } 
        
        Lista<Articulo> resultado = new Lista<Articulo>();    
        
        Lista<Articulo> articulos = this.getArticulos();
        
        articulos.iniciarCursor();
        
        while(articulos.avanzarCursor()) {
            Articulo articuloARevisar = articulos.obtenerCursor();
            
            if (verificarPalabrasExcluidas(palabrasClaves, articuloARevisar)) {
            	continue;   	
            }
            
            if (verificarArticulo(palabrasClaves, articuloARevisar)) {
            	resultado.agregar(articuloARevisar);
            }  
            
//            if (!contieneAlgunaPalabra(articuloARevisar.getPalabrasExcluidas(), palabrasClaves)) &&
//                contieneTodas(articuloARevisar.getTitulo() + " " + articuloARevisar.getTexto(), palabrasClaves)) {
//                	
//            }
        
        }        
        return resultado;
    }
  
    /**
     * verifica si un artículo contiene alguna palabra excluida de la lista proporcionada
     *
     * @param palabrasClaves lista de palabras clave a buscar
     * @param articulo artículo a revisar
     * @return true si el artículo contiene alguna palabra excluida, false en caso contrario
     * @throws Exception si el artículo es nulo
     *
     * pre: palabrasClaves no debe ser null, articulo no debe ser null
     * pos: devuelve true si el artículo contiene alguna palabra excluida, false en caso contrario
     */
	private boolean verificarPalabrasExcluidas(Lista<String> palabrasClaves, Articulo articulo) throws Exception {
		
		if (articulo == null) {
			throw new Exception("No hay articulo");
		}
    	
		Lista<String> palabrasExcluidas = articulo.getPalabrasExcluidas();
		
		palabrasExcluidas.iniciarCursor();
		
		while (palabrasExcluidas.avanzarCursor()) {
			
			String palabraExcluida = palabrasExcluidas.obtenerCursor();
			
			if (RevisarArticuloAExcluir(palabraExcluida, palabrasClaves)) {
				return true;
			}
		}
    	return false;
    	
    }
    
    /**
     * revisa si una palabra excluida se encuentra dentro de la lista de palabras clave
     *
     * @param palabraExcluida palabra a buscar en la lista de claves
     * @param palabrasClaves lista de palabras clave
     * @return true si la palabra excluida se encuentra en la lista, false en caso contrario
     * @throws Exception si la lista de palabras clave es nula
     *
     * pre: palabrasClaves no debe ser null
     * pos: devuelve true si la palabra excluida se encuentra en la lista, false en caso contrario
     */
    private boolean RevisarArticuloAExcluir(String palabraExcluida, Lista<String> palabrasClaves) throws Exception {
		
    	if (palabrasClaves == null) {
    		throw new Exception("No hay una lista valida");
    	}
    	
    	palabrasClaves.iniciarCursor();
    	
    	while (palabrasClaves.avanzarCursor()) {
    		String palabraClave = palabrasClaves.obtenerCursor();
    		
    		if (palabraClave.equals(palabraExcluida)) {
    			return true;
    		}
    	}
    	return false;
		
	}
    
    /**
     * verifica si un artículo contiene alguna de las palabras clave proporcionadas
     *
     * @param palabrasClaves lista de palabras clave a buscar
     * @param articuloARevisar artículo a revisar
     * @return true si el artículo contiene alguna de las palabras clave, false en caso contrario
     * @throws Exception si la lista de palabras clave o el artículo son nulos
     *
     * pre: palabrasClaves no debe ser null, articuloARevisar no debe ser null
     * pos: devuelve true si el artículo contiene alguna de las palabras clave, false en caso contrario
     */
	private boolean verificarArticulo(Lista<String> palabrasClaves, Articulo articuloARevisar) throws Exception {
		
		if (palabrasClaves == null) {
			throw new Exception("No hay palabras a revisar");
		}
		
		if (articuloARevisar == null) {
			throw new Exception("No hay articulo a revisar");
		}
    	palabrasClaves.iniciarCursor();
    	
    	while (palabrasClaves.avanzarCursor()) {
    		
    		String palabra = palabrasClaves.obtenerCursor();
    		
            if ((articuloARevisar.getTitulo().indexOf(palabra) > 0) || 
                    articuloARevisar.getTexto().indexOf(palabra) > 0) {
                   return true;
            }
    	}
		return false;
	}             
}