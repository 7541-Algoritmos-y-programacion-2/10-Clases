package ar.uba.fi.cb100.semana14.miercoles.nahuel.v2;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class AdministradorDeClubSocial1 {
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los socios, uno por familia, cuyo grupo familiar no tubo deudas.
	 */
	public static Lista<Socio> buscarSociosParaDescuento(Lista<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		Lista<String> familiasDeudoras = getFamiliasDeudoras(socios);
		Lista<String> familiasEnResultado = new Lista<String>();
		Lista<Socio> resultado = new Lista<Socio>();


		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.obtenerCursor();
			if ((!familiasDeudoras.contiene( socio.getGrupoFamiliar())) &&
		            (!familiasEnResultado.contiene( socio.getGrupoFamiliar()))) {
				familiasEnResultado.agregar(socio.getGrupoFamiliar());
				resultado.agregar(socio);
			}
		}
		return resultado;
	}
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los apellidos de las familias de las 
	 * cuales por lo menos 1 integrante tubo deuda.
	 */
	public static Lista<String> getFamiliasDeudoras(Lista<Socio> socios) throws Exception{
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		Lista<String> resultado = new Lista<String>();
		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.getCursor();
			if((socio.tuvoDeuda()) && (!resultado.contiene(socio.getGrupoFamiliar()))) {
				resultado.agregar(socio.getGrupoFamiliar());
			}
		}
		return resultado;
	}
	
}
