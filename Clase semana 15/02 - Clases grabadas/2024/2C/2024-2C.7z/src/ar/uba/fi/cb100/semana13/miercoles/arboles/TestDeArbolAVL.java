package ar.uba.fi.cb100.semana13.miercoles.arboles;

public class TestDeArbolAVL {

    public static void main(String[] args) {
        ArbolAVL<Persona> arbolAVL = new ArbolAVL<Persona>();

        // Insertar nodos en el árbol AVL
        arbolAVL.insertar( new Persona(10));
        arbolAVL.insertar( new Persona(20));
        arbolAVL.insertar( new Persona(30));
        arbolAVL.insertar( new Persona(40));
        arbolAVL.insertar( new Persona(50));
        arbolAVL.insertar( new Persona(25));

        // Recorridos
        System.out.print("Inorden: ");
        arbolAVL.inorden();
        System.out.println();

        System.out.print("Preorden: ");
        arbolAVL.preorden();
        System.out.println();

        System.out.print("Postorden: ");
        arbolAVL.postorden();
        System.out.println();
    }
}
