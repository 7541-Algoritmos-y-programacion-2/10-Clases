package ar.uba.fi.cb100.semana08.jueves.tarea.franco;

public enum Direccion {
	ARRIBA, 
	ABAJO, 
	IZQUIERDA, 
	DERECHA,
	IZQUIERDA_ARRIBA,
	IZQUIERDA_ABAJO,
	DERECHA_ARRIBA,
	DERECHA_ABAJO	
}
