package ar.uba.fi.cb100.semana15.miercoles.lucas.v1;

public class Turno {

	public int obtenerHoraDesde() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int obtenerHoraHasta() {
		// TODO Auto-generated method stub
		return 0;
	}

}
