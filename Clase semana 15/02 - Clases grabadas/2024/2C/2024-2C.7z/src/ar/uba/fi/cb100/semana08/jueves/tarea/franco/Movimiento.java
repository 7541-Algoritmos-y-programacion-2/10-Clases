package ar.uba.fi.cb100.semana08.jueves.tarea.franco;

public enum Movimiento {
	ARRIBA, 
	ABAJO, 
	IZQUIERDA, 
	DERECHA
}
