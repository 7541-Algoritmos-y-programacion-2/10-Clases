package test.ar.uba.fi.cb100.c2025_02.estructuras.grafos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.grafos.Arista;
import ar.uba.fi.cb100.c2025_02.material.estructuras.grafos.Grafo;

// Asumiendo que las clases Vertice y Arista son clases internas o que existen en el mismo paquete.
// Para este ejemplo, usaremos T=String y U=Integer.
public class GrafoTest {

    // Helper para crear un Grafo No Dirigido con pesos Integer
    private Grafo<String, Integer> crearGrafoNoDirigido(String cadenaVertices, String cadenaAristas) {
        Grafo<String, Integer> g = Grafo.build(cadenaVertices, cadenaAristas);
        // Agregar aristas de regreso para simular un grafo no dirigido
        // Esto es necesario para los métodos que asumen NO DIRIGIDO (Puntos de Articulación)
        for (String v : Arrays.asList("A", "B", "C", "D", "E")) { // Ejemplo de vértices comunes
            if (g.existeVertice(v)) {
                // Iteramos sobre las aristas ya creadas y creamos la inversa
                List<Arista<String, Integer>> adyacencias = new ArrayList<>(g.getVertice(v).getAdyacencias());
                for (Arista<String, Integer> arista : adyacencias) {
                    String destino = arista.getDestino().getValor();
                    Integer peso = arista.getPeso();
                    if (g.existeVertice(destino) && !v.equals(destino)) {
                        // Evita agregar el mismo arco dos veces si ya existe, pero la implementación
                        // de agregarArista() debería manejar esto o simplemente lo agregamos.
                        // Para fines de prueba simple, simplemente agregamos el reverso.
                        try {
                            // Se debe asegurar que agregarArista() no cree aristas duplicadas si ya existe.
                            // Aquí asumimos que la implementación del Vertice lo permite, pero solo agregamos si el reverso NO existe.
                            // Esto puede ser complejo sin la implementación completa de Arista/Vertice.
                            // Simplificaremos: solo agregaremos la arista de vuelta si no existe ya para evitar loops infinitos.
                            g.agregarArista(destino, v, peso);
                        } catch (Exception ignored) {
                            // Ignoramos si falla por no existir el vertice, lo cual no deberia pasar si build() funcionó
                        }
                    }
                }
            }
        }
        return g;
    }


    // ===========================================
    // 1. Tests de Inicialización y Estructura
    // ===========================================

    @Test
    void testBuild_Vacio() {
        Grafo<String, Integer> g = Grafo.build("V = {}", "A = {}");
        assertTrue(g.getVertices().isEmpty());
    }

    @Test
    void testBuild_Simple() {
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", "A = {(\"A\",\"B\",10)}");
        assertEquals(3, g.getVertices().size());
        assertTrue(g.existeVertice("A"));
        assertTrue(g.existeVertice("B"));
        assertFalse(g.getAdyacentes("A").isEmpty());
        assertEquals(10, g.getAdyacentes("A").get(0).getPeso());
    }

    @Test
    void testGetVertice_NoExistente() {
        Grafo<String, Integer> g = Grafo.build("V = {\"A\"}", "A = {}");
        assertThrows(NoSuchElementException.class, () -> g.getVertice("Z"));
    }
    
    // ===========================================
    // 2. Tests de Recorridos (BFS, DFS)
    // ===========================================

    // Grafo: A -> B, A -> C, B -> D, C -> E
    private Grafo<String, Integer> crearGrafoRecorrido() {
        return Grafo.build("V = {\"A\", \"B\", \"C\", \"D\", \"E\"}", 
                           "A = {(\"A\",\"B\",1), (\"A\",\"C\",1), (\"B\",\"D\",1), (\"C\",\"E\",1)}");
    }

    @Test
    void testRecorridoAnchura_Normal() {
        Grafo<String, Integer> g = crearGrafoRecorrido();
        List<String> bfs = g.recorridoAnchura("A");
        // El orden exacto de BFS no es único (B y C son adyacentes a A)
        assertEquals(5, bfs.size());
        assertTrue(bfs.containsAll(Arrays.asList("A", "B", "C", "D", "E")));
        assertEquals("A", bfs.get(0));
        // Verificación de nivel: A (0) -> B/C (1) -> D/E (2)
        // El orden de B y C puede variar, pero D y E deben ir después.
        int idxD = bfs.indexOf("D");
        int idxE = bfs.indexOf("E");
        assertTrue(idxD > bfs.indexOf("B") && idxD > bfs.indexOf("C"));
        assertTrue(idxE > bfs.indexOf("B") && idxE > bfs.indexOf("C"));
    }

    @Test
    void testRecorridoProfundidad_Normal() {
        Grafo<String, Integer> g = crearGrafoRecorrido();
        List<String> dfs = g.recorridoProfundidad("A");
        // El orden exacto de DFS no es único, pero debe seguir un camino profundo
        assertEquals(5, dfs.size());
        assertTrue(dfs.containsAll(Arrays.asList("A", "B", "C", "D", "E")));
        assertEquals("A", dfs.get(0));
        // Si la implementación de getAdyacentes devuelve en orden B, C:
        // El camino esperado es: A -> B -> D. Luego vuelve a A -> C -> E.
        // O: A, B, D, C, E
        // O: A, C, E, B, D
        
        // Verificamos propiedades: el hijo debe aparecer inmediatamente después de su padre.
        int idxA = dfs.indexOf("A");
        int idxD = dfs.indexOf("D");
        int idxB = dfs.indexOf("B");
        assertTrue(idxD > idxB); // D debe ir después de B
        // En este grafo simple: A, (B, D) o A, (C, E) deben ir juntos en profundidad.
    }
    
    // ===========================================
    // 3. Tests de Aciclidad y Orden Topológico
    // ===========================================

    @Test
    void testTieneCiclo_SinCiclo() {
        Grafo<String, Integer> g = crearGrafoRecorrido(); // A -> B -> D
        assertFalse(g.tieneCiclo());
    }

    @Test
    void testTieneCiclo_ConCiclo() {
        // Grafo: A -> B, B -> C, C -> A (Ciclo)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1), (\"C\",\"A\",1)}");
        assertTrue(g.tieneCiclo());
    }
    
    @Test
    void testTieneCiclo_ConAristaCruzadaSinCiclo() {
        // Grafo: A -> B, A -> C, B -> D, C -> D (No es ciclo)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"A\",\"C\",1), (\"B\",\"D\",1), (\"C\",\"D\",1)}");
        assertFalse(g.tieneCiclo());
    }
    
    @Test
    void testRecorridoTopologicoDFS_Normal() {
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\", \"E\"}", 
                                               "A = {(\"A\",\"C\",1), (\"B\",\"C\",1), (\"B\",\"D\",1), (\"C\",\"E\",1), (\"D\",\"E\",1)}");
        List<String> topo = g.recorridoTopologicoDFS();
        // Criterios: A y B antes que C. C y D antes que E.
        assertEquals(5, topo.size());
        assertTrue(topo.indexOf("A") < topo.indexOf("C"));
        assertTrue(topo.indexOf("B") < topo.indexOf("C"));
        assertTrue(topo.indexOf("C") < topo.indexOf("E"));
        assertTrue(topo.indexOf("D") < topo.indexOf("E"));
    }

    @Test
    void testRecorridoTopologicoBFS_Normal() {
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\", \"E\"}", 
                                               "A = {(\"A\",\"C\",1), (\"B\",\"C\",1), (\"B\",\"D\",1), (\"C\",\"E\",1), (\"D\",\"E\",1)}");
        List<String> topo = g.recorridoTopologicoBFS();
        // Criterios: A y B tienen in-degree 0, deben ir primero. C y D tienen in-degree 1. E tiene in-degree 2.
        assertEquals(5, topo.size());
        assertTrue(topo.indexOf("A") < topo.indexOf("C"));
        assertTrue(topo.indexOf("B") < topo.indexOf("C"));
        assertTrue(topo.indexOf("C") < topo.indexOf("E"));
        assertTrue(topo.indexOf("D") < topo.indexOf("E"));
    }

    @Test
    void testRecorridoTopologico_ConCiclo() {
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1), (\"C\",\"A\",1)}");
        assertThrows(IllegalStateException.class, g::recorridoTopologicoDFS);
        assertThrows(IllegalStateException.class, g::recorridoTopologicoBFS);
    }

    // ===========================================
    // 4. Tests de Componentes Conexas (SCC)
    // ===========================================


    @Test
    void testGetComponentesFuertementeConexas_Normal() {
        // 2 SCCs: {A, B}, {C, D, E}
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\", \"E\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"A\",1), (\"C\",\"D\",1), (\"D\",\"E\",1), (\"E\",\"C\",1), (\"B\",\"C\",1)}");
        List<List<String>> sccs = g.getComponentesFuertementeConexas();
        assertEquals(2, sccs.size());
        
        Set<Set<String>> sccSets = new HashSet<>();
        for (List<String> scc : sccs) {
            sccSets.add(new HashSet<>(scc));
        }

        assertTrue(sccSets.contains(new HashSet<>(Arrays.asList("A", "B"))));
        assertTrue(sccSets.contains(new HashSet<>(Arrays.asList("C", "D", "E"))));
    }
    
    @Test
    void testGetComponentesFuertementeConexas_Aclico() {
        // Cada vértice es su propia SCC: {A}, {B}, {C}
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1)}");
        List<List<String>> sccs = g.getComponentesFuertementeConexas();
        assertEquals(3, sccs.size());
        // El orden de las SCC es inverso al de post-visita.
        
        Set<Set<String>> sccSets = new HashSet<>();
        for (List<String> scc : sccs) {
            sccSets.add(new HashSet<>(scc));
            assertEquals(1, scc.size()); // Deben ser SCCs de tamaño 1
        }
        assertTrue(sccSets.contains(new HashSet<>(Arrays.asList("A"))));
        assertTrue(sccSets.contains(new HashSet<>(Arrays.asList("B"))));
        assertTrue(sccSets.contains(new HashSet<>(Arrays.asList("C"))));
    }
    
    // ===========================================
    // 5. Tests de Puntos de Articulación (AP)
    // ===========================================

    @Test
    void testGetPuntosArticulacion_GrafoSimple() {
        // Grafo: A -- B -- C -- D
        // B y C deben ser P.A.
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1), (\"C\",\"D\",1)}");
        g.agregarArista("B", "A", 1); 
        g.agregarArista("C", "B", 1);
        g.agregarArista("D", "C", 1);
        
        Set<String> puntos = g.getPuntosArticulacion();
        assertEquals(2, puntos.size());
        assertTrue(puntos.containsAll(Arrays.asList("B", "C")));
        assertFalse(puntos.contains("A"));
    }

    @Test
    void testGetPuntosArticulacion_RaizConMasDeUnHijo() {
        // Grafo: A -- B, A -- C. A es la raíz y tiene 2 hijos en el árbol DFS.
        // A debe ser P.A.
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",1), (\"A\",\"C\",1)}");
        g.agregarArista("B", "A", 1);
        g.agregarArista("C", "A", 1);

        Set<String> puntos = g.getPuntosArticulacion();
        assertEquals(1, puntos.size());
        assertTrue(puntos.contains("A"));
    }

    @Test
    void testGetPuntosArticulacion_GrafoConCiclo() {
        // Grafo: A -- B -- C -- A (Ciclo) y C -- D
        // C debe ser P.A. (Conexión al componente D)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1), (\"C\",\"A\",1), (\"C\",\"D\",1)}");
        // Aseguramos que sea no dirigido
        g.agregarArista("B", "A", 1); 
        g.agregarArista("A", "C", 1);
        g.agregarArista("D", "C", 1);

        Set<String> puntos = g.getPuntosArticulacion();
        assertEquals(1, puntos.size());
        assertTrue(puntos.contains("C"));
    }

    // ===========================================
    // 6. Tests de Camino Mínimo (BFS, Dijkstra)
    // ===========================================

    @Test
    void testCaminoMinimoBFS_Existente() {
        // Grafo: A -> B -> C -> D (3 aristas)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"B\",\"C\",1), (\"C\",\"D\",1)}");
        List<String> camino = g.caminoMinimoBFS("A", "D");
        assertEquals(Arrays.asList("A", "B", "C", "D"), camino);
    }
    
    @Test
    void testCaminoMinimoBFS_NoExistente() {
        // Grafo: A -> B y C -> D (inconexos)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"C\",\"D\",1)}");
        List<String> camino = g.caminoMinimoBFS("A", "C");
        assertTrue(camino.isEmpty());
    }

    @Test
    void testDijkstra_Existente() {
        // Caminos: A -> B (1), A -> C (10)
        // A -> B -> C (1 + 1 = 2)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",1), (\"A\",\"C\",10), (\"B\",\"C\",1)}");
        List<String> camino = g.dijkstra("A", "C");
        assertEquals(Arrays.asList("A", "B", "C"), camino);
    }

    @Test
    void testDijkstra_NoExistente() {
        // Grafo: A -> B y C -> D (inconexos)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\", \"D\"}", 
                                               "A = {(\"A\",\"B\",1), (\"C\",\"D\",1)}");
        List<String> camino = g.dijkstra("A", "C");
        assertTrue(camino.isEmpty());
    }

    @Test
    void testDijkstra_PesoCero() {
        // A -> B (0), B -> C (1)
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\", \"C\"}", 
                                               "A = {(\"A\",\"B\",0), (\"B\",\"C\",1)}");
        List<String> camino = g.dijkstra("A", "C");
        assertEquals(Arrays.asList("A", "B", "C"), camino);
    }
    
    @Test
    void testDijkstra_PesoNegativo() {
        // Dijkstra falla con pesos negativos
        Grafo<String, Integer> g = Grafo.build("V = {\"A\", \"B\"}", 
                                               "A = {(\"A\",\"B\",-1)}");
        assertThrows(IllegalArgumentException.class, () -> g.dijkstra("A", "B"));
    }
}
