package test.ar.uba.fi.cb100.c2025_02.estructuras.arboles;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Comparator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.arboles.ArbolBinarioHeap;

public class ArbolBinarioHeapTest {

    // ===========================================
    // 1. Tests de Min-Heap (Prioridad: el menor)
    // ===========================================

    @Test
    void testMinHeap_InsertAndExtract() {
        // Usamos Comparator.naturalOrder() para que el menor sea el "mejor"
    	ArbolBinarioHeap<Integer> minHeap = new ArbolBinarioHeap<Integer>(Comparator.naturalOrder(), 5);

        minHeap.insert(50);
        minHeap.insert(10);
        minHeap.insert(30);
        minHeap.insert(5);
        minHeap.insert(20);

        assertEquals(5, minHeap.size(), "El tamaño debe ser 5 después de las inserciones.");
        
        // El menor debe estar en la cima
        assertEquals(5, minHeap.peek(), "El peek debe devolver el elemento más pequeño (5).");
        
        // Extracción en orden ascendente
        assertEquals(5, minHeap.extract(), "1ra extracción debe ser 5.");
        assertEquals(10, minHeap.extract(), "2da extracción debe ser 10.");
        assertEquals(20, minHeap.extract(), "3ra extracción debe ser 20.");
        assertEquals(30, minHeap.extract(), "4ta extracción debe ser 30.");
        assertEquals(50, minHeap.extract(), "5ta extracción debe ser 50.");
        
        assertTrue(minHeap.isEmpty(), "El heap debe estar vacío al final.");
    }
    
    // ===========================================
    // 2. Tests de Max-Heap (Prioridad: el mayor)
    // ===========================================

    @Test
    void testMaxHeap_InsertAndExtract() {
        // Usamos Comparator.reverseOrder() para que el mayor sea el "mejor"
    	ArbolBinarioHeap<Integer> maxHeap = new ArbolBinarioHeap<Integer>(Comparator.reverseOrder(), 5);

        maxHeap.insert(50);
        maxHeap.insert(10);
        maxHeap.insert(30);
        maxHeap.insert(5);
        maxHeap.insert(20);

        assertEquals(5, maxHeap.size(), "El tamaño debe ser 5 después de las inserciones.");
        
        // El mayor debe estar en la cima
        assertEquals(50, maxHeap.peek(), "El peek debe devolver el elemento más grande (50).");
        
        // Extracción en orden descendente
        assertEquals(50, maxHeap.extract(), "1ra extracción debe ser 50.");
        assertEquals(30, maxHeap.extract(), "2da extracción debe ser 30.");
        assertEquals(20, maxHeap.extract(), "3ra extracción debe ser 20.");
        assertEquals(10, maxHeap.extract(), "4ta extracción debe ser 10.");
        assertEquals(5, maxHeap.extract(), "5ta extracción debe ser 5.");
        
        assertTrue(maxHeap.isEmpty(), "El heap debe estar vacío al final.");
    }

    // ===========================================
    // 3. Tests de Capacidad y Errores
    // ===========================================

    @Test
    void testHeap_ManejoDeCapacidad() {
        // Creamos un heap con capacidad muy pequeña para forzar el redimensionamiento
    	ArbolBinarioHeap<String> heap = new ArbolBinarioHeap<String>(Comparator.naturalOrder(), 2);

        heap.insert("A");
        heap.insert("B");
        // La tercera inserción fuerza el redimensionamiento
        heap.insert("C"); 
        
        assertEquals(3, heap.size(), "El tamaño debe ser 3 después de redimensionar.");
        
        // Verificamos que aún funcione la propiedad de heap (orden alfabético en Min-Heap de strings)
        assertEquals("A", heap.peek(), "Después de redimensionar, la raíz sigue siendo el menor elemento.");
    }

    @Test
    void testHeap_EmptyExceptions() {
    	ArbolBinarioHeap<Integer> heap = new ArbolBinarioHeap<Integer>(Comparator.naturalOrder());
        
        assertTrue(heap.isEmpty(), "El heap debe empezar vacío.");

        // Intentar hacer peek en un heap vacío
        assertThrows(NoSuchElementException.class, heap::peek, 
                     "Peek en un heap vacío debe lanzar NoSuchElementException.");

        // Intentar hacer extract en un heap vacío
        assertThrows(NoSuchElementException.class, heap::extract, 
                     "Extract en un heap vacío debe lanzar NoSuchElementException.");
    }
    
    // ===========================================
    // 4. Test con Tipos Personalizados (Priority-Value)
    // ===========================================

    // Clase auxiliar para probar con objetos que tienen un valor y una prioridad
    static class Task {
        String name;
        int priority;

        Task(String name, int priority) {
            this.name = name;
            this.priority = priority;
        }

        @Override
        public String toString() {
            return name + " (" + priority + ")";
        }
    }

    @Test
    void testHeap_CustomObjectComparator() {
        // Creamos un comparador: el que tiene MENOR número de prioridad es el "mejor" (Min-Heap en el campo priority)
        Comparator<Task> priorityComparator = Comparator.comparingInt(t -> t.priority);
        
        ArbolBinarioHeap<Task> taskHeap = new ArbolBinarioHeap<Task>(priorityComparator);

        taskHeap.insert(new Task("Baja", 3));
        taskHeap.insert(new Task("Alta", 1));
        taskHeap.insert(new Task("Media", 2));
        
        assertEquals(3, taskHeap.size());

        // 1. Debe extraer la prioridad 1 (Alta)
        assertEquals("Alta", taskHeap.extract().name, "La 1ra tarea debe ser la de prioridad 1.");
        
        // 2. Debe extraer la prioridad 2 (Media)
        assertEquals("Media", taskHeap.extract().name, "La 2da tarea debe ser la de prioridad 2.");
        
        // 3. Debe extraer la prioridad 3 (Baja)
        assertEquals("Baja", taskHeap.extract().name, "La 3ra tarea debe ser la de prioridad 3.");
    }
}
