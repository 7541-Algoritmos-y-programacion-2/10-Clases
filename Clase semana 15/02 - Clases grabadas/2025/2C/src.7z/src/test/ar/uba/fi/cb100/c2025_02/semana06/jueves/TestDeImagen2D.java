package test.ar.uba.fi.cb100.c2025_02.semana06.jueves;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial.ComponenteDeColor;
import ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial.Imagen2d;
import ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial.Pixel;

public class TestDeImagen2D {

    private Imagen2d imagen;

    @BeforeEach
    void setUp() {
        imagen = new Imagen2d(3, 4); // 3 de alto, 4 de ancho
    }
    
    @Test
    void testConstructorDimensiones() {
        assertEquals(4, imagen.getAncho());
        assertEquals(3, imagen.getAlto());
    }

    @Test
    void testConstructorInvalido() {
        assertThrows(IllegalArgumentException.class, () -> new Imagen2d(0, 5));
        assertThrows(IllegalArgumentException.class, () -> new Imagen2d(5, -1));
    }

    @Test
    void testGetPixel() {
        Pixel blanco = Pixel.generarPixelBlanco();
        // Nota: La implementación del constructor en el código original tiene un error y no inicializa la matriz.
        // Asumiendo que se corrige, todos los pixeles deben ser blancos.
        // Si no, este test fallará con NullPointerException.
        // Para que pase, la implementación correcta del constructor debería ser:
        // public Imagen2d(int alto, int ancho){
        //     ValidacionesUtiles.validarMayorACero(alto, "alto");
        //     ValidacionesUtiles.validarMayorACero(ancho, "ancho");
        //     this.pixeles = new Pixel[ancho][alto]; // <-- ESTA LÍNEA FALTA
        //     for(int i = 0; i < ancho; i++){
        //         for(int j = 0; j < alto; j++){
        //             pixeles[i][j] = Pixel.generarPixelBlanco();
        //         }
        //     }
        // }
         assertDoesNotThrow(() -> {
            assertEquals(blanco, imagen.getPixel(1, 1));
            assertEquals(blanco, imagen.getPixel(4, 3));
         });
    }

    @Test
    void testGetPixelInvalido() {
        assertThrows(IllegalArgumentException.class, () -> imagen.getPixel(0, 1));
        assertThrows(IllegalArgumentException.class, () -> imagen.getPixel(5, 1));
        assertThrows(IllegalArgumentException.class, () -> imagen.getPixel(1, 4));
    }

    @Test
    void testGetPixelMasRojoVerdeAzul() {
        imagen.getPixel(1, 1).setR(200);
        imagen.getPixel(2, 2).setG(210);
        imagen.getPixel(3, 3).setB(220);

        assertEquals(200, imagen.getPixelMasRojo().getR());
        assertEquals(210, imagen.getPixelMasVerde().getG());
        assertEquals(220, imagen.getPixelMasAzul().getB());
    }

    @Test
    void testGetPixelMasIntenso() {
        imagen.getPixel(1, 2).setR(250);
        imagen.getPixel(3, 1).setG(240);
        
        assertEquals(250, imagen.getPixelMasIntenso(ComponenteDeColor.Rojo).getR());
        assertEquals(240, imagen.getPixelMasIntenso(ComponenteDeColor.Verde).getG());
    }

    @Test
    void testFiltros() {
        Pixel p = imagen.getPixel(2, 2);
        p.setR(100);
        p.setG(150);
        p.setB(200);

        imagen.aplicarFiltroEscalaDeGrises();
        assertEquals(29, p.getR());
        assertEquals(88, p.getG());
        assertEquals(22, p.getB());

        imagen.aplicarFiltroDeBrillo(100);
        assertEquals(129, p.getR());
        assertEquals(188, p.getG());
        assertEquals(122, p.getB());
    }
    
    @Test
    void testInvertirHorizontalmente() {
        // Nota: La implementación de invertir tiene un bug (usa ancho-i en lugar de ancho-1-i)
        // El test está escrito para la lógica correcta.
        Imagen2d img = new Imagen2d(2, 3); // 3 ancho x 2 alto
        Pixel p1 = img.getPixel(1, 1);
        Pixel p3 = img.getPixel(3, 1);
        p1.setR(100);
        p3.setR(200);

        img.invertirHorizontalmente();
        
        // La corrección del bug es:
        // this.pixeles[i][j] = this.pixeles[this.getAncho() - 1 - i][j];
        // this.pixeles[this.getAncho() - 1 - i][j] = temp;
        
        // Asumiendo la corrección
        assertEquals(200, img.getPixel(1, 1).getR());
        assertEquals(100, img.getPixel(3, 1).getR());
    }

    @Test
    void testInvertirVerticalmente() {
        // Similar a la horizontal, la lógica de inversión tiene un bug.
        Imagen2d img = new Imagen2d(3, 2); // 2 ancho x 3 alto
        Pixel p1 = img.getPixel(1, 1);
        Pixel p3 = img.getPixel(1, 3);
        p1.setG(100);
        p3.setG(200);
        
        img.invertirVerticalmente();

        // La corrección del bug es:
        // this.pixeles[i][j] = this.pixeles[i][this.getAlto() - 1 - j];
        // this.pixeles[i][this.getAlto() - 1 - j] = temp;

        // Asumiendo la corrección
        assertEquals(200, img.getPixel(1, 1).getG());
        assertEquals(100, img.getPixel(1, 3).getG());
    }

    @Test
    void testEquals() {
        Imagen2d img1 = new Imagen2d(2, 2);
        Imagen2d img2 = new Imagen2d(2, 2);
        Imagen2d img3 = new Imagen2d(3, 3);

        img1.getPixel(1, 1).setR(50);
        img2.getPixel(1, 1).setR(50);

        assertTrue(img1.equals(img2));
        assertFalse(img1.equals(img3));
    }
}