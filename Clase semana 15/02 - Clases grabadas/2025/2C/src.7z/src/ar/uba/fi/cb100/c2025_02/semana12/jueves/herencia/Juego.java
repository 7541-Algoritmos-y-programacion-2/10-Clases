package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia;

public abstract class Juego {

}
