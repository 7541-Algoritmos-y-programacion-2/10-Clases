package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea03;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Moderador {
    private String nombre;

    public Moderador(String nombre){
        this.nombre = nombre;
    }

    /**
     * Dada una lista de foros, un usuario y una tematica, obtiene el mensaje mas votado de dicho usuario, teniendo en
     * cuenta solamente los foros que no contienen la tematica indicada
     * @param foros lista de foros, no null
     * @param usuarioBuscado usuario del que buscar el mensaje mas votado, no null
     * @param tematicaBuscada tematica no coincidente con los foros, no null
     * @return
     */
    public Mensaje buscarMensajeMasVotadoDelUsuarioSegunTematica(List<Foro> foros, String usuarioBuscado, String tematicaBuscada){
        ValidacionesUtiles.esDistintoDeNull(foros, "Lista de foros");
        ValidacionesUtiles.esDistintoDeNull(usuarioBuscado, "usuarioBuscado");
        ValidacionesUtiles.esDistintoDeNull(tematicaBuscada, "tematicaBuscada");

        List<Foro> forosSinTematicaBuscada = obtenerForosSinTematica(foros, tematicaBuscada);
        if(forosSinTematicaBuscada == null){
            return null;
        }
        List<Mensaje> mensajesDelUsuario = obtenerMensajesDelUsuario(forosSinTematicaBuscada, usuarioBuscado);
        if(mensajesDelUsuario == null){
            return null;
        }
        Mensaje mensajeMasVotado = null;
        for(Mensaje mensajeActual: mensajesDelUsuario){
            if(mensajeMasVotado == null ||
               mensajeActual.contarVotos() > mensajeMasVotado.contarVotos()){
                mensajeMasVotado = mensajeActual;
            }
        }
        return mensajeMasVotado;
    }

    /**
     * Dada una lista de foros, devuelve una lista de los foros que no contengan la tematica
     * @param foros lista de foros, no null
     * @param tematica tematica a buscar, no null
     * @return lista de foros que no tienen la tematica || null
     */
    public List<Foro> obtenerForosSinTematica(List<Foro> foros, String tematica){
       ValidacionesUtiles.esDistintoDeNull(foros, "lista de foros");
       ValidacionesUtiles.esDistintoDeNull(tematica, "tematica");

       List<Foro> forosSinTematicaBuscada = null;
       for(Foro foro: foros){
           if(!foro.obtenerTematicas().contains(tematica)){
               if(forosSinTematicaBuscada == null){
                   forosSinTematicaBuscada = new ListaSimplementeEnlazada<>();
               }
               forosSinTematicaBuscada.add(foro);
           }
       }
       return forosSinTematicaBuscada;
    }

    /**
     * Dada una lista de foros, devuelve una lista de todos los mensajes del usuario
     * @param foros lista de foros, no null
     * @param usuarioBuscado usuario del que buscar mensajes, no null
     * @return lista de mensajes del usuario || null
     */
    public List<Mensaje> obtenerMensajesDelUsuario(List<Foro> foros, String usuarioBuscado){
        ValidacionesUtiles.esDistintoDeNull(foros, "lista de foros");
        ValidacionesUtiles.esDistintoDeNull(usuarioBuscado, "usuarioBuscado");

        List<Mensaje> mensajesDelUsuario = null;
        for(Foro foro: foros){
            for(Mensaje mensaje: foro.obtenerMensajes()){
                if(mensaje.obtenerUsuario().equals(usuarioBuscado)){
                    if(mensajesDelUsuario == null){
                        mensajesDelUsuario = new ListaSimplementeEnlazada<>();
                    }
                    mensajesDelUsuario.add(mensaje);
                }
            }
        }
        return mensajesDelUsuario;
    }
}
