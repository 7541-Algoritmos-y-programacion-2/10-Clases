package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea01.tablero;

public class PrincipalClase18 {

	public static void main(String[] args) {
		System.out.println("### INICIO DE LA SIMULACIÓN DE TORNEO DE AJEDREZ ###\n");
        
        // 1. CONSTRUCTOR: Creamos un torneo para 4 jugadores.
        int cantidadDeJugadores = 4;
        TableroDeAjedrez torneo = new TableroDeAjedrez(cantidadDeJugadores);
        System.out.println("Se ha creado un torneo para " + cantidadDeJugadores + " jugadores.");

        // 2. ESTADO INICIAL: Chequeamos el estado inicial del torneo.
        System.out.println("\n--- ESTADO INICIAL ---");
        System.out.println("¿Torneo finalizado? " + torneo.estaFinalizadoElTorneo()); // Debe ser 'false'
        System.out.println("Puntaje inicial del Jugador 1: " + torneo.getPuntajeDelJugador(1)); // Debe ser 0

        // 3. CARGAR RESULTADOS: Simulamos algunas partidas.
        // (Esto funcionará solo si corriges el error de validación explicado abajo)
        System.out.println("\n--- SIMULANDO ALGUNAS PARTIDAS ---");
        
        // Jugador 1 (Blancas) vs Jugador 2 (Negras) -> Ganan Blancas
        torneo.cargarResultado(1, 2, Resultado.GANAN_BLANCAS);
        System.out.println("Partida cargada: J1 (B) vs J2 (N) -> Ganan Blancas");

        // Jugador 3 (Blancas) vs Jugador 1 (Negras) -> Tablas
        torneo.cargarResultado(3, 1, Resultado.TABLAS);
        System.out.println("Partida cargada: J3 (B) vs J1 (N) -> Tablas");
        
        // Jugador 4 (Blancas) vs Jugador 2 (Negras) -> Ganan Negras
        torneo.cargarResultado(4, 2, Resultado.GANAN_NEGRAS);
        System.out.println("Partida cargada: J4 (B) vs J2 (N) -> Ganan Negras");

        // 4. GETPUNTAJEDELJUGADOR: Verificamos los puntajes parciales.
        System.out.println("\n--- PUNTAJES PARCIALES ---");
        System.out.println("Puntaje Jugador 1: " + torneo.getPuntajeDelJugador(1)); // 3 (vs J2) + 1 (vs J3) = 4
        System.out.println("Puntaje Jugador 2: " + torneo.getPuntajeDelJugador(2)); // 0 (vs J1) + 3 (vs J4) = 3
        System.out.println("Puntaje Jugador 3: " + torneo.getPuntajeDelJugador(3)); // 1 (vs J1) = 1
        System.out.println("Puntaje Jugador 4: " + torneo.getPuntajeDelJugador(4)); // 0 (vs J2) = 0
        
        // 5. ANULAR PARTIDA: Anulamos una partida ya jugada.
        System.out.println("\n--- ANULANDO UNA PARTIDA ---");
        System.out.println("Se anula la partida entre Jugador 3 y Jugador 1.");
        torneo.anularPartida(3, 1);
        
        System.out.println("Puntaje Jugador 1 (después de anular): " + torneo.getPuntajeDelJugador(1)); // 3 (vs J2) - 1 = 2
        System.out.println("Puntaje Jugador 3 (después de anular): " + torneo.getPuntajeDelJugador(3)); // -1
        
        // 6. GETJUGADORGANADOR (FALLO ESPERADO): Intentamos obtener un ganador antes de que termine.
        System.out.println("\n--- INTENTANDO OBTENER GANADOR (ANTES DE FINALIZAR) ---");
        try {
            torneo.getJugadorGanador();
        } catch (RuntimeException e) {
            System.out.println("ÉXITO: Se lanzó la excepción esperada -> " + e.getMessage());
        }
        
        // 7. COMPLETANDO EL TORNEO: Cargamos todos los resultados restantes.
        System.out.println("\n--- COMPLETANDO TODAS LAS PARTIDAS DEL TORNEO ---");
        torneo.cargarResultado(1, 3, Resultado.GANAN_BLANCAS);
        torneo.cargarResultado(1, 4, Resultado.TABLAS);
        torneo.cargarResultado(2, 1, Resultado.GANAN_NEGRAS);
        torneo.cargarResultado(2, 3, Resultado.GANAN_BLANCAS);
        torneo.cargarResultado(2, 4, Resultado.TABLAS);
        torneo.cargarResultado(3, 2, Resultado.TABLAS);
        torneo.cargarResultado(3, 4, Resultado.GANAN_BLANCAS);
        torneo.cargarResultado(4, 1, Resultado.GANAN_NEGRAS);
        torneo.cargarResultado(4, 3, Resultado.GANAN_NEGRAS);
        System.out.println("Todos los resultados han sido cargados.");

        // 8. ESTAFINALIZADOELTORNEO: Verificamos que el torneo ya terminó.
        System.out.println("\n¿Torneo finalizado? " + torneo.estaFinalizadoElTorneo()); // Debe ser 'true'

        // 9. PUNTAJES FINALES Y GANADOR
        System.out.println("\n--- PUNTAJES FINALES ---");
        for (int i = 1; i <= cantidadDeJugadores; i++) {
            System.out.println("Puntaje final Jugador " + i + ": " + torneo.getPuntajeDelJugador(i));
        }
        
        int ganador = torneo.getJugadorGanador();
        System.out.println("\n🏆 EL JUGADOR GANADOR DEL TORNEO ES: ¡JUGADOR " + ganador + "! 🏆");
        
        System.out.println("\n### FIN DE LA SIMULACIÓN ###");
        
        
        System.out.println( torneo.toString() );
	}
}
