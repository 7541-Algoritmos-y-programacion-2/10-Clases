package ar.uba.fi.cb100.c2025_02.semana04.jueves;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1.Libro;

public class Biblioteca {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Libro[] libros = null; //borrar
	//private LibroEnBiblioteca[] libros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Inicializamos la biblioteca con la cantidad de libros maxima (la suma de todos los libros)
	 * @param cantidadMaximaDeLibros
	 */
	public Biblioteca(int cantidadMaximaDeLibros) {
		this.libros = new Libro[cantidadMaximaDeLibros];
		for(int i = 0; i < this.libros.length; i++) {
			this.libros[i] = null;
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Dado un libro lo agregamos a la biblioteca.
	 * @param libro
	 */
	public void agregar(Libro libro) {
		ValidacionesUtiles.validarFalso(estaLlena(), "La Biblioteca esta llena");
		ValidacionesUtiles.esDistintoDeNull(libro, "Libro");
		ValidacionesUtiles.validarFalso(existe(libro), "El libro ya existe en la Biblioteca");
		this.libros[getCantidadDeLibros()] = libro;
	}
	
	/**
	 * Devuelve verdadero si el libro existe en la biblioteca
	 * @param libro: libro a buscar
	 * @return devuelve verdadero si lo encontro
	 */
	public boolean existe(Libro libro) {
		ValidacionesUtiles.esDistintoDeNull(libro, "Libro");
		for(Libro libroActual: this.libros) {
			if ((libroActual != null) &&
			   (libroActual.equals(libro))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Devuelve verdadero si la bibioteca no tiene capacidad de agregar otro libro
	 * @return
	 */
	public boolean estaLlena() {
		return (getCantidadDeLibros() >= libros.length);
	}

	/**
	 * Dado un libro, quita el libro de la biblioteca
	 * @param libro no puede ser nulo y debe existir en la biblioteca
	 */
	public void quitar(Libro libro) {
		ValidacionesUtiles.validarVerdadero(estaVacia(), "La Biblioteca esta vacia");
		ValidacionesUtiles.esDistintoDeNull(libro, "Libro");
		ValidacionesUtiles.validarFalso(existe(libro), "El libro no existe en la Biblioteca");
		for(int i = getPosicionDeLibro(libro); i < this.getCantidadDeLibros() - 1; i++) {
			this.libros[i] = this.libros[i+1];
		}
		this.libros[ this.libros.length-1 ] = null;
	}
	
	/**
	 * Devuelve si la biblioteca esta vacia o no
	 * @return verdadero si la biblioteca esta vacia
	 */
	public boolean estaVacia() {
		return this.getCantidadDeLibros() == 0;
	}

	/**
	 * Dado un libro de la biblioteca, presta 1 ejemplar
	 * @param libro: no puede ser vacio y debe existir con ejemplares para prestar
	 */
	public void prestar(Libro libro) {
		ValidacionesUtiles.esDistintoDeNull(libro, "Libro");
		ValidacionesUtiles.validarVerdadero(existe(libro), "El libro no existe en la Biblioteca");
		this.libros[getPosicionDeLibro(libro)].disminuirCantidadDeCopias();
	}
	
	/**
	 * Dado un libro de la biblioteca, devuelve 1 ejemplar
	 * @param libro: no puede ser vacio y debe existir
	 */
	public void devolver(Libro libro) {
		ValidacionesUtiles.esDistintoDeNull(libro, "Libro");
		ValidacionesUtiles.validarVerdadero(existe(libro), "El libro no existe en la Biblioteca");
		this.libros[getPosicionDeLibro(libro)].aumentarCantidadDeCopias();
	}
	
	/**
	 * 
	 * @param texto
	 * @return
	 */
	public Libro buscar(String texto) {
		for(int i = 0; i < this.getCantidadDeLibros(); i++) {
			if (this.libros[i].contiene(texto)) {
				return this.libros[i];
			}
		}
		throw new RuntimeException("No se encuentra el libro");
	}
	
	/**
	 * Devuelve la posicion del libro
	 * @param libro
	 * @return
	 */
	private int getPosicionDeLibro(Libro libro) {
		for(int i = 0; i < this.getCantidadDeLibros(); i++) {
			if (this.libros[i].equals(libro)) {
				return i;
			}
		}
		throw new RuntimeException("No se encontro el libro");
	}
	
	//cambiar cantidad de ejemplares
	//consultar la cantidad de ejemplares
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @return
	 */
	public int getCantidadDeLibros() {
		for(int i = 0; i < this.libros.length; i++) {
			if (this.libros[i] == null) {
				return i;
			}
		}
		return this.libros.length;
	}
	
	/**
	 * Devuelve un vector con los libros de la biblioteca
	 * @return
	 */
	public Libro[] getLibros() {
		Libro[] resultado = new Libro[getCantidadDeLibros()];
		for(int i = 0; i < this.getCantidadDeLibros(); i++) {
			resultado[i] = this.libros[i];
			//resultado[i] = this.libros[i].getLibro();
		}
		return resultado;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
