package ar.uba.fi.cb100.c2025_02.semana04.jueves;

import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1.Libro;

public class PrincipalClase08 {

	public static void main(String[] args) {
		Biblioteca biblioteca = new Biblioteca(10);
		{ //Agregamos
			biblioteca.agregar(new Libro("Libro 1", "Autor Uno", 2025, 10));
			biblioteca.agregar(new Libro("Libro 2", "Autor Dos", 2025, 30));
			biblioteca.agregar(new Libro("Libro 3", "Autor Tres", 2025, 40));
			biblioteca.agregar(new Libro("Libro 4", "Autor Cuatro", 2025, 40));
		}
		try {
			biblioteca.agregar(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		{//Imprimo
			for(Libro libro: biblioteca.getLibros()) {
				System.out.println(libro.toString());
			}
			biblioteca.getLibros()[0] = null;
			biblioteca.getLibros()[1] = null;
					
		}
		{
			biblioteca.prestar(biblioteca.getLibros()[0]);
			biblioteca.devolver(biblioteca.getLibros()[0]);
			
			Libro libro = biblioteca.buscar("Libro");
			//libro.setTitulo("Hola");
			libro.aumentarCantidadDeCopias();
			libro.aumentarCantidadDeCopias();
			libro.aumentarCantidadDeCopias();
			libro.aumentarCantidadDeCopias();
			libro.setCantidadDeCopias(5000);
		}
			
		//Stock
		//RegistroDeExistencia
		//LibroYCantidad
		//AlmacenamientoDeLibro
		//LibroAlmacenado
		//LibroEnBiblioteca
	}
}
