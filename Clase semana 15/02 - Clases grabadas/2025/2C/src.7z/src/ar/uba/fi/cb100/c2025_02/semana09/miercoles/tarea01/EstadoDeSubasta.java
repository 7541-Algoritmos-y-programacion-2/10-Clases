package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea01;

/**
 * Informa el estado de la subasta
 */
public enum EstadoDeSubasta {
    PENDIENTE,
    ABIERTA,
    CERRADA
}
