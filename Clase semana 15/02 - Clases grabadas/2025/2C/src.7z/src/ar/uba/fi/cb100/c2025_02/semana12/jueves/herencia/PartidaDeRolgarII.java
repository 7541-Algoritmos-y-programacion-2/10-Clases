package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia;

import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas.CartaCampoDeFuerza;

public class PartidaDeRolgarII extends Partida {

	public Personaje getPersonaje() {
		// TODO Auto-generated method stub
		return null;
	}

	public void agregarCarta(CartaCampoDeFuerza cartaCampoDeFuerza) {
		// TODO Auto-generated method stub
		
	}


	public void quitarCarta(CartaCampoDeFuerza cartaCampoDeFuerza) {
		// TODO Auto-generated method stub
		
	}
}
