package ar.uba.fi.cb100.c2025_02.semana01.jueves;

public class Alumno {

	public String nombre;
	public int edad;
	
}
