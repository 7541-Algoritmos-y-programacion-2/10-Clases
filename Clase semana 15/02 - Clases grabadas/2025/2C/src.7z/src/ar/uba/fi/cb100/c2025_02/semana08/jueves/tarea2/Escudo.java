package ar.uba.fi.cb100.c2025_02.semana08.jueves.tarea2;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Escudo {
    private int resistencia;
    private int resistenciaMaxima;
    private int golpesSoportados = 0;


    public Escudo(int resistencia){
        setResistenciaMaxima(resistencia);
        setResistencia(resistencia);
    }

    /**
     * @return True si la resistencia es 0
     */
    public boolean estaDestruido(){
        return resistencia == 0;
    }

    /**
     * @return true si la resistencia es igual a la resistencia maxima
     */
    public boolean estaLleno(){
        return resistencia == resistenciaMaxima;
    }

    /**
     *
     * @return true si no esta destruido
     */
    public boolean estaSano(){
        return !estaDestruido();
    }

    /**
     * @param o   the reference object with which to compare.
     * @return true si ambos tienen la misma resistencia y resistenciaMaxima
     */
    @Override
    public boolean equals(Object o){
        if(o == null){
            return false;
        }
        if(this == o){
            return true;
        }
        if(o.getClass() != this.getClass()){
            return false;
        }
        Escudo other = (Escudo) o;
        return (resistencia == other.getResistencia() &&
                resistenciaMaxima == other.getResistenciaMaxima());
    }

    /**
     *
     * @return Un formato en string del escudo
     */
    @Override
    public String toString(){
        return "Escudo Resistencia:"+resistencia+" Max:"+resistenciaMaxima+"golpes soportados:"+golpesSoportados;
    }

    /**
     * Reduce la resistencia en danio, truncando en 0 si danio es mayor a resistencia
     * @param danio mayor o igual a cero
     */
    public void defenderAtaque(int danio){
        ValidacionesUtiles.validarMayorOIgualACero(danio, "danio");
        int danioARecibir = Math.min(danio, resistencia);
        resistencia -= danioARecibir;
        if(estaSano()){
            golpesSoportados++;
        }
    }

    /**
     * Si el escudo no esta destruido, lo repara por completo
     */
    public void reparar(){
        if(estaSano()){
            resistencia = resistenciaMaxima;
        } else {
            throw new RuntimeException("El escudo no puede ser reparado porque esta destruido.");
        }
    }

    /**
     * Si el escudo no esta destruido, aumenta su resistencia con la reparacion recibida
     * @param reparacion cantidad de resistencia a reparar. Mayor a 0
     */
    public void reparar(int reparacion){
    	ValidacionesUtiles.validarMayorACero(reparacion, "Reparacion");
        if(estaSano()){
            resistencia = Math.min(resistencia + reparacion, resistenciaMaxima);
        } else {
            throw new RuntimeException("El escudo no puede ser reparado porque esta destruido.");
        }
    }

    /**
     *
     * @return la resistencia actual
     */
    public int getResistencia(){
        return resistencia;
    }

    /**
     *
     * @return la resistenciaMaxima
     */
    public int getResistenciaMaxima(){
        return resistenciaMaxima;
    }

    /**
     *
     * @return los golpes soportados sin destruirse
     */
    public int getGolpesSoportados(){
        return golpesSoportados;
    }

    /**
     * setea la resistencia
     * @param resistencia entre 0 y resistenciaMaxima
     */
    private void setResistencia(int resistencia){
    	ValidacionesUtiles.validarRangoNumerico(0, resistenciaMaxima, resistencia, "resistencia");
        this.resistencia = resistencia;
    }

    /**
     * Setea la resistenciaMaxima
     * @param resistencia mayor a 0
     */
    private void setResistenciaMaxima(int resistencia){
    	ValidacionesUtiles.validarMayorACero(resistencia, "resistencia");
        resistenciaMaxima = resistencia;
    }

    /**
     * Setea los golpes soportados
     * @param golpes mayor a 0
     */
    private void setGolpesSoportados(int golpes){
    	ValidacionesUtiles.validarMayorACero(golpes, "golpes");
        golpesSoportados = golpes;
    }

}


//1) Punto 1: metodo sin uso. Ademas deberia soportar 0 y lo usas en el constructor. o lo borras.
///** * Setea los golpes soportados * @param golpes mayor a 0 */ private void setGolpesSoportados(int golpes){ 	ValidacionesUtiles.validarMayorACero(golpes, "golpes"); golpesSoportados = golpes; }
//2) No me gusta el nombre. public boolean estaLleno(){ return resistencia == resistenciaMaxima; }este seria el metodo estaSano.
//3) Este tampoco, estaOperativo? public boolean estaSano(){ return !estaDestruido(); }

