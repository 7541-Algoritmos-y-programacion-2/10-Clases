package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea02;

import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Restaurante {
    private Vector<Mesa> mesas;

    /**
     * Dada una cantidad de mesas, crea el restaurante inicializando dicha cantidad de mesas
     * @param cantidadDeMesas mayor a cero
     */
    public Restaurante(int cantidadDeMesas, int cantidadMaximaDePropinasPorMesa){
    	ValidacionesUtiles.validarMayorACero(cantidadDeMesas, "cantidad de mesas");
        mesas = new Vector<Mesa>(cantidadDeMesas, null);
        for(int i=1; i <= cantidadDeMesas; i++){
            this.mesas.agregar( new Mesa(i,cantidadMaximaDePropinasPorMesa));
        }
    }

    /**
     * @return la primer mesa libre
     */
    public int solicitarMesa() {
        for(int i = 1; i <= this.mesas.getLongitud(); i++) {
        	Mesa mesa = this.mesas.obtener(i);
            if (mesa.estaLibre()) {
                mesa.ocupar();
                return mesa.getNumero();
            }
        }
        throw new RuntimeException("No hay mesas disponibles :(");
    }

    /**
     * @return formato en string del restaurante
     */
    @Override
    public String toString(){
        return "Restaurante de "+getCantidadDeMesas()+" mesas";
    }

    /**
     * @param o el otro objeto para comparar
     * @return true si tienen el mismo vector de mesas
     */
    @Override
    public boolean equals(Object o){
        if(o == null || o.getClass() != this.getClass()){
            return false;
        }
        Restaurante otro = (Restaurante) o;
        return this.mesas.equals(otro.mesas);
    }

    /**
     * @param numeroDeMesa mayor a cero
     * @param propina
     */
    public void cerrarMesa(int numeroDeMesa, double propina){
    	ValidacionesUtiles.validarRangoNumerico(numeroDeMesa, 1, this.getCantidadDeMesas(), "numero de mesa");
        this.mesas.obtener(numeroDeMesa).cerrarMesa(propina);
    }

    public void cerrarMesa(int numeroDeMesa){
    	ValidacionesUtiles.validarRangoNumerico(numeroDeMesa, 1, this.getCantidadDeMesas(), "numero de mesa");
        this.mesas.obtener(numeroDeMesa).cerrarMesa();
    }
    
    /**
     * @return valor de la mayor propina recibida del restaurante
     */
    public Double getMayorPropina(){
        Mesa mesa = getMesaConMayorPropina();
        if (mesa != null) {
        	return mesa.getMayorPropina();
        }
        return null;
    }

    private Mesa getMesaConMayorPropina(){
        Mesa mesaConMayorPropina = null;
        for(int i = 1; i < this.mesas.getLongitud(); i++) {
        	Mesa mesa = this.mesas.obtener(i);
        	Double mayorPropinaDeLaMesa = mesa.getMayorPropina();
        	if (mayorPropinaDeLaMesa != null) {
        		if ((mesaConMayorPropina == null) ||
        			(mayorPropinaDeLaMesa > mesaConMayorPropina.getMayorPropina())) {
        			mesaConMayorPropina = mesa;
        		}
        	}
        }
        return mesaConMayorPropina;
    }
    
    /**
     * @return mesa con mas propina del local
     */
    public Integer getNumeroDeMesaConMayorPropina(){
        Mesa mesa = getMesaConMayorPropina();
        if (mesa != null) {
        	return mesa.getNumero();
        }
        return null;

    }

    /**
     * @return total de propinas recibidas
     */
    public double totalPropinas(){
        double total = 0.0;
        for(int i = 1; i < this.mesas.getLongitud(); i++) {
        	total += this.mesas.obtener(i).getTotalDePropinas();
        }
        return total;
    }


    /**
     * @return cantidad de mesas
     */
    public int getCantidadDeMesas(){
        return mesas.getLongitud();
    }

	public void setMesas(Vector<Mesa> mesas) {
		this.mesas = mesas;
	}
    
	public Vector<Mesa> getMesas() {
		return new Vector<Mesa>(mesas);
	}    

}