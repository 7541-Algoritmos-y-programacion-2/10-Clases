package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

import java.util.Random;

public class CartaCampoDeFuerza extends Carta {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private int cantidadDeTurnos = 0;
	private int valorDelCampoAdicional = 0;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public CartaCampoDeFuerza() {		
		this.cantidadDeTurnos = generarCantidadDeTurnos();
		this.valorDelCampoAdicional = generarValorDelCampoAdicional();
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	private static int generarCantidadDeTurnos() {
		Random random = new Random();
		return 1 + random.nextInt(10);
	}
	
	private static int generarValorDelCampoAdicional() {
		Random random = new Random();
		return 1 + random.nextInt(25);
	}
	
	@Override
	public AdministradorDeCarta getAdministradorDeCarta() {
		return new AdministradorDeCartaCampoDeFuerza(this);
	}

	public int getCantidadDeTurnosRestantes() {
		return this.cantidadDeTurnos;
	}
	
	public void avanzarTurno() {
		this.cantidadDeTurnos--;		
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------

	public int getCantidadDeTurnos() {
		return cantidadDeTurnos;
	}

	public int getValorDelCampoAdicional() {
		return valorDelCampoAdicional;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
