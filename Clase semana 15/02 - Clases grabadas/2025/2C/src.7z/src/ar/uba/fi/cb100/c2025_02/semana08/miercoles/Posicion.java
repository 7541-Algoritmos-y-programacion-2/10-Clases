package ar.uba.fi.cb100.c2025_02.semana08.miercoles;

public enum Posicion {
	Abajo,
	Arriba,
	Izquierda,
	Derecha,
	AbajoAtras,
	AbajoAdelante,
	AbajoIzquierda,
	AbajoDerecha,
	AbajoAtrasIzquierda,
	AbajoAtrasDerecha
}
