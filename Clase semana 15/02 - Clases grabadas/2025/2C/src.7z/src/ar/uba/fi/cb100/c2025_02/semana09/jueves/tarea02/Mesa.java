package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea02;

import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;



/**
 * Hipotesis:
 * - utilizo un maximo fisico
 * - el numero de la mesa es inmutable
 * TO-DO: propinas[] con redimension
 */
public class Mesa {
    private int numero;
    private Vector<Double> propinas;
    private EstadoMesa estadoMesa = EstadoMesa.LIBRE;


//CONSTRUCTORES -------------------------------------------------------------------------------------------

    /**
     * Dado un numero, construye una mesa libre con espacio para 100 propinas
     * @param numero
     */
    public Mesa(int numero, int propinasARecibir){
    	ValidacionesUtiles.validarMayorOIgualACero(propinasARecibir, "propinasARecibir");
    	setNumero(numero);
        propinas = new Vector<Double>(propinasARecibir, null);
    }

    /**
     * @return formato en string de la mesa
     */
    @Override
    public String toString(){
        return "Mesa nro " + numero + " esta " + this.estadoMesa;
    }

    /**
     * @param o   el otro objeto para comparar
     * @return true si son iguales (mismo estado y mismo vector de propinas)
     */
    @Override
    public boolean equals(Object o){
        if(o == null){
            return false;
        }
        if(this.getClass() != o.getClass()){
            return false;
        }
        if(this == o){
            return true;
        }
        Mesa otraMesa = (Mesa) o;
        return this.numero == otraMesa.numero;
    }
    
//METODOS DE CLASE ----------------------------------------------------------------------------------------

    /**
     * Dada una propina, si es mayor a cero la agrega a las propinas e incrementa la cantidad de propinas
     * @param propina mayor o igual a cero
     */
    public void recibirPropina(Double propina){
        ValidacionesUtiles.validarMayorACero(propina, "propina");
        this.propinas.agregar(propina);
    }
    
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------

    /**
     * @return numero de mesa
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @return maximo logico de las propinas
     */
    public int getCantidadDePropinas() {
        return this.propinas.getCantidadDeDatos();
    }

    /**
     * @return estado de la mesa
     */
    public EstadoMesa getEstadoMesa() {
        return this.estadoMesa;
    }

    public double getTotalDePropinas() {
        double total = 0.0;
        for(int i=1; i <= this.getCantidadDePropinas(); i++){
            total += this.propinas.obtener(i);
        }
        return total;
    }
    
    public boolean estaLibre() {
    	return this.estadoMesa == EstadoMesa.LIBRE;
    }
    
    public void ocupar() {
    	ValidacionesUtiles.validarVerdadero(estaLibre(), "Esta ocupada");
    	this.estadoMesa = EstadoMesa.OCUPADA;
    }
    
    public void cerrarMesa(double propina) {    	
    	recibirPropina(propina);
    	cerrarMesa();
    }
    
    public void cerrarMesa() {
    	ValidacionesUtiles.validarFalso(estaLibre(), "Esta libre");
    	this.estadoMesa = EstadoMesa.LIBRE;
    }
    
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     * @param numero mayor a cero
     */
    private void setNumero(int numero) {
    	ValidacionesUtiles.validarMayorACero(numero, "numero");
        this.numero = numero;
    }

	public Double getMayorPropina() {
		Double mayorPropina = null;
		for (int i = 1; i <= getCantidadDePropinas(); i++) {
			if ((mayorPropina == null) || (mayorPropina < this.propinas.obtener(i))) {
				mayorPropina = this.propinas.obtener(i);
			}
		}
		return mayorPropina;
	}

}
