package ar.uba.fi.cb100.c2025_02.semana03.jueves;

import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicio16.Rectangulo;

public class Guia03 {

	public static void main(String[] args) {
		ejercicio16();
	}
	
	public static void ejercicio16() {
		Rectangulo rectangulo = new Rectangulo(10, 50);
		System.out.println("El area es " + rectangulo.getArea());
		
		System.out.println("El perimetro es " + rectangulo.getPerimetro());
		
		System.out.println(rectangulo);
	}
}
