package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista;

public class Atuendo {
    private String tipo;
    private String color;
    private double precio;

    public Atuendo(String tipo, String color, double precio) {
        if (tipo == null || tipo.isBlank()) {
            throw new IllegalArgumentException("El tipo no puede ser vacío");
        }
        if (color == null || color.isBlank()) {
            throw new IllegalArgumentException("El color no puede ser vacío");
        }
        if (precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que cero");
        }
        this.tipo = tipo;
        this.color = color;
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public String getColor() {
        return color;
    }

    public double getPrecio() {
        return precio;
    }

    @Override
    public String toString() {
        return String.format("Atuendo[%s, %s, $%.2f]", tipo, color, precio);
    }
}