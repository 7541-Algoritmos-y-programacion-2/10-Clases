package ar.uba.fi.cb100.c2025_02.semana10.miercoles.tren;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Tren {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private int cantidadDeLocomotoras = 0;
	private int cantidadMaximaDeLocomotoras;
	private int cantidadMaximaDeVagonesPorLocomotora;
	private Vector<Vagon> vagones = null;
	
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * pre: -
	 * @throws Exception
	 * post: deja creado un tren con 1 locomotora y ningun vagon
	 */
	public Tren() throws Exception {
		this(3, 10);
	}
	
	/**
	 * pre: 
	 * @param cantidadDeLocomotoras: debe estar entre 1 y 3 inclusive
	 * @throws Exception da error si la cantidad no esta en rango
	 * post: deja creado un tren con cantidadDeLocomotoras y ningun vagon
	 */
	public Tren(int cantidadMaximaDeLocomotoras, int cantidadMaximaDeVagonesPorLocomotora) {
		setCantidadDeLocomotoras(1);
		setCantidadMaximaDeLocomotoras(cantidadMaximaDeLocomotoras);
		setCantidadMaximaDeVagonesPorLocomotora(cantidadMaximaDeVagonesPorLocomotora);
		this.vagones = new Vector<Vagon>(getCantidadMaximaTeoricaDeVagones(), null);
	}
	
//METODOS DE CLASE ----------------------------------------------------------------------------------------
	
	/**
	 * pre: -
	 * @return: devuelve la cantidad de vagones maxima posible, suponiendo que se tienen las
	 *          3 locomotoras.
	 */
	public int getCantidadMaximaDeLocomotoras() {
		return cantidadMaximaDeLocomotoras;
	}
	
	public int getCantidadMaximaDeVagonesPorLocomotora() {
		return cantidadMaximaDeVagonesPorLocomotora;
	}
	
	public int getCantidadMaximaTeoricaDeVagones() {
		return this.getCantidadMaximaDeLocomotoras() * getCantidadMaximaDeVagonesPorLocomotora();
	}
	
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Tren de " + this.cantidadDeLocomotoras + " locomotoras y " + this.getCantidadDeVagones() + " vagones";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cantidadDeLocomotoras, cantidadMaximaDeLocomotoras, cantidadMaximaDeVagonesPorLocomotora,
				vagones);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tren other = (Tren) obj;
		return cantidadDeLocomotoras == other.cantidadDeLocomotoras
				&& cantidadMaximaDeLocomotoras == other.cantidadMaximaDeLocomotoras
				&& cantidadMaximaDeVagonesPorLocomotora == other.cantidadMaximaDeVagonesPorLocomotora
				&& Objects.equals(vagones, other.vagones);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
	 * pre: -
	 * @throws Exception da error si la cantidad de locomotoras no esta entre 1 y CANTIDAD_MAXIMA_DE_LOCOMOTORAS
	 * @return: devuelve la cantidad de locomotoras actuales
	 * post: agrega una locomotora al tren
	 */
	public int agregarLocomotora() throws Exception {
		ValidacionesUtiles.validarVerdadero(this.cantidadDeLocomotoras >= getCantidadMaximaDeLocomotoras(), "Se supero el maximo de locomotoras");
		this.cantidadDeLocomotoras++;
		return this.cantidadDeLocomotoras;
	}
	
	/**
	 * pre: -
	 * @throws Exception da error si la cantidad de locomotoras no esta entre 1 y CANTIDAD_MAXIMA_DE_LOCOMOTORAS
	 * @return: devuelve la cantidad de locomotoras actuales
	 * post: quita una locomotora del tren
	 */
	public int quitarLocomotora() throws Exception {
		ValidacionesUtiles.validarVerdadero(this.cantidadDeLocomotoras <= 1, "No se puede quedar sin locomotoras");
		ValidacionesUtiles.validarVerdadero(getCantidadDeVagones() > (this.cantidadDeLocomotoras-1) * getCantidadMaximaDeVagonesPorLocomotora(), "Hay que sacar vagones primero");
		this.cantidadDeLocomotoras--;
		return this.cantidadDeLocomotoras;
	}

	/**
	 * pre: 
	 * @param vagones: son los vagones a agregar, no pueden ser nulos y deben estar sin carga
	 * @throws Exception: da error si los vagones son nulos, estan con carga o son mas de los
	 *         que puede aceptar el tren
	 * post: agregar los vagones al tren
	 */
	public void agregarVagon(Vagon ... vagones) {
		ValidacionesUtiles.esDistintoDeNull(vagones, "Vagones");
		ValidacionesUtiles.validarVerdadero(this.getCantidadDeVagonesFaltantes() < vagones.length, "Supera el maximo de vagones");
		for(Vagon vagon: vagones) {
			ValidacionesUtiles.esDistintoDeNull(vagon, "Vagon");
			ValidacionesUtiles.validarVerdadero(!vagon.estaVacio(), "Debe estar vacio");
			this.vagones.agregar( vagon );
		}		
	}
	
	/**
	 * pre: -
	 * @throws Exception
	 * post: quita el ultimo vagon
	 */
	public Vagon quitarVagon() throws Exception {
		ValidacionesUtiles.validarVerdadero( getCantidadDeVagones() <= 1, "Debe quedar 1 vagon");
		ValidacionesUtiles.validarVerdadero( this.vagones.obtener(this.getCantidadDeVagones() -1).estaVacio(), "Debe estar vacio para quitar");
		Vagon resultado = this.vagones.obtener( this.getCantidadDeVagones() -1);
		this.vagones.agregar(this.getCantidadDeVagones() -1, null);
		return resultado;
	}
	
	/**
	 * pre: 
	 * @param carga: debe ser mayor a 0
	 * @throws Exception: da error si la carga supera la capicidad
	 * post: reparte la carga en los vagones que tiene disponible
	 */
	public void agregarCarga(double carga) throws Exception {
		ValidacionesUtiles.validarVerdadero(this.getCapacidadDeCargaRestante() < carga, "No hay disponibilidad");
		for(int i = 1; i <= this.vagones.getLongitud(); i++) {
			Vagon vagon = this.vagones.obtener(i);
			if (vagon != null) {
				double cargaRestante = vagon.getCapacidadDeCargaRestante();
				if (cargaRestante > carga) {
					vagon.agregarCarga(carga);
					return;
				}
				vagon.agregarCarga(cargaRestante);
				carga -= cargaRestante;
			}
		}
	}
	
	/**
	 * pre: 
	 * @param cargaAEliminar: debe ser mayor a 0 y menor a lo disponible
	 * @throws Exception: da error si la carga a quitar no esta en rango
	 * post: descuenta la carga del ultimo vagon al primero
	 */
	public void quitarCarga(double cargaAQuitar) {
		ValidacionesUtiles.validarMayorACero(cargaAQuitar, "Carga a quitar");
		ValidacionesUtiles.validarVerdadero(getCarga() < cargaAQuitar, "No hay carga disponible");
		for(int i = this.vagones.getLongitud()-1; i >= 0; i--) {
			Vagon vagon = this.vagones.obtener(i);
			if (cargaAQuitar <= 0) {
				return;
			}
			if (vagon != null){
				double cargaActual = vagon.getCarga();
				if (cargaActual < cargaAQuitar) {
					vagon.vaciarVagon();
					cargaAQuitar -= cargaActual;
				} else {
					vagon.quitarCarga(cargaAQuitar);
					cargaAQuitar = 0;
				}
			}
		}
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * pre: -
	 * post: devuelve la cantidad de vagones actuales
	 */
	public int getCantidadDeVagones() {
		int resultado = 0;
		for(int i = 1; i <= this.vagones.getLongitud(); i++) {
			if (this.vagones.obtener(i) != null) {
				resultado++;
			}
		}
		return resultado;
	}
	
	/**
	 * pre: -
	 * @return: devuelve la capacidad de vagones que faltan agregar para llegar al maximo
	 */
	public int getCantidadDeVagonesFaltantes() {
		return this.getCantidadMaximaDeVagones() - this.getCantidadDeVagones();
	}
	
	/**
	 * pre: -
	 * post: devuelve la cantidad de vagones maxima
	 */
	public int getCantidadMaximaDeVagones() {
		return this.cantidadDeLocomotoras * getCantidadMaximaDeVagonesPorLocomotora();
	}

	/**
	 * pre: -
	 * @return devuelve la carga del tren, la suma de la carga de los vagones
	 */
	public double getCarga() {
		double resultado = 0;
		for(int i = 1; i <= this.vagones.getLongitud(); i++) {
			Vagon vagon = this.vagones.obtener(i);
			if (vagon != null) {
				resultado += vagon.getCarga();
			}
		}
		return resultado;
	}
	
	/**
	 * pre:
	 * @return devuelve la capacidad restante de carga posible a cargar
	 */
	public double getCapacidadDeCargaRestante() {
		double resultado = 0;
		for(int i = 1; i <= this.vagones.getLongitud(); i++) {
			Vagon vagon = this.vagones.obtener(i);
			if (vagon != null) {
				resultado += vagon.getCapacidadDeCargaRestante();
			}
		}
		return resultado;
	}

	/**
	 * pre: -
	 * @return: devuelve la capacidad de carga maxima del vagon.
	 */
	public double getCapacidadDeCargaMaxima() {
		double resultado = 0;
		for(int i = 1; i <= this.vagones.getLongitud(); i++) {
			Vagon vagon = this.vagones.obtener(i);
			if (vagon != null) {
				resultado += vagon.getCapacidadDeCargaMaxima();
			}
		}
		return resultado;
	}
	
	/**
	 * pre: -
	 * @return devuelve la cantidad de locomotoras
	 */
	public int getCantidadDeLocomotoras() {
		return this.cantidadDeLocomotoras;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	

	/**
	 * 
	 * @param cantidadDeLocomotoras
	 */
	private void setCantidadDeLocomotoras(int cantidadDeLocomotoras) {
		ValidacionesUtiles.validarMayorACero(cantidadDeLocomotoras, "Locomotora");
		this.cantidadDeLocomotoras = cantidadDeLocomotoras;
	}

	/**
	 * 
	 * @param cantidadMaximaDeVagonesPorLocomotora
	 */
	private void setCantidadMaximaDeVagonesPorLocomotora(int cantidadMaximaDeVagonesPorLocomotora) {
		ValidacionesUtiles.validarMayorACero(cantidadMaximaDeVagonesPorLocomotora, "Vagones por locomotora");
		this.cantidadMaximaDeVagonesPorLocomotora = cantidadMaximaDeVagonesPorLocomotora;
	}

	/**
	 * 
	 * @param cantidadMaximaDeLocomotoras
	 */
	public void setCantidadMaximaDeLocomotoras(int cantidadMaximaDeLocomotoras) {
		ValidacionesUtiles.validarMayorACero(cantidadDeLocomotoras, "Locomotora");
		this.cantidadMaximaDeLocomotoras = cantidadMaximaDeLocomotoras;
	}
	
}
