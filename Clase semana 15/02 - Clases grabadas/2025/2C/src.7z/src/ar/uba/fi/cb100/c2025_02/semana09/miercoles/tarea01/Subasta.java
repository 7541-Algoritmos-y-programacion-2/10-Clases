package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea01;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Subasta {
	
    private String articulo;
    private double precioBase = 0;
    //private Double[] ofertas = null;
    //private Vector<Double> ofertas = null;
    private Double ofertaMayor = null;
    private EstadoDeSubasta estado = EstadoDeSubasta.PENDIENTE;

    /**
     * Crea una subasta con el precio minimo indicado
     * @param articulo no null, entre 5 y 30 caracteres
     * @param precio mayor que cero
     */
    public Subasta(String articulo, 
    				double precio){
        setDescripcion(articulo);
        setPrecioBase(precio);
    }

    /**
     * @param articulo no null, entre 5 y 30 caracteres
     */
    public Subasta(String articulo){
        this(articulo, 0.0);
    }

    /**
     * 
     */
    @Override
    public String toString(){
        if (!hayOfertas()) {
        	return String.format("Subasta %s: Estado: %s, Minimo: %.2f, Aun no hay ofertas", articulo, estado, precioBase);
        }
        return String.format("Subasta %s: Estado: %s, Minimo: %.2f, Mejor Oferta: %.2f", articulo, estado, precioBase, getOfertaMayor());
    }

    /**
     * 
     * @return
     */
    public boolean hayOfertas() {
    	return this.ofertaMayor != null;
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || this.getClass() != o.getClass()){
            return false;
        }
        Subasta other = (Subasta) o;
        return this.articulo.equals(other.getArticulo());
    }

    /**
     * Abre una subasta, solo si esta en pendiente
     */
    public void abrirSubasta(){
        if(!this.estaPendiente()){
            throw new RuntimeException("Solo se puede abrir la subasta si esta pendiente");
        }
        this.estado = EstadoDeSubasta.ABIERTA;
    }

    /**
     * 
     * @return
     */
    public boolean estaPendiente() {
    	return this.estado == EstadoDeSubasta.PENDIENTE;
    }
    
    public boolean estaAbierta() {
    	return this.estado == EstadoDeSubasta.ABIERTA;
    }
    
    /**
     * Cierra una subasta, solo si esta abierta
     */
    public void cerrarSubasta(){
        if( !this.estaAbierta()) {
            throw new RuntimeException("Solo se puede cerrar una subasta si esta abierta");
        }
        this.estado = EstadoDeSubasta.CERRADA;
    }

    /**
     * @param oferta agrega la oferta al vector de ofertas, solo si es mayor al precio base
     */
    public double realizarOferta(double oferta){
    	if( !this.estaAbierta()) {
            throw new RuntimeException("No se puede ofertar, la subasta no esta abierta");
        }

        ValidacionesUtiles.validarRango(oferta, precioBase, Double.MAX_VALUE, "oferta");
        if ((this.ofertaMayor == null) ||
            (this.ofertaMayor < oferta)) {
        	this.ofertaMayor = oferta;
        }
        return this.ofertaMayor;
    }

    /**
     * @param descripcion no null, entre 5 y 30 caracteres
     */
    private void setDescripcion(String descripcion){
    	ValidacionesUtiles.esDistintoDeNull(descripcion, "Descripcion");
    	//ValidacionesUtiles.validarLongitudDeTexto(descripcion, 5, 30, "descripcion");
        this.articulo = descripcion;
    }

    /**
     * @param precioBase mayor que cero
     */
    private void setPrecioBase(double precioBase){
    	ValidacionesUtiles.validarMayorOIgualACero(precioBase, "precio");
        this.precioBase = precioBase;
    }

    /**
     * @return la descripcion de la subasta
     */
    public String getArticulo(){
        return this.articulo;
    }

    /**
     * @return el precio base de la subasta
     */
    public double getPrecioBase(){
        return precioBase;
    }

    /**
     * @return un vector identico a ofertas[]
     */
    public double getOfertaMayor(){
    	if (this.ofertaMayor == null) {
    		throw new RuntimeException("No hay oferta todavia");
    	}
        return this.ofertaMayor;
    }

    /**
     * @return el estado de la subasta
     */
    public EstadoDeSubasta getEstado(){
        return estado;
    }

}

