package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea01;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Moderador {
    private String nombre;


    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
    //ATRIBUTOS -----------------------------------------------------------------------------------------------
    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
    //CONSTRUCTORES -------------------------------------------------------------------------------------------
    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
    //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
    //METODOS DE CLASE ----------------------------------------------------------------------------------------
    //METODOS GENERALES ---------------------------------------------------------------------------------------
    //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

    /**
     * busca en la lista de foros el mensaje con promedio mas alto del usuario buscado en la tematica que se le pase
     * la tematica debe estar adentro del foro
     * @param foros no debe estar vacia, no ser null
     * @param autorBuscado debe estar dentro del foro de la tematica buscada, no ser null
     * @param tematicaBuscada no ser null
     * @return devuelve el mensaje mas votado del usuario usuario buscado del foro cuya tematica es tematicaBuscada
     */
    public Mensaje buscarMensajeMasVotadoDelUsuarioSegunTematica(List<Foro> foros, String autorBuscado, String tematicaBuscada){
        ValidacionesUtiles.esDistintoDeNull(autorBuscado,"autor buscado");
        ValidacionesUtiles.esDistintoDeNull(tematicaBuscada,"tematica buscada");
        ValidacionesUtiles.esDistintoDeNull(foros,"foros");

        List<Foro> forosValidos = forosConTematicaBuscada(foros,tematicaBuscada);
        Mensaje mensajeConMayorPromedio = null;
        List<Mensaje> mensajesDelUsuario = null;

            mensajesDelUsuario = obtenerMensajesDelUsuarioDeTodosLosForos(forosValidos,autorBuscado,tematicaBuscada);
            for (Mensaje mensaje : mensajesDelUsuario) {
                if (mensajeConMayorPromedio == null || mensaje.getPromedioDeVotos() > mensajeConMayorPromedio.getPromedioDeVotos()) {
                    mensajeConMayorPromedio = mensaje;
                }
            }

/**
        Mensaje mensajeMayor = null;
        for(Foro foro: foros) {
        	if (filtrarForo(foro)) {
        		Mensaje mensaje
        	}
        }
*/
        return mensajeConMayorPromedio;


    }


    /**
     * filtra los foros que no contienen a las tematicaBuscada
     * @param foros
     * @param tematicaBuscada
     * @return devuelve una lista nueva con los foros que contienen a la tematicaBuscada
     */
    public List<Foro> forosConTematicaBuscada(List<Foro> foros,String tematicaBuscada){
        List<Foro> forosValidos = new ListaSimplementeEnlazada<>();

        for(Foro foro : foros){
            if(foro.getTematicas().contains(tematicaBuscada))
                forosValidos.add(foro);
        }
        return forosValidos;
    }

    /**
     * obtiene los mensajes del usuario de los foros que le pasamos por parametro
     * @param forosValidos
     * @param autorBuscado
     * @return devuelve una lista nueva con los mensajes del usuario
     */
    public List<Mensaje> obtenerMensajesDelUsuarioDeTodosLosForos(List<Foro> forosValidos,String autorBuscado,String tematicaBuscada){
        List<Mensaje> mensajesDeUsuario = new ListaSimplementeEnlazada<>();

        for(Foro foro:forosValidos){
            mensajesDeUsuario.addAll(foro.obtenerMensajesDelUsuarioPorTematica(autorBuscado,tematicaBuscada));
        }
        return mensajesDeUsuario;
    }




    //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    //GETTERS SIMPLES -----------------------------------------------------------------------------------------
    //SETTERS COMPLEJOS----------------------------------------------------------------------------------------
    //SETTERS SIMPLES -----------------------------------------------------------------------------------------

}
