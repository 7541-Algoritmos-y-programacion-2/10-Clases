package ar.uba.fi.cb100.c2025_02.semana07.jueves;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Bateria {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private double cargaMaxima;
	private double consumoPromedioPorKilometro;
	private double cargaActual = 0;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea una bateria con carga maxima y consumo por kilometro y carga actual 0
	 * @param cargaMaxima: debe ser mayor a 0
	 * @param consumoPromedioPorKilometro: debe ser mayor a 0
	 */
	public Bateria(double cargaMaxima, double consumoPromedioPorKilometro) {		
		this.setCargaMaxima( cargaMaxima );
		this.setConsumoPromedioPorKilometro( consumoPromedioPorKilometro );
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Dado un valor de carga, lo suma a la carga actual
	 * @param carga
	 */
	public void cargar(double carga) {
		ValidacionesUtiles.validarMayorACero(carga, "Carga");
		if ((getCargaMaxima() - getCargaActual()) < carga) {
			throw new RuntimeException("La bateria no tiene capidad para esta carga: " + carga);
		}
		this.setCargaActual(this.getCargaActual() + carga);
	}
	
	/**
	 * Reduce la carga actual segun los kilometros recorridos, si es que hay capacidad
	 * @param kilometros
	 */
	public void desplazar(double kilometros) {
		ValidacionesUtiles.validarRango(kilometros, 0, getAutonomia(), "Autonomia");
		this.setCargaActual(this.getCargaActual() - (kilometros * this.getConsumoPromedioPorKilometro()));
	}
	
	/**
	 * Devuelve la autonomia de la bateria
	 * @return
	 */
	public double getAutonomia() {
		return this.cargaActual / this.consumoPromedioPorKilometro;
	}
	
	/**
	 * Devuelve verdadero si la bateria esta vacia
	 * @return
	 */
	public boolean estaVacia() {
		return this.cargaActual == 0;
	}
	
	/**
	 * Devuelve verdadero si la bateria esta llena
	 * @return
	 */
	public boolean estaLlena() {
		return this.cargaActual == this.cargaMaxima;
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public double getCargaMaxima() {
		return cargaMaxima;
	}

	public double getConsumoPromedioPorKilometro() {
		return consumoPromedioPorKilometro;
	}

	public double getCargaActual() {
		return cargaActual;
	}

//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	private void setCargaMaxima(double cargaMaxima) {
		ValidacionesUtiles.validarMayorACero(cargaMaxima, "Carga Maxima");
		this.cargaMaxima = cargaMaxima;
	}

	private void setConsumoPromedioPorKilometro(double consumoPromedioPorKilometro) {
		ValidacionesUtiles.validarMayorACero(consumoPromedioPorKilometro, "Consumo Promedio Por Kilometro");
		this.consumoPromedioPorKilometro = consumoPromedioPorKilometro;
	}

	private void setCargaActual(double cargaActual) {
		ValidacionesUtiles.validarMayorOIgualACero(cargaActual, "Carga");
		this.cargaActual = cargaActual;
	}	
	
	
}