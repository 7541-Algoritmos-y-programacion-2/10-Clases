package ar.uba.fi.cb100.c2025_02.semana03.miercoles;

import ar.uba.fi.cb100.c2025_02.semana01.jueves.PersonaConSalario;
import ar.uba.fi.cb100.c2025_02.semana02.jueves.Guia02;

public class Semana03_Miercoles {

	public static void imprimir() {
		PersonaConSalario personaConSalario = new PersonaConSalario("Gustavo", 45);
		personaConSalario.setSalario( -100 );
	}
	
	public static void main(String[] args) {
		//Caso 1: 
		String texto = "1859686";
		
		Integer entero = Integer.valueOf(texto);
		
		int entero2 = 65;
		
		//Casteo con copia en el stack
		int entero3 = entero2;
		char letra = (char) entero2; //'A'
		entero3++;
		System.out.println(letra);
		
		//Casteo de memoria en el heap
		int[] entero4 = new int[2];
		entero4[0] = 65;
		Character letra1 = (char) entero4[0];
		
		System.out.println(letra1);
		System.out.println(entero4[0]);
		
		entero4[0]++;
		
		System.out.println(letra1);
		System.out.println(entero4[0]);
		Guia02.imprimirVector( entero4);
		
		
		{
			PersonaConSalario personaConSalario = new PersonaConSalario("Gustavo", 45);
			personaConSalario.setSalario( -100 );
			
			//Este si
			if (personaConSalario.getSalario() >= 10) {
				System.out.println( personaConSalario.getSalario() );	
			}
			
			//Este no
			if (personaConSalario.getSalario() >= 10) 
				System.out.println( personaConSalario.getSalario() );
		}	
				
		System.out.println(letra1);
	}

}
