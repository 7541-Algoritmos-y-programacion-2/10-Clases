package ar.uba.fi.cb100.c2025_02.semana14.jueves.parcial;

public class CorreoElectronico {
    private Servidor servidor;     
    private String asunto;
    private int copias;
    public CorreoElectronico(Servidor servidor, String asunto, int copias){
        this.servidor = servidor; 
        this.asunto = asunto;
        this.copias = copias;
    }
    public Servidor getServidor() {
        return servidor;
    }
    public String getAsunto() {
        return asunto;
    }
    public int getCopias() {
        return copias;
    }}

