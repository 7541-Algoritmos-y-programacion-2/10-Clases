package ar.uba.fi.cb100.c2025_02.material.json;

public class SubConfiguracionDeJuego {

	private int cantidadDeCartas;

	public int getCantidadDeCartas() {
		return cantidadDeCartas;
	}

	public void setCantidadDeCartas(int cantidadDeCartas) {
		this.cantidadDeCartas = cantidadDeCartas;
	}
	
	
}
