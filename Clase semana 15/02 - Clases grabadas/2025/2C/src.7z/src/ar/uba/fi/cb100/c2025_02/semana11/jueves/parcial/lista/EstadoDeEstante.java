package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista;

public enum EstadoDeEstante {
	EN_USO,
	EN_REPARACION
}
