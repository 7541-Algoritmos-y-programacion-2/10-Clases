package ar.uba.fi.cb100.c2025_01.semana08.miercoles.ahorcado;

import ar.uba.fi.cb100.c2025_01.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;
//import java.util.Vector NO ESTE CUATRI

public class Ahorcado {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private EstadoDeAhorcado estado = EstadoDeAhorcado.Jugando;
	private int cantidadDeErroresCometidos = 0;
	private int cantidadDeErroresPermitidos = 0;
	private String palabraAAdivinar = null;
	private Vector<Character> letrasArriesgadas = null;

//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un juego del ahorcado con la palabra a adivinar y la cantidad maxima de errores permitidos
	 * @param palabraAAdivinar: no puede ser nula y tiene que tener al menos 1 caracter
	 * @param cantidadDeErroresPermitidos: cantidad maxima de errores permitidos
	 */
	public Ahorcado(String palabraAAdivinar, 
						int cantidadDeErroresPermitidos) {
		ValidacionesUtiles.validarNoNulo(palabraAAdivinar, "Palabra a adivinar");
		ValidacionesUtiles.validarMayorACero(palabraAAdivinar.length(), "Longitud de la palabra a adivinar");
		ValidacionesUtiles.validarMayorOIgualCero(cantidadDeErroresPermitidos, "Cantidad de errores permitidos");
		this.palabraAAdivinar = palabraAAdivinar;
		this.cantidadDeErroresPermitidos = cantidadDeErroresPermitidos; 
		this.letrasArriesgadas = new Vector<Character>(this.palabraAAdivinar.length() + this.cantidadDeErroresPermitidos, null);
	}

//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Devuelve la cantidad de letras de la palabra a adivinar
	 * @return
	 */
	public int getLongitudDeLaPalabraAAdivinar() {
		return this.palabraAAdivinar.length();
	}
	
	/**
	 * Propone una letra, 
	 * @param letra: no puede ser ni nulo ni vacio. Debe estar en el rango de A a Z
	 * @return
	 */
	public int proponerLetra(char letra) {
		ValidacionesUtiles.validarNoNulo(letra, "Letra");
		ValidacionesUtiles.esUnaLetra(letra, "Letra");
		validarEstadoJugando();
		this.letrasArriesgadas.agregar(letra);
		if (this.palabraAAdivinar.contains("" + letra)) {			
			//return this.palabraAAdivinar.split("" + letra).length - 1;
			return Long.valueOf(this.palabraAAdivinar.chars().filter( c -> c == letra).count()).intValue();
		}
		this.cantidadDeErroresCometidos++;
		if (this.cantidadDeErroresCometidos > this.cantidadDeErroresPermitidos) {
			this.estado = EstadoDeAhorcado.Perdido;
		}
		return 0;
	}
	
	/**
	 * Arriesga una palabra para terminar el juego, si la adivina queda el estado ganado y devuelve
	 * verdadero, o sino falso y queda perdido el juego
	 * @param palabra
	 * @return
	 */
	public boolean arriesgar(String palabra) {
		validarEstadoJugando();
		if (this.palabraAAdivinar.equals(palabra)) {
			this.estado = EstadoDeAhorcado.Ganado;
			return true;
		} 
		this.estado = EstadoDeAhorcado.Perdido;
		return false;
	}
	
	/**
	 * Devuelve verdadero si esta jugando
	 * @return
	 */
	public boolean estaJugando() {
		return this.estado.equals(EstadoDeAhorcado.Jugando);
	}
	
	/**
	 * Si no esta el estado jugando, lanza una excepcion
	 */
	private void validarEstadoJugando() {
		if (!this.estaJugando()) {
			throw new RuntimeException("Solo se puede proponer una letra mientras se esta jugando");
		}
	}
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el estado actual del juego
	 * @return
	 */
	public EstadoDeAhorcado getEstado() {
		return estado;
	}

	/**
	 * devuelve la cantidad de errores cometidos
	 * @return
	 */
	public int getCantidadDeErroresCometidos() {
		return cantidadDeErroresCometidos;
	}

	/**
	 * devuelve la cantidad de errores maximos permitidos
	 * @return
	 */
	public int getCantidadDeErroresPermitidos() {
		return cantidadDeErroresPermitidos;
	}

	/**
	 * Devuelve la palabra a adivinar si el estado del juego es Ganado o Perdido
	 * @return
	 */
	public String getPalabraAAdivinar() {
		if (!this.estaJugando()) {
			return palabraAAdivinar;
		}
		//return "";
		String resultado = "";
		for(int i = 0; i < this.palabraAAdivinar.length(); i++) {
			Character letra = this.palabraAAdivinar.charAt(i);
			if (this.letrasArriesgadas.contiene(letra)) {
				resultado += letra;
			} else {
				resultado += "*";
			}
		}
		return resultado;
	}

	
	public Vector<Character> getLetrasArriesgadas() {
		return new Vector<Character>(this.letrasArriesgadas);
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}