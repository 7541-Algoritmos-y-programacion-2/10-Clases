package ar.uba.fi.cb100.c2025_01.semana04.jueves;

/**
 * Escribir la clase Alimento. Un alimento tiene un nombre y una cantidad de 
 * calorias asociadas cada 100 gramos. Hacer un main
 * @param args
 */
public class Alimento {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private String nombre = null;
	private double caloriasPorGramo = 0;

//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Dado un nombre se crea un alimento con calorias por gramo en 0
	 * @param nombre: no puede ser vacio
	 */
	public Alimento(String nombre) {
		this.setNombre(nombre);
	}
	
	/**
	 * 
	 * @param nombre
	 * @param caloriasPorGramo
	 */
	public Alimento(String nombre, double caloriasPorGramo) {
		this(nombre);
		this.setCaloriasPorGramo( caloriasPorGramo );
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Alimento: " + this.nombre + " (" + this.getCaloriasPor100Gramos() + " cal./100gr.)";
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Valida el nombre, si es vacio o no supera los 2 caracteres, da error
	 * @param nombre
	 */
	private void validarNombre(String nombre) {
		if (nombre == null) {
			throw new RuntimeException("El nombre no puede ser vacio");
		}
		nombre = nombre.trim();
		if (nombre.isEmpty()) {
			throw new RuntimeException("El nombre no puede ser vacio o tener espacios");
		}
		if (nombre.length() <= 1) {
			throw new RuntimeException("El nombre tiene que tener al menos 2 caracteres");	
		}
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	/**
	 * Devuelve las calorias por 100 gramos
	 * @return
	 */
	public double getCaloriasPor100Gramos() {
		return getCaloriasPorGramo() * 100.0;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * devuelve el nombre del alimento
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}
	
	/**
	 * devuelve las calorias del alimento
	 * @return
	 */
	public double getCaloriasPorGramo() {
		return caloriasPorGramo;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	
	/**
	 * Cambia el nombre del alimento
	 * @param nombre: no puede ser vacio
	 */
	public void setNombre(String nombre) {
		validarNombre(nombre);
		this.nombre = nombre;
	}
	
	/**
	 * Cambia las calorias del alimento
	 * @param caloriasPorGramo: 0 o mayor
	 */
	public void setCaloriasPorGramo(double caloriasPorGramo) {
		if (caloriasPorGramo < 0) {
			throw new RuntimeException("Las calorias deben ser mayor o igual a 0");
		}
		this.caloriasPorGramo = caloriasPorGramo;
	}
	
	/**
	 * cambia las calorias del alimiento por 100 gramos
	 * @param caloriasPor100Gramos: valor 0 o positivo
	 */
	public void setCaloriasPor100Gramos(double caloriasPor100Gramos) {
		setCaloriasPorGramo( caloriasPor100Gramos / 100.0);
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
