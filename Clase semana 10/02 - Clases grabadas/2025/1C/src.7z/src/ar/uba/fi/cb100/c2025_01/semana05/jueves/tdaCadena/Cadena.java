package ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena;

public class Cadena {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Eslabon[] eslabones = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param cantidadMaximaDeEslabones
	 * @param largoDelEslabon
	 */
	public Cadena(int cantidadMaximaDeEslabones, Eslabon eslabon) {
		ValidacionesUtiles.validarMayorACero(cantidadMaximaDeEslabones, "cantidad maxima de eslabones");
		ValidacionesUtiles.validarNoNulo(eslabon, "eslabon");
		this.eslabones = new Eslabon[cantidadMaximaDeEslabones];
		for(int i = 0; i < this.getCantidadMaximaDeEslabones(); i++) {
			this.eslabones[i] = null;
		}
		this.eslabones[0] = eslabon;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Agrega el eslabon y devuelve la posicion en la cadena (entre 1 y n)
	 * @param eslabon: no puede ser nulo y debe tener el mismo ancho que la cadena
	 */
	public int agregarEslabon(Eslabon eslabon) {
		ValidacionesUtiles.validarNoNulo(eslabon, "eslabon");
		if (this.estaLlena()) {
			throw new RuntimeException("La cadena ya esta llena");
		}
		ValidacionesUtiles.validarIgualdad(eslabon.getAncho(), this.getAncho(), "anchos");
		this.eslabones[this.getCantidadDeEslabones()] = eslabon;
		return this.getCantidadDeEslabones();
	}
	
	/**
	 * Devuelve el ultimo eslabon de la cadena, y lo quita de la cadena
	 * @return
	 */
	public Eslabon retirarEslabon() {
		if (this.getCantidadDeEslabones() <= 1) {
			throw new RuntimeException("La cadena no puede quedar con menos de 1 eslabon");
		}
		Eslabon resultado = this.eslabones[this.getCantidadDeEslabones() - 1];
		this.eslabones[this.getCantidadDeEslabones() - 1] = null;
		return resultado;
	}
	
	/**
	 * Devuelve un eslabon de la cadena en la posicion posicion
	 * @param posicion: debe estar en el rango de 1 y largo de la cadena
	 * @return
	 */
	public Eslabon getEslabon(int posicion) {
		if (this.getCantidadDeEslabones() < posicion) {
			throw new RuntimeException("El eslabon " + posicion + " no esta dentro de la cadena");
		}
		ValidacionesUtiles.validarMayorACero(posicion, "posicion");
		return this.eslabones[posicion - 1];
	}

	/**
	 * 
	 * @return
	 */
	public boolean estaLlena() {
		return this.getCantidadDeEslabones() == this.getCantidadMaximaDeEslabones();
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la cantidad maxima de eslabones que puede almacenar la cadena. Es la capacidad de la cadena.
	 * @return
	 */
	public int getCantidadMaximaDeEslabones() {
		return this.eslabones.length;
	}
	
	/**
	 * Devuelve la cantidad actual de eslabones
	 * @return
	 */
	public int getCantidadDeEslabones() {
		for(int i = 0; i < this.eslabones.length; i++) {
			if (this.eslabones[i] == null) {
				return i;
			}
		}
		return this.eslabones.length;
	}
	
	/**
	 * Devuelve la longitud de toda la cadena
	 * @return
	 */
	public double getLongitud() {
		double resultado = 0;
		for(int i = 0; i < this.getCantidadDeEslabones(); i++) {
			resultado += this.eslabones[i].getLargo();
		}
		return resultado;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el ancho de la cadena
	 * @return
	 */
	public double getAncho() {
		return this.eslabones[0].getAncho();
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}
