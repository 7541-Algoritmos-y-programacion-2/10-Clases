package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

import java.util.Objects;

public class Auto extends Object implements Vehiculo {

	private String modelo = null;
	
	public Auto(String modelo) {
		this.modelo = modelo;
	}
	@Override
	public void arrancar() {
		System.out.println("El auto arranca");
	}

	@Override
	public void detener() {
		System.out.println("El auto se detiene");		
	}

	@Override
	public void acelerar() {
		System.out.println("El auto acelera");
	}
	
	public void abrirPuerta() {
		System.out.println("El auto abre la puerta");
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(modelo);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Auto other = (Auto) obj;
		return Objects.equals(modelo, other.modelo);
	}
	
	
	
}
