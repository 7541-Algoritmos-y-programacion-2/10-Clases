package ar.uba.fi.cb100.c2025_01.semana10.tarea2;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Imagen {
    private ListaSimplementeEnlazada<Comentario> comentarios;
    private String url;
    private Double promedio = null;
    
    public Imagen(String url){
        ValidacionesUtiles.validarNoNulo(url, "url");
        this.url = url;
        this.comentarios = new ListaSimplementeEnlazada<Comentario>();
    }

    public List<Comentario> getComentarios(){
        List<Comentario> resultado = new ListaSimplementeEnlazada<Comentario>();
        resultado.addAll(this.comentarios);
        return resultado;
    }
    
    public List<Comentario> getComentariosCalificados(){
    	List<Comentario> resultado = new ListaSimplementeEnlazada<Comentario>();
    	for(Comentario comentario: this.comentarios) {
    		if (comentario.tieneCalificacion()) {
    			resultado.add(comentario);
    		}
    	}
        return resultado;
    }

    public void agregarComentario(Comentario comentario) {
    	this.getComentarios().add(comentario);
    	this.promedio = null;
    }
    
    public String getUrl(){
        return this.url;
    }

    public double getPromedioDeCalificaciones() {
    	if (this.promedio == null) {
    		//calculamos
    		
    	}
    	return promedio;
    }


}
