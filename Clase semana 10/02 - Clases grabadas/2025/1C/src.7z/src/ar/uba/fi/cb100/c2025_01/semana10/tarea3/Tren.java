package ar.uba.fi.cb100.c2025_01.semana10.tarea3;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Tren {
	
	// ATRIBUTOS
	
	//private Locomotora[] locomotoras = new Locomotora[3];
	private Vagon[] vagones = null;
	private int cantidadDeLocomotoras = 1;
	private int cantidadMaximaDeLocomotoras;
	
	// CONSTRUCTORES
	
	/**
	 * Se crea un tren con una locomotora vacía
	 */
	public Tren(int cantidadMaximaDeVagonesPorLocomotora, int cantidadMaximaDeLocomotoras) {
		ValidacionesUtiles.validarMayorOIgual(cantidadMaximaDeLocomotoras, 1, "Cantidad maxima de locomotoras");
		this.cantidadMaximaDeLocomotoras = cantidadMaximaDeLocomotoras;
		this.vagones = new Vagon[cantidadMaximaDeVagonesPorLocomotora * cantidadMaximaDeLocomotoras];
		for(int i = 0; i < this.vagones.length; i++) {
			this.vagones[i] = null;
		}
	}
	
	// METODOS DE COMPORTAMIENTO
	
	/**
	 * Se agrega una locomotora al tren
	 */
	public void agregarLocotomotora() {
		if(this.getCantidadDeLocomotoras() >= this.getCantidadMaximaDeLocomotoras()) {
			throw new RuntimeException("Cantidad de locomotoras excedida");
		}
		
		this.cantidadDeLocomotoras++;
	}
	
	/**
	 * Se agrega un vagón a la locomotora que tenga disponibilidad.
	 * @param vagon
	 */
	public void agregarVagon(Vagon vagon) {
		ValidacionesUtiles.validarNoNulo(vagon, "Vagon");
		ValidacionesUtiles.validarVerdadero(!vagon.estaVacio(), "Vagon");
		if (this.estaCompleto()) {
			throw new RuntimeException("El tren esta completo");
		}
		this.vagones[this.getCantidadDeVagones()] = vagon;
	}
	
	
	private boolean estaCompleto() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * Se retira el ultimo vagón del tren.
	 * @return
	 */
	public Vagon retirarVagon() {
		ValidacionesUtiles.validarVerdadero( !this.vagones[this.getCantidadDeVagones()-1].estaVacio(), "Vacio");
		Vagon resultado = this.vagones[this.getCantidadDeVagones()-1];
		this.vagones[this.getCantidadDeVagones()-1]= null;
		return resultado;
	}
	
	/**
	 * Se agrega carga en el tren. La misma es distribuida entre las locomotoras.
	 * @param cantidad
	 */
	public void agregarCarga(double carga) {
		ValidacionesUtiles.validarMayorOIgual(getCapacidadDisponible(), carga, "Carga");
		for(int i = this.getCantidadDeVagones(); i < this.getCantidadDeVagonesMaxima(); i++) {
			if (carga > 0) {
				carga = this.vagones[i].cargarFaltante(carga);
			}			
		}
	}
	
	private double getCapacidadDisponible() {
		// TODO Auto-generated method stub
		return 0.0;
	}

	public void retirarCarga(double carga) {
		ValidacionesUtiles.validarMayorOIgual(getCantidadCargada(), carga, "Carga");
		for(int i = this.getCantidadDeVagones(); i > 0; i--) {
			if (carga > 0) {
				carga = this.vagones[i].descargarConSobrante(carga);
			}			
		}
	}
	// GETTERS COMPLEJOS
	
	/**
	 * Devuelve la capacidad maxima del tren.
	 * @return
	 */
	public int getCapacidadMaxima() {
		int capacidadMaxima = 0;
		
		for(int i = 0; i < getCantidadDeLocomotoras(); i++) {
			//capacidadMaxima += this.locomotoras[i].obtenerCargaMaxima();
		}
		
		return capacidadMaxima;
	}
	
	/**
	 * Devuelve la capacidad cantidad cargada en el tren.
	 * @return
	 */
	public int getCantidadCargada() {
		int cantidadCargada = 0;
		
		for(int i = 0; i < getCantidadDeLocomotoras(); i++) {
			//cantidadCargada += this.locomotoras[i].obtenerCarga();
		}
		
		return cantidadCargada;
	}
	
	/**
	 * Devuelve la capacidad restante de carga.
	 * @return
	 */
	public int getRestante() {
		int capacidadRestante = 0;
		
		for(int i = 0; i < getCantidadDeLocomotoras(); i++) {
			//capacidadRestante += this.locomotoras[i].obtenerCargaMaxima() - this.locomotoras[i].obtenerCarga();
		}
		
		return capacidadRestante;
	}
	
	/**
	 * Devuelve la cantidad de locomotoras.
	 * @return
	 */
	public int getCantidadDeLocomotoras() {
		
		int cantidadDeLocomotoras = 0;
		
//		for(int i=0; i < this.locomotoras.length; i++) {
//			if(locomotoras[i] != null) {
//				cantidadDeLocomotoras++;
//			}
//		}
		
		return cantidadDeLocomotoras;
	}

	public int getCantidadMaximaDeLocomotoras() {
		return cantidadMaximaDeLocomotoras;
	}

	public void setCantidadDeLocomotoras(int cantidadDeLocomotoras) {
		this.cantidadDeLocomotoras = cantidadDeLocomotoras;
	}

	public void setCantidadMaximaDeLocomotoras(int cantidadMaximaDeLocomotoras) {
		this.cantidadMaximaDeLocomotoras = cantidadMaximaDeLocomotoras;
	}
	
	public int getCantidadDeVagonesMaxima() {
		return this.vagones.length / this.cantidadMaximaDeLocomotoras * this.cantidadDeLocomotoras;
	}
	
	public int getCantidadDeVagones() {
		int cantidad = 0;
		for(Vagon vagon: this.vagones) {			
			if (vagon == null) {
				return cantidad;
			}
			cantidad++;
		}
		return cantidad;
	}
	
}
