package ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TestDeCadena {

	private static Cadena cadena = null;
	
	@BeforeAll
	public static void inicializar() {
		cadena = new Cadena(10, new Eslabon(10, 15));
	}
	
	@Test
	public void testearAncho() {
		assertEquals(15, cadena.getAncho(), "El ancho no corresponde");
	}
	
	@Test
	public void testearNuevoEslabonDeOtroAncho() {
		assertThrows(RuntimeException.class, () -> {
			cadena.agregarEslabon(new Eslabon(12, 16));
		}, "No se puede agregar el eslabon");
	}
	
	@Test
	public void testearLargo() {
		assertEquals(10, cadena.getLongitud(), "El largo no corresponde");
		cadena.agregarEslabon(new Eslabon(13, 15));
		assertEquals(23, cadena.getLongitud(), "El largo no corresponde");
	}
}
