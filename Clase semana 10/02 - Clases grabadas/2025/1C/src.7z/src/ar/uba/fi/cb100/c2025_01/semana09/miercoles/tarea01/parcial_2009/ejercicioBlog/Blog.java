package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.parcial_2009.ejercicioBlog;

import java.util.List;
import java.util.stream.Collectors;

import ar.uba.fi.cb100.c2025_01.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;


public class Blog {

	//ATRIBUTOS ----------------------------------------------------------------------------------------------
	
	private List<Articulo> articulos = null;

	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un blog sin articulos.
	 *  
	 */
	public Blog() {
		this.articulos = new ListaSimplementeEnlazada<Articulo>();
	}

	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Dado un articulo, se agrega al blog.
	 * @param articulo: Articulo a agregar
	 */
	public void agregarArticulo(Articulo articulo) {
		ValidacionesUtiles.validarNoNulo(articulo, "El articulo");
		this.getArticulos().add(articulo);
	}
	
	
	/**
	 * Dada palabra clave y un rango de calificaciones. Devuelve una lista de artículos
	 * @param palabraClave: Palabra clave a buscar.
	 * @param calificadaDesde: Mínimo de calificación.
	 * @param calificadaHasta: Máximo de calificación.
	 * 
	 * @return
	 */
	public List<Articulo> buscarArticulos(String palabraClave, int calificadaDesde, int calificadaHasta) {
		ValidacionesUtiles.validarRango(1, calificadaDesde, 10, "El mínimo de calificación");
		ValidacionesUtiles.validarRango(1, calificadaHasta, 10, "El máximo de calificación");
		//ValidacionesUtiles.validarNoNulo(palabraClave, "La palabra clave");
		
		List<Articulo> articulosFiltrados = this.articulos.stream().
				filter(articulo -> articulo.contienePalabraCable(palabraClave) &&
						articulo.obtenerPromedioDeCalificaciones() >= calificadaDesde &&
						articulo.obtenerPromedioDeCalificaciones() <= calificadaHasta)
				.collect(Collectors.toList());
		
		
		return articulosFiltrados;
	}
	
	/**
	 * Version 2 del parcial
	 * @param palabraClave
	 * @param calificadaDesde
	 * @param calificadaHasta
	 * @return
	 */
	public List<Articulo> buscarArticulos1(String palabraClave, int calificadaDesde, int calificadaHasta) {
		ValidacionesUtiles.validarRango(1, calificadaDesde, 10, "El mínimo de calificación");
		ValidacionesUtiles.validarRango(1, calificadaHasta, 10, "El máximo de calificación");
		//ValidacionesUtiles.validarNoNulo(palabraClave, "La palabra clave");
		
		List<Articulo> articulosFiltrados = new ListaSimplementeEnlazada<Articulo>();
		
		for(Articulo articulo: getArticulos()) {
			if (articulo.contienePalabraCable(palabraClave) &&	
				articulo.obtenerPromedioDeCalificaciones() >= calificadaDesde &&
				articulo.obtenerPromedioDeCalificaciones() <= calificadaHasta) { 
				articulosFiltrados.add(articulo);					
			}
		}
		return articulosFiltrados;
	}
	

	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve los articulos del Blog.
	 * @return
	 */
	public List<Articulo> getArticulos(){
		return this.articulos;
	}
	
}
