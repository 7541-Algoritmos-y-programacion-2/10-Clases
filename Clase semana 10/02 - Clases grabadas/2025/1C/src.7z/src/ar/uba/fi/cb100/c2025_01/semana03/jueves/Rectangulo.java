package ar.uba.fi.cb100.c2025_01.semana03.jueves;

public class Rectangulo extends Object {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private double base;
	private double altura;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param base: valor mayor que 0 para la base del rectangulo
	 * @param altura: valor mayor que 0 para la altura del rectangulo
	 * @throws RuntimeException
	 */
	public Rectangulo(double base, double altura) throws RuntimeException {
		this.setBase(base);
		this.setAltura(altura);
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param base
	 */
	public static void validarBase(double base) {
		if (base <= 0) {
			throw new RuntimeException("La base debe ser mayor a 0 y se quiere asignar " + base);
		}
	}
	
	/**
	 * 
	 * @param altura
	 */
	public static void validarAltura(double altura) {
		if (altura <= 0) {
			throw new RuntimeException("La altura debe ser mayor a 0 y se quiere asignar " + altura);
		}
	}
	
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	/**
	 * 
	 */
	@Override
	public String toString() {
		return "Rectangulo de " + this.base + " por " + this.altura;
	}
	
	@Override
    public boolean equals(Object obj) {
		Rectangulo rectangulo = (Rectangulo) obj;
		return this.base == rectangulo.base &&
			   this.altura == rectangulo.altura;
    }
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * 
	 * @return devuelve el perimetro calculado con 2 * altura + 2 * base = perimetro
	 */
	public double getPerimetro() {
		return 2 * this.altura + 2 * this.base;
	}
	
	/**
	 * 
	 * @return devuelve el area, calculada con base por altura
	 */
	public double getArea() {
		return this.altura * this.base;
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @return: devuelve el valor de la base actual
	 */
	public double getBase() {
		return base;
	}
	
	/**
	 * 
	 * @return: devuelve el valor de la altura actual
	 */
	public double getAltura() {
		return altura;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	
	/**
	 * Con este metodo se cambia la base del rectangulo actual por base
	 * 
	 * @param base: es el valor de la base. El rango es mayor que 0.
	 * @throws RuntimeException: sino se cumple con el rango de la base
	 */
	public void setBase(double base) throws RuntimeException {
		validarBase(base);
		this.base = base;
	}

	/**
	 * Con este metodo se cambia la altura del rectangulo actual por altura
	 * 
	 * @param altura: es el valor de la altura. El rango es mayor que 0.
	 * @throws RuntimeException: sino se cumple con el rango de la base
	 */
	public void setAltura(double altura) throws RuntimeException {
		validarAltura(altura);
		this.altura = altura;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
