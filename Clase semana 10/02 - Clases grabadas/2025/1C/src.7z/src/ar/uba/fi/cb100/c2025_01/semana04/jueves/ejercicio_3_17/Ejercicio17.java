package ar.uba.fi.cb100.c2025_01.semana04.jueves.ejercicio_3_17;

public class Ejercicio17 {

	/**
	 * Escribir la clase Alimento. Un alimento tiene un nombre y una cantidad de 
	 * calorias asociadas cada 100 gramos. Hacer un main
	 * @param args
	 */
	public static void main(String[] args) {
		
	}
}
