package ar.uba.fi.cb100.c2025_01.estructuras.bitmap;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;

public class TestBitmap {
    public static void main(String[] args) {
        try {
            Bitmap bmp = new Bitmap(300, 300);

            // Dibuja un píxel
            bmp.drawPixel(10, 10, Color.RED);

            // Dibuja una línea
            bmp.drawLine(20, 20, 100, 100, Color.BLUE);

            // Dibuja un rectángulo
            bmp.drawRectangle(50, 50, 100, 80, Color.GREEN);

            // Dibuja un círculo
            bmp.drawCircle(150, 150, 40, Color.MAGENTA);

            // Escribe un texto
            bmp.drawText("Hola Bitmap!", 10, 200, new Font("Arial", Font.BOLD, 14), Color.BLACK);

            // Carga una imagen externa y la pega
            Bitmap ficha = Bitmap.loadFromFile("./src/ar/uba/fi/cb100/material/bitmap/ficha.bmp");  // Requiere un archivo ficha.png en el mismo directorio
            bmp.pasteBitmap(ficha, 200, 200);

            // Guarda la imagen
            bmp.saveToFile("resultado.bmp");

            
            bmp = new Bitmap(400, 400);
            bmp.drawCube(100, 0, 0, 300, Color.BLUE);
            bmp.drawCube(50, 100, 50, 200, Color.RED);
            System.out.println(bmp.saveToFile("cubo3d.bmp"));

            System.out.println("Cubo 3D dibujado y guardado como cubo3d.png");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
