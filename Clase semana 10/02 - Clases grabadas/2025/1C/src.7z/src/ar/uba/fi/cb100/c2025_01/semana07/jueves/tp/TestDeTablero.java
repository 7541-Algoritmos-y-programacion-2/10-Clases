package ar.uba.fi.cb100.c2025_01.semana07.jueves.tp;

public class TestDeTablero {

	public static void main(String[] args) {
		TableroV1<Sector> tablero = new TableroV1<Sector>(5, 8, Sector.class);
	
		for(int i = 0; i < tablero.getAncho(); i++) {
			for(int j = 0; j < tablero.getAlto(); j++) {
				tablero.getCasillero(i, j).setDato(new Sector());
			}
		}
		
		//Sector
		//tablero.getDato(5, 8).setNave (...)
	}
}
