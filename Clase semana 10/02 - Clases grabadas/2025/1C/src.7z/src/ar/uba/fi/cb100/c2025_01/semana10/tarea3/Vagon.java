package ar.uba.fi.cb100.c2025_01.semana10.tarea3;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Vagon {

	// ATRIBUTOS

	private int capacidadMaximaDeCarga = 0;
	private int cantidadCargada = 0;

	// CONSTRUCTORES

	/**
	 * Dada una capacidad máxima, se crea un vagón.
	 * @param capacidadMaxima
	 */
	public Vagon(int capacidadMaxima) {
		setCapacidadMaximaDeCarga(capacidadMaxima);
	}

	// METODOS DE COMPORTAMIENTO
	
	/**
	 * Se agrega carga al vagón.
	 * @param cantidad
	 */
	public void cargar(double cantidad) {
		if(seExcedeLaCapacidad(cantidad)) {
			throw new RuntimeException("Capacidad de carga excedida");
		}

		this.cantidadCargada += cantidad;
	}

	public double cargarFaltante(double carga) {
		if(seExcedeLaCapacidad(carga)) {
			carga -= getCapacidadDisponible();
			cargar(getCapacidadDisponible());
			return carga;
		}
		cargar(carga);
		return 0;
	}
	
	private boolean seExcedeLaCapacidad(double carga) {
		// TODO Auto-generated method stub
		return false;
	}

	public double descargar(double carga) {
		ValidacionesUtiles.validarMayorOIgual(this.getCantidadCargada(), carga,"Supera la carga");
		this.cantidadCargada -= carga;
		return this.cantidadCargada;
	}
	
	public double descargarConSobrante(double carga) {
		//ValidacionesUtiles.validarMayorOIgual(this.getCantidadCargada(), carga,"Supera la carga");
		if (carga > this.cantidadCargada) {
			carga = carga - this.cantidadCargada;
			this.cantidadCargada = 0;
			return carga;
		}
		this.cantidadCargada -= carga;
		return 0;
	}
	
	/**
	 * Dada una cantidad devuelve true si se excede la capacidad disponible.
	 * @param cantidad
	 * @return
	 */
	public boolean seExcedeLaCapacidad(int cantidad) {
		return (cantidad > this.getCapacidadDisponible());
	}

	/**
	 * Devuelve true si la carga es 0.
	 * @return
	 */
	public boolean estaVacio() {
		return this.getCantidadCargada() == 0;
	}

	// GETTERS SIMPLES
	
	/**
	 * Devuelve la cantidad disponible de cargar.
	 * @return
	 */
	public int getCapacidadDisponible() {
		return this.getCapacidadMaximaDeCarga() - this.getCantidadCargada();
	}

	/**
	 * @return capacidadMaximaDeCarga
	 */
	public int getCapacidadMaximaDeCarga() {
		return this.capacidadMaximaDeCarga;
	}

	/**
	 * @return cantidadCargada
	 */
	public int getCantidadCargada() {
		return this.cantidadCargada;
	}

	// SETTERS SIMPLES

	/**
	 * @param capacidadMaximaDeCarga: capacidad maxima de carga a establecer
	 */
	private void setCapacidadMaximaDeCarga(int capacidadMaximaDeCarga) {
		ValidacionesUtiles.validarMayorACero(capacidadMaximaDeCarga, "La capacidad maxima de carga");
		this.capacidadMaximaDeCarga = capacidadMaximaDeCarga;
	}
}
