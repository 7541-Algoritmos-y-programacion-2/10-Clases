package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.ejercicioTostadora;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Tostadora {

	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private EstadoDeTostadora estado = EstadoDeTostadora.Apagada;
	private RanuraDeTostado[] ranuras = null;
	private int nivelDeCalor = 0;

	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Dada una cantidad N de ranuras, se crea una tostadora de N ranuras.
	 * 
	 * @param cantidadDeRanuras: Cantidad de ranuras de la tostadora a crear
	 */
	public Tostadora(int cantidadDeRanuras) {
		ValidacionesUtiles.validarMayorACero(cantidadDeRanuras, "La cantidad de Ranuras");
		this.ranuras = new RanuraDeTostado[cantidadDeRanuras];
		inicializarRanuras(cantidadDeRanuras);
		
	}

	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Dada una cantidad de ranuras, se crean las ranuras con su numero correspondiente.
	 * 
	 * @param cantidadDeRanuras: Cantidad de ranuras de la tostadora
	 */
	private void inicializarRanuras(int cantidadDeRanuras) {
		for(int i = 0; i < cantidadDeRanuras; i++) {
			ranuras[i] = new RanuraDeTostado(i+1);
		}
		
	}
	
	/**
	 * Dado un nivel de calor inicial, se enciende la tostadora.
	 * 
	 * @param nivelDeCalor: Nivel de calor al encender, siendo 0 mínimo y 10 máximo.
	 */
	public void encenderTostadora() {
		encenderTostadora(null);
	}
		
	public void encenderTostadora(Integer nivelDeCalor) {
		ValidacionesUtiles.validarVerdadero(estaApagada(), "La tostadora ya esta encendida");
		if (nivelDeCalor != null) {
			setNivelDeCalor(nivelDeCalor);
		}
		this.estado = EstadoDeTostadora.Encendida;
	}
	
	/**
	 * Se apaga la tostadora.
	 * 
	 */
	public void apagarTostadora() {
		ValidacionesUtiles.validarVerdadero(!estaApagada(), "La tostadora ya esta apagada");
		this.estado = EstadoDeTostadora.Apagada;
		for(RanuraDeTostado ranuraDeTostado: this.ranuras) {
			ranuraDeTostado.finalizarTostado();
		}
	}
	
	
	/**
	 * Dada una ranura a utilizar, se inicia el tostado.
	 * 
	 * @param ranuraAUtilizar: Ranura a utilizar de la tostadora. La numeración va desde el 1, hasta la cantidad de ranuras.
	 */
	public void iniciarTostado(int ranuraAUtilizar) {
		ValidacionesUtiles.validarRango(ranuraAUtilizar, 1, getCantidadDeRanuras(), "La ranura");
		validarTostadoraApagada();
		
		ranuras[ranuraAUtilizar - 1].iniciarTostado();
		
	}
	
	/**
	 * Dada una ranura a utilizar, se finaliza el tostado.
	 * 
	 * @param ranuraAUtilizar: Ranura a utilizar de la tostadora. La numeración va desde el 1, hasta la cantidad de ranuras.
	 */
	public void finalizarTostado(int ranuraAUtilizar) {
		ValidacionesUtiles.validarRango(0, ranuraAUtilizar - 1, getCantidadDeRanuras(), "La ranura");
		validarTostadoraApagada();
		ranuras[ranuraAUtilizar - 1].iniciarTostado();
	}
	
	/**
	 * Devuelve true si la tostadora está apagada.
	 * @return
	 */
	private boolean estaApagada() {
		return this.estado.equals(EstadoDeTostadora.Apagada);
		
	}
	
	/**
	 * Valida si la tostadora está apagada, si lo estuviera, devuelve una excepción.
	 * 
	 */
	private void validarTostadoraApagada() {
		if(this.estaApagada()) {
			throw new RuntimeException("La tostadora está apagada!");
		}		
	}
	
	/**
	 * Devuelve la cantidad de ranuras libres.
	 * @return
	 */
	public int contarRanurasLibres() {
		int ranurasLibres = 0;
		for(RanuraDeTostado ranuraDeTostado: this.ranuras) {
			if(ranuraDeTostado.estaLibre()) {
				ranurasLibres++;
			}
		}		
		return ranurasLibres;		
	}
	
	/**
	 * Devuelve la ranura que más tostó.
	 * @return
	 */
	public RanuraDeTostado devolverRanuraQueMasTosto() {
		RanuraDeTostado resultado = null;		
		for(RanuraDeTostado ranuraDeTostado: this.ranuras) {
			if ((resultado == null) ||
			    (ranuraDeTostado.getCantidadDeUsos() > resultado.getCantidadDeUsos())) {
				resultado = ranuraDeTostado;
			}
		}		
		return resultado;		
	}
	
	/**
	 * Devuelve la ranura indicada
	 * @param numero
	 * @return
	 */
	public RanuraDeTostado getRanuraDeTostado(int numero) {
		ValidacionesUtiles.validarRango(0, numero - 1, getCantidadDeRanuras(), "La ranura");
		return this.ranuras[numero-1];
	}
	
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la cantidad de ranuras de la tostadora.
	 * @return
	 */
	public int getCantidadDeRanuras() {	   
	    return ranuras.length;
	    
	}
	
	/**
	 * Devuelveel nivel de calor de la tostadora.
	 * @return
	 */
	public int getNivelDeCalor() {
		return this.nivelDeCalor;
		
	}
	
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Dado un nivel de calor, se asigna.
	 * 
	 * @param nivelDeCalor: Nivel de calor de la tostadora, siendo 0 mínimo y 10 máximo.
	 */
	public void setNivelDeCalor(int nivelDeCalor) {
		ValidacionesUtiles.validarRango(0, nivelDeCalor, 10, "El nivel de calor");		
		this.nivelDeCalor = nivelDeCalor;		
	}
	
}
