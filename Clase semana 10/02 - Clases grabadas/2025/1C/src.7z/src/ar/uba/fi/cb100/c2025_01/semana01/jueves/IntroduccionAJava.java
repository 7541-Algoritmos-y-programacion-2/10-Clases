package ar.uba.fi.cb100.c2025_01.semana01.jueves;

import ar.uba.fi.cb100.c2025_01.semana01.jueves.tablero.Sector;
import ar.uba.fi.cb100.c2025_01.semana01.jueves.tablero.Tablero;
import ar.uba.fi.cb100.c2025_01.semana01.jueves.teclado.Teclado;

public class IntroduccionAJava {

	public static void recorridosDeMatriz() {
		int[][] matriz = new int[10][10];
		
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 10; j++) {
				matriz[i][j] = i;
			}
		}
		
		for(int i = 0; i < 10; i++) {
			for(int j = 0; j < 10; j++) {
				System.out.print( matriz[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public static void imprimirMatriz(int[][] matriz) {
		for(int i = 0; i < matriz.length; i++) {
			for(int j = 0; j < matriz.length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();
		}		
	}
	
	public static void main(String[] args) {
		/**
		 * Tarea para jueves 20: hacer el menu del TP1 o una simplificacion en una clase aparte
		 */
		
		
//		int i = 0;
//		System.out.println("El valor de i es: " + i);
//
//		int j = 0;
//		System.out.println("El valor de i es: " + (j + i));
//		
//		
//		int[][] matriz = new int[IntroduccionAJava.ANCHO][IntroduccionAJava.ALTO];
//		
//		for(i = 0; i < matriz.length; i++) {
//			for(j = 0; j < matriz.length; j++) {
//				matriz[i][j] = 0;
//			}
//		}
//		imprimirMatriz(matriz);
		

		try {
			//Inicializo el tablero y el teclado
			Teclado.inicializar();
			Sector[][] tablero = new Sector[Tablero.ANCHO][Tablero.ALTO];
			Tablero.inicializarTablero(tablero);
			
			int i = 0;
			while (i++ < 4) {
				int x = Teclado.leerEntero();
				Tablero.asignarValor(tablero, x, 4, "A");
				Tablero.imprimirTablero(tablero);
			}			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			Teclado.finalizar();
		}
		
		
	}

}
