package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea01;

public class TestSubasta {

	public static void main(String[] args) {

        System.out.println("--- 1. Creación de la Subasta ---");
        // Se utiliza el constructor principal para crear una subasta para un artículo con un precio base.
        Subasta miSubasta = new Subasta("Laptop Gamer Antigua", 350.50);

        // Usamos toString() para ver el estado inicial del objeto.
        System.out.println("Estado inicial: " + miSubasta.toString());
        
        // Usamos los getters para obtener información específica.
        System.out.println("Artículo: " + miSubasta.getArticulo());
        System.out.println("Precio Base: $" + miSubasta.getPrecioBase());
        System.out.println("Estado actual: " + miSubasta.getEstado());

        // Verificamos el estado con los métodos booleanos.
        System.out.println("¿La subasta está pendiente? " + miSubasta.estaPendiente()); // Debería ser true
        System.out.println("¿Hay ofertas? " + miSubasta.hayOfertas()); // Debería ser false

        System.out.println("\n--- 2. Apertura de la Subasta ---");
        // Abrimos la subasta para que se puedan realizar ofertas.
        if (miSubasta.estaPendiente()) {
            miSubasta.abrirSubasta();
            System.out.println("¡Subasta abierta! Nuevo estado: " + miSubasta.getEstado());
            System.out.println(miSubasta.toString());
        }

        System.out.println("\n--- 3. Realización de Ofertas ---");
        // Verificamos si la subasta está abierta antes de ofertar.
        if (miSubasta.estaAbierta()) {
            System.out.println("Realizando primera oferta...");
            miSubasta.realizarOferta(400.00);
            System.out.println("Oferta realizada. ¿Hay ofertas ahora? " + miSubasta.hayOfertas());
            System.out.println("Mejor oferta actual: $" + miSubasta.getOfertaMayor());
            System.out.println(miSubasta.toString());

            System.out.println("\nRealizando una oferta más alta...");
            miSubasta.realizarOferta(450.75);
            System.out.println("Mejor oferta actualizada: $" + miSubasta.getOfertaMayor());
            System.out.println(miSubasta.toString());
            
            System.out.println("\nIntentando realizar una oferta más baja (no debería cambiar la oferta mayor)...");
            miSubasta.realizarOferta(420.00);
            System.out.println("Mejor oferta después de intento bajo: $" + miSubasta.getOfertaMayor());
            System.out.println(miSubasta.toString());
        }

        System.out.println("\n--- 4. Cierre de la Subasta ---");
        // Cerramos la subasta. Ya no se aceptarán más ofertas.
        if (miSubasta.estaAbierta()) {
            miSubasta.cerrarSubasta();
            System.out.println("¡Subasta cerrada! Estado final: " + miSubasta.getEstado());
            System.out.println("Resultado final: " + miSubasta.toString());
        }
        
        System.out.println("\n--- 5. Manejo de Excepciones (Intento de ofertar en subasta cerrada) ---");
        try {
            System.out.println("Intentando ofertar $500 en una subasta ya cerrada...");
            miSubasta.realizarOferta(500.00);
        } catch (RuntimeException e) {
            System.out.println("ERROR CAPTURADO: " + e.getMessage());
        }

        System.out.println("\n--- 6. Uso del método equals() ---");
        // Creamos otras subastas para probar la igualdad (se basa solo en el nombre del artículo).
        Subasta subastaIdentica = new Subasta("Laptop Gamer Antigua", 400.00); // Mismo artículo, diferente precio
        Subasta subastaDiferente = new Subasta("Monitor Curvo 27''");

        System.out.println("¿La subasta original es igual a 'subastaIdentica'? " + miSubasta.equals(subastaIdentica)); // Debería ser true
        System.out.println("¿La subasta original es igual a 'subastaDiferente'? " + miSubasta.equals(subastaDiferente)); // Debería ser false
        System.out.println("¿La subasta original es igual a null? " + miSubasta.equals(null)); // Debería ser false
    }
}
