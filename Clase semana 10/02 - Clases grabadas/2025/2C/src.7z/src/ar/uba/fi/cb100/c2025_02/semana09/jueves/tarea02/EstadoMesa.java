package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea02;

public enum EstadoMesa {
    LIBRE,OCUPADA
}
