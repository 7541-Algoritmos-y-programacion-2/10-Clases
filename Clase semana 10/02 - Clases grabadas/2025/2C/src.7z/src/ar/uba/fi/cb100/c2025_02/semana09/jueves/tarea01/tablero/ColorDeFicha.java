package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea01.tablero;

public enum ColorDeFicha {
	BLANCAS,
	NEGRAS
}
