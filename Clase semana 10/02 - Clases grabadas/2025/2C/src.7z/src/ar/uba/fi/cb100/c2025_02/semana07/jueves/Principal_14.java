package ar.uba.fi.cb100.c2025_02.semana07.jueves;

public class Principal_14 {

    public static void main(String[] args) {

        System.out.println("### INICIO DE PRUEBAS DEL TDA BATERIA ###");

        // Creamos una batería con 100 kWh de capacidad máxima y un consumo de 0.5 kWh/km
        Bateria bateria = new Bateria(100.0, 0.5);

        // --- PRUEBA 1: Estado Inicial ---
        System.out.println("\n--- PRUEBA 1: Creación y Estado Inicial ---");
        imprimirEstado(bateria);
        // Esperado: Carga actual = 0.0, Autonomía = 0.0 km, Vacía = true, Llena = false

        // --- PRUEBA 2: Carga Parcial ---
        System.out.println("\n--- PRUEBA 2: Cargando 75 kWh... ---");
        bateria.cargar(75.0);
        imprimirEstado(bateria);
        // Esperado: Carga actual = 75.0, Autonomía = 150.0 km, Vacía = false, Llena = false

        // --- PRUEBA 3: Desplazamiento Válido ---
        System.out.println("\n--- PRUEBA 3: Desplazando 100 km... ---");
        // Consumo esperado: 100 km * 0.5 kWh/km = 50 kWh
        bateria.desplazar(100.0);
        imprimirEstado(bateria);
        // Esperado: Carga actual = 25.0 (75-50), Autonomía = 50.0 km

        // --- PRUEBA 4: Carga Completa ---
        System.out.println("\n--- PRUEBA 4: Cargando los 75 kWh restantes para llenarla... ---");
        bateria.cargar(75.0);
        imprimirEstado(bateria);
        // Esperado: Carga actual = 100.0, Autonomía = 200.0 km, Vacía = false, Llena = true

        // --- PRUEBA 5: Intento de Sobrecarga (Debe fallar) ---
        System.out.println("\n--- PRUEBA 5: Intentando cargar 0.1 kWh extra (debe lanzar excepción) ---");
        try {
            bateria.cargar(0.1);
            System.out.println("FALLO: La batería permitió una sobrecarga.");
        } catch (RuntimeException e) {
            System.out.println("ÉXITO: La batería evitó la sobrecarga correctamente.");
            System.out.println("Mensaje: " + e.getMessage());
        }
        imprimirEstado(bateria); // El estado no debe haber cambiado

        // --- PRUEBA 6: Intento de Desplazamiento Excesivo (Debe fallar) ---
        System.out.println("\n--- PRUEBA 6: Intentando desplazar 201 km (debe lanzar excepción) ---");
        try {
            bateria.desplazar(201.0);
            System.out.println("FALLO: La batería permitió un desplazamiento mayor a su autonomía.");
        } catch (RuntimeException e) {
            System.out.println("ÉXITO: La batería evitó el desplazamiento excesivo.");
            System.out.println("Mensaje: " + e.getMessage());
        }
        imprimirEstado(bateria); // El estado no debe haber cambiado

        // --- PRUEBA 7: Descarga Completa ---
        System.out.println("\n--- PRUEBA 7: Desplazando exactamente 200 km para vaciarla... ---");
        bateria.desplazar(200.0);
        imprimirEstado(bateria);
        // Esperado: Carga actual = 0.0, Autonomía = 0.0 km, Vacía = true, Llena = false
        
        System.out.println("\n### FIN DE PRUEBAS ###");
    }

    /**
     * Método de ayuda para imprimir el estado actual de la batería de forma clara.
     * @param bateria La batería cuyo estado se quiere imprimir.
     */
    public static void imprimirEstado(Bateria bateria) {
        System.out.println("---------------------------------");
        System.out.printf("Carga Máxima: %.2f kWh\n", bateria.getCargaMaxima());
        System.out.printf("Consumo: %.2f kWh/km\n", bateria.getConsumoPromedioPorKilometro());
        System.out.printf("Carga Actual: %.2f kWh\n", bateria.getCargaActual());
        System.out.printf("Autonomía Restante: %.2f km\n", bateria.getAutonomia());
        System.out.println("¿Está vacía? " + bateria.estaVacia());
        System.out.println("¿Está llena? " + bateria.estaLlena());
        System.out.println("---------------------------------");
    }
}