package ar.uba.fi.cb100.c2025_02.semana08.miercoles;

import java.util.Objects;

public class Casillero3D<T> {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private T valor = null;
	private Casillero3D<T>[][][] vecinos = null; //una matriz de 3 x 3 x 3
	private int[] coordenadas;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Casillero3D() {}
	
	public Casillero3D(T valor){
		this.valor = valor;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Casillero " + this.valor;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(valor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Casillero3D<T> other = (Casillero3D<T>) obj;
		return Objects.equals(valor, other.valor);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	public boolean estaLibre() {
		return this.valor == null;
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param x -1, 0, 1
	 * @param y -1, 0, 1
	 * @param z -1, 0, 1
	 * @return
	 */
	public Casillero3D<T> getVecino(int x, int y, int z) {
		return null;
	}
	
	public Casillero3D<T> getVecino(Posicion posicion) {
		return null;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
		
	public T getValor() {
		return valor;
	}
	
	public int getX() {
		return this.coordenadas[0];
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public void setValor(T valor) {
		this.valor = valor;
	}
		
}
