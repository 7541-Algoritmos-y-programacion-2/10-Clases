package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea02.club;

import java.util.Objects;

public class Socio {

    private final String grupoFamiliar;
    private boolean tuvoDeuda;

    public Socio(String grupoFamiliar) {
        this.grupoFamiliar = grupoFamiliar;
        this.tuvoDeuda = false;
    }

    public boolean tuvoDeuda() {
        return tuvoDeuda;
    }

    public String grupoFamiliar() {
        return grupoFamiliar;
    }

    public Socio setTuvoDeuda(boolean tuvoDeuda) {
        this.tuvoDeuda = tuvoDeuda;
        return this;
    }

	@Override
	public int hashCode() {
		return Objects.hash(grupoFamiliar, tuvoDeuda);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Socio other = (Socio) obj;
		return Objects.equals(grupoFamiliar, other.grupoFamiliar);
	}
    
    
}
