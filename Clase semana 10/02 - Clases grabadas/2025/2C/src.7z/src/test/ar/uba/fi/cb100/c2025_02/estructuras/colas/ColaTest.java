package test.ar.uba.fi.cb100.c2025_02.estructuras.colas;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.cola.Cola;

class ColaTest {

    private Cola<Integer> cola;

    @BeforeEach
    void setUp() {
        cola = new Cola<>();
    }

    @Test
    void testOfferAndPeek() {
        assertTrue(cola.offer(10));
        assertTrue(cola.offer(20));
        assertEquals(10, cola.peek());
        assertEquals(2, cola.size());
    }

    @Test
    void testAddBehavesLikeOffer() {
        assertTrue(cola.add(5));
        assertEquals(5, cola.peek());
    }

    @Test
    void testPollOnEmptyReturnsNull() {
        assertNull(cola.poll());
    }

    @Test
    void testPollRemovesElements() {
        cola.offer(1);
        cola.offer(2);
        cola.offer(3);

        assertEquals(1, cola.poll());
        assertEquals(2, cola.poll());
        assertEquals(3, cola.poll());
        assertNull(cola.poll());
        assertTrue(cola.isEmpty());
    }

    @Test
    void testRemoveThrowsOnEmpty() {
        assertThrows(NoSuchElementException.class, () -> cola.remove());
    }

    @Test
    void testRemoveReturnsFirstElement() {
        cola.offer(42);
        assertEquals(42, cola.remove());
        assertTrue(cola.isEmpty());
    }

    @Test
    void testElementThrowsOnEmpty() {
        assertThrows(NoSuchElementException.class, () -> cola.element());
    }

    @Test
    void testElementReturnsFirstWithoutRemoving() {
        cola.offer(99);
        assertEquals(99, cola.element());
        assertEquals(1, cola.size());
    }

    @Test
    void testContainsAndContainsAll() {
        cola.addAll(Arrays.asList(1, 2, 3));
        assertTrue(cola.contains(2));
        assertFalse(cola.contains(5));
        assertTrue(cola.containsAll(Arrays.asList(1, 3)));
        assertFalse(cola.containsAll(Arrays.asList(1, 4)));
    }

    @Test
    void testRemoveObject() {
        cola.addAll(Arrays.asList(1, 2, 3, 2));
        assertTrue(cola.remove(Integer.valueOf(2)));
        assertTrue(cola.contains(2)); // todavía queda uno
        assertTrue(cola.remove(Integer.valueOf(2)));
        assertFalse(cola.contains(2));
    }

    @Test
    void testRemoveAll() {
        cola.addAll(Arrays.asList(1, 2, 3, 4, 2));
        assertTrue(cola.removeAll(List.of(2, 4)));
        assertEquals(2, cola.size());
        assertFalse(cola.contains(2));
        assertFalse(cola.contains(4));
    }

    @Test
    void testRetainAll() {
        cola.addAll(Arrays.asList(1, 2, 3, 4));
        assertTrue(cola.retainAll(List.of(2, 4)));
        assertEquals(2, cola.size());
        assertTrue(cola.containsAll(List.of(2, 4)));
    }

    @Test
    void testToArray() {
        cola.addAll(Arrays.asList(1, 2, 3));
        Object[] arr = cola.toArray();
        assertArrayEquals(new Object[]{1, 2, 3}, arr);
    }

    @Test
    void testToArrayGeneric() {
        cola.addAll(Arrays.asList(1, 2, 3));
        Integer[] arr = cola.toArray(new Integer[0]);
        assertArrayEquals(new Integer[]{1, 2, 3}, arr);
    }

    @Test
    void testIterator() {
        cola.addAll(Arrays.asList(1, 2, 3));
        Iterator<Integer> it = cola.iterator();
        assertTrue(it.hasNext());
        assertEquals(1, it.next());
        assertEquals(2, it.next());
        assertEquals(3, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void testClearAndIsEmpty() {
        cola.addAll(Arrays.asList(1, 2, 3));
        cola.clear();
        assertTrue(cola.isEmpty());
        assertEquals(0, cola.size());
        assertNull(cola.peek());
    }
}
