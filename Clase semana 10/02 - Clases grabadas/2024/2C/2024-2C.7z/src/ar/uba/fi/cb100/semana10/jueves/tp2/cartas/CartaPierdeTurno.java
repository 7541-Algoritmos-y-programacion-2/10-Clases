package ar.uba.fi.cb100.semana10.jueves.tp2.cartas;

import ar.uba.fi.cb100.semana10.jueves.tp2.jugadas.Jugada;
import ar.uba.fi.cb100.semana10.jueves.tp2.jugadas.JugadaPierdeTurno;

public class CartaPierdeTurno extends Carta {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public CartaPierdeTurno() {}

//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	@Override
	protected String getTituloPorDefecto() {
		return "Pierde turno";
	}

	@Override
	public Jugada getJugada() {
		return new JugadaPierdeTurno(this);
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}
