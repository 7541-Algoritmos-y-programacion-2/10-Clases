package ar.uba.fi.cb100.semana10.jueves.tp2.jugadas;

import ar.uba.fi.cb100.semana10.jueves.tp2.Jugador;
import ar.uba.fi.cb100.semana10.jueves.tp2.Tateti;
import ar.uba.fi.cb100.semana10.jueves.tp2.Turno;
import ar.uba.fi.cb100.semana10.jueves.tp2.cartas.Carta;

public abstract class Jugada {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Carta carta = null;
	
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Jugada(Carta carta) {
		this.carta = carta;
	}
	
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	public abstract void jugar(Tateti tateti, 
								Turno turnoActual) throws Exception;

//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public Carta getCarta() {
		return carta;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}
