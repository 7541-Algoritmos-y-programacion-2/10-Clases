package ar.uba.fi.cb100.semana12.jueves.emma;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class Foro {

	public Lista<String> obtenerTematicas() {
		// TODO Auto-generated method stub
		return null;
	}

	public Lista<Mensaje> obtenerMensajes() {
		// TODO Auto-generated method stub
		return null;
	}

}
