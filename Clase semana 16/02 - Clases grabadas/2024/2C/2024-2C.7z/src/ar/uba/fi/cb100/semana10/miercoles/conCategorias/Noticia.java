package ar.uba.fi.cb100.semana10.miercoles.conCategorias;

import ar.uba.fi.cb100.semana08.miercoles.estructuras.Lista;

public class Noticia {

	/* post: inicializa la noticia con el título y cuerpo 
	* indicados, sin categorias asociadas. 
	*/ 
	public Noticia(String titulo, String cuerpo) {} 
	/* post: devuelve el título de la noticia. 
	*/ 
	public String getTitulo() {
		return null;
	} 
	/* post: devuelve el cuerpo de la noticia. 
	*/ 
	public String getCuerpo() {
		return null;
	}
	/* post: devuelve las categorias asociadas a la noticia. */ 
	public Lista<Categoria> getCategorias() {
		return null;
	}
}
