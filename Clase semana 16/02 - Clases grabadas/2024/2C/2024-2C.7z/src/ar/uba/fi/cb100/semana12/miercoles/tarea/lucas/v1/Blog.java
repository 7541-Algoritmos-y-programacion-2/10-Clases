package ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.v1;

import ar.uba.fi.cb100.semana07.miercoles.Lista;
import ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.Articulo;

public class Blog {
    
    private Lista<Articulo> articulos;
    
    public Lista<Articulo> getArticulos() {
        return articulos;
    }
    
    /**
     * busca artículos que contengan alguna de las palabras clave proporcionadas
     * 
     * @param palabrasClaves lista de palabras clave para buscar
     * @return lista de artículos que contienen alguna de las palabras clave
     * @throws Exception
     * 
     * pre: palabrasClaves no debe ser null
     * pos: devuelve una lista de artículos que contienen alguna de las palabras clave
     */
    public Lista<Articulo> buscarArticulos(Lista<String> palabrasClaves) throws Exception {
        
        if(palabrasClaves == null) {
            throw new Exception("La lista esta vacia");
        }       
        Lista<Articulo> resultado = new Lista<Articulo>();    
        
        palabrasClaves.iniciarCursor();
        
        while (palabrasClaves.avanzarCursor()) {        
            String palabraABuscar = palabrasClaves.obtenerCursor();
            
            filtrarArticulos(palabraABuscar, resultado);        
        }                
        return resultado;
    }
    
    /**
     * filtra los artículos y agrega los que contienen la palabra a la lista resultado
     *
     * @param palabraABuscar palabra a buscar en los artículos
     * @param resultado lista donde se agregarán los artículos que contienen la palabra
     * @throws Exception
     * 
     * pre: palabraABuscar no debe estar vacía y resultado no debe ser null
     * pos: agrega a resultado los artículos que contienen palabraABuscar y no tienen palabras excluidas
     */
    public void filtrarArticulos(String palabraABuscar, Lista<Articulo> resultado) throws Exception {
        
        if (palabraABuscar.length() < 2) {
            throw new Exception("La palabra no existe");
        }       
        Lista<Articulo> articulos = this.getArticulos();
        
        articulos.iniciarCursor();
        
        while(articulos.avanzarCursor()) {
            Articulo articuloARevisar = articulos.obtenerCursor();
            
            if(verificarPalabraExcluida(palabraABuscar, articuloARevisar.getPalabrasExcluidas())) {              
                return;
            }
            
            if (verificarPalabra(palabraABuscar, articuloARevisar)) {
                resultado.agregar(articuloARevisar);
            }
        }
        return;
    }

    /**
     * verifica si la palabra está en la lista de palabras excluidas
     * 
     * @param palabra palabra a verificar.
     * @param palabrasExcluidas lista de palabras excluidas
     * @return true si la palabra está excluida, false en caso contrario
     * @throws Exception 
     * 
     * pre: palabra no debe estar vacía y palabrasExcluidas no debe ser null
     * pos: devuelve true si palabra está en palabrasExcluidas, false en caso contrario
     */
    private boolean verificarPalabraExcluida(String palabra, Lista<String> palabrasExcluidas) throws Exception {
        
        if ((palabra.length() < 2)) {        
            throw new Exception("La palabra no exsite");
        } 
        if (palabrasExcluidas == null) {
        	throw new Exception("La lista esta vacia");
        }
        palabrasExcluidas.iniciarCursor();
        
        while (palabrasExcluidas.avanzarCursor()) {
            String palabraExcluida = palabrasExcluidas.obtenerCursor();
            
            if (palabra == palabraExcluida) {
                return true;
            }
        }            
        return false;
    }    
    
    /**
     * verifica si la palabra está en el título o texto del artículo
     * 
     * @param palabra palabra a verificar
     * @param articuloARevisar artículo donde se busca la palabra
     * @return true si la palabra se encuentra en el título o texto, false en caso contrario
     * @throws Exception 
     * 
     * pre: palabra no debe estar vacía y articuloARevisar no debe ser null
     * pos: devuelve true si palabra se encuentra en el título o texto de articuloARevisar, false en caso contrario
     */
    private boolean verificarPalabra(String palabra, Articulo articuloARevisar) throws Exception {
        
        if ((palabra.length() == 0) || (articuloARevisar == null)) {
            throw new Exception("");
        }
        if ((articuloARevisar.getTitulo().indexOf(palabra) > 0) || 
             articuloARevisar.getTexto().indexOf(palabra) > 0) {
            return true;
        }    
        return false;    
    }    
}