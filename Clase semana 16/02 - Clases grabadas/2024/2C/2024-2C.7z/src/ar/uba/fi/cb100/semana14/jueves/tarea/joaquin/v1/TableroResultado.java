package ar.uba.fi.cb100.semana14.jueves.tarea.joaquin.v1;

public class TableroResultado {

    //atributos
    private EstadoTablero tablero[][] = null;
    
    //constructor
    /**
     * pre:
     * @param jugadores
     * @throws Exception
     */
    public TableroResultado(int jugadores) throws Exception {
        if (jugadores <= 1) {
            throw new Exception("Se debe indicar una cantidad de jugadores mayor a 1");
        }
        this.tablero = new EstadoTablero[jugadores][jugadores];
        
        //Falta inicializar
        for(int i = 0; i < this.getCantidadDeJugadores(); i++) {
        	for(int j = 0; j < this.getCantidadDeJugadores(); j++) {
        		this.tablero[i][j] = EstadoTablero.JUGANDO;
        	}
        	this.tablero[i][i] = null;
        }
    }

    //metodos
    public void agregarResultado(int jugador1, int jugador2, EstadoTablero resultado) throws Exception {
        if(jugador1 == jugador2){
            throw new Exception("El jugador ingresado no puede jugar contra si mismo.");
        }
        validarJugadores(jugador1, jugador2);

        //Verificando que el partido se este jugando y el tablero no este terminado
        if(tablero[jugador1][jugador2] != EstadoTablero.JUGANDO){
            throw new Exception("Se esta intentando cargar un resultado en un partido que ya lo tiene.");
        }
        
        switch (resultado) {
        	case TABLAS:
        	case GANAN_BLANCAS:
        	case GANAN_NEGRAS:
        		tablero[jugador1][jugador2]= resultado;
        		break;
        	default:
        		throw new Exception("El resultado no es valido");
		}        
    }
    
    public void anularPartida(int jugador1, int jugador2, EstadoTablero resultado) throws Exception {
        if(jugador1 == jugador2){
            throw new Exception("El jugador ingresado no puede jugar contra si mismo.");
        }
        validarJugadores(jugador1, jugador2);
        
        //Verificando que el partido se este jugando y el tablero no este terminado
        if(tablero[jugador1][jugador2] != EstadoTablero.JUGANDO){
            throw new Exception("Se esta intentando cargar un resultado en un partido que ya lo tiene.");
        }
        tablero[jugador1][jugador2]= EstadoTablero.ANULADO;
    }
    
    public int consultarPuntaje(int jugador) throws Exception{

        int puntaje=0;
        // orientacion el jugador que esta parado en filas es considerado blancas y el que esta parado en columnas negras
        for(int i=0;i<this.getCantidadDeJugadores();i++){
            if (this.tablero[jugador][i] != null){
                switch(this.tablero[jugador][i]){
                    case GANAN_BLANCAS:
                        puntaje+=3;
                        break;
                    case TABLAS:
                        puntaje+=1; 
                        break;
                    case ANULADO:
                    	puntaje-=1;
                    	break;
                    default:
                        break;
                }
            }
            if (this.tablero[i][jugador] != null){
                switch (this.tablero[i][jugador]) {
                    case GANAN_NEGRAS:
                        puntaje+=3;
                        break;
                    case TABLAS:
                        puntaje+=1;
                        break;
                    case ANULADO:
                    	puntaje-=1;
                    	break;
                    default:
                        break;
                }
            }
        }
        return puntaje;
    }
    
    /**
     * pre: -
     * @return devuelve verdadero si todas las partidas se terminaron de jugar, o falso en caso contrario
     */
    public boolean termino() {
        for(int i = 0; i < this.getCantidadDeJugadores(); i++) {
        	for(int j = 0; j < this.getCantidadDeJugadores(); j++) {
        		if (( i != j) &&
        		    (this.tablero[i][j] == EstadoTablero.JUGANDO)) {
       				return false;
        		}
        	}
        }
       	return true;
    }
    
    /**
     * pre: -
     * @return devuelve el jugador ganador
     * @throws Exception
     */
    public int getJugadorGanador() throws Exception {
    	if (!termino()) {
    		throw new Exception("No se termino el torneo");
    	}
    	Integer jugadorGanador = null;
    	for(int i = 0; i < getCantidadDeJugadores(); i++) {
    		int puntaje = consultarPuntaje(i);
    		if ((jugadorGanador == null) ||
    		    (consultarPuntaje(jugadorGanador) < puntaje)) {
    			jugadorGanador = i;
    		}
    	}
    	return jugadorGanador + 1;
    }
    
    public int getCantidadDeJugadores() {
    	return this.tablero.length;
    }
    
    /**
     * pre: debe pasar algun jugador
     * @param jugadores los numeros de los jugadores entre 1 y getCantidadDeJugadores() inclusive
     * @throws Exception
     */
    private void validarJugadores(int ... jugadores) throws Exception {
    	if (jugadores == null) {
    		throw new Exception("No se ingresaron jugadores");
    	}
    	for(int jugador: jugadores) {
	    	if (jugador < 1) {
	    		throw new Exception("El jugador debe ser mayor o igual a 1");
	    	}
	    	if (jugador > this.getCantidadDeJugadores()) {
	    		throw new Exception("El jugador debe ser menor o igual a " + this.getCantidadDeJugadores());
	    	}
    	}
    }
}