package ar.uba.fi.cb100.semana05.miercoles;

public class ExcepcionGeneral extends Exception {

}
