package ar.uba.fi.cb100.semana10.jueves.tp2;

import ar.uba.fi.cb100.semana08.jueves.tarea.franco.Casillero;
import ar.uba.fi.cb100.semana08.jueves.tarea.franco.Direccion;
import ar.uba.fi.cb100.semana08.jueves.tarea.franco.Ficha;
import ar.uba.fi.cb100.semana08.jueves.tarea.franco.Movimiento;
import ar.uba.fi.cb100.semana08.jueves.tarea.franco.Tablero;
import ar.uba.fi.cb100.semana10.jueves.tp2.cartas.Carta;

public class Tateti {
	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	//ATRIBUTOS -----------------------------------------------------------------------------------------------

	private Tablero<Ficha> tablero = null;
	private Jugador[] jugadores = null;
	private Turno[] turnos = null;
	
	//demas cosas, jugadores, cartas, etc

	//CONSTRUCTORES -------------------------------------------------------------------------------------------

	public Tateti() throws Exception {
		this.tablero = new Tablero<Ficha>(3, 3);
	}

	//METODOS DE CLASE ----------------------------------------------------------------------------------------
	//METODOS GENERALES ---------------------------------------------------------------------------------------
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	public void verificarGanador(Casillero<Ficha> casillero) throws Exception {
		//validar
		int cantidadFichas = 3; //longitud del tateti


		//suponemos direccion horizontal                           // casillero de la izquierda                                                                //casillero de la derecha
		int cantidadDeFichasSeguidas = contarFichasSeguidas(casillero, Direccion.ARRIBA, casillero.getDato()) + 
										contarFichasSeguidas(casillero, Direccion.ABAJO, casillero.getDato());
		if(cantidadDeFichasSeguidas >= cantidadFichas) {
			//hay ganador
		}

		cantidadDeFichasSeguidas = contarFichasSeguidas(casillero, Direccion.IZQUIERDA, casillero.getDato()) + 
									contarFichasSeguidas(casillero, Direccion.DERECHA, casillero.getDato());
		if(cantidadDeFichasSeguidas >= cantidadFichas) {
			//hay ganador
		}

		cantidadDeFichasSeguidas = contarFichasSeguidas(casillero, Direccion.IZQUIERDA_ARRIBA, casillero.getDato()) + 
									contarFichasSeguidas(casillero, Direccion.DERECHA_ABAJO, casillero.getDato());
		if(cantidadDeFichasSeguidas >= cantidadFichas) {
			//hay ganador
		}
		cantidadDeFichasSeguidas = contarFichasSeguidas(casillero, Direccion.IZQUIERDA_ABAJO, casillero.getDato()) + 
									contarFichasSeguidas(casillero, Direccion.DERECHA_ARRIBA, casillero.getDato());
		if(cantidadDeFichasSeguidas >= cantidadFichas) {
			//	hay ganador
		}
	}

	public int contarFichasSeguidas(Casillero<Ficha> casillero, Direccion direccion, Ficha ficha) throws Exception {
		if(casillero == null) {
			return 0;
		}
		if(!casillero.getDato().esElMismoSimbolo(ficha)) {
			return 0;
		}
		return 1 + contarFichasSeguidas(casillero.getCasilleroVecino(direccion), direccion, ficha);
	}

	
	public void jugar() throws Exception {
		//while x turno
		//Levantar la carta
		
		Turno turnoActual = null;
		Casillero<Ficha> casilleroDestino = null;
		turnoActual.iniciarTurno();
		if (turnoActual.estaBloqueado()) {
			while (turnoActual.haySubturnos()) {
				turnoActual.utilizarSubturno();
				if (!turnoActual.getJugador().tieneTodasLasFichasEnElTablero()) {
					jugadaInicial(this.tablero, turnoActual.getJugador());
				} else {
					casilleroDestino = mover(this.tablero, turnoActual.getJugador());
				}
				
				//Si juega una carta
				Carta cartaActual = null; //preguntar la carta del jugador
				if (cartaActual != null) {	
					cartaActual.getJugada().jugar(this, turnoActual);
				}				
			}
		}		
		turnoActual.terminarTurno();
		verificarGanador(casilleroDestino);
	}
	
	
	public void jugadaInicial(Tablero<Ficha> tablero, Jugador jugador) throws Exception {

		Ficha ficha = null; //crea
		int x = 0; //pregunta la posicion
		int y = 0;
		Casillero<Ficha> casillero = tablero.getCasillero(x, y);
		if (casillero.estaOcupado()) {
			throw new Exception("El casillero esta ocupado");
		}
		casillero.setDato(ficha);
	}
	
	public Casillero<Ficha> mover(Tablero<Ficha> tablero, 
									Jugador jugador) throws Exception {
		Ficha ficha = null; //Preguntar la ficha al usuario
		Movimiento movimiento = null; //Pregunta al usuario
		Casillero<Ficha> casillero = tablero.getCasillero(ficha);
		if (!casillero.existeElVecino(movimiento)) {
			throw new Exception("No existe el movimiento");
		}
		if (casillero.getCasilleroVecino(movimiento).estaOcupado()) {
			throw new Exception("No existe el movimiento");
		}
		tablero.mover(casillero, casillero.getCasilleroVecino(movimiento), ficha);
		return casillero.getCasilleroVecino(movimiento);
	}

	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public Tablero<Ficha> getTablero() {
		return tablero;
	}

	public Jugador[] getJugadores() {
		return jugadores;
	}
	
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}