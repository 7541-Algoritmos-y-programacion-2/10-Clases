package ar.uba.fi.cb100.semana10.jueves.tp2;

import ar.uba.fi.cb100.semana10.jueves.tp2.cartas.Carta;
import ar.uba.fi.cb100.semana10.jueves.tp2.cartas.CartaPierdeTurno;

public class Principal {

	public static void main(String[] args) {
	
		
		System.out.println("Titulo: " + new CartaPierdeTurno());
		System.out.println("Titulo: " + new CartaPierdeTurno());
		System.out.println("Titulo: " + new CartaPierdeTurno());
		System.out.println("Titulo: " + new CartaPierdeTurno());
		
		
		Carta carta = new CartaPierdeTurno();
		
		
	}
}
