package ar.uba.fi.cb100.semana14.miercoles.nahuel.v1;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class AdministradorDeClubSocial {
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los socios, uno por familia, cuyo grupo familiar no tuvo deudas.
	 */
//	public static Lista<Socio> buscarSociosParaDescuento (Lista<Socio> socios) throws Exception{
//		if(socios == null) {
//			throw new Exception("La cantidad de socios no puede ser 0");
//		}
//		Lista<String> familiasAnalizadas = new Lista<String>();
//		Lista<Socio> resultado = new Lista<Socio>();
//		Lista<Socio> posiblesFamiliares = new Lista<Socio>();
//		socios.iniciarCursor();
//		while(socios.avanzarCursor()) {
//			posiblesFamiliares.agregar(socios.obtenerCursor());
//		}
//		socios.iniciarCursor();
//		while(socios.avanzarCursor()) {
//			if(!socios.obtenerCursor().tuvoDeuda()) {
//				if(familiasAnalizadas != null) {
//					if(!Comprobaciones.laFamiliaEstaAnalizada(familiasAnalizadas, socios.obtenerCursor().getGrupoFamiliar())) {
//						if(!Comprobaciones.tieneLaFamiliaDeuda(posiblesFamiliares, socios.obtenerCursor())) {
//							resultado.agregar(socios.obtenerCursor());
//						}
//						familiasAnalizadas.agregar(socios.obtenerCursor().getGrupoFamiliar());
//					}
//				}else {
//					if(!Comprobaciones.tieneLaFamiliaDeuda(posiblesFamiliares, socios.obtenerCursor())) {
//						resultado.agregar(socios.obtenerCursor());
//					}
//					familiasAnalizadas.agregar(socios.obtenerCursor().getGrupoFamiliar());
//				}
//			}
//		}
//		return resultado;
//	}
	
	/**
	 * pre:
	 * @param socios no puede ser nula
	 * @return
	 * @throws Exception
	 * post: devuelve una nueva lista con los socios, uno por familia, cuyo grupo familiar no tuvo deudas.
	 */
	public static Lista<Socio> buscarSociosParaDescuento2(Lista<Socio> socios) throws Exception {
		if(socios == null) {
			throw new Exception("La cantidad de socios no puede ser 0");
		}
		Lista<String> familiasDeudoras = getFamiliasDeudoras(socios);
		Lista<Socio> resultado = new Lista<Socio>();

		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.obtenerCursor();
			if ((!familiasDeudoras.contieneS4( socio.getGrupoFamiliar())) &&
				(!contieneGrupoFamiliar( resultado, socio))) {
				resultado.agregar(socio);
			}
		}
		return resultado;
	}

	private static boolean contieneGrupoFamiliar(Lista<Socio> resultado, Socio socioABuscar) {
		resultado.iniciarCursor();
		while(resultado.avanzarCursor()) {
			Socio socio = resultado.obtenerCursor();
			if (socio.getGrupoFamiliar().equals(socioABuscar.getGrupoFamiliar())) {
				return true;
			}
		}
		return false;
	}

	private static Lista<String> getFamiliasDeudoras(Lista<Socio> socios) throws Exception {
		Lista<String> familiasDeudoras = new Lista<String>();
		socios.iniciarCursor();
		while(socios.avanzarCursor()) {
			Socio socio = socios.obtenerCursor();
			if (socio.tuvoDeuda()) {
				familiasDeudoras.agregar(socio.getGrupoFamiliar());
			}
		}
		return familiasDeudoras;
	}
}
