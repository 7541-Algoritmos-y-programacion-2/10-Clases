package ar.uba.fi.cb100.semana12.jueves.axel;

public enum EstadoDelJuego {
    JUGANDO,
    GANADO,
    PERDIDO
}
