package ar.uba.fi.cb100.semana06.miercoles;

public enum EstadoDeTelevisor {
	NORMAL,
	SILENCIADO
}
