package ar.uba.fi.cb100.semana12.jueves.emma.v1;

import ar.uba.fi.cb100.semana07.miercoles.Lista;
import ar.uba.fi.cb100.semana12.jueves.emma.Foro;
import ar.uba.fi.cb100.semana12.jueves.emma.Mensaje;

/*/* post: busca en la lista 'foros' el Mensaje más votado del autor 'usuarioBuscado' dentro de un Foro que incluya la temática 'tematicaBuscada'.*/


public class Moderador {
	public Mensaje buscarMensajeMasVotadoDelUsuarioSegunTematica(Lista<Foro> foros, 
																	String usuarioBuscado, 
																	String tematicaBuscada) throws Exception {
		if (foros == null) {
			throw new Exception("La lista de foros no puede estar vacía");
		}
		if (usuarioBuscado == null) {
			throw new Exception("El usuario buscado no puede estar vacío");
		}
		if (tematicaBuscada == null) {
			throw new Exception("La temática buscada no puede estar vacía");
		}
		
		Mensaje mensajeEncontrado = null;
		Lista<Mensaje> mensajesCandidatos = new Lista<Mensaje>();
		
		foros.iniciarCursor();
		while(foros.avanzarCursor()) {
			Foro foroLeido = foros.obtenerCursor();
			if ((foroLeido.obtenerTematicas().existe(tematicaBuscada)) &&
				 incluyeAutor(foroLeido.obtenerMensajes(),usuarioBuscado)){
				Mensaje mayorMensajeDelForo = buscarMayorMensajeDelForo(foroLeido.obtenerMensajes(), usuarioBuscado);
				mensajesCandidatos.agregar(mayorMensajeDelForo);
			}
		}
		
		//Version 2
		foros.iniciarCursor();
//		while(foros.avanzarCursor()) {
//			Foro foroLeido = foros.obtenerCursor();
//			if ((foroLeido.obtenerTematicas().existe(tematicaBuscada)) {
//				Mensaje mayorMensajeDelForo = buscarMensajeMasVotado(foroLeido.obtenerMensajes(), usuarioBuscado);
//				if (mayorMensajeDelForo != null) {
//					//Evaluar el mayor
//				}
//			}
//		}
		mensajeEncontrado = this.buscarMayor(mensajesCandidatos);
		
		
		return mensajeEncontrado;
	}


	public Mensaje buscarMayorMensajeDelForo(Lista<Mensaje> mensajesForoLeido, String usuarioBuscado) throws Exception {
		Lista<Mensaje> mensajesDeAutorBuscado = new Lista<Mensaje>();
		mensajesForoLeido.iniciarCursor();
		while (mensajesForoLeido.avanzarCursor()) {
			Mensaje mensajeLeido = mensajesForoLeido.obtenerCursor();
			if (mensajeLeido.obtenerUsuario().equals(usuarioBuscado)) {
				mensajesDeAutorBuscado.agregar(mensajeLeido);
			}
		}
		
		Mensaje mensajeMasVotado = this.buscarMayor(mensajesDeAutorBuscado);
		
		
		return mensajeMasVotado;
	}
	
	public Mensaje buscarMayor (Lista<Mensaje> mensajesDeAutorBuscado) {
		int mayorCantidadDeVotos = 0;
		Mensaje mensajeMasVotado = null;
		mensajesDeAutorBuscado.iniciarCursor();
		while(mensajesDeAutorBuscado.avanzarCursor()) {
			Mensaje mensajeLeido = mensajesDeAutorBuscado.obtenerCursor();
			if (mensajeLeido.contarVotos()>mayorCantidadDeVotos) {
				mensajeMasVotado=mensajeLeido;
				mayorCantidadDeVotos = mensajeLeido.contarVotos();
			}
		}
		return mensajeMasVotado;
	}


	public boolean incluyeAutor(Lista<Mensaje> mensajesForoLeido, String usuarioBuscado) {
		boolean respuesta = false;
		mensajesForoLeido.iniciarCursor();
		while (mensajesForoLeido.avanzarCursor()) {
			String autorLeido = mensajesForoLeido.obtenerCursor().obtenerUsuario();
			if (autorLeido.equals(usuarioBuscado)) {
				respuesta = true;
			}
		}
		
		return respuesta;
	}
}






