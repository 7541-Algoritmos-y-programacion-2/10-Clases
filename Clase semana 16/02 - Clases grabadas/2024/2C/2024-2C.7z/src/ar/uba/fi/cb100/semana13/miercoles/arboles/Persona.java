package ar.uba.fi.cb100.semana13.miercoles.arboles;

import java.util.Objects;

public class Persona implements Comparable<Persona> {

	private int dni = 0;
	private String datoAdicional = null;
	
	public Persona(int valor) {
		this.dni = valor;
	}
	
	/**
	 * Devuelve:
	 * 1 = si this es mayor que valor
	 * 0 = si this es igual que valor
	 * -1 = si this es menor que valor
	 * 
	 */
	@Override
	public int compareTo(Persona valor) {
		if (valor != null) {
			return Integer.valueOf(this.dni).compareTo( valor.getDni());
		}
		return 0;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return dni == other.dni;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int valor) {
		this.dni = valor;
	}

	protected String getDatoAdicional() {
		return datoAdicional;
	}

	protected void setDatoAdicional(String datoAdicional) {
		this.datoAdicional = datoAdicional;
	}
	
	
	
}
