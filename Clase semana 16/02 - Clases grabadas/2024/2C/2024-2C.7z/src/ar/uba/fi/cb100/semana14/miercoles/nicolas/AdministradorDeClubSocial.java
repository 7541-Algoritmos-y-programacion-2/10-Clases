package ar.uba.fi.cb100.semana14.miercoles.nicolas;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class AdministradorDeClubSocial {

	
	/**
	 	public boolean tuvoDeuda() {
			return false;
		}
		
		public String getGrupoFamiliar() {
			return null;
		}
	 */
	
	
	/**
	 * post: Devuelve una nueva Lista con los socios, uno por familia, cuyo grupo familiar no tubo deudas.
	 * @param socios
	 * @return
	 * @throws Exception 
	 */
	
	public Lista<Socio> buscarSocioParaDescuento(Lista<Socio> socios) throws Exception{
		//Pre
		//Validar
		
		Lista<Socio> sociosParaDescuento = new Lista<Socio>();
		
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			
			String familia = socioAAnalizar.getGrupoFamiliar();
			
			Lista<String> listaFamiliasConDeuda = null; //familiasConDeuda( new Lista<Socio>(socios));
			
			boolean tieneDeuda = analizarFamiliasConDeuda(familia, listaFamiliasConDeuda);
			
			
			if (!tieneDeuda) {
				
				sociosParaDescuento.agregar(socioAAnalizar);
			}
		}
		
		return sociosParaDescuento;
		
		
	}
	
	public Lista<String> familiasConDeuda(Lista<Socio> socios) throws Exception{
		
		Lista<String> familiasConDeuda = new Lista<String>();
		
		socios.iniciarCursor();
		
		while (socios.avanzarCursor()) {
			
			Socio socioAAnalizar = socios.obtenerCursor();
			String grupoFamiliar = socioAAnalizar.getGrupoFamiliar();
			
			if (socioAAnalizar.tuvoDeuda()) {
				familiasConDeuda.agregar(grupoFamiliar);
			}
		}
		
		return familiasConDeuda;
	}
	
	public boolean analizarFamiliasConDeuda(String familia, Lista<String> familiasConDeuda) {
		
		familiasConDeuda.iniciarCursor();
		
		while (familiasConDeuda.avanzarCursor()) {
			
			String familiaAAnalizar = familiasConDeuda.obtenerCursor();
			
			if (familia.equals(familiaAAnalizar)) {
				
				return true;
			}
		}
		
		return false;
		
	}
	
}

