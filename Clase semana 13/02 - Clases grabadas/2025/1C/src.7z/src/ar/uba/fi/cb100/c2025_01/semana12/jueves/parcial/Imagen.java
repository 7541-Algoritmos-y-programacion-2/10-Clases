package ar.uba.fi.cb100.c2025_01.semana12.jueves.parcial;

public class Imagen {
}
