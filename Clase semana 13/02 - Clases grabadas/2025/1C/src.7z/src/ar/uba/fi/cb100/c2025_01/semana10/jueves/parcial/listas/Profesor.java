package ar.uba.fi.cb100.c2025_01.semana10.jueves.parcial.listas;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Profesor {

	/**
	 * TIPS Listas:
	 * Axiomas: Pre y pos condicion
	 * Encapsulamiento
	 * Robustez: Validaciones
	 * Modularizar
	 * Solucionar el problema
	 * Manejo de errores
	 * Nombres
	 */
	
	/**
	 * Pre: alumnos y promedios no son nulos. Todas los alumnos que tienen notas, deben estar en alumnos
	 * Busca los mejores alumnos de cada materia segun su promedio de notas
	 */
	public List<Alumno> buscarMejoresAlumnos(List<Alumno> alumnos, List<Nota> promedios) {
		ValidacionesUtiles.validarNoNulo(alumnos, "Alumnos");
		ValidacionesUtiles.validarNoNulo(promedios, "Promedios");
		
		List<Alumno> resultado = new ListaSimplementeEnlazada<Alumno>();
		for(String materia: getMaterias(promedios)) {
			Nota mejorPromedio = getMejorPromedio(materia, promedios);
			Alumno alumno = getAlumno(mejorPromedio.getPadron(), alumnos);
			if (!resultado.contains(alumno)) {
				resultado.add( alumno );
			}
		}
		return resultado;
	}

	/**
	 * Pre: alumnos y promedios no son nulos. Todas los alumnos que tienen notas, deben estar en alumnos
	 * Busca los mejores alumnos de cada materia segun su promedio de notas. Si hay empate en el mejor 
	 * promedio, incluye ambos
	 */
	public List<Alumno> buscarMejoresAlumnosConEmpate(List<Alumno> alumnos, List<Nota> promedios) {
		ValidacionesUtiles.validarNoNulo(alumnos, "Alumnos");
		ValidacionesUtiles.validarNoNulo(promedios, "Promedios");
		
		List<Alumno> resultado = new ListaSimplementeEnlazada<Alumno>();
		for(String materia: getMaterias(promedios)) {
			List<Nota> mejoresPromedios = getMejoresPromedios(materia, promedios);
			agregarAlumnosFaltantes(resultado, alumnos, mejoresPromedios);
		}
		return resultado;
	}
	
	/**
	 * Agrega a resultado los alumnos de mejores promedios, sin repetir
	 * @param resultado
	 * @param alumnos
	 * @param mejoresPromedios
	 */
	public void agregarAlumnosFaltantes(List<Alumno> resultado, List<Alumno> alumnos, List<Nota> mejoresPromedios) {
		for(Nota mejorPromedio: mejoresPromedios) {
			Alumno alumno = getAlumno(mejorPromedio.getPadron(), alumnos);
			if (!resultado.contains(alumno)) {
				resultado.add( alumno );
			}
		}
	}

	/**
	 * Dado el listado de alumnos, devuelve el alumno con el padron indicado
	 * o error si el alumno no se encuentra
	 * @param padron
	 * @param alumnos
	 * @return
	 */
	public Alumno getAlumno(int padron, List<Alumno> alumnos) {
		for(Alumno alumno: alumnos) {
			if (alumno.getPadron() == padron) {
				return alumno;
			}
		}
		throw new RuntimeException("No se encontro el alumno con padron " + padron);
	}

	/**
	 * Dado los promedios en general y una materia, busca el mejor promedio
	 * @param materia
	 * @param promedios
	 * @return
	 */
	public Nota getMejorPromedio(String materia, List<Nota> promedios) {
		Nota mejorPromedio = null;
		for(Nota nota: promedios) {
			if (nota.getMateria().equals(materia)) {
				if ((mejorPromedio == null) ||
				   (mejorPromedio.getValor() < nota.getValor())) {
					mejorPromedio = nota;
				}
			}
		}
		return mejorPromedio;
	}
	
	/**
	 * Dado los promedios en general y una materia, busca el mejor promedio
	 * @param materia
	 * @param promedios
	 * @return
	 */
	public List<Nota> getMejoresPromedios(String materia, List<Nota> promedios) {
		/* Version 1
		{
			Nota mejorPromedio = getMejorPromedio(materia, promedios);
			List<Nota> mejoresPromedios = new ArrayList<Nota>();
			for(Nota nota: promedios) {
				if (nota.getMateria().equals(materia)) {
					if ((mejorPromedio.getValor() == nota.getValor())) {
						mejoresPromedios.add(nota);
					}
				}
			}
			return mejoresPromedios;
		}
		*/
		//Version 2
		{
			List<Nota> mejoresPromedios = new ListaSimplementeEnlazada<Nota>();
			for(Nota nota: promedios) {
				if (nota.getMateria().equals(materia)) {
					if ((mejoresPromedios.isEmpty()) ||
					   (mejoresPromedios.get(0).getValor() < nota.getValor())) {
						mejoresPromedios.clear();
						mejoresPromedios.add(nota);
					} else {
						if (mejoresPromedios.get(0).getValor() == nota.getValor()) {
							mejoresPromedios.add(nota);	
						}
					}
				}
			}
			return mejoresPromedios;
		}
	}

	/**
	 * Dada una lista de notas devuelve una lista de materias sin duplicados
	 * @param promedios
	 * @return
	 */
	public List<String> getMaterias(List<Nota> promedios) {
		List<String> materias = new ListaSimplementeEnlazada<String>();
		for(Nota nota: promedios) {
			if (!materias.contains(nota.getMateria())) {
				materias.add( nota.getMateria() );
			}
		}
		return materias;
	}
	
	
}
