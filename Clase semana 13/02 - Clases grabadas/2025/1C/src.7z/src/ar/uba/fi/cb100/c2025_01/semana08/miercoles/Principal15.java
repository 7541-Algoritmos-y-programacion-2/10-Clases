package ar.uba.fi.cb100.c2025_01.semana08.miercoles;

import ar.uba.fi.cb100.c2025_01.semana07.miercoles.Auto;

public class Principal15 {

	public static void main(String[] args) {
		Auto auto1 = new Auto("Fiat 147");
		Auto auto2 = new Auto("Fiat 147");
		Auto auto3 = auto1;
		
		{ // Con igual igual
			if (auto1 == auto2) {
				System.out.println("Son iguales");
			} else {
				System.out.println("No son iguales");
			}
			
			if (auto1 == auto3) {
				System.out.println("Son iguales");
			} else {
				System.out.println("No son iguales");
			}
		}
		{ // Con equals de object
			if (auto1.equals(auto2)) {
				System.out.println("Son iguales");
			} else {
				System.out.println("No son iguales");
			}
			
			if (auto1.equals(auto3)) {
				System.out.println("Son iguales");
			} else {
				System.out.println("No son iguales");
			}	
		}
	}
}
