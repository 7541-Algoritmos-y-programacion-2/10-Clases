package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2;

public class Base {

	public void incrementarCampo(int valorDelCampoAdicional) {
		// TODO Auto-generated method stub
		
	}

	public void decrementarCampo(int valorDelCampoAdicional) {
		// TODO Auto-generated method stub
		
	}

}
