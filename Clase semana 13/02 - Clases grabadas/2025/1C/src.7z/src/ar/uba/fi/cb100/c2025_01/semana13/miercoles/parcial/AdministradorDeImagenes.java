package ar.uba.fi.cb100.c2025_01.semana13.miercoles.parcial;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;


public class AdministradorDeImagenes {

	/**
	 * Pre: imagenes no es nula
	 * Dado un listado de imagenes busca la imagen con mas pixeles puros
	 * @param imagenes
	 * @return
	 */
	public Imagen getImagenMasPura(List<Imagen> imagenes) {
		ValidacionesUtiles.validarNoNulo(imagenes, "Imagenes");
		Imagen resultado = null;
		for(Imagen imagen: imagenes) {
			if ((resultado == null) ||
			    (resultado.getCantidadDePixelesPuros() < imagen.getCantidadDePixelesPuros())) {
				resultado = imagen;
			}
		}
		return resultado;
	}
	
	public static void main(String[] args) {
		Imagen imagen = new Imagen(2, 2);
		imagen.getPixel(1, 1).setBlue(0);
		imagen.getPixel(1, 1).setGreen(0);
		imagen.getPixel(1, 1).setRed(1);
	}
}