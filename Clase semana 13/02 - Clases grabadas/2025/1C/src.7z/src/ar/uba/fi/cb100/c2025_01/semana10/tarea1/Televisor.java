package ar.uba.fi.cb100.c2025_01.semana10.tarea1;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

/**
 * TDA del parcial 2021 1C oportunidad 2
 */
public class Televisor {

	// Constants
	private static final int CANTIDAD_CANALES_MAX = 140; //parametro del constructor
	private static final int VOLUMEN_MUTE = 0;  //volumen minimo
	private static final int VOLUMEN_MAX = 100; //volumen maximo
	
	// Atributos
	private Canal[] canales;
	private int volumen; //o dentro del canal
	private Canal canalActual;  //int indiceDeCanalActual
	
	//Constructores
	
	/**
	 * Constructor de Televisor con 140 canales y volumen en 0. Crea canales del 1 al 141 (140 canales).
	 */
	Televisor(){
//		this.canales = new Canal[CANTIDAD_CANALES_MAX];
//		for(int i = 0 ; i < CANTIDAD_CANALES_MAX ; i++) {
//			this.canales[i] = new Canal(i + 1);
//		}
//		this.volumen = VOLUMEN_MUTE;
//		this.canalActual = canales[0];
		this(Televisor.CANTIDAD_CANALES_MAX);
	}
	
	/**
	 * Constructor con una cantidad definida de canales. Crea canales del 1 al (n + 1).
	 * @param cantidadCanales : Cantidad de canales, rango = [1-140]
	 */
	Televisor(int cantidadCanales){
//		ValidacionesUtiles.validarRango(cantidadCanales, 1, CANTIDAD_CANALES_MAX, "Cantidad de canales");
//		this.canales = new Canal[cantidadCanales];
//		for(int i = 0 ; i < cantidadCanales ; i++) {
//			this.canales[i] = new Canal(i + 1);
//		}
//		this.volumen = VOLUMEN_MUTE;
//		this.canalActual = canales[0];
		this(Televisor.CANTIDAD_CANALES_MAX, VOLUMEN_MUTE);
	}
	
	/**
	 * Constructor con cantidad definida de canales y volumen. Crea canales del 1 al (n + 1) con volumen m  
	 * @param cantidadCanales : Cantidad de canales, rango = [1 - 140]
	 * @param volumen : Volumen de los canales, rango = [0 - 100]
	 */
	Televisor(int cantidadCanales, int volumen){
		ValidacionesUtiles.validarRango(volumen, VOLUMEN_MUTE, VOLUMEN_MAX, "Volumen");
		ValidacionesUtiles.validarRango(cantidadCanales, 1, CANTIDAD_CANALES_MAX, "Canales");
		this.canales = new Canal[cantidadCanales];
		for(int i = 0 ; i < cantidadCanales ; i++) {
			this.canales[i] = new Canal((i + 1), volumen);
		}
		this.volumen = volumen;
		this.canalActual = canales[0];
	}
	
	/**
	 * Devuelve el volumen actual de la television
	 * @return Volumen actual de la television
	 */
	public int getVolumen() {
		return this.volumen; //this.canalActual.getVolumen()
	}
	
	/**
	 * Devuelve el canal que se esta mirando
	 * @return Canal actual.
	 */
	public Canal getCanal() {
		return this.canalActual;
	}
	
	/**
	 * Pasa a un canal contiguo al actual. Admite dos modos "+" y "-" para pasar al canal siguiente o al canal anterior respectivamente. 
	 * @param modo : Forma de cambiar, opciones = "-" y "+"
	 */
	public void pasarCanal(String modo) {
		Canal canalAnterior = this.canalActual;
		this.canalActual = this.canales[canalAnterior.getNumeroCanal() + 1];
		this.canalActual.setVolumen( canalAnterior.getVolumen() );
		
		int indiceCanalActual = this.getIndiceCanal(this.canalActual);
		if(modo == "+") {
			this.canalActual = this.canales[(indiceCanalActual + 1)];
			this.canalActual.setVolumen(this.volumen);
		} else if (modo == "-") {
			this.canalActual = this.canales[(indiceCanalActual - 1)];
			this.canalActual.setVolumen(this.volumen);
		} else {
			throw new RuntimeException("El modo que se selecciono no corresponde con un boton de control remoto");
		}
	}

	public void avanzarCanal() {
		pasarCanal("+");
	}

	public void retrocederCanal() {
		pasarCanal("-");
	}
	
	/**
	 * Pasa a un canal correspondiente al indice que se le pase por parametro.
	 * @param indice : Indice a cambiar, rango = [1 - (n + 1)]
	 */
	public void pasarCanal(int numeroDeCanal) {
		ValidacionesUtiles.validarRango(numeroDeCanal, 1, this.getCantidadCanales(), "Indice");
		this.canalActual = this.canales[(numeroDeCanal - 1)];
		this.canalActual.setVolumen(this.volumen);
		//Buscar canal por numero, considerando que no son consecutivos
	}
	
	/**
	 * Cambia el volumen de la television por uno pasado por parametro
	 * @param volumenNuevo : Volumen a pasar.
	 */
	public void volumen(int volumenNuevo) {
		ValidacionesUtiles.validarRango(volumenNuevo, VOLUMEN_MUTE, VOLUMEN_MAX, "Volumen");
		//this.volumen = volumenNuevo;
		this.canalActual.setVolumen(volumenNuevo);
	}
	
	/**
	 * Cambia el volumen de la television por 0.
	 */
	public void mute() {
		//this.volumen = VOLUMEN_MUTE;
		this.canalActual.setVolumen(VOLUMEN_MUTE);
	}
	
	/**
	 * Obtiene el volumen que se escucho por ultima vez en un canal.
	 * @param canal : Canal al que consultar.
	 * @return El volumen del canal consultado.
	 * @throws RuntimeException.
	 */
	public int consultarVolumen(Canal canal) throws RuntimeException {
		for(int i = 0 ; i < this.getCantidadCanales() ; i++) {
			if(this.canales[i].equals(canal)) {
				return this.canales[i].getVolumen();
			}
		}
		throw new RuntimeException("El canal no esta disponible en este televisor");
	}
	
	/**
	 * Obtiene el volumen máximo con el que se escuchó alguna vez un canal.
	 * @param canal : Canal al que consultar.
	 * @return Volumen maximo del canal consultado.
	 * @throws RuntimeException
	 */
	public int consultarVolumenMax(Canal canal) throws RuntimeException {
		return getCanal(canal).getVolumenMax();		
	}
	
	private Canal getCanal(Canal canal) {
		ValidacionesUtiles.validarNoNulo(canal, "canal");
		for(int i = 0 ; i < this.getCantidadCanales() ; i++) {
			if(this.canales[i].equals(canal)) {
				return this.canales[i];
			}
		}
		throw new RuntimeException("El canal no esta disponible en este televisor");
	}

	/**
	 * Consulta el canal cuyo volumen es el mayor.
	 * @return El canal con el que se escuchó a mayor volumen (no puede ver la tele mientras)
	 */
	public Canal consultarCanalVolumenMax() {
		Canal canalVolumenMax = null;
		for(Canal canal: this.canales) {
			if ((canalVolumenMax == null)||
			    (canalVolumenMax.getVolumenMax() < canal.getVolumenMax())) {
				canalVolumenMax = canal;
			}
		}
		return canalVolumenMax;
	}
	
	/**
	 * Devuelve la cantidad de canales disponibles.
	 * @return : Cantidad de canales
	 */
	public int getCantidadCanales() {
		return this.canales.length;
	}

	/**
	 * Devuelve el indice de la lista de canales de un canal, es decir su numero menos uno.
	 * @param canal : Canal al que se le busca el índice.
	 */
	public int getIndiceCanal(Canal canal) {
		ValidacionesUtiles.validarNoNulo(canal, "canal");
		return (canal.getNumeroCanal() - 1);
	}
}
