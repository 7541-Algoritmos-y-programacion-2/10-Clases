package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2;

import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas.CartaCampoDeFuerza;

public class Partida {

	public Base getBasePrincipal() {
		// TODO Auto-generated method stub
		return null;
	}

	public void agregarCarta(CartaCampoDeFuerza cartaCampoDeFuerza) {
		// TODO Auto-generated method stub
		
	}


	public void quitarCarta(CartaCampoDeFuerza cartaCampoDeFuerza) {
		// TODO Auto-generated method stub
		
	}
}
