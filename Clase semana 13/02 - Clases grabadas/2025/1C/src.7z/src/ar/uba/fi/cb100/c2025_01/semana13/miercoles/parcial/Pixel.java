package ar.uba.fi.cb100.c2025_01.semana13.miercoles.parcial;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Pixel {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
	
	public static int RangoSuperiorDeColor = 255;
	
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private int red = 0;
	private int green = 0;
	private int blue = 0;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un pixel Negro
	 */
	public Pixel() {}
	
	/**
	 * Crea un pixel con los colores rgb dados
	 * @param red: entre 0 y 255 inclusive
	 * @param green: entre 0 y 255 inclusive
	 * @param blue: entre 0 y 255 inclusive
	 */
	public Pixel(int red, int green, int blue) {
		setRed(red);
		setGreen(green);
		setBlue(blue);
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Aplica el filtro de escala de gris al pixel
	 */
	public void aplicarFiltroDeEscalaDeGrises() {
		int valor = (int) (0.299 * this.getRed() + 0.587 * this.getGreen() + 0.114 * this.getBlue());
		this.setRed(valor);
		this.setGreen(valor);
		this.setBlue(valor);
	}
	
	/**
	 * Aplica el brillo de ser posible, sino deja el color saturado
	 */
	public void aplicarBrillo(int brillo) {
		ValidacionesUtiles.validarRango(brillo, -1 * Pixel.RangoSuperiorDeColor, Pixel.RangoSuperiorDeColor, null);
		this.setRed( normalizar( this.getRed() + brillo));
		this.setGreen( normalizar( this.getGreen() + brillo));
		this.setBlue( normalizar( this.getBlue() + brillo));
	}
	
	/**
	 * Dado un valor del pixel, devuelve un valor en el rango 0 o 255
	 * @param valor
	 * @return
	 */
	private int normalizar(int valor) {
		if (valor > RangoSuperiorDeColor) {
			return 255;
		}
		if (valor < 0) {
			return 0;
		}
		return valor;
	}
	
	/**
	 * Devuelve verdadero si la imagen tiene 2 colores en 0
	 * @return
	 */
	public boolean esPuro() {
		return (this.getRed() == 0 && this.getGreen() == 0 && this.getBlue()  > 0) ||
			   (this.getRed() == 0 && this.getGreen()  > 0 && this.getBlue() == 0) ||
			   (this.getRed()  > 0 && this.getGreen() == 0 && this.getBlue() == 0);
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la componente roja del pixel
	 * @return
	 */
	public int getRed() {
		return red;
	}
	
	/**
	 * Devuelve la componente verde del pixel
	 * @return
	 */
	public int getGreen() {
		return green;
	}

	/**
	 * Devuelve la componente azul del pixel
	 * @return
	 */
	public int getBlue() {
		return blue;
	}
		
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Cambia el valor rojo del pixel
	 * @param red: debe estar entre 0 y 255
	 */
	public void setRed(int red) {
		ValidacionesUtiles.validarRango(red, 0, RangoSuperiorDeColor, "Red");
		this.red = red;
	}
	public void setGreen(int green) {
		ValidacionesUtiles.validarRango(red, 0, RangoSuperiorDeColor, "Verde");
		this.green = green;
	}
	public void setBlue(int blue) {
		ValidacionesUtiles.validarRango(red, 0, RangoSuperiorDeColor, "Azul");
		this.blue = blue;
	}
}
