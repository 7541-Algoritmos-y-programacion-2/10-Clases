package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2;

import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas.Carta;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas.CartaCampoDeFuerza;

public class InvasionGalactica {

	public Base getBasePrincipal(Jugador jugador) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void jugar() {
		Carta carta = new CartaCampoDeFuerza();
		Turno turno = new Turno();
		
		boolean jugarCarta = true;
		//juega el turno
		if (jugarCarta) {
		
			carta.getAdministradorDeCarta().jugarCarta(this, turno);
		} else {
			carta.getAdministradorDeCarta().avanzarTurno(this, turno);
		}
	}


	public Partida getPartida(Jugador jugador) {
		// TODO Auto-generated method stub
		return null;
	}


	public InterfazGrafica getInterfazGrafica() {
		// TODO Auto-generated method stub
		return null;
	}


	public void getParteDeTablero(Coordenada coordenada, int radioDeVision) {
		// TODO Auto-generated method stub
		
	}

}
