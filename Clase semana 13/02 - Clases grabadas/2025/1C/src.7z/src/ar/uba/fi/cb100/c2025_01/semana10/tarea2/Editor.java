package ar.uba.fi.cb100.c2025_01.semana10.tarea2;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

//
public class Editor {
    private String nombre;//que es?

    /*
    public Editor(String nombre) {
        setNombre(nombre);
    }
	*/
    /*
    private void setNombre(String nombre) {
        ValidacionesUtiles.validarNoNulo(nombre, "nombre");
        this.nombre = nombre;
    }

    public String getNombreDelEditor() {
        return this.nombre;
    }
	*/

    //pre    
    public Imagen seleccionarImagen(ListaSimplementeEnlazada<Imagen> imagenesDisponibles, 
    									int cantidadComentarios) {
        ValidacionesUtiles.validarNoNulo(imagenesDisponibles, "imagenes disponibles");
        ValidacionesUtiles.validarMayorACero(cantidadComentarios, "cantidad de comentarios");
        Imagen imagenDePromedioMaximo = null;
        for (Imagen imagen : imagenesDisponibles) {
            if(imagen.getComentariosCalificados().size() == cantidadComentarios) {
            	if ((imagenDePromedioMaximo == null) ||
            	   (imagenDePromedioMaximo.getPromedioDeCalificaciones() < imagen.getPromedioDeCalificaciones())) {
            		imagenDePromedioMaximo = imagen;
            	}
            }
        }
        //ValidacionesUtiles.validarNoNulo(imagenEncontrada, "imagen encontrada");
        return imagenDePromedioMaximo;
    }


//    public boolean tieneComentariosSuficientes(Imagen imagen, int comentariosSuficientes){
//        int contador = 0;
//        for(Comentario comentario : imagen.getComentarios()){
//            if(comentarioEsValido(comentario)){
//                contador++;
//            }
//            if(contador >= comentariosSuficientes){
//                return true;
//            }
//        }
//        return false;
//    }


/*
    public double getPromedioDeCalificacionDeComentarios(Imagen imagen){
        double puntuaciontotal = 0;
        int cantidadComentarios=0;
        for(Comentario comentario : imagen.getComentariosCalificados()){
        	cantidadComentarios++;
        	puntuaciontotal += comentario.getCalificacion();
        }
        //ValidacionesUtiles.validarMayorACero(cantidadComentarios, "cantidad de comentarios");
        if (cantidadComentarios == 0) {
        	return 0;
        }
        return puntuaciontotal / cantidadComentarios;
    }
*/
//    public boolean comentarioEsValido(Comentario comentario){
//        return comentario.getCalificacion() > 0;
//    }






}

