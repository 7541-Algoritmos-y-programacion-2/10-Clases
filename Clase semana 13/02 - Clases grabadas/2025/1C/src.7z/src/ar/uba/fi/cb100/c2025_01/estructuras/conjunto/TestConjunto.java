package ar.uba.fi.cb100.c2025_01.estructuras.conjunto;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.List;

public class TestConjunto {

    @Test
    public void testDelMetodoAgregarYContiene() {
        Conjunto<String> conjunto = new Conjunto<>();
        assertTrue(conjunto.add("A"));
        assertTrue(conjunto.contains("A"));
        assertFalse(conjunto.add("A")); // duplicado
    }

    @Test
    public void testDelMetodoRemover() {
        Conjunto<Integer> conjunto = new Conjunto<>();
        conjunto.add(1);
        conjunto.add(2);
        assertTrue(conjunto.remove(1));
        assertFalse(conjunto.contains(1));
        assertFalse(conjunto.remove(3));
    }

    @Test
    public void testDelMetodoVacioYLongitud() {
        Conjunto<Double> conjunto = new Conjunto<>();
        assertTrue(conjunto.isEmpty());
        conjunto.add(1.1);
        conjunto.add(2.2);
        assertFalse(conjunto.isEmpty());
        assertEquals(2, conjunto.size());
    }

    @Test
    public void testDelMetodoVaciar() {
        Conjunto<Character> conjunto = new Conjunto<>();
        conjunto.add('A');
        conjunto.add('B');
        conjunto.clear();
        assertTrue(conjunto.isEmpty());
    }

    @Test
    public void testDelMetodoAgregarMuchosYContieneMuchos() {
        Conjunto<String> conjunto = new Conjunto<>();
        List<String> elementos = Arrays.asList("X", "Y", "Z");
        conjunto.addAll(elementos);
        assertTrue(conjunto.containsAll(elementos));
    }

    @Test
    public void testDelMetodoRetenerMuchos() {
        Conjunto<String> conjunto = new Conjunto<>();
        conjunto.add("A");
        conjunto.add("B");
        conjunto.add("C");
        conjunto.retainAll(Arrays.asList("B", "C", "D"));
        assertFalse(conjunto.contains("A"));
        assertTrue(conjunto.contains("B"));
    }

    @Test
    public void testDelMetodoRemoverMuchos() {
        Conjunto<Integer> conjunto = new Conjunto<>();
        conjunto.add(1);
        conjunto.add(2);
        conjunto.add(3);
        conjunto.removeAll(Arrays.asList(1, 3));
        assertFalse(conjunto.contains(1));
        assertTrue(conjunto.contains(2));
    }

    @Test
    public void testDelMetodoUnion() {
        Conjunto<String> a = new Conjunto<>();
        a.add("a");
        a.add("b");
        Conjunto<String> b = new Conjunto<>();
        b.add("b");
        b.add("c");

        Conjunto<String> union = a.union(b);
        assertTrue(union.contains("a"));
        assertTrue(union.contains("b"));
        assertTrue(union.contains("c"));
    }

    @Test
    public void testDelMetodoInterseccion() {
        Conjunto<String> a = new Conjunto<>();
        a.add("a");
        a.add("b");
        Conjunto<String> b = new Conjunto<>();
        b.add("b");
        b.add("c");

        Conjunto<String> inter = a.interseccion(b);
        assertEquals(1, inter.size());
        assertTrue(inter.contains("b"));
    }

    @Test
    public void testDelMetodoDiferencia() {
        Conjunto<String> a = new Conjunto<>();
        a.add("a");
        a.add("b");
        Conjunto<String> b = new Conjunto<>();
        b.add("b");
        b.add("c");

        Conjunto<String> diff = a.diferencia(b);
        assertEquals(1, diff.size());
        assertTrue(diff.contains("a"));
    }
}
