package ar.uba.fi.cb100.c2025_01.semana03.jueves;

public class TestEjercicio16Rectangulo {

	public static void main(String[] args) {
		
		try {
			
			int alturaLeida = 15;
			Rectangulo.validarBase(alturaLeida);
			
			Rectangulo rectangulo1 = new Rectangulo(10,alturaLeida);
		
			
			System.out.println( rectangulo1.getAltura() + " " + rectangulo1.getBase());
			System.out.println( "El area es: " + rectangulo1.getArea());
			System.out.println( "El perimetro es: " + rectangulo1.getPerimetro());
			
			System.out.println( rectangulo1.toString() );
			
			Rectangulo rectangulo2 = new Rectangulo(10,alturaLeida);
			
			if (rectangulo1.equals(rectangulo2)) {
				System.out.println( "Los rectangulos son iguales");	
			}
			if (rectangulo1 != rectangulo2) {
				System.out.println( "Los punteros de los rectangulos son distintos");
			}
			if (rectangulo1 == rectangulo1) {
				System.out.println( "Los punteros de los rectangulos son iguales");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println(e.getMessage());
		}
	}

}
