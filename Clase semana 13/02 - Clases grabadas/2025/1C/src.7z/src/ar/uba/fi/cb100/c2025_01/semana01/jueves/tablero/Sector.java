package ar.uba.fi.cb100.c2025_01.semana01.jueves.tablero;

public class Sector {

	public String valor = "";

}
