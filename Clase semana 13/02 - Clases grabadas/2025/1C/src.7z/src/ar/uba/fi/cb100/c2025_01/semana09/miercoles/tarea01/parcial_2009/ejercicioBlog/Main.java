package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.parcial_2009.ejercicioBlog;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Crear el blog
        Blog blog = new Blog();
        //blog.getArticulos().get(0).getComentarios().clear();
        
        // Crear algunos artículos
        List<String> palabrasClave1 = new ArrayList<>();
        palabrasClave1.add("tecnología");
        palabrasClave1.add("java");

        Articulo articulo1 = new Articulo("Introducción a Java", "Este artículo es sobre Java y sus aplicaciones.", palabrasClave1);

        List<String> palabrasClave2 = new ArrayList<>();
        palabrasClave2.add("cultura");
        palabrasClave2.add("historia");

        Articulo articulo2 = new Articulo("Historia de la humanidad", "Un vistazo a la historia de la humanidad a través del tiempo.", palabrasClave2);

        // Agregar artículos al blog
        blog.agregarArticulo(articulo1);
        blog.agregarArticulo(articulo2);

        // Crear algunos comentarios para los artículos
        Comentario comentario1 = new Comentario("Muy buen artículo sobre Java", 5);
        Comentario comentario2 = new Comentario("Interesante perspectiva histórica", 4);

        // Agregar comentarios a los artículos
        articulo1.agregarComentario(comentario1);
        articulo2.agregarComentario(comentario2);

        // Buscar artículos por palabra clave
        List<Articulo> articulosTecnologia = blog.buscarArticulos("java", 1, 5);

        // Mostrar los artículos encontrados
        System.out.println("Artículos encontrados sobre 'java':");
        for (Articulo articulo : articulosTecnologia) {
            System.out.println("- " + articulo.getPalabrasClave());
        }

        // Verificación del promedio de calificación
        System.out.println("Promedio de calificaciones de los artículos:");
        System.out.println("Artículo 1: " + articulo1.obtenerPromedioDeCalificaciones());
        System.out.println("Artículo 2: " + articulo2.obtenerPromedioDeCalificaciones());
    }
}
