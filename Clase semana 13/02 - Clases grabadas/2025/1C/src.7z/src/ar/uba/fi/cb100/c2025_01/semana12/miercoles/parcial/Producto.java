package ar.uba.fi.cb100.c2025_01.semana12.miercoles.parcial;

import java.util.Objects;

class Producto {

	private String nombre = null;
	private String categoria = null;
	
	/* post: Producto con el nombre y la categoría
	 *	indicados.
	 */
	public Producto(String nombre, String categoria) {}

	/* post: devuelve el nombre del Producto.
	 */
	public String obtenerNombre() { return null;}

	/* post: devuelve la categoría del Producto.
	 */
	public String obtenerCategoria() {return null;}

	@Override
	public int hashCode() {
		return Objects.hash(categoria, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Producto other = (Producto) obj;
		return Objects.equals(categoria, other.categoria) && 
			   Objects.equals(nombre, other.nombre);
	}
	
	
}
