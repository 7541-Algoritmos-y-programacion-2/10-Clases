package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas;

import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.Coordenada;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.InvasionGalactica;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.Turno;

public class AdministradorDeCartaDeRastreadorCuantico extends AdministradorDeCarta {

	public AdministradorDeCartaDeRastreadorCuantico(Carta carta) {
		super(carta);
	}

	@Override
	public void jugarCarta(InvasionGalactica invasionGalactica, Turno turno) {
		Coordenada coordenada = invasionGalactica.getInterfazGrafica().preguntarCoordenada();
		
		invasionGalactica.getParteDeTablero(coordenada, getCartaRastreadorCuantico().getRadioDeVision());
		//recorrer e imprimir
	}

	@Override
	public void avanzarTurno(InvasionGalactica invasionGalactica, Turno turno) {}

	public CartaRastreadorCuantico getCartaRastreadorCuantico() {
		return (CartaRastreadorCuantico) this.getCarta();
	}
}
