package ar.uba.fi.cb100.c2025_01.estructuras.arbol;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaConCursor;

public class ArbolBinarioDeBusqueda<T extends Comparable<T>> {
	
    private NodoDeArbol<T> raiz = null;

    public ArbolBinarioDeBusqueda() {
        raiz = null;
    }

    // Método para insertar un nuevo nodo en el árbol
    public void insertar(T valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    private NodoDeArbol<T> insertarRecursivo(NodoDeArbol<T> nodo, T valor) {
        if (nodo == null) {
            return new NodoDeArbol<T>(valor);
        }

        if (valor.compareTo(nodo.getValor()) == -1) {
            nodo.setIzquierdo( insertarRecursivo(nodo.getIzquierdo(), valor) );
        } else if (valor.compareTo(nodo.getValor()) == 1) {
            nodo.setDerecho( insertarRecursivo(nodo.getDerecho(), valor));
        }

        return nodo;
    }

    // Método para buscar un valor en el árbol
    public boolean buscar(T valor) {
        return buscarRecursivo(raiz, valor);
    }

    private boolean buscarRecursivo(NodoDeArbol<T> nodo, T valor) {
        if (nodo == null) {
            return false;
        }

        if (valor.equals(nodo.getValor())) {
            return true;
        }

        
        return valor.compareTo(nodo.getValor()) == -1
                ? buscarRecursivo(nodo.getIzquierdo(), valor)
                : buscarRecursivo(nodo.getDerecho(), valor);
    }

    public boolean estaVacio() {
    	return this.raiz == null;
    }
    
    //FIXME: agregar el eliminar en la guia
    
    // Recorridos en el árbol

    // Inorden (izquierda, raíz, derecha)
    public void inorden() {
        inordenRecursivo(raiz);
    }

    private ListaConCursor<T> inordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            inordenRecursivo(nodo.getIzquierdo());
            //FIXME: devolver como lista el recorrido. Tarea
            System.out.print(nodo.getValor() + " ");
            inordenRecursivo(nodo.getDerecho());
        }
        return null;
    }

    // Preorden (raíz, izquierda, derecha)
    public void preorden() {
        preordenRecursivo(raiz);
    }

    private void preordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            System.out.print(nodo.getValor() + " ");
            preordenRecursivo(nodo.getIzquierdo());
            preordenRecursivo(nodo.getDerecho());
        }
    }

    // Postorden (izquierda, derecha, raíz)
    public void postorden() {
        postordenRecursivo(raiz);
    }

    private void postordenRecursivo(NodoDeArbol<T> nodo) {
        if (nodo != null) {
            postordenRecursivo(nodo.getIzquierdo());
            postordenRecursivo(nodo.getDerecho());
            System.out.print(nodo.getValor() + " ");
        }
    }

	protected NodoDeArbol<T> getRaiz() {
		return raiz;
	}

	protected void setRaiz(NodoDeArbol<T> raiz) {
		this.raiz = raiz;
	}
    
	/**
	 * Devuelve la cantidad de nodos hojas que tenga el arbol o 0 si esta vacio
	 * @return
	 */
	public int contarCantidadDeHojas() {
		return contarCantidadDeHojas(this.raiz);
	}
    
	/**
	 * Dado un nodo, devuelve la cantidad de hojas que tiene ese subarbol
	 * @param nodo
	 * @return
	 */
	private int contarCantidadDeHojas(NodoDeArbol<T> nodo) {
		if (nodo == null) {
			return 0;
		}
		if (!nodo.tieneHijos()) {
			return 1;
		}
		return contarCantidadDeHojas(nodo.getIzquierdo()) + contarCantidadDeHojas(nodo.getDerecho()); 
	}
	
	/**
	 * Devuelve la cantidad de nodos cons 2 hijos que tenga el arbol o 0 si esta vacio
	 * @return
	 */
	public int contarCantidadDeNodosConDosHijos() {
		return contarCantidadDeNodosConDosHijos(this.raiz);
	}
	
	/**
	 * Dado un nodo, devuelve la cantidad de nodos que tienen 2 hijos de ese subarbol
	 * @param nodo
	 * @return
	 */
	private int contarCantidadDeNodosConDosHijos(NodoDeArbol<T> nodo) {
		if ((nodo == null) ||
		   (!nodo.tieneHijos())) {
			return 0;
		}
		if (nodo.tieneUnHijo()) {
			return contarCantidadDeNodosConDosHijos(nodo.getIzquierdo()) + contarCantidadDeNodosConDosHijos(nodo.getDerecho());
		}
		return 1 + contarCantidadDeNodosConDosHijos(nodo.getIzquierdo()) + contarCantidadDeNodosConDosHijos(nodo.getDerecho());
	}
	
	/**
	 * Devuelve la altura del arbol
	 * @return
	 */
	public int calcularAltura() {
		return calcularAltura(this.raiz);
	}
	
	/**
	 * Dado un nodo, devuelve la altura del mismo
	 * @param nodo
	 * @return
	 */
	private int calcularAltura(NodoDeArbol<T> nodo) {
		if (nodo == null) {
			return 0;
		}
		int alturaIzquierda = calcularAltura(nodo.getIzquierdo());
		int alturaDerecha = calcularAltura(nodo.getDerecho());
		return Math.max(alturaIzquierda, alturaDerecha) + 1;
	}
}