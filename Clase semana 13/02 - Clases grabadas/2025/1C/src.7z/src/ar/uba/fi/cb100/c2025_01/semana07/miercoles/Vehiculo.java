package ar.uba.fi.cb100.c2025_01.semana07.miercoles;

public interface Vehiculo {

	/**
	 * 
	 */
	public void arrancar();
	
	public void detener();
	
	public void acelerar();
}
