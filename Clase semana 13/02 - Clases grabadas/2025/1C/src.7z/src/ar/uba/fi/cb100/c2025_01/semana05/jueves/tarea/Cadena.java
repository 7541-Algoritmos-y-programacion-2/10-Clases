package ar.uba.fi.cb100.c2025_01.semana05.jueves.tarea;

/**
 * Una cadena está compuesta por una secuencia de eslabones.
 * Toda cadena tiene al menos un eslabón. Cada eslabón posee 
 * largo y ancho. Todos los eslabones de la cadena deben 
 * tener el mismo ancho, pero el largo puede diferir. Se
 * debe poder agregar o retirar eslabones de la cadena.
 * Se requiere conocer la longitud total de la cadena.
 * 
 * || Hipotesis: La longitud total de la Cadena está dada 	  ||
 * || por la suma del largo de cada Eslabón. Esta medida es en||
 * || centimetros.											  ||
 * @param args
 */
public class Cadena {

	//INTERFACES ----------------------------------------------------------------------------------------------
	//ENUMERADOS ----------------------------------------------------------------------------------------------
	//CONSTANTES ----------------------------------------------------------------------------------------------
	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	private Eslabon[] eslabones = null;
	private double anchoDelEslabonEnCentimetros = 0;
	private int longitudDeLaCadenaEnCentimetros = 0;

	//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	/**
	 * Dado un primer eslabon y la capacidad maxima de la cadena, se crea un primer eslabon para la cadena.
	 * Además, queda fijo el valor de ancho.
	 * 
	 * @param eslabon: Eslabon a crear
	 * @param capacidadDeEslabones: Capacidad maxima de eslabones que podrá tener la cadena
	 */
	public Cadena(Eslabon eslabon, int capacidadDeEslabones) {
		this.eslabones = new Eslabon[capacidadDeEslabones];
		this.anchoDelEslabonEnCentimetros = eslabon.ancho;
		agregarEslabon(eslabon);
	}
	
	//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
	//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
	//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
	//METODOS DE CLASE ----------------------------------------------------------------------------------------
	//METODOS GENERALES ---------------------------------------------------------------------------------------
	@Override
	public String toString() {
		return "La cadena tiene una longitud de " + getLongitudDeLaCadena() + "cm.";
	}

	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
	 * Agrega un nuevo eslabón a la cadena.
	 * @param eslabon: Eslabón a agregar
	 */
	public void agregarEslabon(Eslabon eslabon) {

		if (getCantidadDeEslabones() >= eslabones.length) {
			throw new RuntimeException("Capacidad máxima alcanzada.");
		}
		
		validarAnchoDelEslabon(eslabon.ancho);

		this.eslabones[getCantidadDeEslabones()] = eslabon;
//		setCantidadDeEslabones(1);
		actualizarLongitudDeLaCadena(eslabon.largo); 		// Sumo el largo del eslabón a retirar de la longitud de la Cadena.
	}
	
	/**
	 * Retira el último eslabón de la cadena y lo retorna.
	 * @return
	 */
	public Eslabon retirarEslabon() {
		
		int indiceEslabon = getCantidadDeEslabones() - 1;
		
	    if (indiceEslabon < 0) {
	        throw new RuntimeException("¡No hay eslabones para retirar!");
	    }
		
	    Eslabon eslabonRetirado = eslabones[indiceEslabon];
	    
		actualizarLongitudDeLaCadena( -(eslabones[indiceEslabon].largo) ); 	// Resto el largo del eslabón a retirar de la longitud de la Cadena.
		eslabones[indiceEslabon] = null;
		
		return eslabonRetirado;
	}
	

	/**
	 * Para nuevos eslabones valido que el ancho sea el mismo que el inicial.
	 * @param anchoDelEslabon
	 */
	private void validarAnchoDelEslabon(double anchoDelEslabon) {
		if( getAnchoDelEslabon() != anchoDelEslabon ) {
			throw new RuntimeException("Todos los eslabones deben ser tener " + getAnchoDelEslabon() + " de ancho");
		}
	}
	
	/**
	 * Cambia la longitud de la cadena.
	 * @param valor: 1 = agregar. -1 = retirar.
	 */
	private void actualizarLongitudDeLaCadena(double largoDelEslabon) {
		this.longitudDeLaCadenaEnCentimetros += largoDelEslabon;
	}
	
	//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
	//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
	//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
	//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	/**
	 * Devuelve la cantidad de eslabones de la cadena.
	 * @return
	 */
	public int getCantidadDeEslabones() {
	    int cantidadDeEslabones = 0;
	    
	    for (int i = 0; i < this.eslabones.length; i++) {
	        if (eslabones[i] != null) {
	        	cantidadDeEslabones++;
	        }
	    }
	    
	    return cantidadDeEslabones;
	}
	/**
	 * Dado un indice, se devuelve el Eslabon de la cadena correspondiente a esa posicion.
	 * @param indiceDelEslabon: Los indices comienzan en 0.
	 * @return
	 */
	public Eslabon getEslabon(int indiceDelEslabon) {
		indiceDelEslabon--;
		
	    if (indiceDelEslabon < 0 || indiceDelEslabon >= getCantidadDeEslabones()) {
	    	throw new IndexOutOfBoundsException("Posición inválida: " + indiceDelEslabon);
	    }
	    
		return eslabones[indiceDelEslabon];
	}
	
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	/**
	 * Devuelve el ancho del eslabón.
	 * @return
	 */
	private double getAnchoDelEslabon() {
		return anchoDelEslabonEnCentimetros;
	}

	/**
	 * Devuelve la longitud de la cadena.
	 * @return
	 */
	public int getLongitudDeLaCadena() {
		return this.longitudDeLaCadenaEnCentimetros;
	}
	
	//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	

}
