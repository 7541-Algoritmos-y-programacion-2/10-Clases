package ar.uba.fi.cb100.c2025_01.semana09.jueves.tarea01;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Compuesto {
  //INTERFACES ----------------------------------------------------------------------------------------------
  //ENUMERADOS ----------------------------------------------------------------------------------------------
  //CONSTANTES ----------------------------------------------------------------------------------------------
  //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
  //ATRIBUTOS -----------------------------------------------------------------------------------------------
    
    private float cantidad = 0;
    private String nombre = null;
    private UnidadDeMedida unidadDeMedida = null;
    
  //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
  //CONSTRUCTORES -------------------------------------------------------------------------------------------
    
    /**
     * Crea un compuesto, el nombre y la unidad de medida quedan fijos
     * @param nombre
     * @param unidadDeMedida
     * @throws Exception
     */
    public Compuesto(String nombre, UnidadDeMedida unidadDeMedida) throws Exception{
        this.setNombre(nombre);
        this.setUnidadDeMedida(unidadDeMedida);
    }
    
  //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
  //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
  //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
  //METODOS DE CLASE ----------------------------------------------------------------------------------------
  //METODOS GENERALES ---------------------------------------------------------------------------------------
  //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
    
    @Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Compuesto other = (Compuesto) obj;
		return Objects.equals(nombre, other.nombre);
	}
    
  //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
  //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
  //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
  //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
  //GETTERS SIMPLES -----------------------------------------------------------------------------------------
    
    /**
     * Devuelve el nombre del compuesto
     * @return
     */
    public String getNombre(){
        return this.nombre;
    }

	/**
     * Devuelve la unidad de medida del compuesto
     */
    public UnidadDeMedida getUnidadDeMedida(){
        return this.unidadDeMedida;
    }

    /**
     * Devuelve la cantidad del compuesto
     * @return
     */
    public float getCantidad(){
        return this.cantidad;
    }
    
  //SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
  //SETTERS SIMPLES -----------------------------------------------------------------------------------------
    
    /**
     * Cambia el nombre del compuesto
     * @param nombre
     * @throws Exception
     */
    private void setNombre(String nombre) {
        ValidacionesUtiles.validarNoNulo(nombre, "Nombre"); 
        this.nombre = nombre;
    }

    /**
     * Cambia la unidad de medida del compuesto
     * @param unidadDeMedida
     */
    private void setUnidadDeMedida(UnidadDeMedida unidadDeMedida) {
    	ValidacionesUtiles.validarNoNulo(unidadDeMedida, "Unidad de medida");
		this.unidadDeMedida = unidadDeMedida;
	}

	/**
     * Cambia la cantidad del compuesto
     * @param cantidad
     * @throws Exception
     */
    public void setCantidad(float cantidad) {
        ValidacionesUtiles.validarMayorACero(cantidad, "Cantidad");
        this.cantidad = cantidad;
    }
    
  }