package test.ar.uba.fi.cb100.c2025_02.estructuras.bitmap;

import java.awt.Color;
import java.awt.Font;

import ar.uba.fi.cb100.c2025_02.material.bitmap.Bitmap;
import ar.uba.fi.cb100.c2025_02.material.bitmap.BitmapViewer;
import ar.uba.fi.cb100.c2025_02.material.utiles.SistemaUtiles;

public class DemoBitmapViewer {
	
	/**
	 * Ejemplo de grafico de bitmaps
	 * @param args
	 * @throws Exception
	 */
    public static void main(String[] args) throws Exception {
        Bitmap bmp1 = new Bitmap(200, 200);
        Bitmap bmp2 = new Bitmap(400, 400);
        
        BitmapViewer.showBitmaps(bmp1, bmp2);

        bmp1.drawCircle(100, 100, 50, Color.RED);
        bmp2.drawCube(100, 100, 0, 0, Color.BLUE);


        // Actualización en tiempo real del bitmap y se dibuja automaticamente
        for (int i = 0; i < 200; i++) {
        	bmp1.drawText(i + "s", 50, 30, new Font("Arial", Font.BOLD, 28), Color.WHITE, Color.BLACK);
        	SistemaUtiles.esperar(200);
            bmp1.drawPixel(i, i, Color.GREEN);
            
        }
    }
}
