package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea02.club;

import java.util.List;
import java.util.Set;

import ar.uba.fi.cb100.c2025_02.material.estructuras.conjuntos.Conjunto;
import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class AdministradorDeClubSocial {

    /**
     * pre: socios no puede ser nulo
     * post: Devuelve una nueva lista con los socios, uno por familia,
     * cuyo grupo familiar no tuvo deudas.
     * @param socios: lista de socios.
     */
//    public List<Socio> buscarSocioParaDescuento(List<Socio> socios) {
//        ValidacionesUtiles.esDistintoDeNull(socios, "'socios'");
//
//        ConjuntoBasico<Socio> sociosFiltrados =
//                					this.sociosSet(socios)
//                						.diferencia(this.sociosSetConDeudas(socios));
//        
//        List<Socio> resultado = new ListaDoblementeEnlazada<Socio>();
//        resultado.addAll(sociosFiltrados.elementos());
//        return resultado;
//    }
    
    public List<Socio> buscarSocioParaDescuentoV2(List<Socio> socios) {
        ValidacionesUtiles.esDistintoDeNull(socios, "'socios'");

        Set<Socio> familias = this.getFamilias(socios);
        familias.removeAll(this.getFamiliasConDeuda(socios));
        
        List<Socio> resultado = new ListaSimplementeEnlazada<Socio>();
        resultado.addAll(familias);
        return resultado; 
        //return List.copyOf(familias);
    }
    

    /**
     * post: Devuelve un nuevo conjunto (sin repeticiones) con los socios de la lista dada.
     * @param socios: lista de socios.
     * @return un conjunto de socios.
     */
    public Set<Socio> getFamilias(List<Socio> socios) {
    	ValidacionesUtiles.esDistintoDeNull(socios, "'socios'");
        Set<Socio> resultado = new Conjunto<Socio>();
        for (Socio socio: socios) {
            resultado.add(socio);
        }
        return resultado;
    }

    /**
     * post: Devuelve un nuevo conjunto con todos los socios de la lista dada
     * que tuvieron deuda.
     * @param socios: lista de socios
     * @return un conjunto de socios morosos.
     */
    public Set<Socio> getFamiliasConDeuda(List<Socio> socios) {
    	ValidacionesUtiles.esDistintoDeNull(socios, "'socios'");
    	Set<Socio> resultado = new Conjunto<Socio>();
        for (Socio socio: socios) {
            if (socio.tuvoDeuda()) {
                resultado.add(socio);
            }
        }
        return resultado;
    }
}