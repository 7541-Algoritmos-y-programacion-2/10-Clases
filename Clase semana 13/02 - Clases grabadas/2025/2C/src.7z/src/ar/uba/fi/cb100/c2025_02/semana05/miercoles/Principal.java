package ar.uba.fi.cb100.c2025_02.semana05.miercoles;

import java.io.FileNotFoundException;

import ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1.Libro;


public class Principal {

	/**
	 * Metodo que no puedo modificar
	 * @throws Exception
	 */
	public static void test2() throws Exception {
		throw new Exception("hola");
	}
	
	/**
	 * Interpretar la excepcion
	 */
	public static void test() {
		try {
			test2();
		} catch (Exception e) {
			throw new TestException(new Libro("Java", "Sun", 32, 23));
		}
		throw new RuntimeException("hola");
	}
	
	public static void test3() throws Exception {
		test2();
	}
	
	public static void main(String[] args) {
		try {
			System.out.println("Paso 1");
			//test();
			System.out.println("Paso 2");
		} catch (TestException e) {
			System.out.println("Paso 3 " + e.getLibro());
			e.printStackTrace();
		} catch (RuntimeException e) {
			System.out.println("Paso 4");
			e.printStackTrace();
		} catch (Throwable t) {
			t.printStackTrace();
		} finally { //optativo
			System.out.println("Paso finally");
		}
	}

}
