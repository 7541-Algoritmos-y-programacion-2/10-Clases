package ar.uba.fi.cb100.c2025_02.semana10.miercoles.tren;

public class PrincipalClase19 {

	public static void main(String[] args) {
		{
			Tren tren = new Tren(3, 10);
			tren.agregarVagon(new Vagon(50), new Vagon(20));
			tren.agregarVagon(new Vagon(50));
		}
		{
			Tren tren = new Tren(1, 20);
		}
	}
}
