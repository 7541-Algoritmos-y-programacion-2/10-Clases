package ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial;

public class PrincipalClase12 {

	public static void main(String[] args) {
	       System.out.println("--- CASO DE USO 1: DIBUJAR TABLERO DE AJEDREZ ---");
	        casoDeUso1();
	        
	        System.out.println("\n--- CASO DE USO 2: CREAR UN DEGRADADO DE ROJO A AZUL ---");
	        casoDeUso2();
	        
	        System.out.println("\n--- CASO DE USO 3: APLICAR FILTRO DE GRISES Y BRILLO ---");
	        casoDeUso3();

	        System.out.println("\n--- CASO DE USO 4: INVERTIR UNA IMAGEN ---");
	        casoDeUso4();
	        
	        System.out.println("\n--- CASO DE USO 5: ENCONTRAR PIXELES MÁS INTENSOS ---");
	        casoDeUso5();
	    }

	    /**
	     * Crea una imagen de 8x8 y dibuja un patrón de tablero de ajedrez.
	     */
	    public static void casoDeUso1() {
	        Imagen2d tablero = new Imagen2d(8, 8);
	        Pixel negro = new Pixel(0, 0, 0);

	        for (int y = 1; y <= tablero.getAlto(); y++) {
	            for (int x = 1; x <= tablero.getAncho(); x++) {
	                // Si la suma de coordenadas es par, el pixel es blanco (por defecto), sino es negro.
	                if ((x + y) % 2 == 0) {
	                    tablero.getPixel(x, y).setR(negro.getR());
	                    tablero.getPixel(x, y).setG(negro.getG());
	                    tablero.getPixel(x, y).setB(negro.getB());
	                }
	            }
	        }
	        System.out.println("Tablero de ajedrez creado:");
	        imprimirImagen(tablero);
	    }
	    
	    /**
	     * Crea una imagen y dibuja un degradado horizontal de rojo a azul.
	     */
	    public static void casoDeUso2() {
	        Imagen2d degradado = new Imagen2d(10, 20);
	        
	        for (int y = 1; y <= degradado.getAlto(); y++) {
	            for (int x = 1; x <= degradado.getAncho(); x++) {
	                int valorRojo = (int) (255 * (1 - ((double) x / degradado.getAncho())));
	                int valorAzul = (int) (255 * ((double) x / degradado.getAncho()));
	                Pixel p = degradado.getPixel(x, y);
	                p.setR(valorRojo);
	                p.setG(0);
	                p.setB(valorAzul);
	            }
	        }
	        System.out.println("Imagen con degradado de rojo a azul:");
	        imprimirImagen(degradado);
	    }

	    /**
	     * Crea una imagen colorida, la muestra, le aplica un filtro de escala de grises,
	     * la vuelve a mostrar, y finalmente le aplica un filtro de brillo.
	     */
	    public static void casoDeUso3() {
	        Imagen2d colores = new Imagen2d(5, 10);
	        // Llenamos con colores
	        for (int y = 1; y <= colores.getAlto(); y++) {
	            for (int x = 1; x <= colores.getAncho(); x++) {
	                colores.getPixel(x, y).setR((x * 25) % 255);
	                colores.getPixel(x, y).setG((y * 45) % 255);
	                colores.getPixel(x, y).setB((x * y * 10) % 255);
	            }
	        }
	        
	        System.out.println("Imagen original colorida:");
	        imprimirImagen(colores);
	        
	        colores.aplicarFiltroEscalaDeGrises();
	        System.out.println("\nImagen en escala de grises:");
	        imprimirImagen(colores);
	        
	        colores.aplicarFiltroDeBrillo(60);
	        System.out.println("\nImagen con +60 de brillo:");
	        imprimirImagen(colores);
	    }
	    
	    /**
	     * Crea una imagen no simétrica (una "L"), la invierte horizontal y verticalmente.
	     */
	    public static void casoDeUso4() {
	        Imagen2d letraL = new Imagen2d(5, 5);
	        Pixel negro = new Pixel(0, 0, 0);

	        // Dibujar la "L"
	        for (int y = 1; y <= 5; y++) {
	            letraL.getPixel(2, y).setR(0); // Columna vertical
	        }
	        for (int x = 2; x <= 4; x++) {
	            letraL.getPixel(x, 5).setR(0); // Fila horizontal
	        }
	        
	        System.out.println("Imagen original (Letra L):");
	        imprimirImagen(letraL);
	        
	        // Se crea una copia para no modificar la original al invertir
	        Imagen2d copiaH = new Imagen2d(5, 5);
	        copiaH.getPixel(1,1).setR(1); // Para que no sea igual a la original
	        copiaH.equals(letraL); // Forzamos a que sean distintas

	        // Copiamos pixel a pixel
	        for(int y = 1; y <= 5; y++) {
	            for(int x = 1; x <= 5; x++) {
	                Pixel pOrig = letraL.getPixel(x,y);
	                Pixel pCopia = copiaH.getPixel(x,y);
	                pCopia.setR(pOrig.getR());
	                pCopia.setG(pOrig.getG());
	                pCopia.setB(pOrig.getB());
	            }
	        }

	        copiaH.invertirHorizontalmente();
	        System.out.println("\nImagen invertida horizontalmente:");
	        imprimirImagen(copiaH);
	        
	        letraL.invertirVerticalmente();
	        System.out.println("\nImagen original invertida verticalmente:");
	        imprimirImagen(letraL);
	    }
	    
	    /**
	     * Crea una imagen con un pixel rojo puro, uno verde puro y uno azul puro,
	     * y luego utiliza los métodos de búsqueda para encontrarlos.
	     */
	    public static void casoDeUso5() {
	        Imagen2d imagen = new Imagen2d(4, 4);
	        
	        // Puntos de color intenso
	        imagen.getPixel(2, 2).setR(255);
	        imagen.getPixel(3, 3).setG(255);
	        imagen.getPixel(4, 1).setB(255);
	        
	        System.out.println("Imagen con puntos de colores intensos:");
	        imprimirImagen(imagen);
	        
	        Pixel masRojo = imagen.getPixelMasRojo();
	        Pixel masVerde = imagen.getPixelMasVerde();
	        Pixel masAzul = imagen.getPixelMasIntenso(ComponenteDeColor.Azul);
	        
	        System.out.println("\nEl pixel más rojo es: " + masRojo + " con valor " + masRojo.getR());
	        System.out.println("El pixel más verde es: " + masVerde + " con valor " + masVerde.getG());
	        System.out.println("El pixel más azul es: " + masAzul + " con valor " + masAzul.getB());
	    }
	    
	    /**
	     * Método auxiliar para imprimir una representación de la imagen en la consola.
	     * Muestra un '#' para pixeles oscuros y un ' ' para pixeles claros.
	     */
	    public static void imprimirImagen(Imagen2d img) {
	        for (int y = 1; y <= img.getAlto(); y++) {
	            for (int x = 1; x <= img.getAncho(); x++) {
	                Pixel p = img.getPixel(x, y);
	                // Si la suma de componentes es menor a 384 (la mitad de 255*3), es "oscuro"
	                if (p.getR() + p.getG() + p.getB() < 384) {
	                    System.out.print("##");
	                } else {
	                    System.out.print("  ");
	                }
	            }
	            System.out.println();
	        }
	    }
	    
    public static void casoDeUso6() {
		Imagen2d imagen2d = new Imagen2d(10, 10);
		
		for(int i = 1; i <= 10; i++ ) {
			imagen2d.getPixel(i, i).setB(100);
		}

		for(int i = 1; i <= imagen2d.getAncho(); i++) {
			for(int j = 1; j <= imagen2d.getAlto(); j++) {
				System.out.println( imagen2d.getPixel(i,  j));
			}
		}
	}
}
