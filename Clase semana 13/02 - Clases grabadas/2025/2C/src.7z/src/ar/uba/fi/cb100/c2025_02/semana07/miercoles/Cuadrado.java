package ar.uba.fi.cb100.c2025_02.semana07.miercoles;

public class Cuadrado implements Figura, Comparable<Cuadrado> {

	private double base = 0;
	private double altura = 0;
	
	public Cuadrado(double base, double altura) {
		this.base = base;
		this.altura = altura;
	}
	
	public Cuadrado() {}

	@Override
	public double getArea() {
		return base * altura;
	}

	public double getBase() {
		return base;
	}

	public double getAltura() {
		return altura;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	@Override
	public int compareTo(Cuadrado o) {
		return Double.valueOf( this.getArea()).compareTo(o.getArea());
	}
	
	

}
