package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea04;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

/**
 * Hipotesis:
 * no tiene que haber setter de erroresCometidos porque empezara en 0 y solo se debe poder aumentar por medio de errar
 */
public class Ahorcado {
    private Estado estado;
    private String palabra = null;
    private int erroresPermitidos;
    private int erroresCometidos = 0;

    /**
     * @param palabra no null, entre 3 y 20 caracteres
     * @param erroresPermitidos mayor o igual a cero
     */
    public Ahorcado(String palabra, int erroresPermitidos){
        setPalabra(palabra);
        setErroresPermitidos(erroresPermitidos);
        setEstado(Estado.JUGANDO);
    }

    @Override
    public String toString(){
        return "Ahorcado de palabra: "+ palabra + " y "+ erroresPermitidos +" errores permitidos";
    }

    @Override
    public boolean equals(Object o){
        if(o == null || o.getClass() != getClass()){
            return false;
        }
        Ahorcado otro = (Ahorcado) o;
        return this == otro ||
               this.estado == otro.getEstado() &&
               this.erroresPermitidos == otro.getErroresPermitidos() &&
               this.getCantidadDeLetras() == otro.getCantidadDeLetras();
    }

    /**
     * Busca una letra en la palabra y devuelve la cantidad de apariciones que hallo. Si no hubo apariciones,
     * se incrementan los errores cometidos.
     * @param letra la letra a buscar en la palabra
     * @return la cantidad de veces que aparece la letra en la palabra
     */
    public int arriesgarLetra(Character letra){
        if(!estaJugando()){
            throw new RuntimeException("El ahorcado no esta en juego");
        }

        letra = Character.toLowerCase(letra);
        int apariciones = 0;
        for(int i = 0; i < palabra.length(); i++){
            if(palabra.charAt(i) == letra){
                apariciones++;
            }
        }
        if(apariciones == 0){
            cometerError();
        }
        if(erroresCometidos > erroresPermitidos)
            setEstado(Estado.PERDIDO);
        return apariciones;
    }

    /**
     * Arriesga una palabra, si es la misma el juego queda ganado y devuelve true, sino, pierde y devuelve false
     * @param palabra no null, entre 5 y 20 caracteres
     * @return true si acerto la palabra, false si no.
     */
    public boolean arriesgarPalabra(String palabra){
        ValidacionesUtiles.esDistintoDeNull(palabra, "palabra");
        ValidacionesUtiles.validarLongitudDeTexto(palabra, 3, 20, "palabra");
        if(palabra.toLowerCase().equals(this.palabra)){
            setEstado(Estado.GANADO);
            return true;
        }
        setEstado(Estado.PERDIDO);
        return false;
    }

    /**
     * Incrementa los errores cometidos en 1
     */
    public void cometerError(){
        this.erroresCometidos++;
    }

    /**
     * Permite conocer si la partida sigue en juego
     * @return true si estado == JUGANDO
     */
    public boolean estaJugando(){
        return estado == Estado.JUGANDO;
    }

    /**
     * @return los erroresPermitidos
     */
    public int getErroresPermitidos(){
        return erroresPermitidos;
    }

    /**
     * Permite conocer el estado de la partida
     * @return JUGANDO, GANADO o PERDIDO
     */
    public Estado getEstado(){
        return estado;
    }

    /**
     * @return cantidad de letras que tiene la palabra
     */
    public int getCantidadDeLetras(){
        return palabra.length();
    }

    /**
     * @return errores cometidos durante esta partida
     */
    public int getErroresCometidos(){
        return erroresCometidos;
    }

    /**
     * Permite conocer la palabra, pero solo si la partida termino
     * @return string vacio o palabra
     */
    public String getPalabra(){
        if(this.estaJugando()){
            return "";
        }
        return this.palabra;
    }

    /**
     * @param palabra no null, entre 3 y 20 caracteres
     */
    private void setPalabra(String palabra){
        ValidacionesUtiles.esDistintoDeNull(palabra, "palabra");
        ValidacionesUtiles.validarLongitudDeTexto(palabra, 3, 20, "palabra");
        this.palabra = palabra.toLowerCase();
    }

    /**
     * @param errores meyor o igual a cero
     */
    private void setErroresPermitidos(int errores){
    	ValidacionesUtiles.validarMayorOIgualACero(errores, "Errores");
        this.erroresPermitidos = errores;
    }

    /**
     * @param estado no null
     */
    private void setEstado(Estado estado) {
    	ValidacionesUtiles.esDistintoDeNull(estado, "Estado");
        if (estado == Estado.PERDIDO && this.estado == Estado.GANADO) {
            throw new RuntimeException("No puede perder si ya gano");
        }
        if (estado == Estado.GANADO && this.estado == Estado.PERDIDO) {
            throw new RuntimeException("No puede perder si ya gano");
        }
        this.estado = estado;
    }

}

