package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia;

public class Personaje {

	public void incrementarEnergia(int valorDelCampoAdicional) {
		// TODO Auto-generated method stub
		
	}

	public void decrementarEnergia(int valorDelCampoAdicional) {
		// TODO Auto-generated method stub
		
	}

}
