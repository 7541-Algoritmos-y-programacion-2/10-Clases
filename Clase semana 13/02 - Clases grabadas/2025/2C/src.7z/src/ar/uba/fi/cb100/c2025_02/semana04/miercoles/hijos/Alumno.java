package ar.uba.fi.cb100.c2025_02.semana04.miercoles.hijos;

import ar.uba.fi.cb100.c2025_02.semana04.miercoles.personas.Persona;

public class Alumno extends Persona {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	
	private static int UltimoNumeroDePadron = 1;
	
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private int padron;

//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public Alumno() {
		this.padron = UltimoNumeroDePadron++;
	}
	
	public Alumno(String nombre) {
		super(nombre);
		this.padron = UltimoNumeroDePadron++;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
	
	public static int getUltimoNumeroDePadronUtilizado() {
		return Alumno.UltimoNumeroDePadron - 1;
	}
	
	public static int getProximoNumeroDePadronLibre() {
		return Alumno.UltimoNumeroDePadron;
	}
	
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	@Override
	public String firmar() {
		return "Alumno: " + this.getNombre() + " (padron: " + getPadron() + ")";
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el padron del alumno
	 * @return
	 */
	public int getPadron() {
		return padron;
	}
	
//	@Override
//	public String getNombre() {
//		return "Gustavo";
//	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
