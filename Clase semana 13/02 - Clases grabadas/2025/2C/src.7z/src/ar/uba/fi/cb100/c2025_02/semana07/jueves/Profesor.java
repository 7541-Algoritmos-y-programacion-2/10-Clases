package ar.uba.fi.cb100.c2025_02.semana07.jueves;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Profesor {

	/**
	 * Alumnos y promedios no pueden ser nulos
	 * @param alumnos: son los alumnos posibles que tienen notas
	 * @param promedios: son los promedios (1 x materia como maximo) de los alumnos de la lista alumnos
	 * @return devolvemos una lista de alumnos (sin repetir) con el mejor promedio de cada materia (si existe)
	 */
	public List<Alumno> buscarMejoresAlumnos(
										List<Alumno> alumnos,
										List<Nota> promedios) {
		ValidacionesUtiles.esDistintoDeNull(alumnos, "Alumnos");
		ValidacionesUtiles.esDistintoDeNull(promedios, "Promedios");
		List<Alumno> resutado = new ListaSimplementeEnlazada<Alumno>();
		for(String materia: getMaterias(promedios)) {
			Nota nota = getMejorPromedio(materia, promedios);
			if (!resutado.contains( new Alumno(nota.getPadron()))) {
				resutado.add(buscarAlumno(nota.getPadron(), alumnos));
			}
		}		
		return resutado;
	}
	
	
	/**
	 * Alumnos y promedios no pueden ser nulos
	 * @param alumnos: son los alumnos posibles que tienen notas
	 * @param promedios: son los promedios (1 x materia como maximo) de los alumnos de la lista alumnos
	 * @return devolvemos una lista de alumnos (sin repetir) con el mejor promedio de cada materia (si existe)
	 */
	public List<Alumno> buscarMejoresAlumnosConEmpate(
										List<Alumno> alumnos,
										List<Nota> promedios) {
		ValidacionesUtiles.esDistintoDeNull(alumnos, "Alumnos");
		ValidacionesUtiles.esDistintoDeNull(promedios, "Promedios");
		List<Alumno> resutado = new ListaSimplementeEnlazada<Alumno>();
		for(String materia: getMaterias(promedios)) {
			List<Nota> notas = getMejorPromedioConEmpate(materia, promedios);
			if (!notas.isEmpty()) {
				agregarAlumnos(resutado, getAlumnos(notas, alumnos));
			}
		}		
		return resutado;
	}
	
	/**
	 * 
	 * @param resutado
	 * @param alumnos
	 */
	public void agregarAlumnos(List<Alumno> resutado, List<Alumno> alumnos) {
		for(Alumno alumno: alumnos) {
			if (!resutado.contains(alumno)) {
				resutado.add(alumno);
			}
		}		
	}


	/**
	 * 
	 * @param notas
	 * @param alumnos
	 * @return
	 */
	public List<Alumno> getAlumnos(List<Nota> notas, List<Alumno> alumnos) {
		List<Alumno> resultado = new ListaSimplementeEnlazada<Alumno>();
		for(Nota nota: notas) {
			resultado.add( buscarAlumno(nota.getPadron(), alumnos));
		}
		return resultado;
	}


	/**
	 * Busca un alumno en el listado
	 * @param padron
	 * @param alumnos
	 * @return el alumno o una excepcion
	 */
	public Alumno buscarAlumno(Integer padron, List<Alumno> alumnos) {
		ValidacionesUtiles.esDistintoDeNull(alumnos, "Alumnos");
		for(Alumno alumno: alumnos) {
			if (padron.equals( alumno.getPadron())) {
				return alumno;
			}
		}
		throw new RuntimeException("No se encontro el alumno: " + padron );
	}

	/**
	 * 
	 * @param materia
	 * @param promedios
	 * @return el mejor promedio si lo encuentra, o null en caso contrario
	 */
	public Nota getMejorPromedio(String materia, List<Nota> promedios) {
		ValidacionesUtiles.esDistintoDeNull(promedios, "Promedios");
		Nota resultado = null;
		for(Nota nota: promedios) {
			if (nota.getMateria().equals(materia) &&
				((resultado == null) ||
				 (resultado.getValor() < nota.getValor()))) {
				resultado = nota;
			}
		}		
		return resultado;
	}

	public List<Nota> getMejorPromedioConEmpate(String materia, List<Nota> promedios) {
		ValidacionesUtiles.esDistintoDeNull(promedios, "Promedios");
		List<Nota> resultado = new ListaSimplementeEnlazada<Nota>();
		Nota mejorPromedio = null;
		for(Nota nota: promedios) {
			if (nota.getMateria().equals(materia)) {				
				if ((mejorPromedio == null) ||
					(mejorPromedio.getValor() < nota.getValor())) {
					mejorPromedio = nota;
					resultado.clear();					
				}
				if (mejorPromedio.getValor() == nota.getValor()) {
					resultado.add(mejorPromedio);
				}
			}
		}		
		return resultado;
	}
	

	/**
	 * Obtiene el listado de materias de el listado de notas
	 * @param promedios: promedios de notas de los alumnos
	 * @return listado de materias no repetidas
	 */
	public List<String> getMaterias(List<Nota> promedios) {
		List<String> materias = new ListaSimplementeEnlazada<String>(); 
		for(Nota nota: promedios) {
			if (!materias.contains(nota.getMateria())) {
				materias.add(nota.getMateria());
			}
		}
		return materias;
	}
}
