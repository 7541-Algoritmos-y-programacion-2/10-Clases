package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea04;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea03.Foro;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea03.Mensaje;

public class ModeradoActualizado {
		
	/**
	 * recibe una lista de foros, un usuario a buscar y una tematica a buscar
	 * @param foros tiene que ser distinto de null
	 * @param usuarioBuscado tiene que ser distinto de null
	 * @param tematicaBuscada tiene que ser distitno de null
	 * @return devuelve el mensaje que mas votos tiene del usuario buscado que tenga la tematica buscada
	 */
	public Mensaje buscarMensajeMasVotadoDelUsuarioSegunTematica(List<Foro> foros, 
			                                                     String usuarioBuscado, 
			                                                     String tematicaBuscada) {
		ValidacionesUtiles.esDistintoDeNull(foros, "foros");
		ValidacionesUtiles.esDistintoDeNull(usuarioBuscado, "usuario buscado");
		ValidacionesUtiles.esDistintoDeNull(tematicaBuscada, "tematica buscada");
		Mensaje resultado = null;
		for(Foro foro: foros) {
			if(foro.obtenerTematicas().contains(tematicaBuscada)) {
			for(Mensaje mensaje: foro.obtenerMensajes()) {
				if(mensaje.obtenerUsuario().equals(usuarioBuscado) &&
				   (resultado == null ||
				   mensaje.contarVotos() > resultado.contarVotos())) {
					resultado = mensaje;
				}
			}
		}
	}
		return resultado;
}	
}
		
		

		

