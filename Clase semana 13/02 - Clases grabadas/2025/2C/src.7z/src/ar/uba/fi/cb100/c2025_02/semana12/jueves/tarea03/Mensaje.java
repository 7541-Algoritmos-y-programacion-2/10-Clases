package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea03;

public class Mensaje {
    private String usuario = null;
    private String texto = null;
    private int votos = 0;

    public Mensaje(String usuario, String texto){
        this.usuario = usuario;
        this.texto = texto;
    }

    public String obtenerUsuario() {
        return usuario;
    }
    public String obtenerContenido(){
        return texto;
    }

    public int contarVotos(){
        return votos;
    }

    public void votar(){
        votos++;
    }

    @Override
    public String toString(){
        return "Usuario: "+usuario+" texto: "+texto+" votos: "+votos;
    }
}
