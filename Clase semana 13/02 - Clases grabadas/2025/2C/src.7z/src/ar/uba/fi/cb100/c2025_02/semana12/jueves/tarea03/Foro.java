package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea03;
import java.util.Collection;
import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.conjuntos.Conjunto;
import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Foro {
    private String nombre = null;
    private List<Mensaje> mensajes = new ListaSimplementeEnlazada<>();
    private Collection<String> tematicas = new Conjunto<>();

    public Foro(String nombre){
        ValidacionesUtiles.esDistintoDeNull(nombre, "nombre");
        this.nombre = nombre;

    }

    public void vaciar(){
        mensajes.clear();
    }

    public String getNombre(){
        return nombre;
    }

    public List<Mensaje> obtenerMensajes(){
        return List.copyOf(mensajes);
    }

    public List<String> obtenerTematicas(){
        return List.copyOf(tematicas);
    }

    public void agregarMensaje(Mensaje mensaje){
        ValidacionesUtiles.esDistintoDeNull(mensaje, "mensaje");
        mensajes.add(mensaje);
    }

    public void agregarTematica(String tematica){
        ValidacionesUtiles.esDistintoDeNull(tematica, "tematica");
        tematicas.add(tematica);
    }

}
