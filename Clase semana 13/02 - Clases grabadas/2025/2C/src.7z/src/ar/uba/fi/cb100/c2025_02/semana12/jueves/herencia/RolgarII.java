package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia;

import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas.Carta;
import ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas.CartaCampoDeFuerza;

public class RolgarII extends Juego {

	public Personaje getBasePrincipal(Jugador jugador) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void jugar() {
		//Antes
		Carta carta = new CartaCampoDeFuerza();
		
		
		//Mucho codigo
		Turno turno = new Turno();
		
		boolean jugarCarta = true;
		//juega el turno
		if (jugarCarta) {
		
			carta.getAdministradorDeCarta().jugarCarta(this, turno);
		} else {
			carta.getAdministradorDeCarta().avanzarTurno(this, turno);
		}
	}


	public PartidaDeRolgarII getPartida(Jugador jugador) {
		// TODO Auto-generated method stub
		return null;
	}


	public InterfazGrafica getInterfazGrafica() {
		// TODO Auto-generated method stub
		return null;
	}


	public void getParteDeTablero(Coordenada coordenada, int radioDeVision) {
		// TODO Auto-generated method stub
		
	}

}
