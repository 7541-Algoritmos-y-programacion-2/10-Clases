package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea04;

public enum Estado {
    JUGANDO,
    GANADO,
    PERDIDO
}
