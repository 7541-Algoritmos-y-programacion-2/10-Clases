package ar.uba.fi.cb100.c2025_02.semana02.jueves;

public class Numero {

	public int valor;
}
