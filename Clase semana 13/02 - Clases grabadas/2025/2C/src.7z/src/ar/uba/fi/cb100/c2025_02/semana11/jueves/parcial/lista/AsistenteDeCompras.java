package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista;

import java.util.Comparator;
import java.util.List;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class AsistenteDeCompras {
	
	private int indiceActual = 0;

    /**
     * post: Busca para cada comprador dos atuendos del mismo color, distinto tipo y cuyo precio combinado
     * no supere el presupuesto. Devuelve los atuendos que NO fueron comprados.
     */
    public List<Atuendo> comprarAtuendos(List<Atuendo> stockDeAtuendos, List<Comprador> compradores) {
    	ValidacionesUtiles.esDistintoDeNull(stockDeAtuendos, "stock");
    	ValidacionesUtiles.esDistintoDeNull(compradores, "Compradores");

        Vector<Atuendo> stockDeAtuendosTemporal = convertirAVector(stockDeAtuendos); 
        compradores.sort(new Comparator<Comprador>() {
			@Override
			public int compare(Comprador o1, Comprador o2) {
				return Double.valueOf(o1.getPresupuesto()).compareTo(o2.getPresupuesto());
			}
		});
        stockDeAtuendos.sort(new Comparator<Atuendo>() {
			@Override
			public int compare(Atuendo o1, Atuendo o2) {
				return Double.valueOf(o1.getPrecio()).compareTo(o2.getPrecio());
			}
		});
        
        for (Comprador comprador : compradores) {        	
            Atuendo atuendo1 = buscarAtuendo(stockDeAtuendosTemporal, 1, comprador.getPresupuesto(), null, null);
            if (atuendo1 != null) {
            	Atuendo atuendo2 = buscarAtuendo(stockDeAtuendosTemporal, indiceActual, comprador.getPresupuesto() - atuendo1.getPrecio(), atuendo1.getColor(), atuendo1.getTipo());
            	if (atuendo2 == null) {
            		stockDeAtuendosTemporal.agregar(atuendo1);	
            	}
            }
        }
        
        //compradores.listIterator(indiceActual);
        return convertirALista(stockDeAtuendosTemporal);
    }

    public Atuendo buscarAtuendo(Vector<Atuendo> stock, 
    								int indiceInicial, 
    								double valorMaximo, 
    								String color,
    								String tipoAEvitar) {
    	for(indiceActual = indiceInicial; indiceActual < stock.getLongitud(); indiceActual++) {
    		Atuendo atuendo = stock.obtener(indiceActual);
    		if ((atuendo != null) &&
    		    (atuendo.getPrecio() < valorMaximo)) {    			
    			if (color == null) {
    				stock.agregar(indiceActual, null);
    				return atuendo;
    			}
    			if (atuendo.getColor().equals(color) &&
    				!atuendo.getTipo().equals(tipoAEvitar)) {
    				stock.agregar(indiceActual, null);
    				return atuendo;
    			}
    		}
    	}
		return null;
	}

    /**
     * Convierte una lista en vector. Tendria que ir en el TDA Vector
     * @param list
     * @return
     */
    public static <T> Vector<T> convertirAVector(List<T> list) {
    	Vector<T> vector = new Vector<T>(list.size(), null);
    	for(T atuendo: list) {
    		vector.agregar(atuendo);
    	}
    	return vector;
    }
    
    /**
     * Convierte un vector en una lista. Tendria que ir en el TDA Lista
     * @param <T>
     * @param vector
     * @return
     */
    public static <T> List<T> convertirALista(Vector<T> vector) {
    	List<T> lista = new ListaSimplementeEnlazada<T>();
    	for(int i = 1; i < vector.getLongitud(); i++) {
    		T atuendo = vector.obtener(i);
    		if (atuendo != null) {
    			lista.add(atuendo);
    		}
    	}
    	return lista;
    }
}
