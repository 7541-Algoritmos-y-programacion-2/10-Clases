package ar.uba.fi.cb100.c2025_02.semana06.jueves.ejercicioParcial;

import ar.uba.fi.cb100.c2025_02.material.utiles.NumerosUtiles;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Pixel {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
    private int r;
    private int g;
    private int b;
    
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
    
    /**
     * Dados los colores del pixel, se genera uno
     * @param r: valor rojo entre 0 y 255
     * @param g: valor verde entre 0 y 255
     * @param b: valor azul entre 0 y 255
     */
    public Pixel(int r, int g, int b){
        setR(r);
        setG(g);
        setB(b);
    }
    
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
    
    /**
     * Genera un pixel blanco
     * @return
     */
    public static Pixel generarPixelBlanco() {
    	return new Pixel(255, 255, 255);
    }
    
//METODOS GENERALES ---------------------------------------------------------------------------------------
    
    /**
     * Devuelve el texto del Pixel
     */
    @Override
    public String toString(){
        return "("+ this.r + ", "+ this.g +" ,  "+ this.b + ")";
    }
    
    @Override
    public boolean equals(Object p){
        if(p == null){
            return false;
        }
        if(p == this){
            return true;
        }
        if(this.getClass() != p.getClass()){
            return false;
        }
        Pixel other = (Pixel) p;
        return this.r == other.r &&
                this.g == other.g &&
                this.b == other.b;
    }
    
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
    


    /**
     * Aplica el filtro en escala de grises al prixel, 
     * siendo: 
     *   rojo = 0.299 * rojo 
     *   verde = 0.587 * verde
     *   azul = 0.114 * azul
     */
	public void aplicarFiltroEscalaDeGrises() {
		this.setR( Double.valueOf(0.299 * this.r).intValue());
		this.setG( Double.valueOf(0.587 * this.g).intValue());
		this.setB( Double.valueOf(0.114 * this.b).intValue());
	}

	/**
	 * Aplica el filtro de brillo
	 * @param brillo: valor entre -255 y 255
	 */
	public void aplicarFiltroDeBrillo(int brillo) {
		ValidacionesUtiles.validarRangoNumerico(-255, 255, brillo, "brillo");
		this.setR(NumerosUtiles.limitarRango(0, 255, this.getR() + brillo));
		this.setG(NumerosUtiles.limitarRango(0, 255, this.getG() + brillo));
		this.setB(NumerosUtiles.limitarRango(0, 255, this.getB() + brillo));
	}
    
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
    
    /**
     * Devuelve la componente Roja del pixel
     * @return
     */
    public int getR(){
        return this.r;
    }

    /**
     * Devuelve la componente verde del pixel
     * @return
     */
    public int getG(){
        return this.g;
    }

    /**
     * Devuelve la componente azul del pixel
     * @return
     */
    public int getB(){
        return this.b;
    }
    
    public int getComponente(ComponenteDeColor componenteDeColor) {
    	switch (componenteDeColor) {
			case Rojo: return getR();
			case Verde: return getG();
			case Azul: return getG();
		}
    	throw new IllegalArgumentException("No se encontro la componente " + componenteDeColor);
    }
    	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     * Cambia la componente rojo del pixel
     * @param valor: debe estar en el rango 0 a 255
     */
    public void setR(int valor){
        ValidacionesUtiles.validarRangoNumerico(0, 255, valor, "rojo");
        this.r = valor;
    }

    /**
     * Cambia la componente verde del pixel
     * @param valor: debe estar en el rango 0 a 255
     */
    public void setG(int valor){
    	ValidacionesUtiles.validarRangoNumerico(0, 255, valor, "verde");
        this.g = valor;
    }

    /**
     * Cambia la componente azul del pixel
     * @param valor: debe estar en el rango 0 a 255
     */
    public void setB(int valor){
    	ValidacionesUtiles.validarRangoNumerico(0, 255, valor, "azul");
        this.b = valor;
    }
}

