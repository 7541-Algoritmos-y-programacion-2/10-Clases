package ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicio16;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Rectangulo {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private double base;
	private double altura;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un rectangulo con la base y altura dada
	 * 
	 * @param base debe ser mayor a 0
	 * @param altura debe ser mayor a 0
	 * 
	 * Si los parametros no verifican la pre condicion, lanza una excepcion
	 */
	public Rectangulo(double base, double altura) {
		this.setBase(base);
		this.setAltura(altura);
	}

	/**
	 * Dado un rectangulo, lo copia con la misma base y altura
	 * @param rectangulo
	 */
	public Rectangulo(Rectangulo rectangulo) {
		this.setBase(rectangulo.getBase());
		this.setAltura(rectangulo.getAltura());
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Rectangulo: base =" + this.base + " x altura =" + this.altura;
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * @return devuelve el area del rectangulo. EL area es base * altura
	 */
	public double getArea() {
		return this.base * this.altura;
	}
	
	/**
	 * 
	 * @return devuelve el perimetro del rectangulo. Es la suma de 2 * base + 2 * altura
	 */
	public double getPerimetro() {
		return this.base * 2 + this.altura * 2;
	}

//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * @return devuelve la base del rectangulo
	 */
	public double getBase() {
		return base;
	}

	/**
	 * @return devuelve la altura del rectangulo
	 */
	public double getAltura() {
		return altura;
	}
		
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	
	
	/**
	 * Cambia la base del rectangulo
	 * @param base debe ser un valor mayor a 0
	 */
	public void setBase(double base) {
		ValidacionesUtiles.validarMayorACero(base, "base");
		this.base = base;
	}

	/**
	 * Cambia la altura del rectangulo
	 * @param altura debe ser un valor mayor a 0
	 */
	public void setAltura(double altura) {
		ValidacionesUtiles.validarMayorACero(altura, "altura");
		this.altura = altura;
	}

//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
