package ar.uba.fi.cb100.c2025_02.semana03.jueves.ejercicioN2E1;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Libro extends Object {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private String titulo = null;
	private String autor = null;
	private int anioDePublicacion;
	private int cantidadDeCopias; //borrar
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param titulo
	 * @param autor
	 * @param anioDePublicacion
	 * @param cantidadDeCopias
	 */
	public Libro(String titulo,
					String autor,
					int anioDePublicacion,
					int cantidadDeCopias) {
		this.setTitulo(titulo);
		this.setAutor(autor);
		this.setAnioDePublicacion(anioDePublicacion);
		this.setCantidadDeCopias(cantidadDeCopias);
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
	
	public static Libro crear(String titulo) {
		return new Libro(titulo, "", 0, 0);
	}
	
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	/**
	 * devuelve el toString del libro con el titulo
	 */
	@Override
	public String toString() {
		return "Libro '" + this.titulo + "' de " + this.autor;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(anioDePublicacion, autor, titulo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		return anioDePublicacion == other.anioDePublicacion &&
				Objects.equals(autor, other.autor) && 
				Objects.equals(titulo, other.titulo);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
	 * Devuelve verdadero si el texto esta en el titulo o en el autor
	 * @param texto debe ser de longitud mayor a 0;
	 * @return
	 */
	public boolean contiene(String texto) {
		ValidacionesUtiles.validarLongitudDeTexto(texto, 1, null, "texto a buscar");
		return this.titulo.contains(texto) ||
				this.autor.contains(texto);
	}
	
	public void disminuirCantidadDeCopias() {
		this.setCantidadDeCopias( this.getCantidadDeCopias() - 1);		
	}
	
	/**
	 * Aumenta en uno la cantidad de copias del libro
	 */
	public void aumentarCantidadDeCopias() {
		this.setCantidadDeCopias( this.getCantidadDeCopias() + 1);
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * @return devuelve el titulo del libro
	 */
	public String getTitulo() {
		return titulo;
	}
	
	/**
	 * @return devuelve el autor del libro
	 */
	public String getAutor() {
		return autor;
	}
	
	/**
	 * @return devuelve el año de publicacion del libro
	 */
	public int getAnioDePublicacion() {
		return anioDePublicacion;
	}
	
	/**
	 * @return devuelve la cantidad de copias del libro en la biblioteca
	 */
	public int getCantidadDeCopias() {
		return cantidadDeCopias;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Cambia el titulo del libro
	 * @param titulo: debe tener entre 1 y 100 caracteres.
	 */
	private void setTitulo(String titulo) {
		ValidacionesUtiles.validarLongitudDeTexto(titulo, 1, 100, "titulo");
		this.titulo = titulo;
	}
	
	/**
	 * Cambia el autor de la publicacion
	 * @param autor: debe tener letras o espacios, entre 2 y 50 caracteres
	 */
	private void setAutor(String autor) {
		ValidacionesUtiles.validarLongitudDeTexto(autor, 2, 50, "autor");
		ValidacionesUtiles.validarCaracteresAlfabeticos(autor, "autor");
		this.autor = autor;
	}
	
	/**
	 * Cambia el año de publicacion del libro. Se permite cualquier año
	 * @param anioDePublicacion
	 */
	private void setAnioDePublicacion(int anioDePublicacion) {
		this.anioDePublicacion = anioDePublicacion;
	}
	
	/**
	 * Cambia la cantidad de copias del libro en la biblioteca
	 * @param cantidadDeCopias
	 */
	public void setCantidadDeCopias(int cantidadDeCopias) {
		ValidacionesUtiles.validarMayorOIgualACero(cantidadDeCopias, "cantidad de copias");
		this.cantidadDeCopias = cantidadDeCopias;
	}
}
