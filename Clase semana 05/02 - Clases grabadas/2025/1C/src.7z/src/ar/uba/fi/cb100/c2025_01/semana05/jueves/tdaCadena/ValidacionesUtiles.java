package ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena;

public class ValidacionesUtiles {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
	
	/**
	 * Valida valor y debe ser mayor a cero, sino tira error
	 * @param valor
	 */
	public static void validarMayorACero(Object object, String nombre) {		
		Double valor = 0.0;
		if (object instanceof Integer) {
			valor = Double.valueOf((Integer) object);
		}
		if (object instanceof Double) {
			valor = Double.valueOf((Double) object);
		}
		if (valor <= 0) {
			throw new RuntimeException("El " + nombre + " debe ser mayor a 0. Se ingreso " + valor);
		}
	}
	
	/**
	 * Valida que object no se nulo, y sino tira una excepcion
	 * @param object
	 * @param nombre
	 */
	public static void validarNoNulo(Object object, String nombre) {
		if (object == null) {
			throw new RuntimeException("El " + nombre + " no puede ser vacio.");
		}		
	}

	/**
	 * Valida la igualdad entre valor1 y 2, sino tira excepcion
	 * @param valor1
	 * @param valor2
	 * @param nombre
	 */
	public static void validarIgualdad(double valor1, double valor2, String nombre) {
		if (valor1 != valor2) {
			throw new RuntimeException("Los " + nombre + " no son iguales. " + valor1 + " no es igual a " + valor2);
		}		
	}
	
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	


}
