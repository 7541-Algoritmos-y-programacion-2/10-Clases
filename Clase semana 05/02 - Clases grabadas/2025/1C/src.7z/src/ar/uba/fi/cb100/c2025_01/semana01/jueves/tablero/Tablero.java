package ar.uba.fi.cb100.c2025_01.semana01.jueves.tablero;

public class Tablero {
	public final static int ANCHO = 5;
	public final static int ALTO = 5;
	
	public static void inicializarTablero(Sector[][] tablero) {
		for(int i = 0; i < tablero.length; i++) {
			for(int j = 0; j < tablero.length; j++) {
				tablero[i][j] = new Sector();
				tablero[i][j].valor = "_";				
			}
		}
	}
	
	public static void imprimirTablero(Sector[][] tablero) {
		for(int i = 0; i < tablero.length; i++) {
			for(int j = 0; j < tablero.length; j++) {
				System.out.print(tablero[i][j].valor + " ");			
			}
			System.out.println();
		}
	}
	
	//x va de 1 a 5
	public static void asignarValor(Sector[][] tablero, int x, int y, String valor) throws RuntimeException {
		if ((x < 1) ||
			(x > ANCHO)) {
			throw new RuntimeException("La posicion en X debe estar entre 1 y " + ANCHO + " inclusive. El valor fue " + x + ".");
		}
		if ((y < 1) ||
			(y > ANCHO)) {
			throw new RuntimeException("La posicion en Y debe estar entre 1 y " + ALTO + " inclusive. El valor fue " + y + ".");
		}
		tablero[x-1][y-1].valor = valor;
	}
}
