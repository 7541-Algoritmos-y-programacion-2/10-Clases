package ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena;

public class Eslabon {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private double largo;
	private double ancho;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * 
	 * @param largo es el largo del eslabon, debe ser mayor a 0
	 * @param ancho es el ancho del eslabon, debe ser mayor a 0
	 */
	public Eslabon(double largo, double ancho) {
		setLargo(largo);
		setAncho(ancho);
	}

//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Eslabon de " + this.getAncho() + " x " + this.getLargo();
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el largo del eslabon
	 * @return
	 */
	public double getLargo() {
		return largo;
	}

	/**
	 * Devuelve el ancho del eslabon
	 * @return
	 */
	public double getAncho() {
		return ancho;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Valida y cambia el largo del eslabon
	 * @param largo: debe ser mayor a 0
	 * @throws RuntimeException
	 */
	private void setLargo(double largo) throws RuntimeException {
		ValidacionesUtiles.validarMayorACero(largo, "largo");
		this.largo = largo;
	}

	/**
	 * Valida y cambia el ancho del eslabon
	 * @param ancho: debe ser mayor a 0
	 * @throws RuntimeException
	 */
	private void setAncho(double ancho) {
		ValidacionesUtiles.validarMayorACero(ancho, "ancho");
		this.ancho = ancho;
	}
	
}
