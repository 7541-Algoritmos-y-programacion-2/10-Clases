package ar.uba.fi.cb100.c2025_01.semana04.jueves.ejercicio_3_17;

import java.util.Scanner;

public class Alimento {

	private int calorias;

	private GramosConsumidos gramos;

	public Alimento() {

		this.calorias = 12;

		this.gramos = new GramosConsumidos();

	}

	public int getCalorias() {

		return calorias;

	}

	public void setGramos(int nroGramos) {

		this.gramos.setGramos(nroGramos);

	}

	public int calculoCalorias() {

		return (this.calorias * this.gramos.getGramos());

	}

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Alimento alimento = new Alimento(); // RECORDAR QUE SIEMPRE QUE LLAMO A UN METODO EN EL MAIN DEBO CREAR EL
											// OBJETO

		Scanner scanner = new Scanner(System.in);

		System.out.println("Ingrese cuantos gramos va a comsumir: ");

		int nroGramos = scanner.nextInt();

		// GramosConsumidos.setGramos(nroGramos);

		alimento.setGramos(nroGramos);

		int caloriasIngesta = alimento.calculoCalorias();

		System.out.println("Va a consumir " + caloriasIngesta + " en " + nroGramos + " los gramos ingresados");

		scanner.close();

	}

}