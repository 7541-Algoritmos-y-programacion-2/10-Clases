package ar.uba.fi.cb100.c2025_01.semana05.jueves.tarea;

/**
 * Una cadena está compuesta por una secuencia de eslabones.
 * Toda cadena tiene al menos un eslabón. Cada eslabón posee 
 * largo y ancho. Todos los eslabones de la cadena deben 
 * tener el mismo ancho, pero el largo puede diferir. Se
 * debe poder agregar o retirar eslabones de la cadena.
 * 
 * || Hipotesis: La longitud total de la Cadena está dada 	  ||
 * || por la suma del largo de cada Eslabón. Esta medida es en||
 * || centimetros.											  ||
 * @param args
 */
public class Eslabon {

	//INTERFACES ----------------------------------------------------------------------------------------------
	//ENUMERADOS ----------------------------------------------------------------------------------------------
	//CONSTANTES ----------------------------------------------------------------------------------------------
	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	protected double largo;
	protected double ancho;
	
	//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	/**
	 * Dado un ancho y largo en centimetros se crea un eslabón.
	 * @param largo: en Centimetros
	 * @param ancho: en Centimetros
	 */
	public Eslabon(double ancho, double largo) {
		this.validarMedidas(ancho, largo);

		this.ancho = ancho;
		this.largo = largo;
	}
	
	//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
	//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
	//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
	//METODOS DE CLASE ----------------------------------------------------------------------------------------
	//METODOS GENERALES ---------------------------------------------------------------------------------------
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	/**
	 * Dados un ancho y largo, se valida que ambos sean mayores a 0.
	 * @param ancho
	 * @param largo
	 */
	private void validarMedidas(double ancho, double largo) {
		if( ancho <= 0 ) {
			throw new RuntimeException("El ancho de la cadena debe ser mayor a 0");
		}
		if( largo <= 0 ) {
			throw new RuntimeException("El alto de la cadena debe ser mayor a 0");
		}
	}
	//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
	//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
	//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
	//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------

}
