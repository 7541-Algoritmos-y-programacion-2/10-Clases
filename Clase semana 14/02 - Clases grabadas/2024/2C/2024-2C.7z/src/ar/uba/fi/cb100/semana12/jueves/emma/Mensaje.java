package ar.uba.fi.cb100.semana12.jueves.emma;

public class Mensaje {

	public String obtenerUsuario() {
		// TODO Auto-generated method stub
		return null;
	}

	public int contarVotos() {
		// TODO Auto-generated method stub
		return 0;
	}

}
