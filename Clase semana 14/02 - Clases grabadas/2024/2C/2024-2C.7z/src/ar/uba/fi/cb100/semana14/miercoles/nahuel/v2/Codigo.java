package ar.uba.fi.cb100.semana14.miercoles.nahuel.v2;

import ar.uba.fi.cb100.semana07.miercoles.Nodo;

public class Codigo<T> {
	
	/**
	 * pre:
	 * @param valor: un valor a evaluar
	 * @throws Exception 
	 * post: retorna true si el valor esta en la lista y false en caso contrario
	 */
	public boolean contiene(T valor) throws Exception {
		if(valor == null) {
			throw new Exception("El valor no puede ser nulo");
		}
		Nodo<T> cursor = null; //this.primero;
		while (cursor != null) {
			if (cursor.getDato() == valor) {
				return true;
			}
			cursor = cursor.getSiguiente();
		}
		return false;
	}
	
}
