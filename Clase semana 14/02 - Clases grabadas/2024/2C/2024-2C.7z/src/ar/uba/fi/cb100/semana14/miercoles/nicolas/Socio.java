package ar.uba.fi.cb100.semana14.miercoles.nicolas;

public class Socio {

	String grupoFamiliar;
	
	public boolean tuvoDeuda() {
		return false;
	}
	
	public String getGrupoFamiliar() {
		return grupoFamiliar;
	}
	
}
