package ar.uba.fi.cb100.semana12.miercoles.parcial;

import ar.uba.fi.cb100.semana07.miercoles.Lista;
import ar.uba.fi.cb100.semana12.miercoles.tarea.lucas.Articulo;

/**
 * 
 * Tips:
 * 1 - solucionar el problema
 * 2 - Pre y post
 * 3 - validar
 * 4 - modularizar (partir el codigo en partes utiles, la estructura es while / if )
 * 5 - cumplir con TDA (conjunto completo de operaciones)
 * 
 */
public class Blog {

    private Lista<Articulo> articulos;
    
    public Lista<Articulo> getArticulos() {
        return articulos;
    }
    
	/**
	 * pre: 
	 * @param palabrasClaves no puede ser nula
	 * @return
	 * @throws Exception 
	 */
	public Lista<Articulo> buscarArticulos(Lista<String> palabrasClaves) throws Exception {
		if (palabrasClaves == null) {
			throw new Exception("Las palabras claves no pueden ser nulas");
		}
		
        Lista<Articulo> resultado = new Lista<Articulo>();    
        articulos.iniciarCursor();
        
        while(articulos.avanzarCursor()) {
            Articulo articuloARevisar = articulos.obtenerCursor();
            if (TextoUtiles.contieneTodas(articuloARevisar.getTitulo() + " " + articuloARevisar.getTexto(), 
            								palabrasClaves) &&
            	!TextoUtiles.contieneAlguna(articuloARevisar.getPalabrasExcluidas(), palabrasClaves)) {
            	resultado.agregar(articuloARevisar);
            }
        }            
		return resultado;
	}

}
