package ar.uba.fi.cb100.semana14.miercoles.nahuel.v1;

import ar.uba.fi.cb100.semana07.miercoles.Lista;

public class Comprobaciones {
	/**
	 * pre:
	 * @param posiblesFamiliares no puede ser nula.
	 * @param socio no puede ser nilo.
	 * @return devuelve true si algun familiar tubo deuda, devuelve false si ningun familiar tubo deuda.
	 * @throws Exception
	 */
	public static boolean tieneLaFamiliaDeuda(Lista<Socio> posiblesFamiliares, Socio socio) throws Exception{
		if((posiblesFamiliares == null) || (socio == null)) {
			throw new Exception("El socio y los posiblesFamiliares no pueden ser nulos");
		}
		posiblesFamiliares.iniciarCursor();
		String apellido = socio.getGrupoFamiliar();
		while(posiblesFamiliares.avanzarCursor()) {
			if(apellido.equals(posiblesFamiliares.obtenerCursor().getGrupoFamiliar())) {
				if(posiblesFamiliares.obtenerCursor().tuvoDeuda()) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * pre:
	 * @param familiasAnalizadas no puede ser nula
	 * @param apellido no puede ser nulo
	 * @return devuelve true si la familia ya se analizo y false en caso contrario.
	 * @throws Exception
	 */
	public static boolean laFamiliaEstaAnalizada(Lista<String> familiasAnalizadas, String apellido) throws Exception{
		if((familiasAnalizadas == null) || (apellido == null)) {
			throw new Exception("El apellido y las familias analizadas no pueden ser nulos");
		}
		familiasAnalizadas.iniciarCursor();
		while(familiasAnalizadas.avanzarCursor()) {
			if(apellido.equals(familiasAnalizadas.obtenerCursor())) {
				return true;
			}
		}
		return false;
	}
}


