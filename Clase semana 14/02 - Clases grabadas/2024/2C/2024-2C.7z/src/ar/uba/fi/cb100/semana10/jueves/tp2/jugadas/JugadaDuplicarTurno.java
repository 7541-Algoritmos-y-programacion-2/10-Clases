package ar.uba.fi.cb100.semana10.jueves.tp2.jugadas;

import ar.uba.fi.cb100.semana10.jueves.tp2.Tateti;
import ar.uba.fi.cb100.semana10.jueves.tp2.Turno;
import ar.uba.fi.cb100.semana10.jueves.tp2.cartas.Carta;

public class JugadaDuplicarTurno extends Jugada {
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public JugadaDuplicarTurno(Carta carta) {
		super(carta);
	}
	
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	@Override
	public void jugar(Tateti tateti, 
						Turno turnoActual) throws Exception {
		turnoActual.agregarSubturno();
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
//SETTERS SIMPLES -----------------------------------------------------------------------------------------	
}