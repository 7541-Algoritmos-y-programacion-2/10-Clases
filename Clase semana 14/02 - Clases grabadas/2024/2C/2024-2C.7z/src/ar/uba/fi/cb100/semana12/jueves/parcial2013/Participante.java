package ar.uba.fi.cb100.semana12.jueves.parcial2013;

import java.util.Objects;

public class Participante extends Object {

	private String nombre = null;
	private int dni = 0;
	private String domicilio = null;
	private int edad = 0;
	
		/* post: inicializa el participantes con el nombre indicado
		 *	y 0 puntos.
		 */
		public Participante(String nombre) {}
	/* post: devuelve el nombre que los identifica
	 */
		
	public String getNombre() { return this.nombre;}
	
	/* post: devuelve la cantidad de puntos del participante
	 */
	public int getPuntos() { return 0;}
	/* post: cambia por cantidad los puntos del participante
	 */
	public void setPuntos(int cantidad) {}
	
	@Override
	public boolean equals(Object obj) {
		//Comparo el puntero
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		
		//Comparo contra un String
		if (obj instanceof String) {
			String nombre = (String) obj;
			return this.getNombre().equals(nombre);
		}
		
		//Comparo contra otra participante
		if (getClass() != obj.getClass())
			return false;
		Participante participante = (Participante) obj;
		if ((this.dni >= 0) &&
		    (participante.dni >= 0)) {
			return dni == participante.dni;    	
		}
		return dni == participante.dni && 
				Objects.equals(domicilio, participante.domicilio) && 
				edad == participante.edad && 
				Objects.equals(nombre, participante.nombre);
		
	}

	@Override
	public int hashCode() {
		return Objects.hash(dni, domicilio, edad, nombre);
	}

	@Override
	public String toString() {
		return this.getNombre();
	}
};
