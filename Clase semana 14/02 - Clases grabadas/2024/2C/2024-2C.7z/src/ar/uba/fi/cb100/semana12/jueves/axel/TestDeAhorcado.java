package ar.uba.fi.cb100.semana12.jueves.axel;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestDeAhorcado {
    @Test
    public void test() throws Exception {
        String palabraSecreta = "GimnasiaYEsgrima";
        int cantidadDeErroresPermitidos = 5;
        Ahorcado ahorcado = new Ahorcado(palabraSecreta, cantidadDeErroresPermitidos);

        Assertions.assertEquals(ahorcado.getCantidadDeLetrasDePalabraSecreta(), palabraSecreta.length());
        ahorcado.proponerLetra("g");
        Assertions.assertFalse(ahorcado.fueGanado());
        Assertions.assertEquals(ahorcado.getCantidadDeErroresCometidos(), 0);
        Assertions.assertEquals(ahorcado.getEstadoDelJuego(), EstadoDelJuego.JUGANDO);

        ahorcado.proponerLetra("i");
        ahorcado.proponerLetra("m");
        ahorcado.proponerLetra("n");
        ahorcado.proponerLetra("a");
        ahorcado.proponerLetra("s");
        ahorcado.proponerLetra("E");
        ahorcado.proponerLetra("r");
        Assertions.assertFalse(ahorcado.fueGanado());
        Assertions.assertEquals(ahorcado.getCantidadDeErroresCometidos(), 0);
        Assertions.assertEquals(ahorcado.getEstadoDelJuego(), EstadoDelJuego.JUGANDO);

        ahorcado.proponerLetra("w");
        ahorcado.proponerLetra("x");
        ahorcado.proponerLetra("k");
        ahorcado.proponerLetra("z");
        Assertions.assertFalse(ahorcado.fueGanado());
        Assertions.assertEquals(ahorcado.getCantidadDeErroresCometidos(), 4);
        Assertions.assertEquals(ahorcado.getEstadoDelJuego(), EstadoDelJuego.JUGANDO);

        ahorcado.proponerLetra("y");
        Assertions.assertTrue(ahorcado.fueGanado());
        Assertions.assertEquals(ahorcado.getCantidadDeErroresCometidos(), 4);
        Assertions.assertEquals(ahorcado.getEstadoDelJuego(), EstadoDelJuego.GANADO);

        Assertions.assertThrows(Exception.class, () -> ahorcado.proponerLetra("n"));
        Assertions.assertThrows(Exception.class, () -> ahorcado.proponerLetra("X"));
        Assertions.assertThrows(Exception.class, () -> ahorcado.arriesgarPalabra("fueGanado"));

        Ahorcado ahorcado2 = new Ahorcado(palabraSecreta, 2);
        ahorcado2.arriesgarPalabra("gimnosio");
        Assertions.assertFalse(ahorcado2.fueGanado());
        Assertions.assertEquals(ahorcado2.getCantidadDeErroresCometidos(), 1);
        Assertions.assertEquals(ahorcado2.getEstadoDelJuego(), EstadoDelJuego.PERDIDO);

        Assertions.assertThrows(Exception.class, () -> ahorcado2.proponerLetra("n"));
        Assertions.assertThrows(Exception.class, () -> ahorcado2.proponerLetra("X"));
        Assertions.assertThrows(Exception.class, () -> ahorcado2.arriesgarPalabra("fueGanado"));

    }
}
