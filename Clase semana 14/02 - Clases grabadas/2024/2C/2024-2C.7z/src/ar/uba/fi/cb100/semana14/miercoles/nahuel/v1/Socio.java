package ar.uba.fi.cb100.semana14.miercoles.nahuel.v1;

public class Socio {
	private static int idCounter = 1;
	
	private String apellido = null;
	private int deuda = 0;
	private int id;
	
	
	public boolean tuvoDeuda(){
		if(this.deuda == 0) {
			return false;
		}else {
			return true;
		}
	}
	
	public String getGrupoFamiliar(){
		return this.apellido;
	}
	
	public Socio(int deuda, String apellido) {
		this.id = idCounter++;
		this.deuda = deuda;
		this.apellido = apellido;
	}
	public int getId(){
		return this.id;
	}


}
