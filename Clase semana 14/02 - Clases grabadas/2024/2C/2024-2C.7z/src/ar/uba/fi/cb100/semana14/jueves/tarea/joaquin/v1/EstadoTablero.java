package ar.uba.fi.cb100.semana14.jueves.tarea.joaquin.v1;

public enum EstadoTablero {
    GANAN_BLANCAS,
    GANAN_NEGRAS,
    TABLAS,
    JUGANDO,
    ANULADO,
}
