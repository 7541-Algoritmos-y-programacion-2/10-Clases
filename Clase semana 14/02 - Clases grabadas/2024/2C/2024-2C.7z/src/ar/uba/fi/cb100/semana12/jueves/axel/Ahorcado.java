package ar.uba.fi.cb100.semana12.jueves.axel;

/*
Estrategia del Ahorcado

Atributos
private String palabraSecreta = null
private String[] letrasAdivinadas = new String[27];
private EstadoDelJuego estado = EstadoDelJuego.JUGANDO
private int cantidadDeErroresPermitidos = 0
private int cantidadDeErroresCometidos = 0

Metodos esenciales
public Ahorcado(String palabraSecreta, int cantidadDeErroresPermitidos)
public int getCantidadDeLetrasDePalabraSecreta()
public EstadoDelJuego getEstadoDelJuego()
public int proponerLetra(String letra)
public int getCantidadDeErroresCometidos()
public EstadoDelJuego arriesgarPalabra(String palabra)
public String getPalabraSecreta()

Metodos validadores
private void validarJugando()
private void validarLetra(String letra)
private void validarPalabra(String palabra)

Metodos necesarios FIXME: ESTOS 5 metodos deberian ser private?
public boolean fueGanado()
public boolean seEstaJugando()
public boolean letraFueAdivinada(String letra)
public int contarAparicionesDeLetra(String letra)
public void agregarLetra(String letra)

Metodos extras para completar el TDA, no los hice
FIXME: el parcial no los pide, el getCantidadDeErroresPermitidos es sencillo para agregar asi que seria un plus
 , pero el getCantidadDeAciertosCometidos es mas complejo asi que mejor no agregarlo verdad?
public int getCantidadDeAciertosCometidos()
public int getCantidadDeErroresPermitidos()
 */
public class Ahorcado {
    private String palabraSecreta = null;
    private String[] letrasAdivinadas = new String[27]; //char[] letrasAdivinadas      Character[] letrasAdivinadas
    private EstadoDelJuego estado = EstadoDelJuego.JUGANDO;
    private int cantidadDeErroresPermitidos = 0;
    private int cantidadDeErroresCometidos = 0;

    /* pre: palabraSecreta debe ser una palabra valida, y cantidad de errores no puede ser menor a 0
       post: inicializa el juego del ahorcado, tira Exception si alguno de los parametros es invalido */
    public Ahorcado(String palabraSecreta, int cantidadDeErroresPermitidos) throws Exception {
        validarPalabra(palabraSecreta);
        if (cantidadDeErroresPermitidos < 0) {
            throw new Exception("La cantidad de errores permitidos no puede ser negativo");
        }
        this.palabraSecreta = palabraSecreta.toLowerCase();
        this.cantidadDeErroresPermitidos = cantidadDeErroresPermitidos;
        for (int i = 0; i < letrasAdivinadas.length; i++) {
            letrasAdivinadas[i] = null;
        }
    }

    /* pre: --
       post: retorna la cantidad de letras de la palabra secreta */
    public int getCantidadDeLetrasDePalabraSecreta() {
        return palabraSecreta.length();
    }

    /* pre: --
       post: retorna el estado del juego */
    public EstadoDelJuego getEstadoDelJuego() {
        return estado;
    }

    /* pre: letra debe ser valida
       post: si la letra pertenece a palabra secreta, la agrega a letras adivinadas, y chequea si ya se adivinaron
             todas las letras de la palabra secreta, si lo fueron el juego fue ganado, si no pertenece o ya fue
             adivinada la letra, aumenta la cantidad de errores cometidos en 1, y chequea si se supero la cantidad
             de errores permitidos, si se supero se pierde el juego, tira Exception si la letra no es valida, o si
             no se esta jugando */
    public int proponerLetra(String letra) throws Exception {
        validarLetra(letra);
        validarJugando();
        letra = letra.toLowerCase();
        // El String de Java tenia un metodo .contains() :O
        if ((letraFueAdivinada(letra)) || 
        	(!palabraSecreta.contains(letra))) {
            cantidadDeErroresCometidos++;
            if (cantidadDeErroresCometidos >= cantidadDeErroresPermitidos) {
                this.estado = EstadoDelJuego.PERDIDO;
            }
        } else {
            agregarLetra(letra);
            if (fueGanado()) {
                this.estado = EstadoDelJuego.GANADO;
            }
        }
        return contarAparicionesDeLetra(letra);
    }

    /* pre: --
       post: retorna la cantidad de errores cometidos */
    public int getCantidadDeErroresCometidos() {
        return cantidadDeErroresCometidos;
    }

    /* pre: palabra no puede ser nula, y debe contener letras del abecedario
       post: retorna el nuevo estado del juego, si palabra equivale a palabraSecreta, se gana el juego, si no el
       juego se pierde, tira Exception si no se esta jugando, o si es una palabra invalida */
    public EstadoDelJuego arriesgarPalabra(String palabra) throws Exception {
        validarPalabra(palabra);
        validarJugando();
        if (palabra.equals(palabraSecreta)) {
            this.estado = EstadoDelJuego.GANADO;
        } else {
            this.estado = EstadoDelJuego.PERDIDO;
            //cantidadDeErroresCometidos++; // FIXME: deberia ser un solo error cometido?
        }
        return this.estado;
    }

    /* pre: --
       post: devuelve la palabra secreta si no se esta jugando, si se esta jugando devuelve una cadena vacia */
    public String getPalabraSecreta() {
        if (seEstaJugando()) {
            return "";
        }
        return palabraSecreta;
    }

    /* pre: --
       post: valida que el estado del juego sea JUGANDO, tira Exception si no lo es */
    private void validarJugando() throws Exception {
        if (this.estado != EstadoDelJuego.JUGANDO) {
            throw new Exception("El juego no se esta jugando");
        }
    }

    /* pre: palabra no puede ser nula, ni vacia y debe estar contenido de letras unicamente
     * 
       post: valida que la palabra sea valida, tira Exception si no lo es */
    private void validarPalabra(String palabra) throws Exception {
        if ((palabra == null) || (palabra.isEmpty())) {
            throw new Exception("La palabra no puede ser vacio");
        }
        palabra = palabra.toLowerCase();
        for (int i = 0; i < palabra.length(); i++) {
            validarLetra(String.valueOf(palabra.charAt(i)));
        }
    }

    /* pre: letra su longitud debe ser 1, y su valor decimal en minuscula, debe estar entre 97 (a) y 122 (b), o ser
            164 (ñ), y no puede ser nula
       post: valida que la letra sea valida, tira Exception si no lo es */
    private void validarLetra(String letra) throws Exception {
        if (letra == null) {
            throw new Exception("Letra no puede ser nula");
        }
        if (letra.length() != 1) {
            throw new Exception("Letra debe tener longitud 1");
        }
        int valorDecimal = Integer.valueOf(letra.toLowerCase().charAt(0)); // sin el .charAt(0) no andaba
        if (!((valorDecimal == 164) || (valorDecimal >= 97 && valorDecimal <= 122))) {
            throw new Exception("Letra debe ser una letra del abecedario a-z");
        }
    }

    /* pre: --
       post: retorna verdadero si la palabra secreta fue adivinada, falso si no lo fue */
    public boolean fueGanado() throws Exception {
        for (int i = 0; i < palabraSecreta.length(); i++) {
            if (!letraFueAdivinada(String.valueOf(palabraSecreta.charAt(i)))) {
                return false;
            }
        }
        return true;
    }

    /* pre: letra no puede ser nula, y debe ser una letra del abecedario
       post: devuelve verdadero si la letra fue adivinada, si no lo fue, tira Exception si es una letra invalida*/
    public boolean letraFueAdivinada(String letra) throws Exception {
        validarLetra(letra);
        for (int i = 0; i < letrasAdivinadas.length; i++) {
            if ((letrasAdivinadas[i] != null) && (letrasAdivinadas[i].equals(letra))) {
                return true;
            }
        }
        return false;
    }

    /* pre: letra no puede ser nula, y debe ser del abecedario
       post: retorna la cantidad de veces que aparece la letra en palabra secreta, tira Exception si es una letra
       invalida */
    public int contarAparicionesDeLetra(String letra) throws Exception {
        validarLetra(letra);
        int cantidad = 0;
        for (int i = 0; i < palabraSecreta.length(); i++) {
            if (String.valueOf(palabraSecreta.charAt(i)).equals(letra)) {
                cantidad++;
            }
        }
        return cantidad;
    }

    /* pre: letra no puede ser nula, y debe ser del abecedario
       post: agrega la letra a las letras adivinadas, tira Exception si es una letra invalida, o si no se esta
       jugando */
    public void agregarLetra(String letra) throws Exception {
        validarLetra(letra);
        validarJugando();
        for (int i = 0; i < letrasAdivinadas.length; i++) {
            if (letrasAdivinadas[i] == null) {
                letrasAdivinadas[i] = letra;
                return;
            }
        }
    }

    /* pre: --
       post: devuelve verdadero si el estado del juego es JUGANDO, falso si no lo es */
    public boolean seEstaJugando() {
        return this.estado == EstadoDelJuego.JUGANDO;
    }
}
