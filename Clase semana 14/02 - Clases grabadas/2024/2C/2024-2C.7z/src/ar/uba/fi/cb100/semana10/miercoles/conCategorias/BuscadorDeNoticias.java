package ar.uba.fi.cb100.semana10.miercoles.conCategorias;

import ar.uba.fi.cb100.semana08.miercoles.estructuras.Lista;
import ar.uba.fi.cb100.semana08.miercoles.estructuras.ListaCircularSimplementeEnlazada;
import ar.uba.fi.cb100.semana08.miercoles.estructuras.ListaSimplementeEnlazada;

public class BuscadorDeNoticias {

	/* post: busca en noticias aquellas Noticias que tengan asociada al menos 2 categorías dadas en conCategorias y 
	 *       que NO contengan ninguna de las categorías de sinCategorias,	
	*	teniendo un mínimo de categorías
	*	Devuelve una nueva Lista con todas las Noticias encontradas. */ 
	public Lista<Noticia> buscarNoticias(Lista<Noticia> noticias,  
											Lista<Categoria> conCategorias, 
											Lista<Categoria> sinCategorias, 
											int cantidadMinimaDeCategorias) throws Exception {
		//validar
		Lista<Noticia> resultado = new ListaSimplementeEnlazada<Noticia>();
		noticias.iniciarCursor();
		while (noticias.avanzarCursor()) {
			Noticia noticia = noticias.obtenerCursor();
			if ((noticia.getCategorias().getTamanio() >=  cantidadMinimaDeCategorias) &&
				(contarCategoriasCoincidentes(noticia, conCategorias) >= 2) &&
				(contarCategoriasCoincidentes(noticia, sinCategorias) == 0)) {
				resultado.agregar(noticia);
			}
		}
		return resultado;
	}

	public int contarCategoriasCoincidentes(Noticia noticia, Lista<Categoria> conCategorias) {
		// TODO Auto-generated method stub
		return 0;
	}
}
