package ar.uba.fi.cb100.semana12.jueves.emma.v2;

import ar.uba.fi.cb100.semana07.miercoles.Lista;
import ar.uba.fi.cb100.semana12.jueves.emma.Foro;
import ar.uba.fi.cb100.semana12.jueves.emma.Mensaje;

/*/* post: busca en la lista 'foros' el Mensaje más votado del autor 'usuarioBuscado' dentro de un Foro que incluya la temática 'tematicaBuscada'.*/


public class Moderador {
	public Mensaje buscarMensajeMasVotadoDelUsuarioSegunTematica(Lista<Foro> foros, String usuarioBuscado, String tematicaBuscada) throws Exception {
		if (foros == null) {
			throw new Exception("La lista de foros no puede estar vacía");
		}
		if (usuarioBuscado == null) {
			throw new Exception("El usuario buscado no puede estar vacío");
		}
		if (tematicaBuscada == null) {
			throw new Exception("La temática buscada no puede estar vacía");
		}
	
		Mensaje mensajeEncontrado = null;
		
		foros.iniciarCursor();
		while(foros.avanzarCursor()) {
			Foro foroLeido = foros.obtenerCursor();
			if (foroLeido.obtenerTematicas().existe(tematicaBuscada)){
				Mensaje mensajeMasVotadoDelForo = buscarMayorMensajeDelForo(foroLeido.obtenerMensajes(), usuarioBuscado);
				if (mensajeMasVotadoDelForo != null &&
					((mensajeEncontrado == null) ||	
					  mensajeMasVotadoDelForo.contarVotos() > mensajeEncontrado.contarVotos())) {
					mensajeEncontrado = mensajeMasVotadoDelForo;
				}
			}
		}
		
		return mensajeEncontrado;
	}

	/*
	 * 
	 * pre: recibe como parámetros una lista de mensajes, un String con el nombre del usuario buscado. Ninguno debe ser nulo.
	 *post: busca en la lista de mensajes, el que contenga la mayor cantidad de votos y que pertenezca al usuario pasado por parámetro 
	 * 
	 * */
	
	public Mensaje buscarMayorMensajeDelForo(Lista<Mensaje> mensajesForoLeido, String usuarioBuscado) throws Exception {
		if (mensajesForoLeido == null) {
			throw new Exception ("La lista de mensajes no puede estar vacía");
		}
		if (usuarioBuscado == null) {
			throw new Exception ("El String del usuario buscado no puede estar vacío");
		}
		int mayorCantidadDeVotosDelForo = 0;
		Mensaje mensajeMasVotadoDelForo = null;
		
		mensajesForoLeido.iniciarCursor();
		while (mensajesForoLeido.avanzarCursor()) {
			Mensaje mensajeLeido = mensajesForoLeido.obtenerCursor();
			if (mensajeLeido.obtenerUsuario().equals(usuarioBuscado) && 
				(mensajeLeido.contarVotos()>mayorCantidadDeVotosDelForo)) {
				mensajeMasVotadoDelForo=mensajeLeido;
				mayorCantidadDeVotosDelForo = mensajeLeido.contarVotos();
			}
		}
		
		return mensajeMasVotadoDelForo;
	}

}


