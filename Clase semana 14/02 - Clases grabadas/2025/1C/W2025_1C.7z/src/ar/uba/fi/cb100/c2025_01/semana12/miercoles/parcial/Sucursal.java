package ar.uba.fi.cb100.c2025_01.semana12.miercoles.parcial;

import java.util.List;

public class Sucursal {

	public Sucursal() {}

	/* post: devuelve las categorias de productos que vende.
	 */
	public List<String> obtenerCategorias() { return null;}

	/* post: devuelve todos los Productos que tiene la sucursal.
	 */
	List<Producto> obtenerProductos() {return null;}

};
