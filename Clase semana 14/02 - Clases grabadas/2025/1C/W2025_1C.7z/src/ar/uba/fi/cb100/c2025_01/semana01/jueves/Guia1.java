package ar.uba.fi.cb100.c2025_01.semana01.jueves;

import java.util.Arrays;
import java.util.Random;

import ar.uba.fi.cb100.c2025_01.semana01.jueves.teclado.Teclado;

public class Guia1 {

	
	public static void main(String[] args) {
		//ejercicio9();
		//ejercicio13();
		strings();
	}
	
	
	public static void strings() {
		String texto = "Hola mundo";
		texto = new String("Hola mundo");
		
		System.out.println(texto.toLowerCase());
		System.out.println(texto.toUpperCase());
		
		texto += " ";
		System.out.println( "'" + texto + "'");
		System.out.println( "'" + texto.trim() + "'");
		System.out.println( "'" + texto + "'");
		texto = texto.trim();
		
		System.out.println( texto.charAt(0));
		
		System.out.println( texto.concat(" cruel"));
		
		texto = texto.concat(" cruel");
		
		System.out.println( texto.length());
		System.out.println( texto.substring(5));
		System.out.println( texto.substring(5, 7));
		
		System.out.println(texto.startsWith("H"));
		System.out.println(texto.endsWith("H"));
		System.out.println(texto.contains("H"));
		
		System.out.println(texto == "Hola mundo cruel");
		
		String texto1 = texto;
		System.out.println(texto == texto1);
		System.out.println(texto.equals("Hola mundo cruel"));
		
		System.out.println(texto.indexOf("mundo"));
		System.out.println("hola hola hola".lastIndexOf("hola"));
		System.out.println(texto.equalsIgnoreCase("hola mundo cruel"));
		System.out.println(texto.toLowerCase().equals("hola mundo cruel".toLowerCase()));
		
		System.out.println(texto.isEmpty());
		System.out.println("".isEmpty());
		
		System.out.println(texto.replace("mundo", "planeta"));
		System.out.println("hola hola hola".replace("hola", "chau"));

		System.out.println(Arrays.toString( texto.split(" ") ));
		System.out.println(Arrays.toString( texto.split("mun") ));
		System.out.println(Arrays.toString( texto.split("planeta") ));
	}
	
	public static void ejercicio13() {
		Teclado.inicializar();
		int valorIngresado = Teclado.leerEntero(); 
		
		//Version 1
		System.out.print("Lista = [");
		for(int i =0; i < 20; i++) {
			System.out.print((valorIngresado + i) + ((i == 19) ? "": ", "));		
		}
		System.out.println("]");
		
		//Version 
		System.out.print("Lista = [");
		for(int i =valorIngresado; i < (valorIngresado+20); i++) {
			System.out.print(i + ((i == (valorIngresado + 19)) ? "": ", "));		
		}
		System.out.print("]");
	}
	
	public static void ejercicio9() {
		esPar(5);
		
		Random random = new Random(System.nanoTime());
		esPar(random.nextInt(100));
		
		Teclado.inicializar();
		
		//Version 1
		int valorIngresado1 = 1;
		while (valorIngresado1 > 0) {
			valorIngresado1 = Teclado.leerEntero(); 
			if (valorIngresado1 > 0) {
				esPar(valorIngresado1);
			}
		}
		
		//Version 2
		int valorIngresado2 = 0;
		do {
			valorIngresado2 = Teclado.leerEntero(); 
			if (valorIngresado2 > 0) {
				esPar(valorIngresado2);
			}
		} while (valorIngresado2 > 0);
		
		Teclado.finalizar();
	}
	
	public static void esPar(int numero) {
		if (numero % 2 == 0) {
			System.out.println("El numero " + numero + " es par");
		} else {
			System.out.println("El numero " + numero + " es impar");
		}
	}
}
