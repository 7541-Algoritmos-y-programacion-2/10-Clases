package ar.uba.fi.cb100.c2025_01.estructuras.arbol;

public class ArbolAVL<T extends Comparable<T>> extends ArbolBinarioDeBusqueda<T> {

    // Método para insertar un nuevo nodo en el árbol AVL
    @Override
    public void insertar(T valor) {
        setRaiz( insertarAVL((NodoAVL<T>) getRaiz(), valor) );
    }

    private NodoAVL<T> insertarAVL(NodoAVL<T> nodo, T valor) {
        // Inserción estándar de un árbol binario de búsqueda
        if (nodo == null) {
            return new NodoAVL<T>(valor);
        }

        if (valor.compareTo(nodo.getValor()) == -1) {
            nodo.setIzquierdo( insertarAVL((NodoAVL<T>) nodo.getIzquierdo(), valor));
        } else if (valor.compareTo(nodo.getValor()) == 1) {
            nodo.setDerecho( insertarAVL((NodoAVL<T>) nodo.getDerecho(), valor) );
        } else {
            // No se permiten valores duplicados en el árbol AVL
            return nodo;
        }

        // Actualizar la altura del nodo actual
        nodo.setAltura( 1 + Math.max(altura((NodoAVL<T>) nodo.getIzquierdo()), altura((NodoAVL<T>) nodo.getDerecho())));

        // Obtener el factor de balance para este nodo
        int balance = obtenerBalance(nodo);

        // Rotaciones para mantener el árbol balanceado

        // Caso Izquierda-Izquierda
        if (balance > 1 && 
        	valor.compareTo( nodo.getIzquierdo().getValor()) == -1) {
            return rotacionDerecha(nodo);
        }

        // Caso Derecha-Derecha
        if (balance < -1 && 
        	valor.compareTo( nodo.getDerecho().getValor()) == 1) {
            return rotacionIzquierda(nodo);
        }

        // Caso Izquierda-Derecha
        if (balance > 1 && 
        	valor.compareTo( nodo.getIzquierdo().getValor()) == 1) {
            nodo.setIzquierdo( rotacionIzquierda((NodoAVL<T>) nodo.getIzquierdo()));
            return rotacionDerecha(nodo);
        }

        // Caso Derecha-Izquierda
        if (balance < -1 && 
        	valor.compareTo( nodo.getDerecho().getValor()) == -1) {
            nodo.setDerecho( rotacionDerecha((NodoAVL<T>) nodo.getDerecho()) );
            return rotacionIzquierda(nodo);
        }

        return nodo;
    }

    // Rotación hacia la derecha
    private NodoAVL<T> rotacionDerecha(NodoAVL<T> y) {
        NodoAVL<T> x = (NodoAVL<T>) y.getIzquierdo();
        NodoAVL<T> T2 = (NodoAVL<T>) x.getDerecho();

        // Realizar la rotación
        x.setDerecho(y);
        y.setIzquierdo(T2);

        // Actualizar alturas
        y.setAltura( Math.max(altura((NodoAVL<T>) y.getIzquierdo()), altura((NodoAVL<T>) y.getDerecho())) + 1 );
        x.setAltura( Math.max(altura((NodoAVL<T>) x.getIzquierdo()), altura((NodoAVL<T>) x.getDerecho())) + 1);

        // Retornar nueva raíz
        return x;
    }

    // Rotación hacia la izquierda
    private NodoAVL<T> rotacionIzquierda(NodoAVL<T> x) {
        NodoAVL<T> y = (NodoAVL<T>) x.getDerecho();
        NodoAVL<T> T2 = (NodoAVL<T>) y.getIzquierdo();

        // Realizar la rotación
        y.setIzquierdo(x);
        x.setDerecho(T2);

        // Actualizar alturas
        x.setAltura( Math.max(altura((NodoAVL<T>) x.getIzquierdo()), altura((NodoAVL<T>) x.getDerecho())) + 1);
        y.setAltura( Math.max(altura((NodoAVL<T>) y.getIzquierdo()), altura((NodoAVL<T>) y.getDerecho())) + 1);

        // Retornar nueva raíz
        return y;
    }

    // Obtener la altura de un nodo
    private int altura(NodoAVL<T> nodo) {
        return (nodo == null) ? 0 : nodo.getAltura();
    }

    // Obtener el factor de balance de un nodo
    private int obtenerBalance(NodoAVL<T> nodo) {
        return (nodo == null) ? 0 : altura((NodoAVL<T>) nodo.getIzquierdo()) - altura((NodoAVL<T>) nodo.getDerecho());
    }

}