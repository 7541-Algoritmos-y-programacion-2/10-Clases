package ar.uba.fi.cb100.c2025_01.semana14.miercoles.tp2;

public class Principal14 {

	public static void main(String[] args) {
		
	}
}
