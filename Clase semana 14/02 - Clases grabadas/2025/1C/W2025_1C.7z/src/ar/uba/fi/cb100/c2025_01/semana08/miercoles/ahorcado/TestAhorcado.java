package ar.uba.fi.cb100.c2025_01.semana08.miercoles.ahorcado;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class TestAhorcado {

    private Ahorcado ahorcado = null;

    @BeforeEach
    void setUp() {
    	String palabra = "hola";
    	ahorcado = new Ahorcado(palabra, 1);
    }

    @Test
    void proponer() {
    	ahorcado.proponerLetra('h');
        assertEquals(0, ahorcado.getCantidadDeErroresCometidos());
        assertEquals(1, ahorcado.getCantidadDeErroresPermitidos());
        assertEquals("h***", ahorcado.getPalabraAAdivinar());
    }
    
    @Test
    void arriesgar() {
    	ahorcado.arriesgar("Hola");    	
        assertEquals(EstadoDeAhorcado.Perdido, ahorcado.getEstado());
        assertThrows(RuntimeException.class, () -> ahorcado.arriesgar("hola"), "Se pudo arriesgar varias veces");
    }
}