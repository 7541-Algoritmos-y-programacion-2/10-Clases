package ar.uba.fi.cb100.c2025_01.semana10.tarea3;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Locomotora {

	// ATRIBUTOS

	private Vagon[] vagones = new Vagon[10];

	// METODOS DE COMPORTAMIENTO

	/**
	 * Dado un vagon, se agrega a la locomotora.
	 * Si no hay capacidad, devuelve excepción.
	 * @param vagon
	 */
	public void agregarVagon(Vagon vagon) {

		ValidacionesUtiles.validarNoNulo(vagon, "El vagón");

		if(getCantidadDeVagones() >= getVagones().length) {
			throw new RuntimeException("Se excede la capacidad de vagones!");
		}

		validarVagonVacio(vagon);

		vagones[getCantidadDeVagones()] = vagon;
	}

	/**
	 * Se agrega una carga a la locomotora, la misma es distribuida entre los vagones que la componen.
	 * @param cantidad
	 * @return devuelve la cantidad que quedó pendiente de cargar
	 */
	public int cargarLocomotora(int cantidad) {

		if(getCantidadDeVagones() == 0) {
			throw new RuntimeException("No hay vagones para agregar carga");
		}

		for(int i = 0; i < getCantidadDeVagones(); i++) {
			if(this.vagones[i].getCapacidadDisponible() > 0) {
				this.vagones[i].cargar(Math.min(vagones[i].getCapacidadDisponible(), cantidad));

				cantidad -= Math.min(vagones[i].getCapacidadDisponible(), cantidad);
			}
		}
		return cantidad;
	}

	/**
	 * Se retira el ultimo vagóon de la locomotora.
	 * Si no hay vagones para retirar tira excepción.
	 * @return devuelve el vagón retirado
	 */
	public Vagon retirarVagon() {

		int indiceEslabon = getCantidadDeVagones() - 1;

		if(indiceEslabon < 0) {
			throw new RuntimeException("No hay vagones para retirar!");
		}

		validarVagonVacio(vagones[indiceEslabon]);

		Vagon vagonRetirado = vagones[indiceEslabon];
		vagones[indiceEslabon] = null;

		return vagonRetirado;

	}

	/**
	 * Dado un vagon, se valida si está vacío, si no lo estuviera, tira excepción.
	 * @param vagon
	 */
	public void validarVagonVacio(Vagon vagon) {
		if(!vagon.estaVacio()) {
			throw new RuntimeException("El vagón debe estar vacío");
		}
	}

	/**
	 * Devuelve la carga maxima disponible de todos los vagones de la locomotora.
	 * @return
	 */
	public int obtenerCargaMaxima() {
		int cargaMaxima = 0;

		for(int i = 0; i < getCantidadDeVagones(); i++) {
			cargaMaxima = vagones[i].getCapacidadMaximaDeCarga();
		}

		return cargaMaxima;
	}

	/**
	 * Devuelve la carga actual de todos los vagones.
	 * @return
	 */
	public int obtenerCarga() {
		int carga = 0;

		for(int i = 0; i < getCantidadDeVagones(); i++) {
			carga = vagones[i].getCantidadCargada();
		}

		return carga;
	}

	/**
	 * Devuelve la cantidad de vagones.
	 * @return
	 */
	public int getCantidadDeVagones() {

		int cantidadDeVagones = 0;

		for(int i = 0; i < vagones.length; i++) {
			if(vagones[i] != null) {
				cantidadDeVagones++;
			}
		}

		return cantidadDeVagones;
	}
	
	// GETTERS SIMPLES
	/**
	 *  Devuelve los vagones de la locomotora.
	 * @return
	 */
	public Vagon[] getVagones() {
		return this.vagones;
	}

}
