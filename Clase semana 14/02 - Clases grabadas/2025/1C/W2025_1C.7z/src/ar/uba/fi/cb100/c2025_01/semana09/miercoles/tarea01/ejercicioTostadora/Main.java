package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.ejercicioTostadora;

/*
 *  Diseñar la especificación e implementar el TDA Tostadora. Debe proveer operaciones para:
 * • Construir de la cantidad de ranuras para panes que tiene. Cada ranura se identifica con un número.
 * • Iniciar tostado de pan, indicando la ranura a utilizar.
 * • Finalizar el tostado de pan, indicando la ranura a utilizar.
 * • Indicar el nivel de calor de la tostadora, de 1 a 10.
 * • contarRanurasLibres: indica la cantidad de ranuras no ocupadas.
 * • Devolver la ranura que más panes tostó.
 * • La tostadora puede estar apagada o encendida
 * Reglas:
 * La tostadora es manual, no tiene automatizado el tiempo de cocción.
 * Hacer un mail para testear
 */

public class Main {
	
	public static void main(String[] args) {
		
		Tostadora tostadora = new Tostadora(4);
		
		tostadora.encenderTostadora(5);
		
		tostadora.iniciarTostado(1);
		tostadora.finalizarTostado(1);
		
		for(int i = 0; i < 7; i ++) {
			if( i%2 == 0) {
				tostadora.iniciarTostado(2);	
			} else {
				tostadora.finalizarTostado(2);;
			}
		}
		
		System.out.println("La tostadora tiene el nivel de calor en: " + tostadora.getNivelDeCalor() + ".");
		
		tostadora.setNivelDeCalor(0);
		
		System.out.println("La tostadora tiene el nivel de calor en: " + tostadora.getNivelDeCalor() + ".");
		
		tostadora.apagarTostadora();
		
		System.out.println("La tostadora tiene " + tostadora.contarRanurasLibres() + " ranuras libres");
		
		System.out.println("La ranura que más tostó fue la: " + tostadora.devolverRanuraQueMasTosto() + ".");
	}
}
