package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2;

public class Coordenada {

}
