package ar.uba.fi.cb100.c2025_01.semana10.jueves.parcial.listas;

public class Nota {
    private int padron;
    private String materia;
    private double valor;
    
    //Devuelve el padron
	public int getPadron() {return padron;}
	
	//Devuelve el nombre de la materia
	public String getMateria() {return materia;}
	
	//Devuelve la nota entre 0 y 10
	public double getValor() {return valor;}
}
