package ar.uba.fi.cb100.c2025_01.semana11.jueves;

import java.util.Arrays;

public class EjerciciosDeComplejidad {

	
	public static void main(String[] args) {
		
	}
	
	
	public static void ejercicio1(int n) {
	    for (int i = 0; i < n; i++) {
	    	//N veces
	        for (int j = 0; j < n; j++) {
	        	//N otras veces
	            System.out.println(i + "," + j);  //OE 1
	        }
	    }
	    //T(n) = n2
	}	
	
	public static int ejercicio2(int n) {
	    if (n <= 1)     //OE 1
	        return 1;  
	    return ejercicio2(n - 1) + ejercicio2(n - 2);
	    
	    //T(n) = T(n-1) + T(n-2) + 1
	    //Metodo de expansion o por el teorema maestro
	    // O(n) = 2n
	}
	
	public void ejercicio3(int n) {
	    if (n == 0)
	        return;
	    System.out.println(n); // OE 1
	    ejercicio3(n - 1);
	    //T(n) = T(n-1) + 1
	}
	
	
	public int[] ejercicio4(int[] arr) {
	    if (arr.length <= 1)
	        return arr;
	    int mid = arr.length / 2;
	    int[] left = Arrays.copyOfRange(arr, 0, mid);
	    int[] right = Arrays.copyOfRange(arr, mid, arr.length);
	    return merge(ejercicio4(left), ejercicio4(right));
	    
	    //T(n) = 2T(n/2) + n
	    //O(n) = n log n
	}


	private int[] merge(int[] ejercicio4, int[] ejercicio42) {
		// TODO Auto-generated method stub
		return null;
	}
}
