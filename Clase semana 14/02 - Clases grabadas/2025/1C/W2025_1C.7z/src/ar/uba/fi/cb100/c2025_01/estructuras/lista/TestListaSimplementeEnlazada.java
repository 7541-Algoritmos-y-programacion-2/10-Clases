package ar.uba.fi.cb100.c2025_01.estructuras.lista;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestListaSimplementeEnlazada {

    public static void main(String[] args) {
        ListaSimplementeEnlazada<String> lista = new ListaSimplementeEnlazada<>();

        lista.add("Hola");
        lista.add("Java");
        lista.add("Mundo");

        System.out.println("Recorrido con for-each:");
        for (String s : lista) {
            System.out.println(s);
        }

        System.out.println("Recorrido con Iterator:");
        Iterator<String> it = lista.iterator();
        while (it.hasNext()) {
            String valor = it.next();
            System.out.println(valor);
        }

        System.out.println("Recorrido con Stream:");
        lista.stream().forEach(System.out::println);
    }

    private List<String> lista;

    @BeforeEach
    void setUp() {
        lista = new ListaSimplementeEnlazada<>();
        lista.add("A");
        lista.add("B");
        lista.add("C");
    }

    @Test
    void testAddAndSize() {
        assertEquals(3, lista.size());
        lista.add("D");
        assertEquals(4, lista.size());
        assertEquals("D", lista.get(3));
    }

    @Test
    void testAddAtIndex() {
        lista.add(1, "X");
        assertEquals("X", lista.get(1));
        assertEquals("B", lista.get(2));
    }

    @Test
    void testGet() {
        assertEquals("A", lista.get(0));
        assertEquals("C", lista.get(2));
        assertThrows(IndexOutOfBoundsException.class, () -> lista.get(5));
    }

    @Test
    void testRemoveByIndex() {
        String eliminado = lista.remove(1); // elimina B
        assertEquals("B", eliminado);
        assertEquals(2, lista.size());
        assertEquals("C", lista.get(1));
    }

    @Test
    void testContainsAndIndexOf() {
        assertTrue(lista.contains("B"));
        assertEquals(1, lista.indexOf("B"));
        assertEquals(-1, lista.indexOf("Z"));
    }

    @Test
    void testSet() {
        lista.set(0, "Z");
        assertEquals("Z", lista.get(0));
    }

    @Test
    void testToArray() {
        Object[] array = lista.toArray();
        assertArrayEquals(new Object[]{"A", "B", "C"}, array);
    }

    @Test
    void testIterator() {
        StringBuilder sb = new StringBuilder();
        for (String s : lista) {
            sb.append(s);
        }
        assertEquals("ABC", sb.toString());
    }

    @Test
    void testListIteratorForwardAndBackward() {
        ListIterator<String> it = lista.listIterator();
        assertTrue(it.hasNext());
        assertEquals("A", it.next());
        assertEquals("B", it.next());

        assertTrue(it.hasPrevious());
        assertEquals("B", it.previous());
        assertEquals("A", it.previous());
    }

    @Test
    void testListIteratorAddSetRemove() {
        ListIterator<String> it = lista.listIterator();
        it.next(); // A
        it.set("Z"); // cambia A por Z
        it.add("X"); // inserta X después de Z

        assertEquals("Z", lista.get(0));
        assertEquals("X", lista.get(1));
        assertEquals("B", lista.get(2));

        it.next(); // B
        it.remove(); // elimina B

        assertEquals(3, lista.size());
        assertEquals("C", lista.get(2));
    }
}
