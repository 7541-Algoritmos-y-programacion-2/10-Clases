package ar.uba.fi.cb100.c2025_01.semana10.tarea1;

import java.util.Objects;

// Había comentado los metodos y me crasheó Eclipse.
public class Canal {

	private int volumen;
	private int numeroCanal;
	private int volumenMax;
	
	//pre y pos, robustez
	Canal(int numeroCanal){
		this.volumen = 0;
		this.volumenMax = 0;
		this.numeroCanal = numeroCanal;
	}
	
	Canal(int numeroCanal, int volumen) {
		this.volumen = volumen;
		this.volumenMax = volumen;
		this.numeroCanal = numeroCanal;
	}
	
	
	//falto el equals
	
	public int getNumeroCanal() {
		return this.numeroCanal;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(numeroCanal);
	}

	//pre:
	//post: 
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Canal other = (Canal) obj;
		return numeroCanal == other.numeroCanal;
	}

	public int getVolumen() {
		return this.volumen;
	}
	
	public int getVolumenMax() {
		return this.volumenMax;
	}
	
	public void setNumeroCanal(int numeroNuevo) {
		this.numeroCanal = numeroNuevo;
	}
	
	public void setVolumen(int nuevoVolumen) {
		if(this.volumenMax < nuevoVolumen) {
			this.volumenMax = nuevoVolumen;
		}
		this.volumen = nuevoVolumen;
	}
	
}
