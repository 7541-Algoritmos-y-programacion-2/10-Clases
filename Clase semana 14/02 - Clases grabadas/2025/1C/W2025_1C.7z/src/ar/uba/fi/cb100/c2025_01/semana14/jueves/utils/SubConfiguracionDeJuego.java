package ar.uba.fi.cb100.c2025_01.semana14.jueves.utils;

public class SubConfiguracionDeJuego {

	private int cantidadDeCartas;

	public int getCantidadDeCartas() {
		return cantidadDeCartas;
	}

	public void setCantidadDeCartas(int cantidadDeCartas) {
		this.cantidadDeCartas = cantidadDeCartas;
	}
	
	
}
