package ar.uba.fi.cb100.c2025_01.semana14.miercoles.tp2;

public enum PosicionDeVecino {	
	Derecha, 
	Izquierda,
	Arriba,
	Abajo,
	Atras,
	Adelante,
	ArribaDerecha,
	ArribaDerechaAdelante,
	ArribaDerechaAtras,
	ArribaIzquierda	
}
