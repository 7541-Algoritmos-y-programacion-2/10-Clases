package ar.uba.fi.cb100.c2025_01.estructuras.conjunto;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;

public class Conjunto<T> implements Set<T> {
    private List<T> elementos;

    public Conjunto() {
        elementos = new ListaSimplementeEnlazada<T>();
    }

    @Override
    public int size() {
        return elementos.size();
    }

    @Override
    public boolean isEmpty() {
        return elementos.isEmpty();
    }

    @Override
    public boolean contains(Object o) {
        return elementos.contains(o);
    }

    @Override
    public Iterator<T> iterator() {
        return elementos.iterator();
    }

    @Override
    public Object[] toArray() {
        return elementos.toArray();
    }

    @Override
    public <E> E[] toArray(E[] a) {
        return elementos.toArray(a);
    }

    @Override
    public boolean add(T t) {
        if (!elementos.contains(t)) {
            elementos.add(t);
            return true;
        }
        return false;
    }

    @Override
    public boolean remove(Object o) {
        return elementos.remove(o);
    }

    @Override
    public boolean containsAll(Collection<?> c) {
        return elementos.containsAll(c);
    }

    @Override
    public boolean addAll(Collection<? extends T> c) {
        boolean changed = false;
        for (T item : c) {
            if (add(item)) {
                changed = true;
            }
        }
        return changed;
    }

    @Override
    public boolean retainAll(Collection<?> c) {
        return elementos.retainAll(c);
    }

    @Override
    public boolean removeAll(Collection<?> c) {
        return elementos.removeAll(c);
    }

    @Override
    public void clear() {
        elementos.clear();
    }

    public Conjunto<T> union(Conjunto<T> otro) {
        Conjunto<T> resultado = new Conjunto<>();
        resultado.addAll(this);
        resultado.addAll(otro);
        return resultado;
    }

    public Conjunto<T> interseccion(Conjunto<T> otro) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : this) {
            if (otro.contains(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    public Conjunto<T> diferencia(Conjunto<T> otro) {
        Conjunto<T> resultado = new Conjunto<>();
        for (T elemento : this) {
            if (!otro.contains(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    @Override
    public String toString() {
        return elementos.toString();
    }
}
