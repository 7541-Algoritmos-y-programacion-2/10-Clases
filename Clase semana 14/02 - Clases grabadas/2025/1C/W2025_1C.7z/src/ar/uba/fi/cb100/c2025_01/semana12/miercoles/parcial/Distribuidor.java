package ar.uba.fi.cb100.c2025_01.semana12.miercoles.parcial;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.cola.Cola;
import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;

class Distribuidor {


	/* 
	 * pre:
	 * post: remueve los Productos de la cola ‘productosDisponibles’ y los agrega a alguna Sucursal de
	 *	‘sucursalesExistentes’ que tenga la categoria del Producto.
	 *	Aquellos Productos que no pueden ser agregados a ninguna Sucursal se devuelven a la cola
	 *	‘productosDisponibles’.
	 */
	void distribuirProductosEnSucursales(Cola<Producto> productosDisponibles, List<Sucursal> sucursalesExistentes) {
		//validar
		List<Producto> productosNoAgregados = new ListaSimplementeEnlazada<Producto>();
		while(!productosDisponibles.estaVacia()) {
			Producto productoDisponible = productosDisponibles.desacolar();
			if (!distribuirProductoEnSucursales(productoDisponible, sucursalesExistentes)) {
				productosNoAgregados.add(productoDisponible);
			}
		}
		productosDisponibles.acolarAll(productosNoAgregados);
	}

	void distribuirProductosEnSucursalesConLista(ListaSimplementeEnlazada<Producto> productosDisponibles, List<Sucursal> sucursalesExistentes) {
		//validar
		List<Producto> productosNoAgregados = new ListaSimplementeEnlazada<Producto>();
		productosDisponibles.iniciarCursor();
		while(productosDisponibles.avanzarCursor()) {
			Producto productoDisponible = productosDisponibles.obtenerCursor();
			if (!distribuirProductoEnSucursales(productoDisponible, sucursalesExistentes)) {
				productosNoAgregados.add(productoDisponible);
			}
		}
		productosDisponibles.addAll(productosNoAgregados);
	}

	/**
	 * pre:
	 * pos: dado un producto lo agrega en sucursalesExistentes si cumple con la categoria o devuelve falso sino puede
	 * @param productoDisponible
	 * @param sucursalesExistentes
	 */
	public boolean distribuirProductoEnSucursales(Producto productoDisponible, List<Sucursal> sucursalesExistentes) {
		for(Sucursal sucursal: sucursalesExistentes) {
			if (sucursal.obtenerCategorias().contains( productoDisponible.obtenerCategoria())) {
				sucursal.obtenerProductos().add(productoDisponible);
				return true;
			}
		}
		return false;
	}
}
