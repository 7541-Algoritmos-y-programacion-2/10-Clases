package ar.uba.fi.cb100.c2025_01.semana08.miercoles.ahorcado;

public enum EstadoDeAhorcado {

	Jugando,
	Perdido,
	Ganado
}
