package ar.uba.fi.cb100.c2025_01.semana09.jueves.tarea01;

import java.util.ArrayList;
import java.util.List;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class IngenieroQuimico {

//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
    /** post: busca en 'solucionesDisponibles' las Soluciones que tenga los mismos Compuestos que 'solucionRequerida',  
     *       con cantidades iguales o superiores pero menores (o igual) al doble. 
     */
    public List<Solucion> buscarSolucionesEquivalente(Solucion solucionRequerida, List<Solucion> solucionesDisponibles) {
        ValidacionesUtiles.validarNoNulo(solucionesDisponibles, "Soluciones disponibles");
        ValidacionesUtiles.validarNoNulo(solucionRequerida, "Solucion requerida");
    	List<Solucion> solucionesEquivalentes = new ArrayList<>();
        for(Solucion solucion : solucionesDisponibles){
        	//Version 2
        	if ((solucion.getCantidadCompuestos() == solucionRequerida.getCantidadCompuestos()) &&
        	    this.sonCompuestosEquivalentes(solucion.getCompuestos(), solucionRequerida.getCompuestos())) {
        		solucionesEquivalentes.add(solucion);
        	}
        }
        return solucionesEquivalentes;
    }

    /**
     * Evalua que todo el listado de compuesto compuestos2, tenga un equivalente en compuestos1
     */
    public boolean sonCompuestosEquivalentes(List<Compuesto> compuestos1, List<Compuesto> compuestos2){
        for(Compuesto compuesto2 : compuestos2){
        	if (!sonCompuestosEquivalentes(compuestos1, compuesto2)) {
        		return false;
        	}
        }
        return true;
    }

    public boolean sonCompuestosEquivalentes(List<Compuesto> compuestos1, Compuesto compuesto2) {
        for(Compuesto compuesto1 : compuestos1){
        	if ((compuesto1.equals(compuesto2)) &&
        		(compuesto1.getCantidad() <= compuesto2.getCantidad()) &&
        		(2 * compuesto1.getCantidad() >= compuesto2.getCantidad())) {
        		return true;
        	}
        }
        return false;
    }
}
