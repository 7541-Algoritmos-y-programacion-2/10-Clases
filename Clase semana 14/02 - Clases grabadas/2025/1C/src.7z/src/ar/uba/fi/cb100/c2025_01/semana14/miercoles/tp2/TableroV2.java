package ar.uba.fi.cb100.c2025_01.semana14.miercoles.tp2;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class TableroV2<T> {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private List<List<List<CasilleroV2<T>>>> casilleros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un tablero de ancho "ancho" y alto "alto"
	 * @param ancho: debe ser mayor a 0
	 * @param alto: debe ser mayor a 0 
	 */
	public TableroV2(int ancho, int alto, int profundo, Class<T> clase) {
		try {
			ValidacionesUtiles.validarMayorACero(ancho, "Ancho");
			ValidacionesUtiles.validarMayorACero(alto, "Alto");
			ValidacionesUtiles.validarMayorACero(profundo, "Profundo");
			this.casilleros = new ListaSimplementeEnlazada<List<List<CasilleroV2<T>>>>();
			for(int i = 0; i < ancho; i++) {
				List<List<CasilleroV2<T>>> columna = new ListaSimplementeEnlazada<List<CasilleroV2<T>>>();
				CasilleroV2<T> anteriorEnVertical = null;
				for(int j = 0; j < alto; j++) {
					List<CasilleroV2<T>> fila = new ListaSimplementeEnlazada<CasilleroV2<T>>();
					CasilleroV2<T> anteriorEnHorizontal = null;
					for(int k = 0; k < profundo; k++) {
						CasilleroV2<T> temporalEnHorizontal = new CasilleroV2<T>(clase.getDeclaredConstructor().newInstance());
						fila.add(temporalEnHorizontal );
						if (anteriorEnHorizontal == null) {
							anteriorEnVertical = temporalEnHorizontal;
						}
						anteriorEnHorizontal = temporalEnHorizontal;
						relacionarAnterior(anteriorEnHorizontal, temporalEnHorizontal);
						anteriorEnVertical = anteriorEnVertical.getVecino(PosicionDeVecino.Derecha);
					}
					columna.add(fila);
				}
				this.casilleros.add(columna);
			}
			calcularVecinos();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	/**
	 * Devuelve verdadero si la coordenada esta dentro del tablero
	 */
	public boolean enRango(int i, int j, int k) {
		return ((i > 0) && 
			    (i < getAncho()) &&
			    (j > 0) && 
				(j < getAlto()) &&
				(k > 0) && 
				(k < getProfundo()));
	}
	
	/**
	 * Asigna un vecino a un casillero en una posicion
	 * @param vecino
	 * @param PosicionDeVecino
	 * @param i
	 * @param j
	 * @param k
	 */
	private void asignarVecino(CasilleroV2<T> vecino, PosicionDeVecino PosicionDeVecino, int i, int j, int k) {
		if (enRango(i, j, k)) {
			vecino.setVecino(PosicionDeVecino, getCasillero(i, j, k));
		}
	}
	
	/**
	 * 
	 */
	private void calcularVecinos() {
		for(int i = 0; i < getAncho(); i++) {
			for(int j = 0; j < getAlto(); j++) {
				for(int k = 0; k < getProfundo(); k++) {
					CasilleroV2<T> actual = getCasillero(i, j, k);
					asignarVecino(actual, PosicionDeVecino.Abajo, i, j+1, k);
					asignarVecino(actual, PosicionDeVecino.Arriba, i, j-1, k);
					asignarVecino(actual, PosicionDeVecino.Derecha, i+1, j, k);
					asignarVecino(actual, PosicionDeVecino.Izquierda, i-1, j, k);
				}
			}
		}		
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	private void relacionarAnterior(CasilleroV2<T> anteriorEnHorizontal, CasilleroV2<T> temporalEnHorizontal) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Devuelve el casillero de la posicion x e y
	 * @param x: debe estar en el rango 1 a ancho
	 * @param y: debe estar en el rango de 1 a alto
	 * @return
	 */
	public CasilleroV2<T> getCasillero(int x, int y, int z) {
		ValidacionesUtiles.validarRango(x, 1, this.getAncho(), "Coordenada X");
		ValidacionesUtiles.validarRango(y, 1, this.getAlto(), "Coordenada Y");
		ValidacionesUtiles.validarRango(z, 1, this.getAlto(), "Coordenada Y");
		return this.casilleros.get(x - 1).get(y - 1).get(z-1);
	}
	
	/**
	 * Devuelve el dato de la posicion x e y
	 * @param x: debe estar en el rango 1 a ancho
	 * @param y: debe estar en el rango de 1 a alto
	 * @return
	 */
	public T getDato(int x, int y, int z) {
		return getCasillero(x, y, z).getDato();
	}
	
	/**
	 * Devuelve el ancho de la lista
	 * @return
	 */
	public int getAncho() {
		return this.casilleros.size();
	}
	
	/**
	 * Devuelve el alto de la lista
	 * @return
	 */
	public int getAlto() {
		return this.casilleros.get(0).size();
	}
	
	public int getProfundo() {
		return this.casilleros.get(0).get(0).size();
	}
	
//		NUNCA EN EL TDA, salvo el TDA para imprimir
//		/**
//		 * Imprime el tablero en pantalla
//		 */
//		public void imprimir() {
//			for(int i = 0; i < this.getAncho(); i++) {
//				for(int j = 0; j < this.getAlto(); j++) {
//					System.out.print( this.getDato(i, j) + " ");
//				}
//				System.out.println();
//			}
//		}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

}