package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.parcial_2009.ejercicioBlog;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Articulo {

	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	private String titulo = null;
	private String texto = null;
	private List<String> palabrasClave = null;
	private List<Comentario> comentarios = null;

	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Dado un titulo, texto y lista de palabras clave, se crea un Articulo.
	 * @param titulo: 	Titulo del articulo.
	 * @param texto: 	Texto del articulo.
	 */
	public Articulo(String titulo, String texto, List<String> palabrasClave) {
		//ValidacionesUtiles.validarListaVacia(palabrasClave, "La lista de palabras clave");
		this.setTitulo( titulo );
		this.setTexto(texto);
		this.getPalabrasClave().addAll(palabrasClave);
	}
	
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Dado un comentario, se agrega al articulo.
	 * @param comentario: comentario del articulo. No puede ser vacío y su calificación debe estar entre 1 y 10
	 * @return
	 */
	public void agregarComentario(Comentario comentario) {
		ValidacionesUtiles.validarNoNulo(comentario, "El comentario");
		this.getComentarios().add(comentario);
	}
	
	/**
	 * Devuelve el promedio de calificaciones del articulo.
	 * @return
	 */
	public double obtenerPromedioDeCalificaciones() {
		if(this.getComentarios().isEmpty() ) {
			return 0;
		}		
		double total = 0;		
		for(Comentario comentario : this.getComentarios()) {
			total += comentario.getCalificacion();
		}		
		return total / this.getComentarios().size();		
	}
	
	/**
	 * Devuelve verdadero si la palabra clave es null o si esta en la lista
	 * @param palabraClave
	 * @return
	 */
	public boolean contienePalabraCable(String palabraClave) {
		return ((palabraClave != null) && getPalabrasClave().contains(palabraClave) ||
				 (palabraClave == null));
	}
	
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la lista de palabras clave del articulo.
	 * @return
	 */
	public List<String> getPalabrasClave(){
		if (this.palabrasClave == null) {
			this.palabrasClave = new ListaSimplementeEnlazada<String>();
		}
		return this.palabrasClave;
	}

	/**
	 * Devuelve el titulo
	 * @return
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * Devuelve el texto del articulo
	 * @return
	 */
	public String getTexto() {
		return texto;
	}

	public List<Comentario> getComentarios() {
		if (this.comentarios == null) {
			this.comentarios = new ListaSimplementeEnlazada<Comentario>();
		}
		return comentarios;
	}

	public void setTitulo(String titulo) {
		ValidacionesUtiles.validarNoNulo(titulo, 	"El título");
		this.titulo = titulo;
	}

	public void setTexto(String texto) {
		ValidacionesUtiles.validarNoNulo(texto, 	"El texto");
		this.texto = texto;
	}
}
