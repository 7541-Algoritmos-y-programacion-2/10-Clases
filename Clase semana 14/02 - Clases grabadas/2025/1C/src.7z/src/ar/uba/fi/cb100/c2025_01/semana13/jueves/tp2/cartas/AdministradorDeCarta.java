package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.InvasionGalactica;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.Turno;

public abstract class AdministradorDeCarta {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Carta carta = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	public AdministradorDeCarta(Carta carta) {
		ValidacionesUtiles.validarNoNulo(carta, "Carta");
		this.carta = carta;
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Aplica la funcionalidad de jugar una carga al momento de jugarla por primera vez
	 */
	public abstract void jugarCarta(InvasionGalactica invasionGalactica, Turno turno);
	
	/**
	 * Dada una carta ya jugada, se juega los siguientes turnos de la carta
	 * @param invasionGalactica
	 * @param turno
	 */
	public abstract void avanzarTurno(InvasionGalactica invasionGalactica, Turno turno);
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la carta que se esta jugando
	 * @return
	 */
	public Carta getCarta() {
		return carta;
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
