package ar.uba.fi.cb100.c2025_01.semana13.miercoles.parcial;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Imagen {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private Pixel[][] pixeles = null;
	private Integer cantidadDePixelesPuros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea una imagen del ancho y alto dados
	 * @param ancho: mayor a 0
	 * @param alto: mayor a 0
	 */
	public Imagen(int ancho, int alto) {
		ValidacionesUtiles.validarMayorACero(ancho, "Ancho");
		ValidacionesUtiles.validarMayorACero(alto, "alto");
		this.pixeles = new Pixel[ancho][alto];
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				this.pixeles[i][j] = new Pixel();
			}
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el pixel en la posicion i j
	 * @param i: un valor entre 1 y el ancho
	 * @param j: un valor entre 1 y el alto
	 * @return
	 */
	public Pixel getPixel(int i, int j) {
		ValidacionesUtiles.validarRango(i, 1, this.getAncho(), "i");
		ValidacionesUtiles.validarRango(j, 1, this.getAlto(), "j");
		this.cantidadDePixelesPuros = null;
		return this.pixeles[i-1][j-1];		
	}
	
	/**
	 * Devuelve el pixel con la componente rojo con el valor mas grande de toda la imagen
	 * @return
	 */
	public Pixel getPixelMasRojo() {
		Pixel resultado = null;
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				if ((resultado == null) ||
				   (resultado.getRed() < this.pixeles[i][j].getRed())) {
				 resultado = this.pixeles[i][j];
				}
			}
		}
		return resultado; 
	}
	
	/**
	 * Aplica el filtro de escala de grises a cada pixel de la imagen
	 */
	public void aplicarFiltroDeEscalaDeGrises() {
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				this.pixeles[i][j].aplicarFiltroDeEscalaDeGrises();
			}
		}
	}
	
	/**
	 * Aplica el brillo dado a cada parametro
	 * @param brillo: un valor entre -255 y 255
	 */
	public void aplicarBrillo(int brillo) {
		ValidacionesUtiles.validarRango(brillo, -1 * Pixel.RangoSuperiorDeColor, Pixel.RangoSuperiorDeColor, null);
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				this.pixeles[i][j].aplicarBrillo(brillo);
			}
		}
	}
	
	/**
	 * Invierte la imagen horizontalmente
	 */
	public void invertirHorizontalmente() {
		for(int i = 0; i < this.getAncho() / 2; i++) {
			for(int j = 0; j < this.getAlto(); j++) {
				Pixel temp = this.pixeles[i][j];
				this.pixeles[i][j] = this.pixeles[this.getAncho() - i][j];
				this.pixeles[this.getAncho() - i][j] = temp;
			}
		}
	}
	
	/**
	 * Invierte la imagen verticalmente
	 */
	public void invertirVerticalmente() {
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto() / 2; j++) {
				Pixel temp = this.pixeles[i][j];
				this.pixeles[i][j] = this.pixeles[i][this.getAlto() - j];
				this.pixeles[i][this.getAlto() - j] = temp;
			}
		}
	}
	
	/**
	 * Devuelve la cantidad de pixeles puros
	 * @return
	 */
	public int getCantidadDePixelesPuros() {
		if (this.cantidadDePixelesPuros != null) {
			return this.cantidadDePixelesPuros;
		}
		for(int i = 0; i < this.getAncho(); i++) {
			for(int j = 0; j < this.getAlto() / 2; j++) {
				if (this.pixeles[i][j].esPuro()) {
					this.cantidadDePixelesPuros++;
				}
			}
		}
		return this.cantidadDePixelesPuros;
	}
	
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el alto de la imagen
	 * @return
	 */
	public int getAlto() {
		return this.pixeles[0].length;
	}

	/**
	 * Devuelve el ancho de la imagen
	 * @return
	 */
	public int getAncho() {
		return this.pixeles.length;
	}

//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	
	/**
	 * Cambia el pixel de una posicion
	 * @param i
	 * @param j
	 * @param pixel
	 */
	public void setPixel(int i, int j, Pixel pixel) {
		ValidacionesUtiles.validarRango(i, 1, this.getAncho(), "i");
		ValidacionesUtiles.validarRango(j, 1, this.getAlto(), "j");
		ValidacionesUtiles.validarNoNulo(pixel, "Pixel");
		this.pixeles[i-1][j-1] = pixel;
		this.cantidadDePixelesPuros = null;
	}
	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
