package ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.cartas;

import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.Base;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.InvasionGalactica;
import ar.uba.fi.cb100.c2025_01.semana13.jueves.tp2.Turno;

public class AdministradorDeCartaCampoDeFuerza extends AdministradorDeCarta {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------

	public AdministradorDeCartaCampoDeFuerza(Carta carta) {
		super(carta);
	}

//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	@Override
	public void jugarCarta(InvasionGalactica invasionGalactica, Turno turno) {
		Base base = invasionGalactica.getPartida(turno.getJugador()).getBasePrincipal();
		base.incrementarCampo( getCartaCampoDeFuerza().getValorDelCampoAdicional());
		
		invasionGalactica.getPartida(turno.getJugador()).agregarCarta(getCartaCampoDeFuerza());
	}

	@Override
	public void avanzarTurno(InvasionGalactica invasionGalactica, Turno turno) {
		if (getCartaCampoDeFuerza().getCantidadDeTurnosRestantes() > 0) {
			this.getCartaCampoDeFuerza().avanzarTurno();
			return;
		}
		Base base = invasionGalactica.getBasePrincipal( turno.getJugador());
		base.decrementarCampo( getCartaCampoDeFuerza().getValorDelCampoAdicional() );
		
		invasionGalactica.getPartida(turno.getJugador()).quitarCarta(getCartaCampoDeFuerza());
	}

//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public CartaCampoDeFuerza getCartaCampoDeFuerza() {
		return (CartaCampoDeFuerza) this.getCarta();
	}
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
