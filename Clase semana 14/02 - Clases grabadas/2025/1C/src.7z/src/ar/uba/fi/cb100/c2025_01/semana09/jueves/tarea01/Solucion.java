package ar.uba.fi.cb100.c2025_01.semana09.jueves.tarea01;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class Solucion {
  //INTERFACES ----------------------------------------------------------------------------------------------
  //ENUMERADOS ----------------------------------------------------------------------------------------------
  //CONSTANTES ----------------------------------------------------------------------------------------------
  //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
  //ATRIBUTOS -----------------------------------------------------------------------------------------------
    
    private List<Compuesto> compuestos = null;
    private String codigo = null;
    
  //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
  //CONSTRUCTORES -------------------------------------------------------------------------------------------
    
    public Solucion(String codigo) throws Exception {
        this.setCodigo(codigo);
        this.compuestos = new ListaSimplementeEnlazada<Compuesto>();
    }
    
  //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
  //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
  //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
  //METODOS DE CLASE ----------------------------------------------------------------------------------------
  //METODOS GENERALES ---------------------------------------------------------------------------------------
  //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
    
    /**
     * Agrega el compuesto siempre y cuando no este en la solucion
     * @param compuesto
     */
    public void agregarCompuesto(Compuesto compuesto) {
    	ValidacionesUtiles.validarNoNulo(compuesto, "Compuesto");
    	//Opcion de equal: usa object lo mimos ==, o sea, compara punteros
    	//Opcion sobrecarga de equals = escribo el equals en la clase compuesto
    	if (this.compuestos.contains(compuesto)) {
    		Compuesto compuestoOriginal = this.compuestos.get( this.compuestos.indexOf(compuesto));
    		compuestoOriginal.setCantidad( compuestoOriginal.getCantidad() + compuesto.getCantidad());
        }
        this.compuestos.add(compuesto);
    }

    /**
     * Elimina un compuesto de la lista
     * @param compuesto
     */
    public void borrarCompuesto(Compuesto compuesto) {
    	ValidacionesUtiles.validarNoNulo(compuesto, "Compuesto");
        if (!compuestos.contains(compuesto)){
            throw new RuntimeException("Ese compuesto no se encuentra en la lista");
        }
        this.compuestos.remove(compuesto);
    }
    
  //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
  //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
  //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
  //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    
    /**
     * Devuelve la cantidad de compuestos de la solucion
     * @return
     */
    public int getCantidadCompuestos(){
        return this.compuestos.size();
    }
    
  //GETTERS SIMPLES -----------------------------------------------------------------------------------------
    
    /**
     * Devuelve los compuestos de la solucion
     * @return
     */
    public List<Compuesto> getCompuestos(){
        return this.compuestos;
    }
    
    public String getCodigo() throws Exception{
    	ValidacionesUtiles.validarNoNulo(codigo, "Codigo");
        return this.codigo;
    }
    
  //SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
  //SETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     * Cambia el codigo de la solucion
     * @param codigo
     * @throws Exception
     */
    private void setCodigo(String codigo) throws Exception {
        ValidacionesUtiles.validarNoVacio(codigo, "Codigo");
        this.codigo = codigo;
    }

  }
