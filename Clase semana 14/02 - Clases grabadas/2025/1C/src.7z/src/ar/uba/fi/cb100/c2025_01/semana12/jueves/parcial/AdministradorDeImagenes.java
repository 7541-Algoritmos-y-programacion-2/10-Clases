package ar.uba.fi.cb100.c2025_01.semana12.jueves.parcial;

import java.util.List;

public abstract class AdministradorDeImagenes {

	/**
	 * Dado un listado de imagenes busca la imagen con mas pixeles puros
	 * @param imagenes
	 * @return
	 */
	public abstract Imagen getImagenMasPura(List<Imagen> imagenes);
}
