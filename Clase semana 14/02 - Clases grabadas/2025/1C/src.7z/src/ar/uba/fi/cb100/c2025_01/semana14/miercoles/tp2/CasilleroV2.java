package ar.uba.fi.cb100.c2025_01.semana14.miercoles.tp2;

public class CasilleroV2<T> {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private T dato = null;
	private CasilleroV2<T>[][][] vecinos = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Construye un casillero con el dato dato, puede ser nulo
	 * @param dato
	 */
	public CasilleroV2(T dato) {
		this.dato = dato;
		this.vecinos = new CasilleroV2[3][3][3];
	}

	/**
	 * Construye un casillero vacio
	 */
	public CasilleroV2() {
		this(null);
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el dato guardado en el casillero
	 * @param dato
	 */
	public T getDato() {
		return dato;
	}

	/**
	 * Este casillero esta en la posicion (0, 0, 0). Mis vecinos van desde (-1,-1,-1) a (1,1,1) 
	 * @param posicionDeVecino
	 * @return
	 */
	public CasilleroV2<T> getVecino(PosicionDeVecino posicionDeVecino) {
		switch(posicionDeVecino) {
			case Derecha: return this.vecinos[1][1][2];
			case Abajo:
				break;
			case Arriba:
				break;
			case Izquierda:
				break;
			default:
				break;
		}
		throw new RuntimeException("No se encontro la posicion " + posicionDeVecino);
	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Cambia el dato guardado en el casillero
	 * @param dato
	 */
	public void setDato(T dato) {
		this.dato = dato;
	}

	public void setVecino(PosicionDeVecino posicionDeVecino, CasilleroV2<T> casillero) {
		switch(posicionDeVecino) {
			case Derecha: this.vecinos[1][1][2] = casillero;
			case Abajo:
				break;
			case Arriba:
				break;
			case Izquierda:
				break;
			default:
				break;
		}
	}
}