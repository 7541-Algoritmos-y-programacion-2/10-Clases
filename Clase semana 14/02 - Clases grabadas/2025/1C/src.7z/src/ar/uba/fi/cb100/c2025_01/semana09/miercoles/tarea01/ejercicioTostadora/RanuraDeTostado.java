package ar.uba.fi.cb100.c2025_01.semana09.miercoles.tarea01.ejercicioTostadora;

import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class RanuraDeTostado {

	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private EstadoDeRanuraDeTostado estado = EstadoDeRanuraDeTostado.Libre;
	private int usos = 0;
	private int numero;
	
	//METODOS GENERALES ---------------------------------------------------------------------------------------
		
	public RanuraDeTostado(int numero) {
		ValidacionesUtiles.validarMayorACero(numero, "El numero");
		this.numero = numero;
	}
	
	/**
	 * Se llena la ranura con el estado "Llena".
	 * 
	 */
	public void iniciarTostado() {
		validarRanuraOcupada();
		this.estado = EstadoDeRanuraDeTostado.Ocupada;
	}
	
	/**
	 * Se vacía la ranura con el estado "Vacia".
	 * 
	 */
	public void finalizarTostado() {
		validarRanuraLibre();		
		this.estado = EstadoDeRanuraDeTostado.Libre;
		this.usos++;
	}
	
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Devuelve true si la ranura está vacía.
	 * @return
	 */
	public boolean estaLibre() {
		return this.estado.equals(EstadoDeRanuraDeTostado.Libre);
		
	}
	
	/**
	 * Se valida que la ranura esté vacía, si lo estuviera, devuelve excepción.
	 * 
	 */
	private void validarRanuraLibre() {
		if(estaLibre()) {
			throw new RuntimeException("La ranura está libre!");
		}
		
	}
	
	/**
	 * Se valida que la ranura esté vacía, si lo estuviera, devuelve excepción.
	 * 
	 */
	private void validarRanuraOcupada() {
		if(!estaLibre()) {
			throw new RuntimeException("La ranura ya está llena!");
		}
		
	}
	
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve la cantidad de usos de la ranura.
	 * @return
	 */
	public int getCantidadDeUsos() {
		return this.usos;
		
	}

	public int getNumero() {
		return numero;
	}
	
	

}
