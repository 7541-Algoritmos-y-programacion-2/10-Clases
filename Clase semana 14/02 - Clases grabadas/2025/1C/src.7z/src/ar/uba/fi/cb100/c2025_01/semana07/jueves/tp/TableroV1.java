package ar.uba.fi.cb100.c2025_01.semana07.jueves.tp;

import java.util.List;

import ar.uba.fi.cb100.c2025_01.estructuras.lista.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_01.semana05.jueves.tdaCadena.ValidacionesUtiles;

public class TableroV1<T> {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private List<List<CasilleroV1<T>>> casilleros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Crea un tablero de ancho "ancho" y alto "alto"
	 * @param ancho: debe ser mayor a 0
	 * @param alto: debe ser mayor a 0 
	 */
	public TableroV1(int ancho, int alto, Class<T> clase) {
		try {
			ValidacionesUtiles.validarMayorACero(ancho, "Ancho");
			ValidacionesUtiles.validarMayorACero(alto, "Alto");
			this.casilleros = new ListaSimplementeEnlazada<List<CasilleroV1<T>>>();
			for(int i = 0; i < ancho; i++) {
				List<CasilleroV1<T>> columna = new ListaSimplementeEnlazada<CasilleroV1<T>>();
				for(int j = 0; j < alto; j++) {
					columna.add( new CasilleroV1<T>(clase.getDeclaredConstructor().newInstance()));
				}
				this.casilleros.add(columna);
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el casillero de la posicion x e y
	 * @param x: debe estar en el rango 1 a ancho
	 * @param y: debe estar en el rango de 1 a alto
	 * @return
	 */
	public CasilleroV1<T> getCasillero(int x, int y) {
		ValidacionesUtiles.validarRango(x, 1, this.getAncho(), "Coordenada X");
		ValidacionesUtiles.validarRango(x, 1, this.getAlto(), "Coordenada Y");
		return this.casilleros.get(x - 1).get(y - 1);
	}
	
	/**
	 * Devuelve el dato de la posicion x e y
	 * @param x: debe estar en el rango 1 a ancho
	 * @param y: debe estar en el rango de 1 a alto
	 * @return
	 */
	public T getDato(int x, int y) {
		return getCasillero(x, y).getDato();
	}
	
	/**
	 * Devuelve el ancho de la lista
	 * @return
	 */
	public int getAncho() {
		return this.casilleros.size();
	}
	
	/**
	 * Devuelve el alto de la lista
	 * @return
	 */
	public int getAlto() {
		return this.casilleros.get(0).size();
	}
	
//	NUNCA EN EL TDA, salvo el TDA para imprimir
//	/**
//	 * Imprime el tablero en pantalla
//	 */
//	public void imprimir() {
//		for(int i = 0; i < this.getAncho(); i++) {
//			for(int j = 0; j < this.getAlto(); j++) {
//				System.out.print( this.getDato(i, j) + " ");
//			}
//			System.out.println();
//		}
//	}
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

}