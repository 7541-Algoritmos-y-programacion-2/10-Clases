package ar.uba.fi.cb100.c2025_02.semana05.jueves;

public class PrincipalClase08 {

	public static void tateti() {
		Tablero tablero = new Tablero("A", 3, 3, 1);
		
		for(int i = 1; i <= tablero.getAncho(); i++) {
			for(int j = 1; j <= tablero.getAlto(); j++) {
				tablero.getCasillero(i, j).setValor(" ");
			}
		}
		
		//   x
		//   O x x   
		//     O O
		tablero.getCasillero(1, 1).setValor("X");
		tablero.getCasillero(2, 1).setValor("O");
		tablero.getCasillero(2, 2).setValor("X");
		tablero.getCasillero(2, 3).setValor("X");
		tablero.getCasillero(3, 2).setValor("O");
		tablero.getCasillero(3, 3).setValor("O");
				
		for(int i = 1; i <= tablero.getAncho(); i++) {
			for(int j = 1; j <= tablero.getAlto(); j++) {
				Casillero casillero = tablero.getCasillero(i, j);
				System.out.print(casillero + " ");
			}
			System.out.println();
		}
	}
	
	public static void ajedrez() {
		Tablero tablero = new Tablero("A", 8, 8, 1);
		
		for(int i = 1; i <= tablero.getAncho(); i++) {
			for(int j = 1; j <= tablero.getAlto(); j++) {
				tablero.getCasillero(i, j).setValor(" ");
			}
		}
		
		//   x
		//   O x x   
		//     O O
		tablero.getCasillero(1, 1).setValor("T");
		tablero.getCasillero(2, 1).setValor("P");
		tablero.getCasillero(2, 2).setValor("P");
		tablero.getCasillero(2, 3).setValor("P");
		tablero.getCasillero(8, 8).setValor("T");
		tablero.getCasillero(8, 7).setValor("C");
		tablero.getCasillero(1, 4).setValor("R");
		tablero.getCasillero(8, 4).setValor("R");
				
		for(int i = 1; i <= tablero.getAncho(); i++) {
			for(int j = 1; j <= tablero.getAlto(); j++) {
				Casillero casillero = tablero.getCasillero(i, j);
				System.out.print(casillero + " ");
			}
			System.out.println();
		}
	}
	public static void main(String[] args) {
		ajedrez();
	}
}
