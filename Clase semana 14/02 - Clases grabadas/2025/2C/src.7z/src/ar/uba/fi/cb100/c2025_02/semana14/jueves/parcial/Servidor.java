package ar.uba.fi.cb100.c2025_02.semana14.jueves.parcial;

import java.util.List;

public class Servidor {
    private String ip;
    private List<CorreoElectronico> correos = null;
    public Servidor(String ip) {
        this.ip = ip;
    }
    public String getIp() {
        return ip;
    }
}
