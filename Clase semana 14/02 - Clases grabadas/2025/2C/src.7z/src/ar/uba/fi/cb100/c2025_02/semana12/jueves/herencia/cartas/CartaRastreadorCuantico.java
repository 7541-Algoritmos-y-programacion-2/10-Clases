package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

import java.util.Random;

public class CartaRastreadorCuantico extends Carta {

	private int radioDeVision = 0;
	
	public CartaRastreadorCuantico() {		
		this.radioDeVision = generarRadioDeVision();
	}
	
	private static int generarRadioDeVision() {
		Random random = new Random();
		return 1 + random.nextInt(10);
	}
	
	@Override
	public AdministradorDeCarta getAdministradorDeCarta() {
		return new AdministradorDeCartaDeRastreadorCuantico(this);
	}

	public int getRadioDeVision() {
		return radioDeVision;
	}

	
}
