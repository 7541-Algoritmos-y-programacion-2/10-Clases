package ar.uba.fi.cb100.c2025_02.semana14.jueves.parcial;

public class Aplicacion {

    private String nombre;
    private double consumoEnDisco;
    private double consumoRam;

    public Aplicacion(String nombre, double consumoRam, double consumoEnDisco) {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("LA aplicacion no puede no tener nombre");
        }

        if (consumoEnDisco <= 0 || consumoRam <= 0) {
            throw new IllegalArgumentException("El consumo debe ser positivo");
        }

        this.nombre = nombre;
        this.consumoEnDisco = consumoEnDisco;
        this.consumoRam = consumoRam;
    }

    public String getNombre() {
        return this.nombre;
    }

    public double getConsumoRam() {
        return this.consumoRam;
    }

    public double getConsumoEnDisco() {
        return this.consumoEnDisco;
    }
}
