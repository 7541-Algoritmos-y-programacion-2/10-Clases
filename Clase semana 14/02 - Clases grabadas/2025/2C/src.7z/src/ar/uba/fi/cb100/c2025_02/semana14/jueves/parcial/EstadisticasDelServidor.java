package ar.uba.fi.cb100.c2025_02.semana14.jueves.parcial;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;

public class EstadisticasDelServidor {

    private Servidor servidor;
    private ListaSimplementeEnlazada<String> asuntosEnviados;
    private int contadorSpam;

    public EstadisticasDelServidor(Servidor servidor) {

        this.servidor = servidor;
        this.asuntosEnviados = new ListaSimplementeEnlazada<String>();
        this.contadorSpam = 0;
    }

    public Servidor getServidor(){
        return this.servidor;
    }

    public int getContadorSpam() {
        return this.contadorSpam;
    }

    public boolean procesarAsunto(String asunto) {

        if (this.esAsuntoRepetido(asunto)) {
            this.contadorSpam++;

            return true;
        } else {
            this.asuntosEnviados.add(asunto);

            return false;
        }

    }

    private boolean esAsuntoRepetido(String asunto) {

        this.asuntosEnviados.iniciarCursor();
        while (this.asuntosEnviados.avanzarCursor()) {
            if (this.asuntosEnviados.obtenerCursor().equals(asunto)) {
                return true;
            }
        }

        return false;
    }
}
