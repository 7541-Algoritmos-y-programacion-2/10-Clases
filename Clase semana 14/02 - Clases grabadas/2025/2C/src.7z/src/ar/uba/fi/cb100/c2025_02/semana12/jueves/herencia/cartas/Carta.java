package ar.uba.fi.cb100.c2025_02.semana12.jueves.herencia.cartas;

public abstract class Carta {
//	
//	private boolean activada = false;
//	public Jugador jugadorPropietario = null;
//	public Class<?> tipo;
//	public Coordenada coordenada; // coordenadas de la carta
//	public Coordenada coordenada2;
//
//	// Constructor sin jugador
//	public Carta(TiposDeCartas tipoCarta) {
//		this.tipo = getClaseTipoDeCarta(tipoCarta);
//	}
//
//	// Constructor con jugador
//	public Carta(TiposDeCartas tipoCarta, Jugador jugador) {
//		this(tipoCarta);
//		this.jugadorPropietario = jugador;
//	}
//
//	// Constructor completo con coordenadas
//	public Carta(TiposDeCartas tipoCarta, Jugador jugador, Coordenada coordenada) {
//		this(tipoCarta,jugador);
//		this.coordenada = coordenada;
//	}
//
//	// Constructor completo con segunda coordenada (Para DobleSaltoHiperespacial)
//	public Carta(TiposDeCartas tipoCarta, Jugador jugador, Coordenada coordenada, Coordenada coordenada2) {
//		this(tipoCarta,jugador,coordenada);
//		this.coordenada2 = coordenada2;
//	}
//
//	//SETTERS
//	/**
//	 * Dado un jugador, lo hace propietario de la carta
//	 * @param jugador
//	 */
//	public void setJugador(Jugador jugador) {
//		this.jugadorPropietario = jugador;
//	}
//
//	/**
//	 * Dadas las coordenadas (x,y,z), coloca la carta en esa posición del tablero.
//	 * @param x
//	 * @param y
//	 * @param z
//	 */
//	public void setCoordenadas(Coordenada coordenada) {
//		this.coordenada = coordenada;
//	}
//
//	public void setCoordenadas2(Coordenada coordenada2) {
//		this.coordenada2 = coordenada2;
//	}
//
//	public void setTipoCarta(TiposDeCartas tipo) {this.tipo = getClaseTipoDeCarta(tipo);}
//
//	public void activarCarta() {
//		this.activada = true;
//	}
//
//	/**
//	 * Dado el tablero, aplica la carta en la posicion dada.
//	 * @param tablero
//	 */
//	public void aplicarCarta() {
//		Verificaciones.validarCoordenadas(this.jugadorPropietario.getTablero(), this.coordenada);
//	}
//
//	/**
//	 * Devuelve true si está activa.
//	 * Devuelve false si no se activo.
//	 * @return
//	 */
//
//	//GETTERS
//	public boolean estaActivada () {
//		return this.activada;
//	}
//
//	public Coordenada getCoordenada() {return this.coordenada;}
//
//	public int getXcoordenada2() {return this.coordenada2.getX();}
//
//	public int getYcoordenada2() {return this.coordenada2.getY();}
//
//	public int getZcoordenada2() {return this.coordenada2.getZ();}
//
//	public int getX() {return this.coordenada.getX();}
//
//	public int getY() {return this.coordenada.getY();}
//
//	public int getZ() {return this.coordenada.getZ();}
//
//	private Class<?> getClaseTipoDeCarta(TiposDeCartas tipo){
//		if (tipo == TiposDeCartas.CampoDeFuerza) {
//			return CampoDeFuerza.class;
//		}else if(tipo == TiposDeCartas.BaseAdicional) {
//			return BaseAdicional.class;
//		}else if(tipo == TiposDeCartas.NaveAdicional) {
//			return NaveAdicional.class;
//		}else if(tipo == TiposDeCartas.RastreadorCuantico) {
//			return RastreadorCuantico.class;
//		}else if(tipo == TiposDeCartas.Bomba) {
//			return Bomba.class;
//		}else if(tipo == TiposDeCartas.Senuelo) {
//			return Senuelo.class;
//		}
//		return null;
//	}
//
//	public Jugador getJugadorPropietario() {
//		return this.jugadorPropietario;
//	}

//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private String identificacion;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------
	
	/**
	 * Devuelve el comportamiento de la carta
	 * @return
	 */
	public abstract AdministradorDeCarta getAdministradorDeCarta();

//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	public String getIdentificacion() {
		//Validaciones
		return identificacion;
	}


//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------

	public void setIdentificacion(String identificacion) {
		this.identificacion = identificacion;
	}
	
}
