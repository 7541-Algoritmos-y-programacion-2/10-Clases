package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.tda;

import java.util.Objects;

public class Libro {
    private String titulo; //clave
    private double ancho;  //no clave
    private double peso;

    public Libro(String titulo, double ancho, double peso) {
        if (titulo == null || titulo.isBlank()) {
            throw new IllegalArgumentException("El título no puede ser nulo ni vacío");
        }
        if (ancho <= 0 || peso <= 0) {
            throw new IllegalArgumentException("El ancho y el peso deben ser mayores que cero");
        }
        this.titulo = titulo;
        this.ancho = ancho;
        this.peso = peso;
    }

    public String getTitulo() {
        return titulo;
    }

    public double getAncho() {
        return ancho;
    }

    public double getPeso() {
        return peso;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Libro)) return false;
        Libro other = (Libro) obj;
        return Objects.equals(this.titulo.toLowerCase(), other.titulo.toLowerCase());
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo.toLowerCase());
    }

    @Override
    public String toString() {
        return String.format("Libro[título='%s', ancho=%.2f, peso=%.2f]", titulo, ancho, peso);
    }
}
