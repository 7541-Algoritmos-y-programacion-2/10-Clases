package ar.uba.fi.cb100.c2025_02.semana12.jueves.tarea01;

import java.util.List;
import java.util.ListIterator;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Mensaje {

    //INTERFACES ----------------------------------------------------------------------------------------------
    //ENUMERADOS ----------------------------------------------------------------------------------------------
    //CONSTANTES ----------------------------------------------------------------------------------------------
    //ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
    //ATRIBUTOS -----------------------------------------------------------------------------------------------

    private String usuario = null;
    private String contenidoDelMensaje = null;
    private String tematica;

    //Cada entero de la lista es un voto/calificacion que le puso algún usuario al mensaje (del 1 al 10)
    private List<Integer> listaDeVotos;


    //ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
    //CONSTRUCTORES -------------------------------------------------------------------------------------------

    /**
     * crea un mensaje con el usuario, el texto del mensaje y la tematica donde se coloco el mensaje
     * @param usuario no debe ser null
     * @param texto no debe ser null
     * @param tematica no debe ser null
     */
    public Mensaje(String usuario,String texto,String tematica){
        setUsuario(usuario);
        setContenidoDelMensaje(texto);
        setTematica(tematica);
        listaDeVotos = new ListaSimplementeEnlazada<>();
    }
    //METODOS ABSTRACTOS --------------------------------------------------------------------------------------
    //METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
    //METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
    //METODOS DE CLASE ----------------------------------------------------------------------------------------
    //METODOS GENERALES ---------------------------------------------------------------------------------------
    //METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

    public void agregarVoto(int voto) {
        if (voto < 1 || voto > 10) {
            throw new RuntimeException("El voto debe estar entre 1 y 10");
        }
        listaDeVotos.add(voto);
    }


    //CONSULTA: es mejor usar for each aca?
    /**
     * mediante la lista de votos hace un promedio de votos
     * @return
     */
    public double getPromedioDeVotos(){
        if(this.getCantidadDeVotos() == 0){
            return 0.0;
        }
        int sumaDeVotos = 0;
        ListIterator<Integer> iterador = this.listaDeVotos.listIterator();
        while(iterador.hasNext()){
            Integer voto = iterador.next();
            sumaDeVotos += voto;

        }
        return sumaDeVotos/(double)this.getCantidadDeVotos();
    }


    //METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------
    //GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
    //GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
    //GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
    //GETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     *devuelve el contenido del mensaje
     * @return
     */
    public String getContenidoDelMensaje(){
        return this.contenidoDelMensaje;

    }

    /**
     * devuelve la cantidad de votos/calificaciones obtenidas por el mensaje
     *@return  devuelve la cantidad de votos obtenidos
     */
    public int getCantidadDeVotos(){
        return listaDeVotos.size();
    }

    /**
     * devuelve el usuario
     * @return devuelve el nombre de usuario
     */
    public String getUsuario(){
        return this.usuario;

    }

    /**
     * devuelve la tematica donde se encuentra el mensaje
     * @return
     */
    public String getTematica() {
        return tematica;
    }

    //SETTERS COMPLEJOS----------------------------------------------------------------------------------------
    //SETTERS SIMPLES -----------------------------------------------------------------------------------------

    /**
     * modifica al nombre del usuario
     * @param usuario que no sea null
     */
    private void setUsuario(String usuario){
        ValidacionesUtiles.esDistintoDeNull(usuario,"usuario");
        this.usuario = usuario;
    }

    /**
     * modifica el contenido del mensaje
     * @param texto no debe ser null
     */
    private void setContenidoDelMensaje(String texto){
        ValidacionesUtiles.esDistintoDeNull(texto,"Texto");
        this.contenidoDelMensaje = texto;
    }

    /**
     * modifica la tematica en la cual se encuentra el mensaje
     * @param tematica no debe ser null
     */
    private void setTematica(String tematica){
        ValidacionesUtiles.esDistintoDeNull(tematica,"Tematica");
        this.tematica = tematica;
    }

}
