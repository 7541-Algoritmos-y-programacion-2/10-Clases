package ar.uba.fi.cb100.c2025_02.semana09.jueves.tarea02;

public class PrincipalDeMesa {

	public static void main(String[] args) {
        System.out.println("###  Restaurante 'El Buen Comer' - Simulación de Operaciones ###\n");

        // --- 1. CREACIÓN DEL RESTAURANTE ---
        final int CANTIDAD_MESAS = 4;
        final int MAX_PROPINAS_POR_MESA = 10;
        
        // Se testea el constructor de Restaurante y Mesa implícitamente.
        Restaurante miRestaurante = new Restaurante(CANTIDAD_MESAS, MAX_PROPINAS_POR_MESA);
        
        // Se testea el método toString() y getCantidadDeMesas()
        System.out.println("Bienvenido a " + miRestaurante);
        System.out.println("El restaurante tiene " + miRestaurante.getCantidadDeMesas() + " mesas.\n");

        // --- 2. LLEGAN LOS PRIMEROS CLIENTES ---
        System.out.println("--- INICIO DEL SERVICIO ---");
        
        // Se testea solicitarMesa() y el cambio de estado en Mesa (ocupar())
        int numeroMesaClienteA = miRestaurante.solicitarMesa();
        System.out.println("Cliente A se sienta en la mesa: " + numeroMesaClienteA);
        
        int numeroMesaClienteB = miRestaurante.solicitarMesa();
        System.out.println("Cliente B se sienta en la mesa: " + numeroMesaClienteB);

        // --- 3. LOS CLIENTES TERMINAN Y PAGAN ---
        System.out.println("\n--- CIERRE DE MESAS ---");

        // Se testea cerrarMesa(numero, propina) y recibirPropina() en Mesa
        double propinaClienteA = 350.75;
        miRestaurante.cerrarMesa(numeroMesaClienteA, propinaClienteA);
        System.out.println("La mesa " + numeroMesaClienteA + " ha sido cerrada con una propina de $" + propinaClienteA);

        // Se testea la sobrecarga cerrarMesa(numero) sin propina
        miRestaurante.cerrarMesa(numeroMesaClienteB);
        System.out.println("La mesa " + numeroMesaClienteB + " ha sido cerrada sin propina.");

        // --- 4. CONSULTA DE ESTADÍSTICAS PARCIALES ---
        System.out.println("\n--- ESTADÍSTICAS PARCIALES ---");

        // Se testea totalPropinas()
        System.out.println("Total de propinas acumuladas: $" + miRestaurante.totalPropinas());
        
        // Se testea getMayorPropina() y getNumeroDeMesaConMayorPropina()
        System.out.println("La mayor propina recibida hoy fue de: $" + miRestaurante.getMayorPropina());
        System.out.println("Fue dejada en la mesa número: " + miRestaurante.getNumeroDeMesaConMayorPropina());

        // --- 5. SEGUNDA RONDA DE CLIENTES ---
        System.out.println("\n--- LLEGAN MÁS CLIENTES ---");
        
        // La mesa 1 vuelve a ser ocupada y deja una propina mayor
        int mesaReocupada = miRestaurante.solicitarMesa(); // Debería ser la 1 de nuevo
        double segundaPropinaMesa1 = 500.0;
        System.out.println("Cliente C ocupa la mesa " + mesaReocupada + " (que estaba libre).");
        miRestaurante.cerrarMesa(mesaReocupada, segundaPropinaMesa1);
        System.out.println("La mesa " + mesaReocupada + " se cierra por segunda vez con una propina de $" + segundaPropinaMesa1);
        
        // Ocupamos las otras dos mesas
        int numeroMesaClienteD = miRestaurante.solicitarMesa(); // Debería ser la 2
        miRestaurante.cerrarMesa(numeroMesaClienteD, 120.0);
        System.out.println("Mesa " + numeroMesaClienteD + " fue ocupada y cerrada con propina de $120.0");
        
        // --- 6. ESTADÍSTICAS FINALES DEL DÍA ---
        System.out.println("\n--- ESTADÍSTICAS FINALES ---");
        System.out.println("Total de propinas final: $" + miRestaurante.totalPropinas());
        System.out.println("La mayor propina del día fue: $" + miRestaurante.getMayorPropina()); // Debe ser 500.0
        System.out.println("Fue dejada en la mesa: " + miRestaurante.getNumeroDeMesaConMayorPropina()); // Debe ser la 1
        
        // Testeando los métodos de la clase Mesa directamente a través de getMesas()
        Mesa mesaUno = miRestaurante.getMesas().obtener(1);
        System.out.println("Detalles de la Mesa 1: " + mesaUno);
        System.out.println("  - Propinas recibidas: " + mesaUno.getCantidadDePropinas()); // Debería ser 2
        System.out.println("  - Total de propinas: $" + mesaUno.getTotalDePropinas()); // 350.75 + 500.0 = 850.75
        System.out.println("  - Mayor propina: $" + mesaUno.getMayorPropina()); // Debería ser 500.0
        
        // --- 7. PRUEBA DE CASO LÍMITE: RESTAURANTE LLENO ---
        System.out.println("\n--- PROBANDO RESTAURANTE LLENO ---");
        System.out.println("Ocupando todas las mesas disponibles...");
        miRestaurante.solicitarMesa(); // Mesa 1
        miRestaurante.solicitarMesa(); // Mesa 2
        miRestaurante.solicitarMesa(); // Mesa 3
        miRestaurante.solicitarMesa(); // Mesa 4
        System.out.println("Todas las mesas están ocupadas.");
        
        try {
            // Este llamado debe fallar y lanzar una RuntimeException
            miRestaurante.solicitarMesa();
        } catch (RuntimeException e) {
            System.out.println("ÉXITO: Se intentó solicitar una mesa extra y se recibió el error esperado: '" + e.getMessage() + "'");
        }
        
        // --- 8. PRUEBA DEL MÉTODO EQUALS ---
        System.out.println("\n--- PROBANDO MÉTODO EQUALS ---");
        Restaurante restauranteA = new Restaurante(2, 5);
        Restaurante restauranteB = new Restaurante(2, 5);
        Restaurante restauranteC = new Restaurante(3, 5);
        
        // Se testea equals() en Restaurante y Mesa (implícitamente)
        System.out.println("Restaurante A y B son idénticos al inicio? " + restauranteA.equals(restauranteB)); // true
        System.out.println("Restaurante A y C tienen diferente cantidad de mesas? " + !restauranteA.equals(restauranteC)); // true
        
        // Modificamos el estado de uno de ellos
        restauranteA.solicitarMesa();
        System.out.println("Después de ocupar una mesa en A, A y B siguen siendo iguales? " + restauranteA.equals(restauranteB)); // false
        
        System.out.println("\n### FIN DE LA SIMULACIÓN ###");
    }
}
