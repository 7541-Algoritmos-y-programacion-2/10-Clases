package ar.uba.fi.cb100.c2025_02.semana14.jueves.parcial;

import java.util.List;
import java.util.Queue;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;

public class AnalizadorSpam {

    public Servidor encontrarServidorConMasSpam(Queue<CorreoElectronico> colaCorreos) {

        List<EstadisticasDelServidor> memoria = new ListaSimplementeEnlazada<EstadisticasDelServidor>();

        EstadisticasDelServidor servidorGanador = null;

        while(!colaCorreos.isEmpty()) {
            CorreoElectronico correo = colaCorreos.poll();
            EstadisticasDelServidor estadisticas = this.buscarEnMemoria(memoria, correo.getServidor().getIp());
            if (estadisticas == null) {
                estadisticas = new EstadisticasDelServidor(correo.getServidor());
                memoria.add(estadisticas);
            }
            estadisticas.procesarAsunto( correo.getAsunto()); 

        }
        for(EstadisticasDelServidor estadisticasDelServidor: memoria) {
            if ((servidorGanador == null) ||
                estadisticasDelServidor.getContadorSpam() > servidorGanador.getContadorSpam()) {
            	servidorGanador = estadisticasDelServidor;
            }
        }

        return servidorGanador.getServidor();
    }

    private EstadisticasDelServidor buscarEnMemoria(List<EstadisticasDelServidor> memoria1, String ip) {
    	if (memoria1 instanceof ListaSimplementeEnlazada<EstadisticasDelServidor> memoria) {
	        memoria.iniciarCursor();
	        while (memoria.avanzarCursor()) {
	            EstadisticasDelServidor estadisticas = memoria.obtenerCursor();
	
	            if (estadisticas.getServidor().getIp().equals(ip)) {
	                return estadisticas;
	            }
	
	        }
    	}
        return null;
    }
}
