package ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.lista;

import java.util.List;

import ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.tda.Estante;
import ar.uba.fi.cb100.c2025_02.semana11.jueves.parcial.tda.Libro;

public class Principal {
    public static void pruebaDeTDA() {
        List<Atuendo> stock = List.of(
                new Atuendo("remera", "rojo", 50),
                new Atuendo("pantalon", "rojo", 70),
                new Atuendo("remera", "azul", 60),
                new Atuendo("pantalon", "azul", 90),
                new Atuendo("remera", "verde", 100)
        );

        List<Comprador> compradores = List.of(
                new Comprador("Ana", 150),
                new Comprador("Juan", 100)
        );

        AsistenteDeCompras asistente = new AsistenteDeCompras();
        List<Atuendo> stockRestante = asistente.comprarAtuendos(stock, compradores);

        System.out.println("Stock restante:");
        stockRestante.forEach(System.out::println);
    }
    
    public static void pruebaDeEstante() {
        
        System.out.println("### 🚀 INICIO DE PRUEBAS TDA ESTANTE ###");

        // --- 1. Prueba de Constructor y Estado Inicial ---
        System.out.println("\n--- 1. Creación y Estado Inicial ---");
        Estante estante = new Estante(100.0, 50.0); // 100cm ancho, 50kg max
        System.out.println("Estante creado: " + estante.toString());
        
        // Pruebas de estado inicial
        System.out.println("¿Está vacío? (Esperado: true): " + estante.estaVacio());
        System.out.println("¿En reparación? (Esperado: false): " + estante.estaEnReparacion());
        System.out.println("Cantidad de libros (Esperado: 0): " + estante.getCantidadLibros());
        System.out.println("Ancho libre (Esperado: 100.0): " + estante.getAnchoLibre());
        System.out.println("Peso libre (Esperado: 50.0): " + estante.getPesoLibre());
        System.out.println("Ancho ocupado (Esperado: 0.0): " + estante.getAnchoOcupado());
        System.out.println("Peso ocupado (Esperado: 0.0): " + estante.getPesoOcupado());

        // Pruebas constructor con error
        try {
            new Estante(0, 50);
        } catch (IllegalArgumentException e) {
            System.out.println("OK (Constructor): Capturada excepción por ancho cero.");
        }
        try {
            new Estante(100, -10);
        } catch (IllegalArgumentException e) {
            System.out.println("OK (Constructor): Capturada excepción por peso negativo.");
        }

        // --- 2. Caso de Uso: Llenar el estante (agregarLibro) ---
        System.out.println("\n--- 2. Caso de Uso: Llenar el Estante ---");
        Libro libro1 = new Libro("Cálculo", 10.0, 2.0);
        Libro libro2 = new Libro("Álgebra", 8.0, 1.5);
        Libro libro3 = new Libro("Física 1", 12.0, 3.0);
        
        estante.agregarLibro(libro1);
        System.out.println("Libro 1 agregado: " + estante.toString());
        estante.agregarLibro(libro2);
        System.out.println("Libro 2 agregado: " + estante.toString());
        estante.agregarLibro(libro3);
        System.out.println("Libro 3 agregado: " + estante.toString());

        // --- 3. Pruebas de Getters (Ancho, Peso, Cantidad) ---
        System.out.println("\n--- 3. Pruebas de Getters con Libros ---");
        // Total Ancho: 10 + 8 + 12 = 30.0
        // Total Peso: 2 + 1.5 + 3 = 6.5
        System.out.println("¿Está vacío? (Esperado: false): " + estante.estaVacio());
        System.out.println("Cantidad de libros (Esperado: 3): " + estante.getCantidadLibros());
        System.out.println("Ancho ocupado (Esperado: 30.0): " + estante.getAnchoOcupado());
        System.out.println("Peso ocupado (Esperado: 6.5): " + estante.getPesoOcupado());
        System.out.println("Ancho libre (Esperado: 70.0): " + estante.getAnchoLibre());
        System.out.println("Peso libre (Esperado: 43.5): " + estante.getPesoLibre());

        // --- 4. Pruebas de Búsqueda (existeElLibro, buscarLibro) ---
        System.out.println("\n--- 4. Pruebas de Búsqueda ---");
        System.out.println("¿Existe 'Álgebra'? (Esperado: true): " + estante.existeElLibro(libro1));
        System.out.println("¿Existe 'FÍSICA 1'? (Esperado: true, ignora case): " + estante.existeElLibro(libro2));
        System.out.println("¿Existe 'Química'? (Esperado: false): " + estante.existeElLibro(libro3));
        
        // Buscar
        Libro buscado = estante.buscarLibro(libro1);
        System.out.println("Libro encontrado: " + buscado.getTitulo());
        
        // Buscar con error
        try {
            Libro libroEncontrado = estante.buscarLibro(new Libro("Física 1", 1, 1.0));
            libroEncontrado = estante.buscarLibro(new Libro("Quimica", 1, 1.0));
        } catch (RuntimeException e) {
            System.out.println("OK (Buscar): Capturada excepción por libro no encontrado.");
        }

        // --- 5. Pruebas de Límites (Ancho y Peso) ---
        System.out.println("\n--- 5. Pruebas de Límites (Excepciones) ---");
        // Ancho libre 70.0, Peso libre 43.5
        
        try {
            Libro libroAncho = new Libro("Enciclopedia", 80.0, 5.0); // Más ancho que 70
            estante.agregarLibro(libroAncho);
        } catch (IllegalStateException e) {
            System.out.println("OK (Agregar): Capturada excepción por falta de espacio.");
        }

        try {
            Libro libroPesado = new Libro("Atlas", 10.0, 50.0); // Más pesado que 43.5
            estante.agregarLibro(libroPesado);
        } catch (IllegalStateException e) {
            System.out.println("OK (Agregar): Capturada excepción por exceso de peso.");
        }

        // --- 6. Prueba de quitar() ---
        System.out.println("\n--- 6. Prueba de quitar() ---");
        System.out.println("Estado antes de quitar: " + estante.toString());
        // El método quitar() (según tu código) quita el de la pos 1 ("Cálculo") 
        // y lo reemplaza con null.
        Libro quitado = estante.quitar(libro1); 
        System.out.println("Libro quitado (Esperado: Cálculo): " + quitado.getTitulo());
        System.out.println("Estado después de quitar: " + estante.toString());
        
        // Verificamos los contadores (el Mock de Vector cuenta no-nulos)
        // Ancho: 8 (Algebra) + 12 (Fisica) = 20
        // Peso: 1.5 (Algebra) + 3 (Fisica) = 4.5
        System.out.println("Cantidad de libros (Esperado: 2): " + estante.getCantidadLibros());
        System.out.println("Ancho ocupado (Esperado: 20.0): " + estante.getAnchoOcupado());
        System.out.println("Peso ocupado (Esperado: 4.5): " + estante.getPesoOcupado());

        // Verificamos que "Cálculo" ya no existe (porque tu buscarLibro chequea nulls)
        System.out.println("¿Existe 'Cálculo'? (Esperado: false): " + estante.existeElLibro(libro1));
        
        // Probamos quitar de nuevo. Ahora la pos 1 es 'null'.
        Libro quitado2 = estante.quitar(libro2);
        System.out.println("Libro quitado (Esperado: null): " + (quitado2 == null ? "null" : quitado2.getTitulo()));
        System.out.println("Estado (sin cambios): " + estante.toString());
        System.out.println("Cantidad (Esperado: 2): " + estante.getCantidadLibros());


        // --- 7. Prueba de Reparación (iniciar/finalizar) ---
        System.out.println("\n--- 7. Prueba de Reparación ---");
        
        // Error: No se puede reparar si no está vacío
        try {
            estante.iniciarReparacion();
        } catch (IllegalArgumentException e) { 
            System.out.println("OK (Reparar): Capturada excepción por reparar estante en uso.");
        }
        
        // Para probar el ciclo de reparación, creamos un estante nuevo
        // ya que el método quitar() no nos permite vaciar el estante original.
        System.out.println("... Creando estante nuevo para probar ciclo de reparación ...");
        Estante estanteRep = new Estante(10, 10);
        
        // 1. Iniciar reparación (OK, está vacío)
        estanteRep.iniciarReparacion();
        System.out.println("Estado (Esperado: en reparación): " + estanteRep.toString());
        System.out.println("¿En reparación? (Esperado: true): " + estanteRep.estaEnReparacion());

        // 2. Error: Agregar libro mientras está en reparación
        try {
            estanteRep.agregarLibro(libro1);
        } catch (IllegalStateException e) {
            System.out.println("OK (Reparar): Capturada excepción por agregar en reparación.");
        }
            
        // 3. Error: Iniciar reparación de nuevo
        try {
            estanteRep.iniciarReparacion();
        } catch (IllegalArgumentException e) {
            System.out.println("OK (Reparar): Capturada excepción por reparar estante ya en reparación.");
        }

        // 4. Finalizar reparación
        estanteRep.finalizarReparacion();
        System.out.println("Estado (Esperado: en uso): " + estanteRep.toString());
        System.out.println("¿En reparación? (Esperado: false): " + estanteRep.estaEnReparacion());
            
        // 5. Error: Finalizar reparación de nuevo
        try {
            estanteRep.finalizarReparacion();
        } catch (IllegalArgumentException e) { 
            System.out.println("OK (Reparar): Capturada excepción por finalizar reparación de estante en uso.");
        }

        // 6. Ahora sí se puede agregar
        estanteRep.agregarLibro(libro1);
        System.out.println("Libro agregado post-reparación: " + estanteRep.toString());
        System.out.println("Cantidad de libros (Esperado: 1): " + estanteRep.getCantidadLibros());
            
        Libro libroAEliminar = null;
        for(int i = 1; i <= estante.getCantidadLibros(); i++) {
        	System.out.println(estante.getLibro(i));   
        	if (i == 8) {
        		libroAEliminar = estante.getLibro(i);
        	}
        }
        if (libroAEliminar != null) {
        	estante.quitar(libroAEliminar);
        }
        
        //Forma 1:
        try {
        	Libro libro = estante.buscarLibro("hola mundo");
        } catch (Exception e) {
        	System.out.println("no existe");
		}
        
        //Forma 2:
        if (estante.existeElLibro("hola mundo")) {
        	Libro libro = estante.buscarLibro("hola mundo");
        }
        
        System.out.println("\n### ✅ FIN DE PRUEBAS TDA ESTANTE ###");
    }
}
