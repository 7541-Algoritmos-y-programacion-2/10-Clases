package ar.uba.fi.cb100.c2025_02.semana09.miercoles.tarea03;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Subasta {
	//INTERFACES ----------------------------------------------------------------------------------------------
	//ENUMERADOS ----------------------------------------------------------------------------------------------
	//CONSTANTES ----------------------------------------------------------------------------------------------
	//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
	//ATRIBUTOS -----------------------------------------------------------------------------------------------
	private String descripcionDelArticulo;
	private double precioBase;
	private boolean estadoDeLaOferta;
	private double ofertaActual;
	//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
	//CONSTRUCTORES -------------------------------------------------------------------------------------------
	/**
	 * crea la subasta con la descripcion del articulo y su precio base igual a 0
	 * @param descripcionDelArticulo
	 */
	public Subasta(String descripcionDelArticulo) {
		setDescripcionDelArticulo(descripcionDelArticulo);
		this.precioBase = 0;
		estadoDeLaOferta = true;
	}
	
	/**
	 * crea la subasta con la descripcion del articulo y su precio base pasado por parametro
	 * @param descripcionDelArticulo
	 * @param precioBase
	 */
	public Subasta(String descripcionDelArticulo, double precioBase) {
		setDescripcionDelArticulo(descripcionDelArticulo);
		setPrecioBase(precioBase);
		estadoDeLaOferta = true;
		
	}
	//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
	//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
	//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
	//METODOS DE CLASE ----------------------------------------------------------------------------------------
	/**
	 * crea el toString articulo con su descripcion y su precio base
	 */
	@Override
	public String toString() {
		return "El articulo " + this.descripcionDelArticulo + " tiene un precio base de $" + this.precioBase  + ". Y una oferta actual de $" + this.ofertaActual;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(descripcionDelArticulo, precioBase);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Subasta other = (Subasta) obj;
		return Objects.equals(descripcionDelArticulo, other.descripcionDelArticulo)
				&& Double.doubleToLongBits(precioBase) == Double.doubleToLongBits(other.precioBase);
	}

	//METODOS GENERALES ---------------------------------------------------------------------------------------
	//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
	 * cierra la subasta poniendo la el estado de la oferta en False
	 */
	public void cerrarOferta() {
		this.estadoDeLaOferta = false;
	}
	
	/**
	 * devuelve el estado de la de la oferta
	 * @return
	 */
	public boolean estaAbierta() {
		return this.estadoDeLaOferta;
	}
	
	
	/**
	 * realiza una nueva oferta, si el estado de la oferta es tru y  la nueva oferta es mayor a la oferta base y a la oferta actual,  se modifica la oferta actual, de lo contrario lanza excepcion
	 * @param nuevaOferta
	 */
	public void realizarOferta(double nuevaOferta){
		ValidacionesUtiles.validarVerdadero(this.estaAbierta(), descripcionDelArticulo);
		if(nuevaOferta <= this.getPrecioBase() || nuevaOferta <= this.getOfertaActual()) {
			throw new RuntimeException("No se puede realizar la oferta ya que el monto es menor a la oferta actual");
		}
		setOfertaActual(nuevaOferta);
		
		
	}
	//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
	//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
	//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
	//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
	/**
	 * devuelve el precio base del artriculo
	 * @return
	 */
	public double getPrecioBase() {
		return this.precioBase;
	}
	
	/**
	 * devuelve la descripcion del articulo
	 * @return
	 */
	public String getDescripcionDelArticulo() {
		return this.descripcionDelArticulo;
	}
	
	/**
	 * devuelve la oferta actual de la subasta
	 * @return
	 */
	public double getOfertaActual() {
		return this.ofertaActual;
	}
	
	
	//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	//SETTERS COMPLEJOS----------------------------------------------------------------------------------------
	//SETTERS SIMPLES -----------------------------------------------------------------------------------------
	/**
	 * modifica el precio base del articulo
	 * @param precioBase tiene que ser mayor o igual a 0
	 * @return
	 */
	private void setPrecioBase(double precioBase){
		ValidacionesUtiles.validarMayorOIgualACero(precioBase, "precio base");
		this.precioBase = precioBase;
		
	}
	
	/**
	 * modifica la descripcion del articulo
	 * @param descripcionDelArticulo tiene que tener solo caracteres alfabeticos y entre 1 y 100 caracteres
	 */
	private void setDescripcionDelArticulo(String descripcionDelArticulo) {
		ValidacionesUtiles.validarCaracteresAlfabeticos(descripcionDelArticulo, "descripcion del articulo");
		ValidacionesUtiles.validarLongitudDeTexto(descripcionDelArticulo, 1, 100, "descripcion del articulo");
		this.descripcionDelArticulo = descripcionDelArticulo;
	}
	
	/**
	 * modifica la oferta actual con su nueva oferta
	 * @param nuevaOferta tiene que ser mayor a 0
	 */
	private void setOfertaActual(double nuevaOferta){
		ValidacionesUtiles.validarMayorACero(nuevaOferta, "nueva oferta");
		this.ofertaActual = nuevaOferta;
		
	}
	
	

}
