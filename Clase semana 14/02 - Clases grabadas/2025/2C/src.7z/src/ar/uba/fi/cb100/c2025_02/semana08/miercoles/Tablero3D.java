package ar.uba.fi.cb100.c2025_02.semana08.miercoles;

import java.util.List;
import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.estructuras.listas.ListaSimplementeEnlazada;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;


/**
 * Tablero o Tablero3D
 */
public class Tablero3D<T> {
//INTERFACES ----------------------------------------------------------------------------------------------
//ENUMERADOS ----------------------------------------------------------------------------------------------
//CONSTANTES ----------------------------------------------------------------------------------------------
//ATRIBUTOS DE CLASE --------------------------------------------------------------------------------------
//ATRIBUTOS -----------------------------------------------------------------------------------------------
	
	private List<List<List<Casillero3D<T>>>> casilleros = null;
	
//ATRIBUTOS TRANSITORIOS ----------------------------------------------------------------------------------
//CONSTRUCTORES -------------------------------------------------------------------------------------------
	
	/**
	 * Generamos un tablero de ancho x alto x profundo
	 * @param ancho: mayor o igual 1
	 * @param alto: mayor o igual 1
	 * @param profundo: mayor o igual 1
	 */
	public Tablero3D(int ancho, int alto, int profundo) {
		this(ancho, alto, profundo, null);
	}
	
	public Tablero3D(int ancho, int alto, int profundo, T valorPorDefecto) {
		ValidacionesUtiles.validarMayorACero(ancho, "ancho");
		ValidacionesUtiles.validarMayorACero(alto, "alto");
		ValidacionesUtiles.validarMayorACero(profundo, "profundo");
		this.casilleros = new ListaSimplementeEnlazada<List<List<Casillero3D<T>>>>();
		for(int i = 0; i < ancho; i++) {
			List<List<Casillero3D<T>>> fila = new ListaSimplementeEnlazada<List<Casillero3D<T>>>();
			for(int j = 0; j < alto; j++) {
				List<Casillero3D<T>> columna = new ListaSimplementeEnlazada<Casillero3D<T>>();
				for(int k = 0; k < profundo; k++) {
					columna.add(new Casillero3D<T>(valorPorDefecto));
				}
				fila.add(columna);
			}
			this.casilleros.add(fila);
		}
	}
	
//METODOS ABSTRACTOS --------------------------------------------------------------------------------------
//METODOS HEREDADOS (CLASE)--------------------------------------------------------------------------------
//METODOS HEREDADOS (INTERFACE)----------------------------------------------------------------------------
//METODOS DE CLASE ----------------------------------------------------------------------------------------
//METODOS GENERALES ---------------------------------------------------------------------------------------
	
	@Override
	public String toString() {
		return "Tablero de " + this.getAncho() + " x " + this.getAlto() + " x " + this.getProfundo();
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(casilleros);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tablero3D<T> other = (Tablero3D<T>) obj;
		return Objects.equals(casilleros, other.casilleros);
	}
	
//METODOS DE COMPORTAMIENTO -------------------------------------------------------------------------------

	/**
	 * Devuelve un casillero en la posicion (x, y, z)
	 * @param x: de 1 a ancho
	 * @param y: de 1 a alto
	 * @param z: de 1 a alto
	 * @return
	 */
	public Casillero3D<T> getCasillero(int x, int y, int z) {
		ValidacionesUtiles.validarMayorACero(x, "X");
		ValidacionesUtiles.validarMayorACero(y, "Y");
		ValidacionesUtiles.validarMayorACero(z, "Z");
		return this.casilleros.get(x-1).get(y-1).get(z-1);
	}
	
//METODOS DE CONSULTA DE ESTADO ---------------------------------------------------------------------------	
//GETTERS REDEFINIDOS -------------------------------------------------------------------------------------
//GETTERS INICIALIZADOS -----------------------------------------------------------------------------------
//GETTERS COMPLEJOS ---------------------------------------------------------------------------------------
//GETTERS SIMPLES -----------------------------------------------------------------------------------------
	
	/**
	 * Devuelve el ancho del tablero
	 * @return
	 */
	public int getAncho() {
		return this.casilleros.size();
	}
	
	/**
	 * Devuelve el alto del tablero
	 * @return
	 */
	public int getAlto() {
		return this.casilleros.get(0).size();
	}

	/**
	 * Devuelve lo profundo del tablero
	 * @return
	 */
	public int getProfundo() {
		return this.casilleros.get(0).get(0).size();
	}
	
	public int getCantidadDeCasilleros() {
		return getAncho() * getAlto() * getProfundo();
	}
	
	public int getCantidadDeCasillerosLibres() {
		int cantidadDeCasillerosLibres = 0;
		for(int i = 1; i <= getAncho(); i++) {
			for(int j = 1; j <= getAlto(); j++) {
				for(int k = 1; k <= getProfundo(); k++) {
					if (getCasillero(i, j, k).estaLibre()) {
						cantidadDeCasillerosLibres++;
					}
				}
			}
		}
		return cantidadDeCasillerosLibres;
	}
	
	/**
	 * Manejo de vecinos: tarea
	 * Manejo de coordenadas: tarea
	 * 
	 * Diseñar el T del tablero
	 * Diseñar el TDA que contiene el tablero
	 */
	
//SETTERS COMPLEJOS----------------------------------------------------------------------------------------	
//SETTERS SIMPLES -----------------------------------------------------------------------------------------
}
