package ar.uba.fi.cb100.c2025_02.semana14.miercoles.parcial.tda01;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.estructuras.vector.Vector;
import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Servidor {
    private final float capacidadRam;
    private final float capacidadDisco;
    private Vector<Aplicacion> aplicacionesAlmacenadas;
    private Vector<Aplicacion> aplicacionesEjecutandose;

    /**
     * Constructor (Operación CrearServidor)
     * capacidadRam: capacidad de ram, cantidad de ram maxima a utilizar
     * capacidadDisco: cantidad de disco, cantidad maxima de disco a utilizar
     * 
     * Arranca con un vector de 10 aplicaciones y luego se autoincrementa
     */
    public Servidor(float capacidadRam, float capacidadDisco) {
    	ValidacionesUtiles.validarMayorACero(capacidadRam, "Ram");
    	ValidacionesUtiles.validarMayorACero(capacidadDisco, "Disco");
        this.capacidadRam = capacidadRam;
        this.capacidadDisco = capacidadDisco;
        this.aplicacionesAlmacenadas = new Vector<Aplicacion>(10, null);
        this.aplicacionesEjecutandose = new Vector<Aplicacion>(10, null);
    }

    /**
     * Calcula el consumo de Disco de TODAS las apps ALMACENADAS.
     */
    public float calcularConsumoDeDiscoAlmacenadoUtilizado() {
        float discoTotal = 0.0f;
        for (Aplicacion app : aplicacionesAlmacenadas) {
        	if (app != null) {
        		discoTotal += app.getDiscoConsumo();
        	}
        }
        return discoTotal;
    }
    
    
    @Override
	public int hashCode() {
		return Objects.hash(capacidadDisco, capacidadRam);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Servidor other = (Servidor) obj;
		return Float.floatToIntBits(capacidadDisco) == Float.floatToIntBits(other.capacidadDisco)
				&& Float.floatToIntBits(capacidadRam) == Float.floatToIntBits(other.capacidadRam);
	}

	/**
     * Devuelve la cantidad de ram utilizada
     * @return
     */
    public float calcularConsumoDeRamUtilizado() {
        float discoTotal = 0.0f;
        for (Aplicacion app : aplicacionesAlmacenadas) {
        	if (app != null) {
        		discoTotal += app.getDiscoConsumo();
        	}
        }
        return discoTotal;
    }

    // --- Operaciones Públicas Requeridas ---

    /**
     * 1. Permitir al servidor guardar una aplicación.
     * Sino hay espacio en disco, da excepcion
     */
    public void guardarAplicacion(Aplicacion app) {
        float discoOcupadoActual = calcularConsumoDeDiscoAlmacenadoUtilizado();
        
        if (discoOcupadoActual + app.getDiscoConsumo() <= capacidadDisco) {
            // Se puede guardar: se añade al vector de aplicacionesAlmacenadas
            aplicacionesAlmacenadas.agregar(app);
            return;
        }
        throw new RuntimeException("No hay espacio");
    }
    
    /**
     * Elimina una aplicacion del disco si no esta instalada
     * @param app
     */
    public void removerAplicacion(Aplicacion app) {
        ValidacionesUtiles.esDistintoDeNull(app, "App");
        if (!this.aplicacionesAlmacenadas.contains(app)) {
        	throw new RuntimeException("La aplicacion no esta guardada");
        }
        if (this.aplicacionesEjecutandose.contains(app)) {
        	throw new RuntimeException("La aplicacion se esta ejecutando");
        }
        this.aplicacionesAlmacenadas.remove(app);
    }

    /**
     * Detiene una aplicacion
     * @param app
     */
    public void detenerAplicacion(Aplicacion app) {
        ValidacionesUtiles.esDistintoDeNull(app, "App");
        if (!this.aplicacionesEjecutandose.contains(app)) {
        	throw new RuntimeException("La aplicacion no se esta ejecutando");
        }
        this.aplicacionesAlmacenadas.remove(app);
    }
    
    /**
     * 2. Permitir ejecutar una aplicación.
     */
    public void ejecutarAplicacion(String nombreApp) {
    	ValidacionesUtiles.esDistintoDeNull(nombreApp, "App");
        Aplicacion appAEjecutar = null;
        
        // A. Buscar si la aplicación está ALMACENADA
        for (Aplicacion app : aplicacionesAlmacenadas) {
        	if ((app != null) &&
        		(app.getNombre().equals(nombreApp))) {
                appAEjecutar = app;
                break;
            }
        }

        if (appAEjecutar == null) {
            throw new RuntimeException("No se encontro la App " + nombreApp);
        }
        
        // B. Verificar Recursos
        float ramOcupadaActual = calcularConsumoDeRamUtilizado();

        float ramNecesaria = appAEjecutar.getRamConsumo();

        if (ramOcupadaActual + ramNecesaria <= capacidadRam) {
            // Si hay recursos, se añade al vector de ejecución
            aplicacionesEjecutandose.agregar(appAEjecutar);
            return;
        }
        throw new RuntimeException("No hay ram disponible " + ramOcupadaActual);
    }

    /**
     * 4. Devolver la cantidad de aplicaciones en ejecución.
     */
    public int obtenerAppsEnEjecucion() {
        return aplicacionesEjecutandose.getLongitud();
    }

	public float getCapacidadRam() {
		return capacidadRam;
	}

	public float getCapacidadDisco() {
		return capacidadDisco;
	}
}
