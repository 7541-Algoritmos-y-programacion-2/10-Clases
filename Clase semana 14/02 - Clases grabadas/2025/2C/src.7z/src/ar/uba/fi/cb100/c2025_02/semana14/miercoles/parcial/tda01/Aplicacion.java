package ar.uba.fi.cb100.c2025_02.semana14.miercoles.parcial.tda01;

import java.util.Objects;

import ar.uba.fi.cb100.c2025_02.material.utiles.ValidacionesUtiles;

public class Aplicacion {
    private String nombre;
    private float ramConsumo;     // Consumo de RAM en GB
    private float discoConsumo;   // Consumo de Disco en GB

    /**
     * Constructor (Operación CrearAplicacion)
     */
    public Aplicacion(String nombre, float ramConsumo, float discoConsumo) {
    	ValidacionesUtiles.esDistintoDeNull(nombre, "Nombre");
    	ValidacionesUtiles.validarMayorACero(ramConsumo, "Ram");
    	ValidacionesUtiles.validarMayorACero(discoConsumo, "Disco");
        this.nombre = nombre;
        this.ramConsumo = ramConsumo;
        this.discoConsumo = discoConsumo;
    }

    // --- Operaciones de Consulta (Getters) ---
    
    public String getNombre() {
        return nombre;
    }

    public float getRamConsumo() {
        return ramConsumo;
    }

    public float getDiscoConsumo() {
        return discoConsumo;
    }

	@Override
	public int hashCode() {
		return Objects.hash(nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aplicacion other = (Aplicacion) obj;
		return Objects.equals(nombre, other.nombre);
	}
    
    
}
