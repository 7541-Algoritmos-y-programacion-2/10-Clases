package ar.uba.fi.cb100.c2025_02.semana01.jueves;

public class PersonaConSalario {

	private String nombre = null;
	private double salario;
	private int edad = 0;
	private double altura = 0;
		
	public PersonaConSalario() {
		this.salario = 0;
	}
	
	public PersonaConSalario(String nombre, int edad) {  //PersonaConSalario(double)
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public PersonaConSalario(double salario) {  //PersonaConSalario(double)
		this.setSalario( salario );
	}
	
	public PersonaConSalario(double altura, double salario) {  //PersonaConSalario(double, double)
		this.altura = altura;
		this.salario = salario;
	}
		
	
	public void cumplirAnios() {
		this.edad++;
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public double getSalario() {
		return this.salario;
	}
		
	public int getEdad() {
		return this.edad;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setSalario(double salario) {
		if (salario < 0) {
			throw new RuntimeException("El salario debe ser mayor a 0");
		}
		this.salario = salario;
	}
	
	
}
