package ar.uba.fi.cb100.c2025_02.semana14.miercoles.parcial.punteros;

public class Punteros_13_11 {

    public static void ejercicio(int ultimoDigitoDelPadron) {
        int X, Y, Z = ultimoDigitoDelPadron ;
        char W;
        int T;
        int[] A = new int[4];
        int[] B = A;

        T = 77;
        W = 'C';
        X = T;
        A[0] = X;
        B[1] = A[0] / 2;

        System.out.println(X + "-" + W + "-" + B[0] + "-" + A[1]);

        W = (char)(T + 1);
        B[2] = A[0] * 2;

        System.out.println(W + "-" + T + "-" + B[1] + "-" + A[2]);

        while (A[0] > 30) {
            T -= 2;
            X -= 3;
            Y = X + Z;
            System.out.println(Y + "-" + T + "-" + B[1] + "-" + Z);
            Z = Y;
            A[0] -= 10;
        }

        // ¿Qué hace el garbage collector aquí? ¿Sobre que variable?
    }
    
    public static void main(String[] args) throws InterruptedException {
		for(int i = 0; i <= 9; i++) {
			System.err.println("----------------Padron " + i + "-------------");
			ejercicio(i);
			System.err.println("--------------------------------------");
			Thread.sleep(1000);
		}
	}
}

