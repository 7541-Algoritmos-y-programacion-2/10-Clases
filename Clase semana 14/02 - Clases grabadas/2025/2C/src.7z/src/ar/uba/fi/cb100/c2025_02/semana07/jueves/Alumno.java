package ar.uba.fi.cb100.c2025_02.semana07.jueves;

import java.util.Objects;

public class Alumno {
    private String nombre;
    private int padron;
    
    public Alumno(Integer padron) {
    	this.padron = padron;
	}

	//Devuelve el nombre del alumno
	public String getNombre() { return this.nombre;}
	
	//Devuelve el padron del alumno
    public int getPadron() { return this.padron;}

	@Override
	public int hashCode() {
		return Objects.hash(padron);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumno other = (Alumno) obj;
		return padron == other.padron;
	}
    
    
}
