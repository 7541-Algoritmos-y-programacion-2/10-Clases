package test.ar.uba.fi.cb100.c2025_02.estructuras.conjuntos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.material.estructuras.conjuntos.Conjunto;

class ConjuntoArrayListTest {

    private Set<String> conjunto;

    @BeforeEach
    void setUp() {
        conjunto = new Conjunto<>();
    }

    @Test
    void testAdd() {
        assertTrue(conjunto.add("A"));
        assertTrue(conjunto.contains("A"));
        assertFalse(conjunto.add("A")); // no permite duplicados
    }

    @Test
    void testRemove() {
        conjunto.add("B");
        assertTrue(conjunto.remove("B"));
        assertFalse(conjunto.contains("B"));
        assertFalse(conjunto.remove("B")); // ya no existe
    }

    @Test
    void testContains() {
        conjunto.add("C");
        assertTrue(conjunto.contains("C"));
        assertFalse(conjunto.contains("D"));
    }

    @Test
    void testSizeAndIsEmpty() {
        assertTrue(conjunto.isEmpty());
        conjunto.add("X");
        conjunto.add("Y");
        assertEquals(2, conjunto.size());
        assertFalse(conjunto.isEmpty());
    }

    @Test
    void testClear() {
        conjunto.add("P");
        conjunto.add("Q");
        conjunto.clear();
        assertTrue(conjunto.isEmpty());
        assertEquals(0, conjunto.size());
    }

    @Test
    void testAddAll() {
        Set<String> otros = new HashSet<>(Arrays.asList("A", "B", "C"));
        assertTrue(conjunto.addAll(otros));
        assertEquals(3, conjunto.size());
        assertFalse(conjunto.addAll(otros)); // ya están todos
    }

    @Test
    void testRemoveAll() {
        conjunto.addAll(Arrays.asList("A", "B", "C"));
        Set<String> eliminar = new HashSet<>(Arrays.asList("B", "C", "D"));
        assertTrue(conjunto.removeAll(eliminar));
        assertEquals(1, conjunto.size());
        assertTrue(conjunto.contains("A"));
        assertFalse(conjunto.contains("B"));
        assertFalse(conjunto.contains("C"));
    }

    @Test
    void testRetainAll() {
        conjunto.addAll(Arrays.asList("A", "B", "C"));
        Set<String> otros = new HashSet<>(Arrays.asList("B", "C", "D"));
        assertTrue(conjunto.retainAll(otros));
        assertEquals(2, conjunto.size());
        assertFalse(conjunto.contains("A"));
        assertTrue(conjunto.contains("B"));
        assertTrue(conjunto.contains("C"));
    }

    @Test
    void testToArray() {
        conjunto.addAll(Arrays.asList("A", "B", "C"));
        Object[] array = conjunto.toArray();
        assertEquals(3, array.length);
    }

    @Test
    void testIterator() {
        conjunto.addAll(Arrays.asList("X", "Y", "Z"));
        int count = 0;
        for (String s : conjunto) {
            assertTrue(conjunto.contains(s));
            count++;
        }
        assertEquals(conjunto.size(), count);
    }
}
