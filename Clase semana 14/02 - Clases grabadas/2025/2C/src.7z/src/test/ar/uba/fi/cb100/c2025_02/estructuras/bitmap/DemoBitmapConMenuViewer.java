package test.ar.uba.fi.cb100.c2025_02.estructuras.bitmap;

import java.awt.Color;
import java.awt.Font;
import java.util.List;

import javax.swing.JOptionPane;

import ar.uba.fi.cb100.c2025_02.material.bitmap.Bitmap;
import ar.uba.fi.cb100.c2025_02.material.bitmap.BitmapViewerConMenu;
import ar.uba.fi.cb100.c2025_02.material.utiles.SistemaUtiles;

public class DemoBitmapConMenuViewer {
	    
    public static void main(String[] args) {
        Bitmap bmp1 = new Bitmap(200, 200);
        Bitmap bmp2 = new Bitmap(400, 400);

        bmp1.drawCircle(100, 100, 50, Color.RED);
        bmp2.drawCube(100, 100, 0, 0, Color.BLUE);
        
        List<BitmapViewerConMenu.MenuAction> menu = List.of(
            new BitmapViewerConMenu.MenuAction("Imprimir mensaje", 
                () -> System.out.println("¡Hola! Se tocó el botón 1.")
            ),
            new BitmapViewerConMenu.MenuAction("Mostrar alerta", 
                () -> JOptionPane.showMessageDialog(null, "Botón 2 presionado")
            ),
            new BitmapViewerConMenu.MenuAction("Salir", 
                () -> System.exit(0)
            )
        );

        BitmapViewerConMenu.showBitmapsWithMenu(menu, bmp1, bmp2);
        
        // Actualización en tiempo real del bitmap y se dibuja automaticamente
        for (int i = 0; i < 200; i++) {
        	bmp1.drawText(i + "s", 50, 30, new Font("Arial", Font.BOLD, 28), Color.WHITE, Color.BLACK);
        	SistemaUtiles.esperar(200);
            bmp1.drawPixel(i, i, Color.GREEN);
            
        }
    }
    
}
