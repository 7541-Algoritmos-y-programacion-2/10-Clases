package test.ar.uba.fi.cb100.c2025_02.semana05.jueves;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import ar.uba.fi.cb100.c2025_02.semana05.jueves.Casillero;
import ar.uba.fi.cb100.c2025_02.semana05.jueves.Tablero;

public class TableroTest {

    // ----------------------------------------------------------------------------------
    // 1. TESTS DE CREACIÓN E INICIALIZACIÓN
    // ----------------------------------------------------------------------------------

    @Test
    void testCrearTableroConDimensionesValidas() {
        // Caso de uso: Crear un tablero de 3x3.
        // Se espera que el tablero se cree correctamente con las dimensiones dadas.
        Tablero tablero = new Tablero("2", 3, 3, 1);
        
        assertNotNull(tablero, "El tablero no debería ser nulo.");
        assertEquals(3, tablero.getAncho(), "El ancho del tablero debería ser 3.");
        assertEquals(3, tablero.getAlto(), "El alto del tablero debería ser 3.");
        
        // Verificamos que todos los casilleros internos no sean nulos.
        for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                assertNotNull(tablero.getCasillero(i, j), "El casillero en (" + i + "," + j + ") no debería ser nulo.");
            }
        }
    }

    @Test
    void testCrearTableroConAnchoCeroLanzaExcepcion() {
        // Caso de uso: Intentar crear un tablero con ancho 0.
        // Se espera que lance una IllegalArgumentException.
        Exception exception = assertThrows(RuntimeException.class, () -> {
            new Tablero("2",0, 5, 1);
        });

        String expectedMessage = "El ancho debe ser mayor a 0. Se ingreso 0.0";
        String actualMessage = exception.getMessage();
        
        assertTrue(actualMessage.contains(expectedMessage), "El mensaje de excepción no es el esperado.");
    }

    @Test
    void testCrearTableroConAltoNegativoLanzaExcepcion() {
        // Caso de uso: Intentar crear un tablero con alto negativo.
        // Se espera que lance una IllegalArgumentException.
        assertThrows(RuntimeException.class, () -> {
            new Tablero("2",5, -1, 1);
        }, "Se debería lanzar una excepción por alto negativo.");
    }

    // ----------------------------------------------------------------------------------
    // 2. TESTS DE FUNCIONALIDAD BÁSICA
    // ----------------------------------------------------------------------------------

    @Test
    void testGetCasilleroConCoordenadasValidas() {
        // Caso de uso: Obtener un casillero específico de un tablero 5x5.
        Tablero tablero = new Tablero("2",5, 5, 1);
        Casillero casillero = tablero.getCasillero(2, 4); // Coordenadas (x=2, y=4)
        
        assertNotNull(casillero, "El casillero obtenido no debería ser nulo.");
    }

    @Test
    void testGetCasilleroConCoordenadaXInvalidaLanzaExcepcion() {
        // Caso de uso: Intentar acceder a una coordenada X fuera de los límites.
        Tablero tablero = new Tablero("2",3, 3, 1);
        
        // Prueba con X = 0
        assertThrows(RuntimeException.class, () -> {
            tablero.getCasillero(0, 1);
        }, "Se debería lanzar excepción para coordenada X igual a 0.");
        
        // Prueba con X > ancho (usa ArrayIndexOutOfBoundsException porque la validación es para > 0)
        assertThrows(RuntimeException.class, () -> {
            tablero.getCasillero(4, 1);
        }, "Se debería lanzar excepción para coordenada X fuera de límites superiores.");
    }

    @Test
    void testEqualsYHashCode() {
        // Caso de uso: Comparar dos tableros para verificar si son iguales.
        Tablero tablero1 = new Tablero("2",2, 2, 1);
        Tablero tablero2 = new Tablero("2",2, 2, 1);
        Tablero tablero3 = new Tablero("2",3, 3, 1);
        
        // Dos tableros nuevos con las mismas dimensiones deben ser iguales.
        assertEquals(tablero1, tablero2, "Dos tableros vacíos de las mismas dimensiones deben ser iguales.");
        assertEquals(tablero1.hashCode(), tablero2.hashCode(), "Los hashCodes de dos tableros iguales deben ser idénticos.");
        
        // Un tablero de diferentes dimensiones no debe ser igual.
        assertNotEquals(tablero1, tablero3, "Tableros de diferentes dimensiones no deben ser iguales.");
        
        // Modificamos un casillero y ya no deben ser iguales.
        tablero1.getCasillero(1, 1).setValor("X");
        assertNotEquals(tablero1, tablero2, "Tableros con contenido diferente no deben ser iguales.");
        assertNotEquals(tablero1.hashCode(), tablero2.hashCode(), "Los hashCodes de tableros diferentes no deben ser idénticos.");
    }

    // ----------------------------------------------------------------------------------
    // 3. CASO DE USO: SIMULACIÓN DE UN TA-TE-TI
    // ----------------------------------------------------------------------------------
    
    @Test
    void testCargaDeUnTaTeTi() {
        // Caso de uso: Simular una partida de Ta-te-ti y verificar el estado final del tablero.
        Tablero tableroTaTeTi = new Tablero(3, 3);

        // Simulación de jugadas
        tableroTaTeTi.getCasillero(2, 2).setValor("X"); // Jugador 1 en el centro
        tableroTaTeTi.getCasillero(1, 1).setValor("O"); // Jugador 2 en esquina sup-izq
        tableroTaTeTi.getCasillero(1, 2).setValor("X"); // Jugador 1
        tableroTaTeTi.getCasillero(3, 3).setValor("O"); // Jugador 2
        tableroTaTeTi.getCasillero(3, 2).setValor("X"); // Jugador 1 gana

        // Verificamos algunas posiciones clave
        assertEquals("X", tableroTaTeTi.getCasillero(2, 2).getValor(), "El centro debería tener una 'X'.");
        assertEquals("O", tableroTaTeTi.getCasillero(3, 3).getValor(), "La esquina inf-der debería tener una 'O'.");
        assertNull(tableroTaTeTi.getCasillero(1, 3).getValor(), "El casillero (1,3) debería estar vacío.");
        
        // Creamos un tablero de referencia con el estado final esperado
        Tablero tableroEsperado = new Tablero(3, 3);
        tableroEsperado.getCasillero(2, 2).setValor("X");
        tableroEsperado.getCasillero(1, 1).setValor("O");
        tableroEsperado.getCasillero(1, 2).setValor("X");
        tableroEsperado.getCasillero(3, 3).setValor("O");
        tableroEsperado.getCasillero(3, 2).setValor("X");
        
        // Comparamos el tablero del juego con el tablero esperado usando el método equals.
        assertEquals(tableroEsperado, tableroTaTeTi, "El tablero del juego no coincide con el estado final esperado.");
    }
}