package ar.uba.fi.cb100.c2025_01.semana04.jueves;

public class Practica_clase_08 {

	public static void main(String[] args) {
//		Padre padre = null;
//		
//		Teclado.inicializar();
//		if ( Teclado.leerEntero() > 10) {
//			padre = new Padre();
//		} else {
//			padre = new Hijo();
//		}
//		
//		System.out.println( padre.sumar(10) );
//		Teclado.finalizar();
		
		Alimento alimento = new Alimento("Limon");
		alimento.setCaloriasPor100Gramos(25);

		System.out.println(alimento.toString());
		
	}
}
